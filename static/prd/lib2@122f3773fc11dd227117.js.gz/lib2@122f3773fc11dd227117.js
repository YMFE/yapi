webpackJsonp([2,3],{

/***/ 0:
/***/ function(module, exports, __webpack_require__) {

	__webpack_require__(904);
	__webpack_require__(901);
	module.exports = __webpack_require__(911);


/***/ },

/***/ 901:
/***/ function(module, exports, __webpack_require__) {

	(function webpackUniversalModuleDefinition(root, factory) {
		if(true)
			module.exports = factory();
		else if(typeof define === 'function' && define.amd)
			define([], factory);
		else if(typeof exports === 'object')
			exports["Mock"] = factory();
		else
			root["Mock"] = factory();
	})(this, function() {
	return /******/ (function(modules) { // webpackBootstrap
	/******/ 	// The module cache
	/******/ 	var installedModules = {};

	/******/ 	// The require function
	/******/ 	function __webpack_require__(moduleId) {

	/******/ 		// Check if module is in cache
	/******/ 		if(installedModules[moduleId])
	/******/ 			return installedModules[moduleId].exports;

	/******/ 		// Create a new module (and put it into the cache)
	/******/ 		var module = installedModules[moduleId] = {
	/******/ 			exports: {},
	/******/ 			id: moduleId,
	/******/ 			loaded: false
	/******/ 		};

	/******/ 		// Execute the module function
	/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

	/******/ 		// Flag the module as loaded
	/******/ 		module.loaded = true;

	/******/ 		// Return the exports of the module
	/******/ 		return module.exports;
	/******/ 	}


	/******/ 	// expose the modules object (__webpack_modules__)
	/******/ 	__webpack_require__.m = modules;

	/******/ 	// expose the module cache
	/******/ 	__webpack_require__.c = installedModules;

	/******/ 	// __webpack_public_path__
	/******/ 	__webpack_require__.p = "";

	/******/ 	// Load entry module and return exports
	/******/ 	return __webpack_require__(0);
	/******/ })
	/************************************************************************/
	/******/ ([
	/* 0 */
	/***/ function(module, exports, __webpack_require__) {

		/* global require, module, window */
		var Handler = __webpack_require__(1)
		var Util = __webpack_require__(3)
		var Random = __webpack_require__(5)
		var RE = __webpack_require__(20)
		var toJSONSchema = __webpack_require__(23)
		var valid = __webpack_require__(25)

		var XHR
		if (typeof window !== 'undefined') XHR = __webpack_require__(27)

		/*!
		    Mock - 模拟请求 & 模拟数据
		    https://github.com/nuysoft/Mock
		    墨智 mozhi.gyy@taobao.com nuysoft@gmail.com
		*/
		var Mock = {
		    Handler: Handler,
		    Random: Random,
		    Util: Util,
		    XHR: XHR,
		    RE: RE,
		    toJSONSchema: toJSONSchema,
		    valid: valid,
		    heredoc: Util.heredoc,
		    setup: function(settings) {
		        return XHR.setup(settings)
		    },
		    _mocked: {}
		}

		Mock.version = '1.0.1-beta3'

		// 避免循环依赖
		if (XHR) XHR.Mock = Mock

		/*
		    * Mock.mock( template )
		    * Mock.mock( function() )
		    * Mock.mock( rurl, template )
		    * Mock.mock( rurl, function(options) )
		    * Mock.mock( rurl, rtype, template )
		    * Mock.mock( rurl, rtype, function(options) )

		    根据数据模板生成模拟数据。
		*/
		Mock.mock = function(rurl, rtype, template) {
		    // Mock.mock(template)
		    if (arguments.length === 1) {
		        return Handler.gen(rurl)
		    }
		    // Mock.mock(rurl, template)
		    if (arguments.length === 2) {
		        template = rtype
		        rtype = undefined
		    }
		    // 拦截 XHR
		    if (XHR) window.XMLHttpRequest = XHR
		    Mock._mocked[rurl + (rtype || '')] = {
		        rurl: rurl,
		        rtype: rtype,
		        template: template
		    }
		    return Mock
		}

		module.exports = Mock

	/***/ },
	/* 1 */
	/***/ function(module, exports, __webpack_require__) {

		/* 
		    ## Handler

		    处理数据模板。
		    
		    * Handler.gen( template, name?, context? )

		        入口方法。

		    * Data Template Definition, DTD
		        
		        处理数据模板定义。

		        * Handler.array( options )
		        * Handler.object( options )
		        * Handler.number( options )
		        * Handler.boolean( options )
		        * Handler.string( options )
		        * Handler.function( options )
		        * Handler.regexp( options )
		        
		        处理路径（相对和绝对）。

		        * Handler.getValueByKeyPath( key, options )

		    * Data Placeholder Definition, DPD

		        处理数据占位符定义

		        * Handler.placeholder( placeholder, context, templateContext, options )

		*/

		var Constant = __webpack_require__(2)
		var Util = __webpack_require__(3)
		var Parser = __webpack_require__(4)
		var Random = __webpack_require__(5)
		var RE = __webpack_require__(20)

		var Handler = {
		    extend: Util.extend
		}

		/*
		    template        属性值（即数据模板）
		    name            属性名
		    context         数据上下文，生成后的数据
		    templateContext 模板上下文，

		    Handle.gen(template, name, options)
		    context
		        currentContext, templateCurrentContext, 
		        path, templatePath
		        root, templateRoot
		*/
		Handler.gen = function(template, name, context) {
		    /* jshint -W041 */
		    name = name == undefined ? '' : (name + '')

		    context = context || {}
		    context = {
		            // 当前访问路径，只有属性名，不包括生成规则
		            path: context.path || [Constant.GUID],
		            templatePath: context.templatePath || [Constant.GUID++],
		            // 最终属性值的上下文
		            currentContext: context.currentContext,
		            // 属性值模板的上下文
		            templateCurrentContext: context.templateCurrentContext || template,
		            // 最终值的根
		            root: context.root || context.currentContext,
		            // 模板的根
		            templateRoot: context.templateRoot || context.templateCurrentContext || template
		        }
		        // console.log('path:', context.path.join('.'), template)

		    var rule = Parser.parse(name)
		    var type = Util.type(template)
		    var data

		    if (Handler[type]) {
		        data = Handler[type]({
		            // 属性值类型
		            type: type,
		            // 属性值模板
		            template: template,
		            // 属性名 + 生成规则
		            name: name,
		            // 属性名
		            parsedName: name ? name.replace(Constant.RE_KEY, '$1') : name,

		            // 解析后的生成规则
		            rule: rule,
		            // 相关上下文
		            context: context
		        })

		        if (!context.root) context.root = data
		        return data
		    }

		    return template
		}

		Handler.extend({
		    array: function(options) {
		        var result = [],
		            i, ii;

		        // 'name|1': []
		        // 'name|count': []
		        // 'name|min-max': []
		        if (options.template.length === 0) return result

		        // 'arr': [{ 'email': '@EMAIL' }, { 'email': '@EMAIL' }]
		        if (!options.rule.parameters) {
		            for (i = 0; i < options.template.length; i++) {
		                options.context.path.push(i)
		                options.context.templatePath.push(i)
		                result.push(
		                    Handler.gen(options.template[i], i, {
		                        path: options.context.path,
		                        templatePath: options.context.templatePath,
		                        currentContext: result,
		                        templateCurrentContext: options.template,
		                        root: options.context.root || result,
		                        templateRoot: options.context.templateRoot || options.template
		                    })
		                )
		                options.context.path.pop()
		                options.context.templatePath.pop()
		            }
		        } else {
		            // 'method|1': ['GET', 'POST', 'HEAD', 'DELETE']
		            if (options.rule.min === 1 && options.rule.max === undefined) {
		                // fix #17
		                options.context.path.push(options.name)
		                options.context.templatePath.push(options.name)
		                result = Random.pick(
		                    Handler.gen(options.template, undefined, {
		                        path: options.context.path,
		                        templatePath: options.context.templatePath,
		                        currentContext: result,
		                        templateCurrentContext: options.template,
		                        root: options.context.root || result,
		                        templateRoot: options.context.templateRoot || options.template
		                    })
		                )
		                options.context.path.pop()
		                options.context.templatePath.pop()
		            } else {
		                // 'data|+1': [{}, {}]
		                if (options.rule.parameters[2]) {
		                    options.template.__order_index = options.template.__order_index || 0

		                    options.context.path.push(options.name)
		                    options.context.templatePath.push(options.name)
		                    result = Handler.gen(options.template, undefined, {
		                        path: options.context.path,
		                        templatePath: options.context.templatePath,
		                        currentContext: result,
		                        templateCurrentContext: options.template,
		                        root: options.context.root || result,
		                        templateRoot: options.context.templateRoot || options.template
		                    })[
		                        options.template.__order_index % options.template.length
		                    ]

		                    options.template.__order_index += +options.rule.parameters[2]

		                    options.context.path.pop()
		                    options.context.templatePath.pop()

		                } else {
		                    // 'data|1-10': [{}]
		                    for (i = 0; i < options.rule.count; i++) {
		                        // 'data|1-10': [{}, {}]
		                        for (ii = 0; ii < options.template.length; ii++) {
		                            options.context.path.push(result.length)
		                            options.context.templatePath.push(ii)
		                            result.push(
		                                Handler.gen(options.template[ii], result.length, {
		                                    path: options.context.path,
		                                    templatePath: options.context.templatePath,
		                                    currentContext: result,
		                                    templateCurrentContext: options.template,
		                                    root: options.context.root || result,
		                                    templateRoot: options.context.templateRoot || options.template
		                                })
		                            )
		                            options.context.path.pop()
		                            options.context.templatePath.pop()
		                        }
		                    }
		                }
		            }
		        }
		        return result
		    },
		    object: function(options) {
		        var result = {},
		            keys, fnKeys, key, parsedKey, inc, i;

		        // 'obj|min-max': {}
		        /* jshint -W041 */
		        if (options.rule.min != undefined) {
		            keys = Util.keys(options.template)
		            keys = Random.shuffle(keys)
		            keys = keys.slice(0, options.rule.count)
		            for (i = 0; i < keys.length; i++) {
		                key = keys[i]
		                parsedKey = key.replace(Constant.RE_KEY, '$1')
		                options.context.path.push(parsedKey)
		                options.context.templatePath.push(key)
		                result[parsedKey] = Handler.gen(options.template[key], key, {
		                    path: options.context.path,
		                    templatePath: options.context.templatePath,
		                    currentContext: result,
		                    templateCurrentContext: options.template,
		                    root: options.context.root || result,
		                    templateRoot: options.context.templateRoot || options.template
		                })
		                options.context.path.pop()
		                options.context.templatePath.pop()
		            }

		        } else {
		            // 'obj': {}
		            keys = []
		            fnKeys = [] // #25 改变了非函数属性的顺序，查找起来不方便
		            for (key in options.template) {
		                (typeof options.template[key] === 'function' ? fnKeys : keys).push(key)
		            }
		            keys = keys.concat(fnKeys)

		            /*
		                会改变非函数属性的顺序
		                keys = Util.keys(options.template)
		                keys.sort(function(a, b) {
		                    var afn = typeof options.template[a] === 'function'
		                    var bfn = typeof options.template[b] === 'function'
		                    if (afn === bfn) return 0
		                    if (afn && !bfn) return 1
		                    if (!afn && bfn) return -1
		                })
		            */

		            for (i = 0; i < keys.length; i++) {
		                key = keys[i]
		                parsedKey = key.replace(Constant.RE_KEY, '$1')
		                options.context.path.push(parsedKey)
		                options.context.templatePath.push(key)
		                result[parsedKey] = Handler.gen(options.template[key], key, {
		                    path: options.context.path,
		                    templatePath: options.context.templatePath,
		                    currentContext: result,
		                    templateCurrentContext: options.template,
		                    root: options.context.root || result,
		                    templateRoot: options.context.templateRoot || options.template
		                })
		                options.context.path.pop()
		                options.context.templatePath.pop()
		                    // 'id|+1': 1
		                inc = key.match(Constant.RE_KEY)
		                if (inc && inc[2] && Util.type(options.template[key]) === 'number') {
		                    options.template[key] += parseInt(inc[2], 10)
		                }
		            }
		        }
		        return result
		    },
		    number: function(options) {
		        var result, parts;
		        if (options.rule.decimal) { // float
		            options.template += ''
		            parts = options.template.split('.')
		                // 'float1|.1-10': 10,
		                // 'float2|1-100.1-10': 1,
		                // 'float3|999.1-10': 1,
		                // 'float4|.3-10': 123.123,
		            parts[0] = options.rule.range ? options.rule.count : parts[0]
		            parts[1] = (parts[1] || '').slice(0, options.rule.dcount)
		            while (parts[1].length < options.rule.dcount) {
		                parts[1] += (
		                    // 最后一位不能为 0：如果最后一位为 0，会被 JS 引擎忽略掉。
		                    (parts[1].length < options.rule.dcount - 1) ? Random.character('number') : Random.character('123456789')
		                )
		            }
		            result = parseFloat(parts.join('.'), 10)
		        } else { // integer
		            // 'grade1|1-100': 1,
		            result = options.rule.range && !options.rule.parameters[2] ? options.rule.count : options.template
		        }
		        return result
		    },
		    boolean: function(options) {
		        var result;
		        // 'prop|multiple': false, 当前值是相反值的概率倍数
		        // 'prop|probability-probability': false, 当前值与相反值的概率
		        result = options.rule.parameters ? Random.bool(options.rule.min, options.rule.max, options.template) : options.template
		        return result
		    },
		    string: function(options) {
		        var result = '',
		            i, placeholders, ph, phed;
		        if (options.template.length) {

		            //  'foo': '★',
		            /* jshint -W041 */
		            if (options.rule.count == undefined) {
		                result += options.template
		            }

		            // 'star|1-5': '★',
		            for (i = 0; i < options.rule.count; i++) {
		                result += options.template
		            }
		            // 'email|1-10': '@EMAIL, ',
		            placeholders = result.match(Constant.RE_PLACEHOLDER) || [] // A-Z_0-9 > \w_
		            for (i = 0; i < placeholders.length; i++) {
		                ph = placeholders[i]

		                // 遇到转义斜杠，不需要解析占位符
		                if (/^\\/.test(ph)) {
		                    placeholders.splice(i--, 1)
		                    continue
		                }

		                phed = Handler.placeholder(ph, options.context.currentContext, options.context.templateCurrentContext, options)

		                // 只有一个占位符，并且没有其他字符
		                if (placeholders.length === 1 && ph === result && typeof phed !== typeof result) { // 
		                    result = phed
		                    break

		                    if (Util.isNumeric(phed)) {
		                        result = parseFloat(phed, 10)
		                        break
		                    }
		                    if (/^(true|false)$/.test(phed)) {
		                        result = phed === 'true' ? true :
		                            phed === 'false' ? false :
		                            phed // 已经是布尔值
		                        break
		                    }
		                }
		                result = result.replace(ph, phed)
		            }

		        } else {
		            // 'ASCII|1-10': '',
		            // 'ASCII': '',
		            result = options.rule.range ? Random.string(options.rule.count) : options.template
		        }
		        return result
		    },
		    'function': function(options) {
		        // ( context, options )
		        return options.template.call(options.context.currentContext, options)
		    },
		    'regexp': function(options) {
		        var source = ''

		        // 'name': /regexp/,
		        /* jshint -W041 */
		        if (options.rule.count == undefined) {
		            source += options.template.source // regexp.source
		        }

		        // 'name|1-5': /regexp/,
		        for (var i = 0; i < options.rule.count; i++) {
		            source += options.template.source
		        }

		        return RE.Handler.gen(
		            RE.Parser.parse(
		                source
		            )
		        )
		    }
		})

		Handler.extend({
		    _all: function() {
		        var re = {};
		        for (var key in Random) re[key.toLowerCase()] = key
		        return re
		    },
		    // 处理占位符，转换为最终值
		    placeholder: function(placeholder, obj, templateContext, options) {
		        // console.log(options.context.path)
		        // 1 key, 2 params
		        Constant.RE_PLACEHOLDER.exec('')
		        var parts = Constant.RE_PLACEHOLDER.exec(placeholder),
		            key = parts && parts[1],
		            lkey = key && key.toLowerCase(),
		            okey = this._all()[lkey],
		            params = parts && parts[2] || ''
		        var pathParts = this.splitPathToArray(key)

		        // 解析占位符的参数
		        try {
		            // 1. 尝试保持参数的类型
		            /*
		                #24 [Window Firefox 30.0 引用 占位符 抛错](https://github.com/nuysoft/Mock/issues/24)
		                [BX9056: 各浏览器下 window.eval 方法的执行上下文存在差异](http://www.w3help.org/zh-cn/causes/BX9056)
		                应该属于 Window Firefox 30.0 的 BUG
		            */
		            /* jshint -W061 */
		            params = eval('(function(){ return [].splice.call(arguments, 0 ) })(' + params + ')')
		        } catch (error) {
		            // 2. 如果失败，只能解析为字符串
		            // console.error(error)
		            // if (error instanceof ReferenceError) params = parts[2].split(/,\s*/);
		            // else throw error
		            params = parts[2].split(/,\s*/)
		        }

		        // 占位符优先引用数据模板中的属性
		        if (obj && (key in obj)) return obj[key]

		        // @index @key
		        // if (Constant.RE_INDEX.test(key)) return +options.name
		        // if (Constant.RE_KEY.test(key)) return options.name

		        // 绝对路径 or 相对路径
		        if (
		            key.charAt(0) === '/' ||
		            pathParts.length > 1
		        ) return this.getValueByKeyPath(key, options)

		        // 递归引用数据模板中的属性
		        if (templateContext &&
		            (typeof templateContext === 'object') &&
		            (key in templateContext) &&
		            (placeholder !== templateContext[key]) // fix #15 避免自己依赖自己
		        ) {
		            // 先计算被引用的属性值
		            templateContext[key] = Handler.gen(templateContext[key], key, {
		                currentContext: obj,
		                templateCurrentContext: templateContext
		            })
		            return templateContext[key]
		        }

		        // 如果未找到，则原样返回
		        if (!(key in Random) && !(lkey in Random) && !(okey in Random)) return placeholder

		        // 递归解析参数中的占位符
		        for (var i = 0; i < params.length; i++) {
		            Constant.RE_PLACEHOLDER.exec('')
		            if (Constant.RE_PLACEHOLDER.test(params[i])) {
		                params[i] = Handler.placeholder(params[i], obj, templateContext, options)
		            }
		        }

		        var handle = Random[key] || Random[lkey] || Random[okey]
		        switch (Util.type(handle)) {
		            case 'array':
		                // 自动从数组中取一个，例如 @areas
		                return Random.pick(handle)
		            case 'function':
		                // 执行占位符方法（大多数情况）
		                handle.options = options
		                var re = handle.apply(Random, params)
		                if (re === undefined) re = '' // 因为是在字符串中，所以默认为空字符串。
		                delete handle.options
		                return re
		        }
		    },
		    getValueByKeyPath: function(key, options) {
		        var originalKey = key
		        var keyPathParts = this.splitPathToArray(key)
		        var absolutePathParts = []

		        // 绝对路径
		        if (key.charAt(0) === '/') {
		            absolutePathParts = [options.context.path[0]].concat(
		                this.normalizePath(keyPathParts)
		            )
		        } else {
		            // 相对路径
		            if (keyPathParts.length > 1) {
		                absolutePathParts = options.context.path.slice(0)
		                absolutePathParts.pop()
		                absolutePathParts = this.normalizePath(
		                    absolutePathParts.concat(keyPathParts)
		                )

		            }
		        }

		        key = keyPathParts[keyPathParts.length - 1]
		        var currentContext = options.context.root
		        var templateCurrentContext = options.context.templateRoot
		        for (var i = 1; i < absolutePathParts.length - 1; i++) {
		            currentContext = currentContext[absolutePathParts[i]]
		            templateCurrentContext = templateCurrentContext[absolutePathParts[i]]
		        }
		        // 引用的值已经计算好
		        if (currentContext && (key in currentContext)) return currentContext[key]

		        // 尚未计算，递归引用数据模板中的属性
		        if (templateCurrentContext &&
		            (typeof templateCurrentContext === 'object') &&
		            (key in templateCurrentContext) &&
		            (originalKey !== templateCurrentContext[key]) // fix #15 避免自己依赖自己
		        ) {
		            // 先计算被引用的属性值
		            templateCurrentContext[key] = Handler.gen(templateCurrentContext[key], key, {
		                currentContext: currentContext,
		                templateCurrentContext: templateCurrentContext
		            })
		            return templateCurrentContext[key]
		        }
		    },
		    // https://github.com/kissyteam/kissy/blob/master/src/path/src/path.js
		    normalizePath: function(pathParts) {
		        var newPathParts = []
		        for (var i = 0; i < pathParts.length; i++) {
		            switch (pathParts[i]) {
		                case '..':
		                    newPathParts.pop()
		                    break
		                case '.':
		                    break
		                default:
		                    newPathParts.push(pathParts[i])
		            }
		        }
		        return newPathParts
		    },
		    splitPathToArray: function(path) {
		        var parts = path.split(/\/+/);
		        if (!parts[parts.length - 1]) parts = parts.slice(0, -1)
		        if (!parts[0]) parts = parts.slice(1)
		        return parts;
		    }
		})

		module.exports = Handler

	/***/ },
	/* 2 */
	/***/ function(module, exports) {

		/*
		    ## Constant

		    常量集合。
		 */
		/*
		    RE_KEY
		        'name|min-max': value
		        'name|count': value
		        'name|min-max.dmin-dmax': value
		        'name|min-max.dcount': value
		        'name|count.dmin-dmax': value
		        'name|count.dcount': value
		        'name|+step': value

		        1 name, 2 step, 3 range [ min, max ], 4 drange [ dmin, dmax ]

		    RE_PLACEHOLDER
		        placeholder(*)

		    [正则查看工具](http://www.regexper.com/)

		    #26 生成规则 支持 负数，例如 number|-100-100
		*/
		module.exports = {
		    GUID: 1,
		    RE_KEY: /(.+)\|(?:\+(\d+)|([\+\-]?\d+-?[\+\-]?\d*)?(?:\.(\d+-?\d*))?)/,
		    RE_RANGE: /([\+\-]?\d+)-?([\+\-]?\d+)?/,
		    RE_PLACEHOLDER: /\\*@([^@#%&()\?\s]+)(?:\((.*?)\))?/g
		    // /\\*@([^@#%&()\?\s\/\.]+)(?:\((.*?)\))?/g
		    // RE_INDEX: /^index$/,
		    // RE_KEY: /^key$/
		}

	/***/ },
	/* 3 */
	/***/ function(module, exports) {

		/*
		    ## Utilities
		*/
		var Util = {}

		Util.extend = function extend() {
		    var target = arguments[0] || {},
		        i = 1,
		        length = arguments.length,
		        options, name, src, copy, clone

		    if (length === 1) {
		        target = this
		        i = 0
		    }

		    for (; i < length; i++) {
		        options = arguments[i]
		        if (!options) continue

		        for (name in options) {
		            src = target[name]
		            copy = options[name]

		            if (target === copy) continue
		            if (copy === undefined) continue

		            if (Util.isArray(copy) || Util.isObject(copy)) {
		                if (Util.isArray(copy)) clone = src && Util.isArray(src) ? src : []
		                if (Util.isObject(copy)) clone = src && Util.isObject(src) ? src : {}

		                target[name] = Util.extend(clone, copy)
		            } else {
		                target[name] = copy
		            }
		        }
		    }

		    return target
		}

		Util.each = function each(obj, iterator, context) {
		    var i, key
		    if (this.type(obj) === 'number') {
		        for (i = 0; i < obj; i++) {
		            iterator(i, i)
		        }
		    } else if (obj.length === +obj.length) {
		        for (i = 0; i < obj.length; i++) {
		            if (iterator.call(context, obj[i], i, obj) === false) break
		        }
		    } else {
		        for (key in obj) {
		            if (iterator.call(context, obj[key], key, obj) === false) break
		        }
		    }
		}

		Util.type = function type(obj) {
		    return (obj === null || obj === undefined) ? String(obj) : Object.prototype.toString.call(obj).match(/\[object (\w+)\]/)[1].toLowerCase()
		}

		Util.each('String Object Array RegExp Function'.split(' '), function(value) {
		    Util['is' + value] = function(obj) {
		        return Util.type(obj) === value.toLowerCase()
		    }
		})

		Util.isObjectOrArray = function(value) {
		    return Util.isObject(value) || Util.isArray(value)
		}

		Util.isNumeric = function(value) {
		    return !isNaN(parseFloat(value)) && isFinite(value)
		}

		Util.keys = function(obj) {
		    var keys = [];
		    for (var key in obj) {
		        if (obj.hasOwnProperty(key)) keys.push(key)
		    }
		    return keys;
		}
		Util.values = function(obj) {
		    var values = [];
		    for (var key in obj) {
		        if (obj.hasOwnProperty(key)) values.push(obj[key])
		    }
		    return values;
		}

		/*
		    ### Mock.heredoc(fn)

		    * Mock.heredoc(fn)

		    以直观、安全的方式书写（多行）HTML 模板。

		    **使用示例**如下所示：

		        var tpl = Mock.heredoc(function() {
		            /*!
		        {{email}}{{age}}
		        <!-- Mock { 
		            email: '@EMAIL',
		            age: '@INT(1,100)'
		        } -->
		            *\/
		        })
		    
		    **相关阅读**
		    * [Creating multiline strings in JavaScript](http://stackoverflow.com/questions/805107/creating-multiline-strings-in-javascript)、
		*/
		Util.heredoc = function heredoc(fn) {
		    // 1. 移除起始的 function(){ /*!
		    // 2. 移除末尾的 */ }
		    // 3. 移除起始和末尾的空格
		    return fn.toString()
		        .replace(/^[^\/]+\/\*!?/, '')
		        .replace(/\*\/[^\/]+$/, '')
		        .replace(/^[\s\xA0]+/, '').replace(/[\s\xA0]+$/, '') // .trim()
		}

		Util.noop = function() {}

		module.exports = Util

	/***/ },
	/* 4 */
	/***/ function(module, exports, __webpack_require__) {

		/*
			## Parser

			解析数据模板（属性名部分）。

			* Parser.parse( name )
				
				```json
				{
					parameters: [ name, inc, range, decimal ],
					rnage: [ min , max ],

					min: min,
					max: max,
					count : count,

					decimal: decimal,
					dmin: dmin,
					dmax: dmax,
					dcount: dcount
				}
				```
		 */

		var Constant = __webpack_require__(2)
		var Random = __webpack_require__(5)

		/* jshint -W041 */
		module.exports = {
			parse: function(name) {
				name = name == undefined ? '' : (name + '')

				var parameters = (name || '').match(Constant.RE_KEY)

				var range = parameters && parameters[3] && parameters[3].match(Constant.RE_RANGE)
				var min = range && range[1] && parseInt(range[1], 10) // || 1
				var max = range && range[2] && parseInt(range[2], 10) // || 1
					// repeat || min-max || 1
					// var count = range ? !range[2] && parseInt(range[1], 10) || Random.integer(min, max) : 1
				var count = range ? !range[2] ? parseInt(range[1], 10) : Random.integer(min, max) : undefined

				var decimal = parameters && parameters[4] && parameters[4].match(Constant.RE_RANGE)
				var dmin = decimal && decimal[1] && parseInt(decimal[1], 10) // || 0,
				var dmax = decimal && decimal[2] && parseInt(decimal[2], 10) // || 0,
					// int || dmin-dmax || 0
				var dcount = decimal ? !decimal[2] && parseInt(decimal[1], 10) || Random.integer(dmin, dmax) : undefined

				var result = {
					// 1 name, 2 inc, 3 range, 4 decimal
					parameters: parameters,
					// 1 min, 2 max
					range: range,
					min: min,
					max: max,
					// min-max
					count: count,
					// 是否有 decimal
					decimal: decimal,
					dmin: dmin,
					dmax: dmax,
					// dmin-dimax
					dcount: dcount
				}

				for (var r in result) {
					if (result[r] != undefined) return result
				}

				return {}
			}
		}

	/***/ },
	/* 5 */
	/***/ function(module, exports, __webpack_require__) {

		/*
		    ## Mock.Random
		    
		    工具类，用于生成各种随机数据。
		*/

		var Util = __webpack_require__(3)

		var Random = {
		    extend: Util.extend
		}

		Random.extend(__webpack_require__(6))
		Random.extend(__webpack_require__(7))
		Random.extend(__webpack_require__(8))
		Random.extend(__webpack_require__(10))
		Random.extend(__webpack_require__(13))
		Random.extend(__webpack_require__(15))
		Random.extend(__webpack_require__(16))
		Random.extend(__webpack_require__(17))
		Random.extend(__webpack_require__(14))
		Random.extend(__webpack_require__(19))

		module.exports = Random

	/***/ },
	/* 6 */
	/***/ function(module, exports) {

		/*
		    ## Basics
		*/
		module.exports = {
		    // 返回一个随机的布尔值。
		    boolean: function(min, max, cur) {
		        if (cur !== undefined) {
		            min = typeof min !== 'undefined' && !isNaN(min) ? parseInt(min, 10) : 1
		            max = typeof max !== 'undefined' && !isNaN(max) ? parseInt(max, 10) : 1
		            return Math.random() > 1.0 / (min + max) * min ? !cur : cur
		        }

		        return Math.random() >= 0.5
		    },
		    bool: function(min, max, cur) {
		        return this.boolean(min, max, cur)
		    },
		    // 返回一个随机的自然数（大于等于 0 的整数）。
		    natural: function(min, max) {
		        min = typeof min !== 'undefined' ? parseInt(min, 10) : 0
		        max = typeof max !== 'undefined' ? parseInt(max, 10) : 9007199254740992 // 2^53
		        return Math.round(Math.random() * (max - min)) + min
		    },
		    // 返回一个随机的整数。
		    integer: function(min, max) {
		        min = typeof min !== 'undefined' ? parseInt(min, 10) : -9007199254740992
		        max = typeof max !== 'undefined' ? parseInt(max, 10) : 9007199254740992 // 2^53
		        return Math.round(Math.random() * (max - min)) + min
		    },
		    int: function(min, max) {
		        return this.integer(min, max)
		    },
		    // 返回一个随机的浮点数。
		    float: function(min, max, dmin, dmax) {
		        dmin = dmin === undefined ? 0 : dmin
		        dmin = Math.max(Math.min(dmin, 17), 0)
		        dmax = dmax === undefined ? 17 : dmax
		        dmax = Math.max(Math.min(dmax, 17), 0)
		        var ret = this.integer(min, max) + '.';
		        for (var i = 0, dcount = this.natural(dmin, dmax); i < dcount; i++) {
		            ret += (
		                // 最后一位不能为 0：如果最后一位为 0，会被 JS 引擎忽略掉。
		                (i < dcount - 1) ? this.character('number') : this.character('123456789')
		            )
		        }
		        return parseFloat(ret, 10)
		    },
		    // 返回一个随机字符。
		    character: function(pool) {
		        var pools = {
		            lower: 'abcdefghijklmnopqrstuvwxyz',
		            upper: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
		            number: '0123456789',
		            symbol: '!@#$%^&*()[]'
		        }
		        pools.alpha = pools.lower + pools.upper
		        pools['undefined'] = pools.lower + pools.upper + pools.number + pools.symbol

		        pool = pools[('' + pool).toLowerCase()] || pool
		        return pool.charAt(this.natural(0, pool.length - 1))
		    },
		    char: function(pool) {
		        return this.character(pool)
		    },
		    // 返回一个随机字符串。
		    string: function(pool, min, max) {
		        var len
		        switch (arguments.length) {
		            case 0: // ()
		                len = this.natural(3, 7)
		                break
		            case 1: // ( length )
		                len = pool
		                pool = undefined
		                break
		            case 2:
		                // ( pool, length )
		                if (typeof arguments[0] === 'string') {
		                    len = min
		                } else {
		                    // ( min, max )
		                    len = this.natural(pool, min)
		                    pool = undefined
		                }
		                break
		            case 3:
		                len = this.natural(min, max)
		                break
		        }

		        var text = ''
		        for (var i = 0; i < len; i++) {
		            text += this.character(pool)
		        }

		        return text
		    },
		    str: function( /*pool, min, max*/ ) {
		        return this.string.apply(this, arguments)
		    },
		    // 返回一个整型数组。
		    range: function(start, stop, step) {
		        // range( stop )
		        if (arguments.length <= 1) {
		            stop = start || 0;
		            start = 0;
		        }
		        // range( start, stop )
		        step = arguments[2] || 1;

		        start = +start
		        stop = +stop
		        step = +step

		        var len = Math.max(Math.ceil((stop - start) / step), 0);
		        var idx = 0;
		        var range = new Array(len);

		        while (idx < len) {
		            range[idx++] = start;
		            start += step;
		        }

		        return range;
		    }
		}

	/***/ },
	/* 7 */
	/***/ function(module, exports) {

		/*
		    ## Date
		*/
		var patternLetters = {
		    yyyy: 'getFullYear',
		    yy: function(date) {
		        return ('' + date.getFullYear()).slice(2)
		    },
		    y: 'yy',

		    MM: function(date) {
		        var m = date.getMonth() + 1
		        return m < 10 ? '0' + m : m
		    },
		    M: function(date) {
		        return date.getMonth() + 1
		    },

		    dd: function(date) {
		        var d = date.getDate()
		        return d < 10 ? '0' + d : d
		    },
		    d: 'getDate',

		    HH: function(date) {
		        var h = date.getHours()
		        return h < 10 ? '0' + h : h
		    },
		    H: 'getHours',
		    hh: function(date) {
		        var h = date.getHours() % 12
		        return h < 10 ? '0' + h : h
		    },
		    h: function(date) {
		        return date.getHours() % 12
		    },

		    mm: function(date) {
		        var m = date.getMinutes()
		        return m < 10 ? '0' + m : m
		    },
		    m: 'getMinutes',

		    ss: function(date) {
		        var s = date.getSeconds()
		        return s < 10 ? '0' + s : s
		    },
		    s: 'getSeconds',

		    SS: function(date) {
		        var ms = date.getMilliseconds()
		        return ms < 10 && '00' + ms || ms < 100 && '0' + ms || ms
		    },
		    S: 'getMilliseconds',

		    A: function(date) {
		        return date.getHours() < 12 ? 'AM' : 'PM'
		    },
		    a: function(date) {
		        return date.getHours() < 12 ? 'am' : 'pm'
		    },
		    T: 'getTime'
		}
		module.exports = {
		    // 日期占位符集合。
		    _patternLetters: patternLetters,
		    // 日期占位符正则。
		    _rformat: new RegExp((function() {
		        var re = []
		        for (var i in patternLetters) re.push(i)
		        return '(' + re.join('|') + ')'
		    })(), 'g'),
		    // 格式化日期。
		    _formatDate: function(date, format) {
		        return format.replace(this._rformat, function creatNewSubString($0, flag) {
		            return typeof patternLetters[flag] === 'function' ? patternLetters[flag](date) :
		                patternLetters[flag] in patternLetters ? creatNewSubString($0, patternLetters[flag]) :
		                date[patternLetters[flag]]()
		        })
		    },
		    // 生成一个随机的 Date 对象。
		    _randomDate: function(min, max) { // min, max
		        min = min === undefined ? new Date(0) : min
		        max = max === undefined ? new Date() : max
		        return new Date(Math.random() * (max.getTime() - min.getTime()))
		    },
		    // 返回一个随机的日期字符串。
		    date: function(format) {
		        format = format || 'yyyy-MM-dd'
		        return this._formatDate(this._randomDate(), format)
		    },
		    // 返回一个随机的时间字符串。
		    time: function(format) {
		        format = format || 'HH:mm:ss'
		        return this._formatDate(this._randomDate(), format)
		    },
		    // 返回一个随机的日期和时间字符串。
		    datetime: function(format) {
		        format = format || 'yyyy-MM-dd HH:mm:ss'
		        return this._formatDate(this._randomDate(), format)
		    },
		    // 返回当前的日期和时间字符串。
		    now: function(unit, format) {
		        // now(unit) now(format)
		        if (arguments.length === 1) {
		            // now(format)
		            if (!/year|month|day|hour|minute|second|week/.test(unit)) {
		                format = unit
		                unit = ''
		            }
		        }
		        unit = (unit || '').toLowerCase()
		        format = format || 'yyyy-MM-dd HH:mm:ss'

		        var date = new Date()

		        /* jshint -W086 */
		        // 参考自 http://momentjs.cn/docs/#/manipulating/start-of/
		        switch (unit) {
		            case 'year':
		                date.setMonth(0)
		            case 'month':
		                date.setDate(1)
		            case 'week':
		            case 'day':
		                date.setHours(0)
		            case 'hour':
		                date.setMinutes(0)
		            case 'minute':
		                date.setSeconds(0)
		            case 'second':
		                date.setMilliseconds(0)
		        }
		        switch (unit) {
		            case 'week':
		                date.setDate(date.getDate() - date.getDay())
		        }

		        return this._formatDate(date, format)
		    }
		}

	/***/ },
	/* 8 */
	/***/ function(module, exports, __webpack_require__) {

		/* WEBPACK VAR INJECTION */(function(module) {/* global document  */
		/*
		    ## Image
		*/
		module.exports = {
		    // 常见的广告宽高
		    _adSize: [
		        '300x250', '250x250', '240x400', '336x280', '180x150',
		        '720x300', '468x60', '234x60', '88x31', '120x90',
		        '120x60', '120x240', '125x125', '728x90', '160x600',
		        '120x600', '300x600'
		    ],
		    // 常见的屏幕宽高
		    _screenSize: [
		        '320x200', '320x240', '640x480', '800x480', '800x480',
		        '1024x600', '1024x768', '1280x800', '1440x900', '1920x1200',
		        '2560x1600'
		    ],
		    // 常见的视频宽高
		    _videoSize: ['720x480', '768x576', '1280x720', '1920x1080'],
		    /*
		        生成一个随机的图片地址。

		        替代图片源
		            http://fpoimg.com/
		        参考自 
		            http://rensanning.iteye.com/blog/1933310
		            http://code.tutsplus.com/articles/the-top-8-placeholders-for-web-designers--net-19485
		    */
		    image: function(size, background, foreground, format, text) {
		        // Random.image( size, background, foreground, text )
		        if (arguments.length === 4) {
		            text = format
		            format = undefined
		        }
		        // Random.image( size, background, text )
		        if (arguments.length === 3) {
		            text = foreground
		            foreground = undefined
		        }
		        // Random.image()
		        if (!size) size = this.pick(this._adSize)

		        if (background && ~background.indexOf('#')) background = background.slice(1)
		        if (foreground && ~foreground.indexOf('#')) foreground = foreground.slice(1)

		        // http://dummyimage.com/600x400/cc00cc/470047.png&text=hello
		        return 'http://dummyimage.com/' + size +
		            (background ? '/' + background : '') +
		            (foreground ? '/' + foreground : '') +
		            (format ? '.' + format : '') +
		            (text ? '&text=' + text : '')
		    },
		    img: function() {
		        return this.image.apply(this, arguments)
		    },

		    /*
		        BrandColors
		        http://brandcolors.net/
		        A collection of major brand color codes curated by Galen Gidman.
		        大牌公司的颜色集合

		        // 获取品牌和颜色
		        $('h2').each(function(index, item){
		            item = $(item)
		            console.log('\'' + item.text() + '\'', ':', '\'' + item.next().text() + '\'', ',')
		        })
		    */
		    _brandColors: {
		        '4ormat': '#fb0a2a',
		        '500px': '#02adea',
		        'About.me (blue)': '#00405d',
		        'About.me (yellow)': '#ffcc33',
		        'Addvocate': '#ff6138',
		        'Adobe': '#ff0000',
		        'Aim': '#fcd20b',
		        'Amazon': '#e47911',
		        'Android': '#a4c639',
		        'Angie\'s List': '#7fbb00',
		        'AOL': '#0060a3',
		        'Atlassian': '#003366',
		        'Behance': '#053eff',
		        'Big Cartel': '#97b538',
		        'bitly': '#ee6123',
		        'Blogger': '#fc4f08',
		        'Boeing': '#0039a6',
		        'Booking.com': '#003580',
		        'Carbonmade': '#613854',
		        'Cheddar': '#ff7243',
		        'Code School': '#3d4944',
		        'Delicious': '#205cc0',
		        'Dell': '#3287c1',
		        'Designmoo': '#e54a4f',
		        'Deviantart': '#4e6252',
		        'Designer News': '#2d72da',
		        'Devour': '#fd0001',
		        'DEWALT': '#febd17',
		        'Disqus (blue)': '#59a3fc',
		        'Disqus (orange)': '#db7132',
		        'Dribbble': '#ea4c89',
		        'Dropbox': '#3d9ae8',
		        'Drupal': '#0c76ab',
		        'Dunked': '#2a323a',
		        'eBay': '#89c507',
		        'Ember': '#f05e1b',
		        'Engadget': '#00bdf6',
		        'Envato': '#528036',
		        'Etsy': '#eb6d20',
		        'Evernote': '#5ba525',
		        'Fab.com': '#dd0017',
		        'Facebook': '#3b5998',
		        'Firefox': '#e66000',
		        'Flickr (blue)': '#0063dc',
		        'Flickr (pink)': '#ff0084',
		        'Forrst': '#5b9a68',
		        'Foursquare': '#25a0ca',
		        'Garmin': '#007cc3',
		        'GetGlue': '#2d75a2',
		        'Gimmebar': '#f70078',
		        'GitHub': '#171515',
		        'Google Blue': '#0140ca',
		        'Google Green': '#16a61e',
		        'Google Red': '#dd1812',
		        'Google Yellow': '#fcca03',
		        'Google+': '#dd4b39',
		        'Grooveshark': '#f77f00',
		        'Groupon': '#82b548',
		        'Hacker News': '#ff6600',
		        'HelloWallet': '#0085ca',
		        'Heroku (light)': '#c7c5e6',
		        'Heroku (dark)': '#6567a5',
		        'HootSuite': '#003366',
		        'Houzz': '#73ba37',
		        'HTML5': '#ec6231',
		        'IKEA': '#ffcc33',
		        'IMDb': '#f3ce13',
		        'Instagram': '#3f729b',
		        'Intel': '#0071c5',
		        'Intuit': '#365ebf',
		        'Kickstarter': '#76cc1e',
		        'kippt': '#e03500',
		        'Kodery': '#00af81',
		        'LastFM': '#c3000d',
		        'LinkedIn': '#0e76a8',
		        'Livestream': '#cf0005',
		        'Lumo': '#576396',
		        'Mixpanel': '#a086d3',
		        'Meetup': '#e51937',
		        'Nokia': '#183693',
		        'NVIDIA': '#76b900',
		        'Opera': '#cc0f16',
		        'Path': '#e41f11',
		        'PayPal (dark)': '#1e477a',
		        'PayPal (light)': '#3b7bbf',
		        'Pinboard': '#0000e6',
		        'Pinterest': '#c8232c',
		        'PlayStation': '#665cbe',
		        'Pocket': '#ee4056',
		        'Prezi': '#318bff',
		        'Pusha': '#0f71b4',
		        'Quora': '#a82400',
		        'QUOTE.fm': '#66ceff',
		        'Rdio': '#008fd5',
		        'Readability': '#9c0000',
		        'Red Hat': '#cc0000',
		        'Resource': '#7eb400',
		        'Rockpack': '#0ba6ab',
		        'Roon': '#62b0d9',
		        'RSS': '#ee802f',
		        'Salesforce': '#1798c1',
		        'Samsung': '#0c4da2',
		        'Shopify': '#96bf48',
		        'Skype': '#00aff0',
		        'Snagajob': '#f47a20',
		        'Softonic': '#008ace',
		        'SoundCloud': '#ff7700',
		        'Space Box': '#f86960',
		        'Spotify': '#81b71a',
		        'Sprint': '#fee100',
		        'Squarespace': '#121212',
		        'StackOverflow': '#ef8236',
		        'Staples': '#cc0000',
		        'Status Chart': '#d7584f',
		        'Stripe': '#008cdd',
		        'StudyBlue': '#00afe1',
		        'StumbleUpon': '#f74425',
		        'T-Mobile': '#ea0a8e',
		        'Technorati': '#40a800',
		        'The Next Web': '#ef4423',
		        'Treehouse': '#5cb868',
		        'Trulia': '#5eab1f',
		        'Tumblr': '#34526f',
		        'Twitch.tv': '#6441a5',
		        'Twitter': '#00acee',
		        'TYPO3': '#ff8700',
		        'Ubuntu': '#dd4814',
		        'Ustream': '#3388ff',
		        'Verizon': '#ef1d1d',
		        'Vimeo': '#86c9ef',
		        'Vine': '#00a478',
		        'Virb': '#06afd8',
		        'Virgin Media': '#cc0000',
		        'Wooga': '#5b009c',
		        'WordPress (blue)': '#21759b',
		        'WordPress (orange)': '#d54e21',
		        'WordPress (grey)': '#464646',
		        'Wunderlist': '#2b88d9',
		        'XBOX': '#9bc848',
		        'XING': '#126567',
		        'Yahoo!': '#720e9e',
		        'Yandex': '#ffcc00',
		        'Yelp': '#c41200',
		        'YouTube': '#c4302b',
		        'Zalongo': '#5498dc',
		        'Zendesk': '#78a300',
		        'Zerply': '#9dcc7a',
		        'Zootool': '#5e8b1d'
		    },
		    _brandNames: function() {
		        var brands = [];
		        for (var b in this._brandColors) {
		            brands.push(b)
		        }
		        return brands
		    },
		    /*
		        生成一段随机的 Base64 图片编码。

		        https://github.com/imsky/holder
		        Holder renders image placeholders entirely on the client side.

		        dataImageHolder: function(size) {
		            return 'holder.js/' + size
		        },
		    */
		    dataImage: function(size, text) {
		        var canvas
		        if (typeof document !== 'undefined') {
		            canvas = document.createElement('canvas')
		        } else {
		            /*
		                https://github.com/Automattic/node-canvas
		                    npm install canvas --save
		                安装问题：
		                * http://stackoverflow.com/questions/22953206/gulp-issues-with-cario-install-command-not-found-when-trying-to-installing-canva
		                * https://github.com/Automattic/node-canvas/issues/415
		                * https://github.com/Automattic/node-canvas/wiki/_pages

		                PS：node-canvas 的安装过程实在是太繁琐了，所以不放入 package.json 的 dependencies。
		             */
		            var Canvas = module.require('canvas')
		            canvas = new Canvas()
		        }

		        var ctx = canvas && canvas.getContext && canvas.getContext("2d")
		        if (!canvas || !ctx) return ''

		        if (!size) size = this.pick(this._adSize)
		        text = text !== undefined ? text : size

		        size = size.split('x')

		        var width = parseInt(size[0], 10),
		            height = parseInt(size[1], 10),
		            background = this._brandColors[this.pick(this._brandNames())],
		            foreground = '#FFF',
		            text_height = 14,
		            font = 'sans-serif';

		        canvas.width = width
		        canvas.height = height
		        ctx.textAlign = 'center'
		        ctx.textBaseline = 'middle'
		        ctx.fillStyle = background
		        ctx.fillRect(0, 0, width, height)
		        ctx.fillStyle = foreground
		        ctx.font = 'bold ' + text_height + 'px ' + font
		        ctx.fillText(text, (width / 2), (height / 2), width)
		        return canvas.toDataURL('image/png')
		    }
		}
		/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(9)(module)))

	/***/ },
	/* 9 */
	/***/ function(module, exports) {

		module.exports = function(module) {
			if(!module.webpackPolyfill) {
				module.deprecate = function() {};
				module.paths = [];
				// module.parent = undefined by default
				module.children = [];
				module.webpackPolyfill = 1;
			}
			return module;
		}


	/***/ },
	/* 10 */
	/***/ function(module, exports, __webpack_require__) {

		/*
		    ## Color

		    http://llllll.li/randomColor/
		        A color generator for JavaScript.
		        randomColor generates attractive colors by default. More specifically, randomColor produces bright colors with a reasonably high saturation. This makes randomColor particularly useful for data visualizations and generative art.

		    http://randomcolour.com/
		        var bg_colour = Math.floor(Math.random() * 16777215).toString(16);
		        bg_colour = "#" + ("000000" + bg_colour).slice(-6);
		        document.bgColor = bg_colour;
		    
		    http://martin.ankerl.com/2009/12/09/how-to-create-random-colors-programmatically/
		        Creating random colors is actually more difficult than it seems. The randomness itself is easy, but aesthetically pleasing randomness is more difficult.
		        https://github.com/devongovett/color-generator

		    http://www.paulirish.com/2009/random-hex-color-code-snippets/
		        Random Hex Color Code Generator in JavaScript

		    http://chancejs.com/#color
		        chance.color()
		        // => '#79c157'
		        chance.color({format: 'hex'})
		        // => '#d67118'
		        chance.color({format: 'shorthex'})
		        // => '#60f'
		        chance.color({format: 'rgb'})
		        // => 'rgb(110,52,164)'

		    http://tool.c7sky.com/webcolor
		        网页设计常用色彩搭配表
		    
		    https://github.com/One-com/one-color
		        An OO-based JavaScript color parser/computation toolkit with support for RGB, HSV, HSL, CMYK, and alpha channels.
		        API 很赞

		    https://github.com/harthur/color
		        JavaScript color conversion and manipulation library

		    https://github.com/leaverou/css-colors
		        Share & convert CSS colors
		    http://leaverou.github.io/css-colors/#slategray
		        Type a CSS color keyword, #hex, hsl(), rgba(), whatever:

		    色调 hue
		        http://baike.baidu.com/view/23368.htm
		        色调指的是一幅画中画面色彩的总体倾向，是大的色彩效果。
		    饱和度 saturation
		        http://baike.baidu.com/view/189644.htm
		        饱和度是指色彩的鲜艳程度，也称色彩的纯度。饱和度取决于该色中含色成分和消色成分（灰色）的比例。含色成分越大，饱和度越大；消色成分越大，饱和度越小。
		    亮度 brightness
		        http://baike.baidu.com/view/34773.htm
		        亮度是指发光体（反光体）表面发光（反光）强弱的物理量。
		    照度 luminosity
		        物体被照亮的程度,采用单位面积所接受的光通量来表示,表示单位为勒[克斯](Lux,lx) ,即 1m / m2 。

		    http://stackoverflow.com/questions/1484506/random-color-generator-in-javascript
		        var letters = '0123456789ABCDEF'.split('')
		        var color = '#'
		        for (var i = 0; i < 6; i++) {
		            color += letters[Math.floor(Math.random() * 16)]
		        }
		        return color
		    
		        // 随机生成一个无脑的颜色，格式为 '#RRGGBB'。
		        // _brainlessColor()
		        var color = Math.floor(
		            Math.random() *
		            (16 * 16 * 16 * 16 * 16 * 16 - 1)
		        ).toString(16)
		        color = "#" + ("000000" + color).slice(-6)
		        return color.toUpperCase()
		*/

		var Convert = __webpack_require__(11)
		var DICT = __webpack_require__(12)

		module.exports = {
		    // 随机生成一个有吸引力的颜色，格式为 '#RRGGBB'。
		    color: function(name) {
		        if (name || DICT[name]) return DICT[name].nicer
		        return this.hex()
		    },
		    // #DAC0DE
		    hex: function() {
		        var hsv = this._goldenRatioColor()
		        var rgb = Convert.hsv2rgb(hsv)
		        var hex = Convert.rgb2hex(rgb[0], rgb[1], rgb[2])
		        return hex
		    },
		    // rgb(128,255,255)
		    rgb: function() {
		        var hsv = this._goldenRatioColor()
		        var rgb = Convert.hsv2rgb(hsv)
		        return 'rgb(' +
		            parseInt(rgb[0], 10) + ', ' +
		            parseInt(rgb[1], 10) + ', ' +
		            parseInt(rgb[2], 10) + ')'
		    },
		    // rgba(128,255,255,0.3)
		    rgba: function() {
		        var hsv = this._goldenRatioColor()
		        var rgb = Convert.hsv2rgb(hsv)
		        return 'rgba(' +
		            parseInt(rgb[0], 10) + ', ' +
		            parseInt(rgb[1], 10) + ', ' +
		            parseInt(rgb[2], 10) + ', ' +
		            Math.random().toFixed(2) + ')'
		    },
		    // hsl(300,80%,90%)
		    hsl: function() {
		        var hsv = this._goldenRatioColor()
		        var hsl = Convert.hsv2hsl(hsv)
		        return 'hsl(' +
		            parseInt(hsl[0], 10) + ', ' +
		            parseInt(hsl[1], 10) + ', ' +
		            parseInt(hsl[2], 10) + ')'
		    },
		    // http://martin.ankerl.com/2009/12/09/how-to-create-random-colors-programmatically/
		    // https://github.com/devongovett/color-generator/blob/master/index.js
		    // 随机生成一个有吸引力的颜色。
		    _goldenRatioColor: function(saturation, value) {
		        this._goldenRatio = 0.618033988749895
		        this._hue = this._hue || Math.random()
		        this._hue += this._goldenRatio
		        this._hue %= 1

		        if (typeof saturation !== "number") saturation = 0.5;
		        if (typeof value !== "number") value = 0.95;

		        return [
		            this._hue * 360,
		            saturation * 100,
		            value * 100
		        ]
		    }
		}

	/***/ },
	/* 11 */
	/***/ function(module, exports) {

		/*
		    ## Color Convert

		    http://blog.csdn.net/idfaya/article/details/6770414
		        颜色空间RGB与HSV(HSL)的转换
		*/
		// https://github.com/harthur/color-convert/blob/master/conversions.js
		module.exports = {
			rgb2hsl: function rgb2hsl(rgb) {
				var r = rgb[0] / 255,
					g = rgb[1] / 255,
					b = rgb[2] / 255,
					min = Math.min(r, g, b),
					max = Math.max(r, g, b),
					delta = max - min,
					h, s, l;

				if (max == min)
					h = 0;
				else if (r == max)
					h = (g - b) / delta;
				else if (g == max)
					h = 2 + (b - r) / delta;
				else if (b == max)
					h = 4 + (r - g) / delta;

				h = Math.min(h * 60, 360);

				if (h < 0)
					h += 360;

				l = (min + max) / 2;

				if (max == min)
					s = 0;
				else if (l <= 0.5)
					s = delta / (max + min);
				else
					s = delta / (2 - max - min);

				return [h, s * 100, l * 100];
			},
			rgb2hsv: function rgb2hsv(rgb) {
				var r = rgb[0],
					g = rgb[1],
					b = rgb[2],
					min = Math.min(r, g, b),
					max = Math.max(r, g, b),
					delta = max - min,
					h, s, v;

				if (max === 0)
					s = 0;
				else
					s = (delta / max * 1000) / 10;

				if (max == min)
					h = 0;
				else if (r == max)
					h = (g - b) / delta;
				else if (g == max)
					h = 2 + (b - r) / delta;
				else if (b == max)
					h = 4 + (r - g) / delta;

				h = Math.min(h * 60, 360);

				if (h < 0)
					h += 360;

				v = ((max / 255) * 1000) / 10;

				return [h, s, v];
			},
			hsl2rgb: function hsl2rgb(hsl) {
				var h = hsl[0] / 360,
					s = hsl[1] / 100,
					l = hsl[2] / 100,
					t1, t2, t3, rgb, val;

				if (s === 0) {
					val = l * 255;
					return [val, val, val];
				}

				if (l < 0.5)
					t2 = l * (1 + s);
				else
					t2 = l + s - l * s;
				t1 = 2 * l - t2;

				rgb = [0, 0, 0];
				for (var i = 0; i < 3; i++) {
					t3 = h + 1 / 3 * -(i - 1);
					if (t3 < 0) t3++;
					if (t3 > 1) t3--;

					if (6 * t3 < 1)
						val = t1 + (t2 - t1) * 6 * t3;
					else if (2 * t3 < 1)
						val = t2;
					else if (3 * t3 < 2)
						val = t1 + (t2 - t1) * (2 / 3 - t3) * 6;
					else
						val = t1;

					rgb[i] = val * 255;
				}

				return rgb;
			},
			hsl2hsv: function hsl2hsv(hsl) {
				var h = hsl[0],
					s = hsl[1] / 100,
					l = hsl[2] / 100,
					sv, v;
				l *= 2;
				s *= (l <= 1) ? l : 2 - l;
				v = (l + s) / 2;
				sv = (2 * s) / (l + s);
				return [h, sv * 100, v * 100];
			},
			hsv2rgb: function hsv2rgb(hsv) {
				var h = hsv[0] / 60
				var s = hsv[1] / 100
				var v = hsv[2] / 100
				var hi = Math.floor(h) % 6

				var f = h - Math.floor(h)
				var p = 255 * v * (1 - s)
				var q = 255 * v * (1 - (s * f))
				var t = 255 * v * (1 - (s * (1 - f)))

				v = 255 * v

				switch (hi) {
					case 0:
						return [v, t, p]
					case 1:
						return [q, v, p]
					case 2:
						return [p, v, t]
					case 3:
						return [p, q, v]
					case 4:
						return [t, p, v]
					case 5:
						return [v, p, q]
				}
			},
			hsv2hsl: function hsv2hsl(hsv) {
				var h = hsv[0],
					s = hsv[1] / 100,
					v = hsv[2] / 100,
					sl, l;

				l = (2 - s) * v;
				sl = s * v;
				sl /= (l <= 1) ? l : 2 - l;
				l /= 2;
				return [h, sl * 100, l * 100];
			},
			// http://www.140byt.es/keywords/color
			rgb2hex: function(
				a, // red, as a number from 0 to 255
				b, // green, as a number from 0 to 255
				c // blue, as a number from 0 to 255
			) {
				return "#" + ((256 + a << 8 | b) << 8 | c).toString(16).slice(1)
			},
			hex2rgb: function(
				a // take a "#xxxxxx" hex string,
			) {
				a = '0x' + a.slice(1).replace(a.length > 4 ? a : /./g, '$&$&') | 0;
				return [a >> 16, a >> 8 & 255, a & 255]
			}
		}

	/***/ },
	/* 12 */
	/***/ function(module, exports) {

		/*
		    ## Color 字典数据

		    字典数据来源 [A nicer color palette for the web](http://clrs.cc/)
		*/
		module.exports = {
		    // name value nicer
		    navy: {
		        value: '#000080',
		        nicer: '#001F3F'
		    },
		    blue: {
		        value: '#0000ff',
		        nicer: '#0074D9'
		    },
		    aqua: {
		        value: '#00ffff',
		        nicer: '#7FDBFF'
		    },
		    teal: {
		        value: '#008080',
		        nicer: '#39CCCC'
		    },
		    olive: {
		        value: '#008000',
		        nicer: '#3D9970'
		    },
		    green: {
		        value: '#008000',
		        nicer: '#2ECC40'
		    },
		    lime: {
		        value: '#00ff00',
		        nicer: '#01FF70'
		    },
		    yellow: {
		        value: '#ffff00',
		        nicer: '#FFDC00'
		    },
		    orange: {
		        value: '#ffa500',
		        nicer: '#FF851B'
		    },
		    red: {
		        value: '#ff0000',
		        nicer: '#FF4136'
		    },
		    maroon: {
		        value: '#800000',
		        nicer: '#85144B'
		    },
		    fuchsia: {
		        value: '#ff00ff',
		        nicer: '#F012BE'
		    },
		    purple: {
		        value: '#800080',
		        nicer: '#B10DC9'
		    },
		    silver: {
		        value: '#c0c0c0',
		        nicer: '#DDDDDD'
		    },
		    gray: {
		        value: '#808080',
		        nicer: '#AAAAAA'
		    },
		    black: {
		        value: '#000000',
		        nicer: '#111111'
		    },
		    white: {
		        value: '#FFFFFF',
		        nicer: '#FFFFFF'
		    }
		}

	/***/ },
	/* 13 */
	/***/ function(module, exports, __webpack_require__) {

		/*
		    ## Text

		    http://www.lipsum.com/
		*/
		var Basic = __webpack_require__(6)
		var Helper = __webpack_require__(14)

		function range(defaultMin, defaultMax, min, max) {
		    return min === undefined ? Basic.natural(defaultMin, defaultMax) : // ()
		        max === undefined ? min : // ( len )
		        Basic.natural(parseInt(min, 10), parseInt(max, 10)) // ( min, max )
		}

		module.exports = {
		    // 随机生成一段文本。
		    paragraph: function(min, max) {
		        var len = range(3, 7, min, max)
		        var result = []
		        for (var i = 0; i < len; i++) {
		            result.push(this.sentence())
		        }
		        return result.join(' ')
		    },
		    // 
		    cparagraph: function(min, max) {
		        var len = range(3, 7, min, max)
		        var result = []
		        for (var i = 0; i < len; i++) {
		            result.push(this.csentence())
		        }
		        return result.join('')
		    },
		    // 随机生成一个句子，第一个单词的首字母大写。
		    sentence: function(min, max) {
		        var len = range(12, 18, min, max)
		        var result = []
		        for (var i = 0; i < len; i++) {
		            result.push(this.word())
		        }
		        return Helper.capitalize(result.join(' ')) + '.'
		    },
		    // 随机生成一个中文句子。
		    csentence: function(min, max) {
		        var len = range(12, 18, min, max)
		        var result = []
		        for (var i = 0; i < len; i++) {
		            result.push(this.cword())
		        }

		        return result.join('') + '。'
		    },
		    // 随机生成一个单词。
		    word: function(min, max) {
		        var len = range(3, 10, min, max)
		        var result = '';
		        for (var i = 0; i < len; i++) {
		            result += Basic.character('lower')
		        }
		        return result
		    },
		    // 随机生成一个或多个汉字。
		    cword: function(pool, min, max) {
		        // 最常用的 500 个汉字 http://baike.baidu.com/view/568436.htm
		        var DICT_KANZI = '的一是在不了有和人这中大为上个国我以要他时来用们生到作地于出就分对成会可主发年动同工也能下过子说产种面而方后多定行学法所民得经十三之进着等部度家电力里如水化高自二理起小物现实加量都两体制机当使点从业本去把性好应开它合还因由其些然前外天政四日那社义事平形相全表间样与关各重新线内数正心反你明看原又么利比或但质气第向道命此变条只没结解问意建月公无系军很情者最立代想已通并提直题党程展五果料象员革位入常文总次品式活设及管特件长求老头基资边流路级少图山统接知较将组见计别她手角期根论运农指几九区强放决西被干做必战先回则任取据处队南给色光门即保治北造百规热领七海口东导器压志世金增争济阶油思术极交受联什认六共权收证改清己美再采转更单风切打白教速花带安场身车例真务具万每目至达走积示议声报斗完类八离华名确才科张信马节话米整空元况今集温传土许步群广石记需段研界拉林律叫且究观越织装影算低持音众书布复容儿须际商非验连断深难近矿千周委素技备半办青省列习响约支般史感劳便团往酸历市克何除消构府称太准精值号率族维划选标写存候毛亲快效斯院查江型眼王按格养易置派层片始却专状育厂京识适属圆包火住调满县局照参红细引听该铁价严龙飞'

		        var len
		        switch (arguments.length) {
		            case 0: // ()
		                pool = DICT_KANZI
		                len = 1
		                break
		            case 1: // ( pool )
		                if (typeof arguments[0] === 'string') {
		                    len = 1
		                } else {
		                    // ( length )
		                    len = pool
		                    pool = DICT_KANZI
		                }
		                break
		            case 2:
		                // ( pool, length )
		                if (typeof arguments[0] === 'string') {
		                    len = min
		                } else {
		                    // ( min, max )
		                    len = this.natural(pool, min)
		                    pool = DICT_KANZI
		                }
		                break
		            case 3:
		                len = this.natural(min, max)
		                break
		        }

		        var result = ''
		        for (var i = 0; i < len; i++) {
		            result += pool.charAt(this.natural(0, pool.length - 1))
		        }
		        return result
		    },
		    // 随机生成一句标题，其中每个单词的首字母大写。
		    title: function(min, max) {
		        var len = range(3, 7, min, max)
		        var result = []
		        for (var i = 0; i < len; i++) {
		            result.push(this.capitalize(this.word()))
		        }
		        return result.join(' ')
		    },
		    // 随机生成一句中文标题。
		    ctitle: function(min, max) {
		        var len = range(3, 7, min, max)
		        var result = []
		        for (var i = 0; i < len; i++) {
		            result.push(this.cword())
		        }
		        return result.join('')
		    }
		}

	/***/ },
	/* 14 */
	/***/ function(module, exports, __webpack_require__) {

		/*
		    ## Helpers
		*/

		var Util = __webpack_require__(3)

		module.exports = {
			// 把字符串的第一个字母转换为大写。
			capitalize: function(word) {
				return (word + '').charAt(0).toUpperCase() + (word + '').substr(1)
			},
			// 把字符串转换为大写。
			upper: function(str) {
				return (str + '').toUpperCase()
			},
			// 把字符串转换为小写。
			lower: function(str) {
				return (str + '').toLowerCase()
			},
			// 从数组中随机选取一个元素，并返回。
			pick: function pick(arr, min, max) {
				// pick( item1, item2 ... )
				if (!Util.isArray(arr)) {
					arr = [].slice.call(arguments)
					min = 1
					max = 1
				} else {
					// pick( [ item1, item2 ... ] )
					if (min === undefined) min = 1

					// pick( [ item1, item2 ... ], count )
					if (max === undefined) max = min
				}

				if (min === 1 && max === 1) return arr[this.natural(0, arr.length - 1)]

				// pick( [ item1, item2 ... ], min, max )
				return this.shuffle(arr, min, max)

				// 通过参数个数判断方法签名，扩展性太差！#90
				// switch (arguments.length) {
				// 	case 1:
				// 		// pick( [ item1, item2 ... ] )
				// 		return arr[this.natural(0, arr.length - 1)]
				// 	case 2:
				// 		// pick( [ item1, item2 ... ], count )
				// 		max = min
				// 			/* falls through */
				// 	case 3:
				// 		// pick( [ item1, item2 ... ], min, max )
				// 		return this.shuffle(arr, min, max)
				// }
			},
			/*
			    打乱数组中元素的顺序，并返回。
			    Given an array, scramble the order and return it.

			    其他的实现思路：
			        // https://code.google.com/p/jslibs/wiki/JavascriptTips
			        result = result.sort(function() {
			            return Math.random() - 0.5
			        })
			*/
			shuffle: function shuffle(arr, min, max) {
				arr = arr || []
				var old = arr.slice(0),
					result = [],
					index = 0,
					length = old.length;
				for (var i = 0; i < length; i++) {
					index = this.natural(0, old.length - 1)
					result.push(old[index])
					old.splice(index, 1)
				}
				switch (arguments.length) {
					case 0:
					case 1:
						return result
					case 2:
						max = min
							/* falls through */
					case 3:
						min = parseInt(min, 10)
						max = parseInt(max, 10)
						return result.slice(0, this.natural(min, max))
				}
			},
			/*
			    * Random.order(item, item)
			    * Random.order([item, item ...])

			    顺序获取数组中的元素

			    [JSON导入数组支持数组数据录入](https://github.com/thx/RAP/issues/22)

			    不支持单独调用！
			*/
			order: function order(array) {
				order.cache = order.cache || {}

				if (arguments.length > 1) array = [].slice.call(arguments, 0)

				// options.context.path/templatePath
				var options = order.options
				var templatePath = options.context.templatePath.join('.')

				var cache = (
					order.cache[templatePath] = order.cache[templatePath] || {
						index: 0,
						array: array
					}
				)

				return cache.array[cache.index++ % cache.array.length]
			}
		}

	/***/ },
	/* 15 */
	/***/ function(module, exports) {

		/*
		    ## Name

		    [Beyond the Top 1000 Names](http://www.ssa.gov/oact/babynames/limits.html)
		*/
		module.exports = {
			// 随机生成一个常见的英文名。
			first: function() {
				var names = [
					// male
					"James", "John", "Robert", "Michael", "William",
					"David", "Richard", "Charles", "Joseph", "Thomas",
					"Christopher", "Daniel", "Paul", "Mark", "Donald",
					"George", "Kenneth", "Steven", "Edward", "Brian",
					"Ronald", "Anthony", "Kevin", "Jason", "Matthew",
					"Gary", "Timothy", "Jose", "Larry", "Jeffrey",
					"Frank", "Scott", "Eric"
				].concat([
					// female
					"Mary", "Patricia", "Linda", "Barbara", "Elizabeth",
					"Jennifer", "Maria", "Susan", "Margaret", "Dorothy",
					"Lisa", "Nancy", "Karen", "Betty", "Helen",
					"Sandra", "Donna", "Carol", "Ruth", "Sharon",
					"Michelle", "Laura", "Sarah", "Kimberly", "Deborah",
					"Jessica", "Shirley", "Cynthia", "Angela", "Melissa",
					"Brenda", "Amy", "Anna"
				])
				return this.pick(names)
					// or this.capitalize(this.word())
			},
			// 随机生成一个常见的英文姓。
			last: function() {
				var names = [
					"Smith", "Johnson", "Williams", "Brown", "Jones",
					"Miller", "Davis", "Garcia", "Rodriguez", "Wilson",
					"Martinez", "Anderson", "Taylor", "Thomas", "Hernandez",
					"Moore", "Martin", "Jackson", "Thompson", "White",
					"Lopez", "Lee", "Gonzalez", "Harris", "Clark",
					"Lewis", "Robinson", "Walker", "Perez", "Hall",
					"Young", "Allen"
				]
				return this.pick(names)
					// or this.capitalize(this.word())
			},
			// 随机生成一个常见的英文姓名。
			name: function(middle) {
				return this.first() + ' ' +
					(middle ? this.first() + ' ' : '') +
					this.last()
			},
			/*
			    随机生成一个常见的中文姓。
			    [世界常用姓氏排行](http://baike.baidu.com/view/1719115.htm)
			    [玄派网 - 网络小说创作辅助平台](http://xuanpai.sinaapp.com/)
			 */
			cfirst: function() {
				var names = (
					'王 李 张 刘 陈 杨 赵 黄 周 吴 ' +
					'徐 孙 胡 朱 高 林 何 郭 马 罗 ' +
					'梁 宋 郑 谢 韩 唐 冯 于 董 萧 ' +
					'程 曹 袁 邓 许 傅 沈 曾 彭 吕 ' +
					'苏 卢 蒋 蔡 贾 丁 魏 薛 叶 阎 ' +
					'余 潘 杜 戴 夏 锺 汪 田 任 姜 ' +
					'范 方 石 姚 谭 廖 邹 熊 金 陆 ' +
					'郝 孔 白 崔 康 毛 邱 秦 江 史 ' +
					'顾 侯 邵 孟 龙 万 段 雷 钱 汤 ' +
					'尹 黎 易 常 武 乔 贺 赖 龚 文'
				).split(' ')
				return this.pick(names)
			},
			/*
			    随机生成一个常见的中文名。
			    [中国最常见名字前50名_三九算命网](http://www.name999.net/xingming/xingshi/20131004/48.html)
			 */
			clast: function() {
				var names = (
					'伟 芳 娜 秀英 敏 静 丽 强 磊 军 ' +
					'洋 勇 艳 杰 娟 涛 明 超 秀兰 霞 ' +
					'平 刚 桂英'
				).split(' ')
				return this.pick(names)
			},
			// 随机生成一个常见的中文姓名。
			cname: function() {
				return this.cfirst() + this.clast()
			}
		}

	/***/ },
	/* 16 */
	/***/ function(module, exports) {

		/*
		    ## Web
		*/
		module.exports = {
		    /*
		        随机生成一个 URL。

		        [URL 规范](http://www.w3.org/Addressing/URL/url-spec.txt)
		            http                    Hypertext Transfer Protocol 
		            ftp                     File Transfer protocol 
		            gopher                  The Gopher protocol 
		            mailto                  Electronic mail address 
		            mid                     Message identifiers for electronic mail 
		            cid                     Content identifiers for MIME body part 
		            news                    Usenet news 
		            nntp                    Usenet news for local NNTP access only 
		            prospero                Access using the prospero protocols 
		            telnet rlogin tn3270    Reference to interactive sessions
		            wais                    Wide Area Information Servers 
		    */
		    url: function(protocol, host) {
		        return (protocol || this.protocol()) + '://' + // protocol?
		            (host || this.domain()) + // host?
		            '/' + this.word()
		    },
		    // 随机生成一个 URL 协议。
		    protocol: function() {
		        return this.pick(
		            // 协议簇
		            'http ftp gopher mailto mid cid news nntp prospero telnet rlogin tn3270 wais'.split(' ')
		        )
		    },
		    // 随机生成一个域名。
		    domain: function(tld) {
		        return this.word() + '.' + (tld || this.tld())
		    },
		    /*
		        随机生成一个顶级域名。
		        国际顶级域名 international top-level domain-names, iTLDs
		        国家顶级域名 national top-level domainnames, nTLDs
		        [域名后缀大全](http://www.163ns.com/zixun/post/4417.html)
		    */
		    tld: function() { // Top Level Domain
		        return this.pick(
		            (
		                // 域名后缀
		                'com net org edu gov int mil cn ' +
		                // 国内域名
		                'com.cn net.cn gov.cn org.cn ' +
		                // 中文国内域名
		                '中国 中国互联.公司 中国互联.网络 ' +
		                // 新国际域名
		                'tel biz cc tv info name hk mobi asia cd travel pro museum coop aero ' +
		                // 世界各国域名后缀
		                'ad ae af ag ai al am an ao aq ar as at au aw az ba bb bd be bf bg bh bi bj bm bn bo br bs bt bv bw by bz ca cc cf cg ch ci ck cl cm cn co cq cr cu cv cx cy cz de dj dk dm do dz ec ee eg eh es et ev fi fj fk fm fo fr ga gb gd ge gf gh gi gl gm gn gp gr gt gu gw gy hk hm hn hr ht hu id ie il in io iq ir is it jm jo jp ke kg kh ki km kn kp kr kw ky kz la lb lc li lk lr ls lt lu lv ly ma mc md mg mh ml mm mn mo mp mq mr ms mt mv mw mx my mz na nc ne nf ng ni nl no np nr nt nu nz om qa pa pe pf pg ph pk pl pm pn pr pt pw py re ro ru rw sa sb sc sd se sg sh si sj sk sl sm sn so sr st su sy sz tc td tf tg th tj tk tm tn to tp tr tt tv tw tz ua ug uk us uy va vc ve vg vn vu wf ws ye yu za zm zr zw'
		            ).split(' ')
		        )
		    },
		    // 随机生成一个邮件地址。
		    email: function(domain) {
		        return this.character('lower') + '.' + this.word() + '@' +
		            (
		                domain ||
		                (this.word() + '.' + this.tld())
		            )
		            // return this.character('lower') + '.' + this.last().toLowerCase() + '@' + this.last().toLowerCase() + '.' + this.tld()
		            // return this.word() + '@' + (domain || this.domain())
		    },
		    // 随机生成一个 IP 地址。
		    ip: function() {
		        return this.natural(0, 255) + '.' +
		            this.natural(0, 255) + '.' +
		            this.natural(0, 255) + '.' +
		            this.natural(0, 255)
		    }
		}

	/***/ },
	/* 17 */
	/***/ function(module, exports, __webpack_require__) {

		/*
		    ## Address
		*/

		var DICT = __webpack_require__(18)
		var REGION = ['东北', '华北', '华东', '华中', '华南', '西南', '西北']

		module.exports = {
		    // 随机生成一个大区。
		    region: function() {
		        return this.pick(REGION)
		    },
		    // 随机生成一个（中国）省（或直辖市、自治区、特别行政区）。
		    province: function() {
		        return this.pick(DICT).name
		    },
		    // 随机生成一个（中国）市。
		    city: function(prefix) {
		        var province = this.pick(DICT)
		        var city = this.pick(province.children)
		        return prefix ? [province.name, city.name].join(' ') : city.name
		    },
		    // 随机生成一个（中国）县。
		    county: function(prefix) {
		        var province = this.pick(DICT)
		        var city = this.pick(province.children)
		        var county = this.pick(city.children) || {
		            name: '-'
		        }
		        return prefix ? [province.name, city.name, county.name].join(' ') : county.name
		    },
		    // 随机生成一个邮政编码（六位数字）。
		    zip: function(len) {
		        var zip = ''
		        for (var i = 0; i < (len || 6); i++) zip += this.natural(0, 9)
		        return zip
		    }

		    // address: function() {},
		    // phone: function() {},
		    // areacode: function() {},
		    // street: function() {},
		    // street_suffixes: function() {},
		    // street_suffix: function() {},
		    // states: function() {},
		    // state: function() {},
		}

	/***/ },
	/* 18 */
	/***/ function(module, exports) {

		/*
		    ## Address 字典数据

		    字典数据来源 http://www.atatech.org/articles/30028?rnd=254259856

		    国标 省（市）级行政区划码表

		    华北   北京市 天津市 河北省 山西省 内蒙古自治区
		    东北   辽宁省 吉林省 黑龙江省
		    华东   上海市 江苏省 浙江省 安徽省 福建省 江西省 山东省
		    华南   广东省 广西壮族自治区 海南省
		    华中   河南省 湖北省 湖南省
		    西南   重庆市 四川省 贵州省 云南省 西藏自治区
		    西北   陕西省 甘肃省 青海省 宁夏回族自治区 新疆维吾尔自治区
		    港澳台 香港特别行政区 澳门特别行政区 台湾省
		    
		    **排序**
		    
		    ```js
		    var map = {}
		    _.each(_.keys(REGIONS),function(id){
		      map[id] = REGIONS[ID]
		    })
		    JSON.stringify(map)
		    ```
		*/
		var DICT = {
		    "110000": "北京",
		    "110100": "北京市",
		    "110101": "东城区",
		    "110102": "西城区",
		    "110105": "朝阳区",
		    "110106": "丰台区",
		    "110107": "石景山区",
		    "110108": "海淀区",
		    "110109": "门头沟区",
		    "110111": "房山区",
		    "110112": "通州区",
		    "110113": "顺义区",
		    "110114": "昌平区",
		    "110115": "大兴区",
		    "110116": "怀柔区",
		    "110117": "平谷区",
		    "110228": "密云县",
		    "110229": "延庆县",
		    "110230": "其它区",
		    "120000": "天津",
		    "120100": "天津市",
		    "120101": "和平区",
		    "120102": "河东区",
		    "120103": "河西区",
		    "120104": "南开区",
		    "120105": "河北区",
		    "120106": "红桥区",
		    "120110": "东丽区",
		    "120111": "西青区",
		    "120112": "津南区",
		    "120113": "北辰区",
		    "120114": "武清区",
		    "120115": "宝坻区",
		    "120116": "滨海新区",
		    "120221": "宁河县",
		    "120223": "静海县",
		    "120225": "蓟县",
		    "120226": "其它区",
		    "130000": "河北省",
		    "130100": "石家庄市",
		    "130102": "长安区",
		    "130103": "桥东区",
		    "130104": "桥西区",
		    "130105": "新华区",
		    "130107": "井陉矿区",
		    "130108": "裕华区",
		    "130121": "井陉县",
		    "130123": "正定县",
		    "130124": "栾城县",
		    "130125": "行唐县",
		    "130126": "灵寿县",
		    "130127": "高邑县",
		    "130128": "深泽县",
		    "130129": "赞皇县",
		    "130130": "无极县",
		    "130131": "平山县",
		    "130132": "元氏县",
		    "130133": "赵县",
		    "130181": "辛集市",
		    "130182": "藁城市",
		    "130183": "晋州市",
		    "130184": "新乐市",
		    "130185": "鹿泉市",
		    "130186": "其它区",
		    "130200": "唐山市",
		    "130202": "路南区",
		    "130203": "路北区",
		    "130204": "古冶区",
		    "130205": "开平区",
		    "130207": "丰南区",
		    "130208": "丰润区",
		    "130223": "滦县",
		    "130224": "滦南县",
		    "130225": "乐亭县",
		    "130227": "迁西县",
		    "130229": "玉田县",
		    "130230": "曹妃甸区",
		    "130281": "遵化市",
		    "130283": "迁安市",
		    "130284": "其它区",
		    "130300": "秦皇岛市",
		    "130302": "海港区",
		    "130303": "山海关区",
		    "130304": "北戴河区",
		    "130321": "青龙满族自治县",
		    "130322": "昌黎县",
		    "130323": "抚宁县",
		    "130324": "卢龙县",
		    "130398": "其它区",
		    "130400": "邯郸市",
		    "130402": "邯山区",
		    "130403": "丛台区",
		    "130404": "复兴区",
		    "130406": "峰峰矿区",
		    "130421": "邯郸县",
		    "130423": "临漳县",
		    "130424": "成安县",
		    "130425": "大名县",
		    "130426": "涉县",
		    "130427": "磁县",
		    "130428": "肥乡县",
		    "130429": "永年县",
		    "130430": "邱县",
		    "130431": "鸡泽县",
		    "130432": "广平县",
		    "130433": "馆陶县",
		    "130434": "魏县",
		    "130435": "曲周县",
		    "130481": "武安市",
		    "130482": "其它区",
		    "130500": "邢台市",
		    "130502": "桥东区",
		    "130503": "桥西区",
		    "130521": "邢台县",
		    "130522": "临城县",
		    "130523": "内丘县",
		    "130524": "柏乡县",
		    "130525": "隆尧县",
		    "130526": "任县",
		    "130527": "南和县",
		    "130528": "宁晋县",
		    "130529": "巨鹿县",
		    "130530": "新河县",
		    "130531": "广宗县",
		    "130532": "平乡县",
		    "130533": "威县",
		    "130534": "清河县",
		    "130535": "临西县",
		    "130581": "南宫市",
		    "130582": "沙河市",
		    "130583": "其它区",
		    "130600": "保定市",
		    "130602": "新市区",
		    "130603": "北市区",
		    "130604": "南市区",
		    "130621": "满城县",
		    "130622": "清苑县",
		    "130623": "涞水县",
		    "130624": "阜平县",
		    "130625": "徐水县",
		    "130626": "定兴县",
		    "130627": "唐县",
		    "130628": "高阳县",
		    "130629": "容城县",
		    "130630": "涞源县",
		    "130631": "望都县",
		    "130632": "安新县",
		    "130633": "易县",
		    "130634": "曲阳县",
		    "130635": "蠡县",
		    "130636": "顺平县",
		    "130637": "博野县",
		    "130638": "雄县",
		    "130681": "涿州市",
		    "130682": "定州市",
		    "130683": "安国市",
		    "130684": "高碑店市",
		    "130699": "其它区",
		    "130700": "张家口市",
		    "130702": "桥东区",
		    "130703": "桥西区",
		    "130705": "宣化区",
		    "130706": "下花园区",
		    "130721": "宣化县",
		    "130722": "张北县",
		    "130723": "康保县",
		    "130724": "沽源县",
		    "130725": "尚义县",
		    "130726": "蔚县",
		    "130727": "阳原县",
		    "130728": "怀安县",
		    "130729": "万全县",
		    "130730": "怀来县",
		    "130731": "涿鹿县",
		    "130732": "赤城县",
		    "130733": "崇礼县",
		    "130734": "其它区",
		    "130800": "承德市",
		    "130802": "双桥区",
		    "130803": "双滦区",
		    "130804": "鹰手营子矿区",
		    "130821": "承德县",
		    "130822": "兴隆县",
		    "130823": "平泉县",
		    "130824": "滦平县",
		    "130825": "隆化县",
		    "130826": "丰宁满族自治县",
		    "130827": "宽城满族自治县",
		    "130828": "围场满族蒙古族自治县",
		    "130829": "其它区",
		    "130900": "沧州市",
		    "130902": "新华区",
		    "130903": "运河区",
		    "130921": "沧县",
		    "130922": "青县",
		    "130923": "东光县",
		    "130924": "海兴县",
		    "130925": "盐山县",
		    "130926": "肃宁县",
		    "130927": "南皮县",
		    "130928": "吴桥县",
		    "130929": "献县",
		    "130930": "孟村回族自治县",
		    "130981": "泊头市",
		    "130982": "任丘市",
		    "130983": "黄骅市",
		    "130984": "河间市",
		    "130985": "其它区",
		    "131000": "廊坊市",
		    "131002": "安次区",
		    "131003": "广阳区",
		    "131022": "固安县",
		    "131023": "永清县",
		    "131024": "香河县",
		    "131025": "大城县",
		    "131026": "文安县",
		    "131028": "大厂回族自治县",
		    "131081": "霸州市",
		    "131082": "三河市",
		    "131083": "其它区",
		    "131100": "衡水市",
		    "131102": "桃城区",
		    "131121": "枣强县",
		    "131122": "武邑县",
		    "131123": "武强县",
		    "131124": "饶阳县",
		    "131125": "安平县",
		    "131126": "故城县",
		    "131127": "景县",
		    "131128": "阜城县",
		    "131181": "冀州市",
		    "131182": "深州市",
		    "131183": "其它区",
		    "140000": "山西省",
		    "140100": "太原市",
		    "140105": "小店区",
		    "140106": "迎泽区",
		    "140107": "杏花岭区",
		    "140108": "尖草坪区",
		    "140109": "万柏林区",
		    "140110": "晋源区",
		    "140121": "清徐县",
		    "140122": "阳曲县",
		    "140123": "娄烦县",
		    "140181": "古交市",
		    "140182": "其它区",
		    "140200": "大同市",
		    "140202": "城区",
		    "140203": "矿区",
		    "140211": "南郊区",
		    "140212": "新荣区",
		    "140221": "阳高县",
		    "140222": "天镇县",
		    "140223": "广灵县",
		    "140224": "灵丘县",
		    "140225": "浑源县",
		    "140226": "左云县",
		    "140227": "大同县",
		    "140228": "其它区",
		    "140300": "阳泉市",
		    "140302": "城区",
		    "140303": "矿区",
		    "140311": "郊区",
		    "140321": "平定县",
		    "140322": "盂县",
		    "140323": "其它区",
		    "140400": "长治市",
		    "140421": "长治县",
		    "140423": "襄垣县",
		    "140424": "屯留县",
		    "140425": "平顺县",
		    "140426": "黎城县",
		    "140427": "壶关县",
		    "140428": "长子县",
		    "140429": "武乡县",
		    "140430": "沁县",
		    "140431": "沁源县",
		    "140481": "潞城市",
		    "140482": "城区",
		    "140483": "郊区",
		    "140485": "其它区",
		    "140500": "晋城市",
		    "140502": "城区",
		    "140521": "沁水县",
		    "140522": "阳城县",
		    "140524": "陵川县",
		    "140525": "泽州县",
		    "140581": "高平市",
		    "140582": "其它区",
		    "140600": "朔州市",
		    "140602": "朔城区",
		    "140603": "平鲁区",
		    "140621": "山阴县",
		    "140622": "应县",
		    "140623": "右玉县",
		    "140624": "怀仁县",
		    "140625": "其它区",
		    "140700": "晋中市",
		    "140702": "榆次区",
		    "140721": "榆社县",
		    "140722": "左权县",
		    "140723": "和顺县",
		    "140724": "昔阳县",
		    "140725": "寿阳县",
		    "140726": "太谷县",
		    "140727": "祁县",
		    "140728": "平遥县",
		    "140729": "灵石县",
		    "140781": "介休市",
		    "140782": "其它区",
		    "140800": "运城市",
		    "140802": "盐湖区",
		    "140821": "临猗县",
		    "140822": "万荣县",
		    "140823": "闻喜县",
		    "140824": "稷山县",
		    "140825": "新绛县",
		    "140826": "绛县",
		    "140827": "垣曲县",
		    "140828": "夏县",
		    "140829": "平陆县",
		    "140830": "芮城县",
		    "140881": "永济市",
		    "140882": "河津市",
		    "140883": "其它区",
		    "140900": "忻州市",
		    "140902": "忻府区",
		    "140921": "定襄县",
		    "140922": "五台县",
		    "140923": "代县",
		    "140924": "繁峙县",
		    "140925": "宁武县",
		    "140926": "静乐县",
		    "140927": "神池县",
		    "140928": "五寨县",
		    "140929": "岢岚县",
		    "140930": "河曲县",
		    "140931": "保德县",
		    "140932": "偏关县",
		    "140981": "原平市",
		    "140982": "其它区",
		    "141000": "临汾市",
		    "141002": "尧都区",
		    "141021": "曲沃县",
		    "141022": "翼城县",
		    "141023": "襄汾县",
		    "141024": "洪洞县",
		    "141025": "古县",
		    "141026": "安泽县",
		    "141027": "浮山县",
		    "141028": "吉县",
		    "141029": "乡宁县",
		    "141030": "大宁县",
		    "141031": "隰县",
		    "141032": "永和县",
		    "141033": "蒲县",
		    "141034": "汾西县",
		    "141081": "侯马市",
		    "141082": "霍州市",
		    "141083": "其它区",
		    "141100": "吕梁市",
		    "141102": "离石区",
		    "141121": "文水县",
		    "141122": "交城县",
		    "141123": "兴县",
		    "141124": "临县",
		    "141125": "柳林县",
		    "141126": "石楼县",
		    "141127": "岚县",
		    "141128": "方山县",
		    "141129": "中阳县",
		    "141130": "交口县",
		    "141181": "孝义市",
		    "141182": "汾阳市",
		    "141183": "其它区",
		    "150000": "内蒙古自治区",
		    "150100": "呼和浩特市",
		    "150102": "新城区",
		    "150103": "回民区",
		    "150104": "玉泉区",
		    "150105": "赛罕区",
		    "150121": "土默特左旗",
		    "150122": "托克托县",
		    "150123": "和林格尔县",
		    "150124": "清水河县",
		    "150125": "武川县",
		    "150126": "其它区",
		    "150200": "包头市",
		    "150202": "东河区",
		    "150203": "昆都仑区",
		    "150204": "青山区",
		    "150205": "石拐区",
		    "150206": "白云鄂博矿区",
		    "150207": "九原区",
		    "150221": "土默特右旗",
		    "150222": "固阳县",
		    "150223": "达尔罕茂明安联合旗",
		    "150224": "其它区",
		    "150300": "乌海市",
		    "150302": "海勃湾区",
		    "150303": "海南区",
		    "150304": "乌达区",
		    "150305": "其它区",
		    "150400": "赤峰市",
		    "150402": "红山区",
		    "150403": "元宝山区",
		    "150404": "松山区",
		    "150421": "阿鲁科尔沁旗",
		    "150422": "巴林左旗",
		    "150423": "巴林右旗",
		    "150424": "林西县",
		    "150425": "克什克腾旗",
		    "150426": "翁牛特旗",
		    "150428": "喀喇沁旗",
		    "150429": "宁城县",
		    "150430": "敖汉旗",
		    "150431": "其它区",
		    "150500": "通辽市",
		    "150502": "科尔沁区",
		    "150521": "科尔沁左翼中旗",
		    "150522": "科尔沁左翼后旗",
		    "150523": "开鲁县",
		    "150524": "库伦旗",
		    "150525": "奈曼旗",
		    "150526": "扎鲁特旗",
		    "150581": "霍林郭勒市",
		    "150582": "其它区",
		    "150600": "鄂尔多斯市",
		    "150602": "东胜区",
		    "150621": "达拉特旗",
		    "150622": "准格尔旗",
		    "150623": "鄂托克前旗",
		    "150624": "鄂托克旗",
		    "150625": "杭锦旗",
		    "150626": "乌审旗",
		    "150627": "伊金霍洛旗",
		    "150628": "其它区",
		    "150700": "呼伦贝尔市",
		    "150702": "海拉尔区",
		    "150703": "扎赉诺尔区",
		    "150721": "阿荣旗",
		    "150722": "莫力达瓦达斡尔族自治旗",
		    "150723": "鄂伦春自治旗",
		    "150724": "鄂温克族自治旗",
		    "150725": "陈巴尔虎旗",
		    "150726": "新巴尔虎左旗",
		    "150727": "新巴尔虎右旗",
		    "150781": "满洲里市",
		    "150782": "牙克石市",
		    "150783": "扎兰屯市",
		    "150784": "额尔古纳市",
		    "150785": "根河市",
		    "150786": "其它区",
		    "150800": "巴彦淖尔市",
		    "150802": "临河区",
		    "150821": "五原县",
		    "150822": "磴口县",
		    "150823": "乌拉特前旗",
		    "150824": "乌拉特中旗",
		    "150825": "乌拉特后旗",
		    "150826": "杭锦后旗",
		    "150827": "其它区",
		    "150900": "乌兰察布市",
		    "150902": "集宁区",
		    "150921": "卓资县",
		    "150922": "化德县",
		    "150923": "商都县",
		    "150924": "兴和县",
		    "150925": "凉城县",
		    "150926": "察哈尔右翼前旗",
		    "150927": "察哈尔右翼中旗",
		    "150928": "察哈尔右翼后旗",
		    "150929": "四子王旗",
		    "150981": "丰镇市",
		    "150982": "其它区",
		    "152200": "兴安盟",
		    "152201": "乌兰浩特市",
		    "152202": "阿尔山市",
		    "152221": "科尔沁右翼前旗",
		    "152222": "科尔沁右翼中旗",
		    "152223": "扎赉特旗",
		    "152224": "突泉县",
		    "152225": "其它区",
		    "152500": "锡林郭勒盟",
		    "152501": "二连浩特市",
		    "152502": "锡林浩特市",
		    "152522": "阿巴嘎旗",
		    "152523": "苏尼特左旗",
		    "152524": "苏尼特右旗",
		    "152525": "东乌珠穆沁旗",
		    "152526": "西乌珠穆沁旗",
		    "152527": "太仆寺旗",
		    "152528": "镶黄旗",
		    "152529": "正镶白旗",
		    "152530": "正蓝旗",
		    "152531": "多伦县",
		    "152532": "其它区",
		    "152900": "阿拉善盟",
		    "152921": "阿拉善左旗",
		    "152922": "阿拉善右旗",
		    "152923": "额济纳旗",
		    "152924": "其它区",
		    "210000": "辽宁省",
		    "210100": "沈阳市",
		    "210102": "和平区",
		    "210103": "沈河区",
		    "210104": "大东区",
		    "210105": "皇姑区",
		    "210106": "铁西区",
		    "210111": "苏家屯区",
		    "210112": "东陵区",
		    "210113": "新城子区",
		    "210114": "于洪区",
		    "210122": "辽中县",
		    "210123": "康平县",
		    "210124": "法库县",
		    "210181": "新民市",
		    "210184": "沈北新区",
		    "210185": "其它区",
		    "210200": "大连市",
		    "210202": "中山区",
		    "210203": "西岗区",
		    "210204": "沙河口区",
		    "210211": "甘井子区",
		    "210212": "旅顺口区",
		    "210213": "金州区",
		    "210224": "长海县",
		    "210281": "瓦房店市",
		    "210282": "普兰店市",
		    "210283": "庄河市",
		    "210298": "其它区",
		    "210300": "鞍山市",
		    "210302": "铁东区",
		    "210303": "铁西区",
		    "210304": "立山区",
		    "210311": "千山区",
		    "210321": "台安县",
		    "210323": "岫岩满族自治县",
		    "210381": "海城市",
		    "210382": "其它区",
		    "210400": "抚顺市",
		    "210402": "新抚区",
		    "210403": "东洲区",
		    "210404": "望花区",
		    "210411": "顺城区",
		    "210421": "抚顺县",
		    "210422": "新宾满族自治县",
		    "210423": "清原满族自治县",
		    "210424": "其它区",
		    "210500": "本溪市",
		    "210502": "平山区",
		    "210503": "溪湖区",
		    "210504": "明山区",
		    "210505": "南芬区",
		    "210521": "本溪满族自治县",
		    "210522": "桓仁满族自治县",
		    "210523": "其它区",
		    "210600": "丹东市",
		    "210602": "元宝区",
		    "210603": "振兴区",
		    "210604": "振安区",
		    "210624": "宽甸满族自治县",
		    "210681": "东港市",
		    "210682": "凤城市",
		    "210683": "其它区",
		    "210700": "锦州市",
		    "210702": "古塔区",
		    "210703": "凌河区",
		    "210711": "太和区",
		    "210726": "黑山县",
		    "210727": "义县",
		    "210781": "凌海市",
		    "210782": "北镇市",
		    "210783": "其它区",
		    "210800": "营口市",
		    "210802": "站前区",
		    "210803": "西市区",
		    "210804": "鲅鱼圈区",
		    "210811": "老边区",
		    "210881": "盖州市",
		    "210882": "大石桥市",
		    "210883": "其它区",
		    "210900": "阜新市",
		    "210902": "海州区",
		    "210903": "新邱区",
		    "210904": "太平区",
		    "210905": "清河门区",
		    "210911": "细河区",
		    "210921": "阜新蒙古族自治县",
		    "210922": "彰武县",
		    "210923": "其它区",
		    "211000": "辽阳市",
		    "211002": "白塔区",
		    "211003": "文圣区",
		    "211004": "宏伟区",
		    "211005": "弓长岭区",
		    "211011": "太子河区",
		    "211021": "辽阳县",
		    "211081": "灯塔市",
		    "211082": "其它区",
		    "211100": "盘锦市",
		    "211102": "双台子区",
		    "211103": "兴隆台区",
		    "211121": "大洼县",
		    "211122": "盘山县",
		    "211123": "其它区",
		    "211200": "铁岭市",
		    "211202": "银州区",
		    "211204": "清河区",
		    "211221": "铁岭县",
		    "211223": "西丰县",
		    "211224": "昌图县",
		    "211281": "调兵山市",
		    "211282": "开原市",
		    "211283": "其它区",
		    "211300": "朝阳市",
		    "211302": "双塔区",
		    "211303": "龙城区",
		    "211321": "朝阳县",
		    "211322": "建平县",
		    "211324": "喀喇沁左翼蒙古族自治县",
		    "211381": "北票市",
		    "211382": "凌源市",
		    "211383": "其它区",
		    "211400": "葫芦岛市",
		    "211402": "连山区",
		    "211403": "龙港区",
		    "211404": "南票区",
		    "211421": "绥中县",
		    "211422": "建昌县",
		    "211481": "兴城市",
		    "211482": "其它区",
		    "220000": "吉林省",
		    "220100": "长春市",
		    "220102": "南关区",
		    "220103": "宽城区",
		    "220104": "朝阳区",
		    "220105": "二道区",
		    "220106": "绿园区",
		    "220112": "双阳区",
		    "220122": "农安县",
		    "220181": "九台市",
		    "220182": "榆树市",
		    "220183": "德惠市",
		    "220188": "其它区",
		    "220200": "吉林市",
		    "220202": "昌邑区",
		    "220203": "龙潭区",
		    "220204": "船营区",
		    "220211": "丰满区",
		    "220221": "永吉县",
		    "220281": "蛟河市",
		    "220282": "桦甸市",
		    "220283": "舒兰市",
		    "220284": "磐石市",
		    "220285": "其它区",
		    "220300": "四平市",
		    "220302": "铁西区",
		    "220303": "铁东区",
		    "220322": "梨树县",
		    "220323": "伊通满族自治县",
		    "220381": "公主岭市",
		    "220382": "双辽市",
		    "220383": "其它区",
		    "220400": "辽源市",
		    "220402": "龙山区",
		    "220403": "西安区",
		    "220421": "东丰县",
		    "220422": "东辽县",
		    "220423": "其它区",
		    "220500": "通化市",
		    "220502": "东昌区",
		    "220503": "二道江区",
		    "220521": "通化县",
		    "220523": "辉南县",
		    "220524": "柳河县",
		    "220581": "梅河口市",
		    "220582": "集安市",
		    "220583": "其它区",
		    "220600": "白山市",
		    "220602": "浑江区",
		    "220621": "抚松县",
		    "220622": "靖宇县",
		    "220623": "长白朝鲜族自治县",
		    "220625": "江源区",
		    "220681": "临江市",
		    "220682": "其它区",
		    "220700": "松原市",
		    "220702": "宁江区",
		    "220721": "前郭尔罗斯蒙古族自治县",
		    "220722": "长岭县",
		    "220723": "乾安县",
		    "220724": "扶余市",
		    "220725": "其它区",
		    "220800": "白城市",
		    "220802": "洮北区",
		    "220821": "镇赉县",
		    "220822": "通榆县",
		    "220881": "洮南市",
		    "220882": "大安市",
		    "220883": "其它区",
		    "222400": "延边朝鲜族自治州",
		    "222401": "延吉市",
		    "222402": "图们市",
		    "222403": "敦化市",
		    "222404": "珲春市",
		    "222405": "龙井市",
		    "222406": "和龙市",
		    "222424": "汪清县",
		    "222426": "安图县",
		    "222427": "其它区",
		    "230000": "黑龙江省",
		    "230100": "哈尔滨市",
		    "230102": "道里区",
		    "230103": "南岗区",
		    "230104": "道外区",
		    "230106": "香坊区",
		    "230108": "平房区",
		    "230109": "松北区",
		    "230111": "呼兰区",
		    "230123": "依兰县",
		    "230124": "方正县",
		    "230125": "宾县",
		    "230126": "巴彦县",
		    "230127": "木兰县",
		    "230128": "通河县",
		    "230129": "延寿县",
		    "230181": "阿城区",
		    "230182": "双城市",
		    "230183": "尚志市",
		    "230184": "五常市",
		    "230186": "其它区",
		    "230200": "齐齐哈尔市",
		    "230202": "龙沙区",
		    "230203": "建华区",
		    "230204": "铁锋区",
		    "230205": "昂昂溪区",
		    "230206": "富拉尔基区",
		    "230207": "碾子山区",
		    "230208": "梅里斯达斡尔族区",
		    "230221": "龙江县",
		    "230223": "依安县",
		    "230224": "泰来县",
		    "230225": "甘南县",
		    "230227": "富裕县",
		    "230229": "克山县",
		    "230230": "克东县",
		    "230231": "拜泉县",
		    "230281": "讷河市",
		    "230282": "其它区",
		    "230300": "鸡西市",
		    "230302": "鸡冠区",
		    "230303": "恒山区",
		    "230304": "滴道区",
		    "230305": "梨树区",
		    "230306": "城子河区",
		    "230307": "麻山区",
		    "230321": "鸡东县",
		    "230381": "虎林市",
		    "230382": "密山市",
		    "230383": "其它区",
		    "230400": "鹤岗市",
		    "230402": "向阳区",
		    "230403": "工农区",
		    "230404": "南山区",
		    "230405": "兴安区",
		    "230406": "东山区",
		    "230407": "兴山区",
		    "230421": "萝北县",
		    "230422": "绥滨县",
		    "230423": "其它区",
		    "230500": "双鸭山市",
		    "230502": "尖山区",
		    "230503": "岭东区",
		    "230505": "四方台区",
		    "230506": "宝山区",
		    "230521": "集贤县",
		    "230522": "友谊县",
		    "230523": "宝清县",
		    "230524": "饶河县",
		    "230525": "其它区",
		    "230600": "大庆市",
		    "230602": "萨尔图区",
		    "230603": "龙凤区",
		    "230604": "让胡路区",
		    "230605": "红岗区",
		    "230606": "大同区",
		    "230621": "肇州县",
		    "230622": "肇源县",
		    "230623": "林甸县",
		    "230624": "杜尔伯特蒙古族自治县",
		    "230625": "其它区",
		    "230700": "伊春市",
		    "230702": "伊春区",
		    "230703": "南岔区",
		    "230704": "友好区",
		    "230705": "西林区",
		    "230706": "翠峦区",
		    "230707": "新青区",
		    "230708": "美溪区",
		    "230709": "金山屯区",
		    "230710": "五营区",
		    "230711": "乌马河区",
		    "230712": "汤旺河区",
		    "230713": "带岭区",
		    "230714": "乌伊岭区",
		    "230715": "红星区",
		    "230716": "上甘岭区",
		    "230722": "嘉荫县",
		    "230781": "铁力市",
		    "230782": "其它区",
		    "230800": "佳木斯市",
		    "230803": "向阳区",
		    "230804": "前进区",
		    "230805": "东风区",
		    "230811": "郊区",
		    "230822": "桦南县",
		    "230826": "桦川县",
		    "230828": "汤原县",
		    "230833": "抚远县",
		    "230881": "同江市",
		    "230882": "富锦市",
		    "230883": "其它区",
		    "230900": "七台河市",
		    "230902": "新兴区",
		    "230903": "桃山区",
		    "230904": "茄子河区",
		    "230921": "勃利县",
		    "230922": "其它区",
		    "231000": "牡丹江市",
		    "231002": "东安区",
		    "231003": "阳明区",
		    "231004": "爱民区",
		    "231005": "西安区",
		    "231024": "东宁县",
		    "231025": "林口县",
		    "231081": "绥芬河市",
		    "231083": "海林市",
		    "231084": "宁安市",
		    "231085": "穆棱市",
		    "231086": "其它区",
		    "231100": "黑河市",
		    "231102": "爱辉区",
		    "231121": "嫩江县",
		    "231123": "逊克县",
		    "231124": "孙吴县",
		    "231181": "北安市",
		    "231182": "五大连池市",
		    "231183": "其它区",
		    "231200": "绥化市",
		    "231202": "北林区",
		    "231221": "望奎县",
		    "231222": "兰西县",
		    "231223": "青冈县",
		    "231224": "庆安县",
		    "231225": "明水县",
		    "231226": "绥棱县",
		    "231281": "安达市",
		    "231282": "肇东市",
		    "231283": "海伦市",
		    "231284": "其它区",
		    "232700": "大兴安岭地区",
		    "232702": "松岭区",
		    "232703": "新林区",
		    "232704": "呼中区",
		    "232721": "呼玛县",
		    "232722": "塔河县",
		    "232723": "漠河县",
		    "232724": "加格达奇区",
		    "232725": "其它区",
		    "310000": "上海",
		    "310100": "上海市",
		    "310101": "黄浦区",
		    "310104": "徐汇区",
		    "310105": "长宁区",
		    "310106": "静安区",
		    "310107": "普陀区",
		    "310108": "闸北区",
		    "310109": "虹口区",
		    "310110": "杨浦区",
		    "310112": "闵行区",
		    "310113": "宝山区",
		    "310114": "嘉定区",
		    "310115": "浦东新区",
		    "310116": "金山区",
		    "310117": "松江区",
		    "310118": "青浦区",
		    "310120": "奉贤区",
		    "310230": "崇明县",
		    "310231": "其它区",
		    "320000": "江苏省",
		    "320100": "南京市",
		    "320102": "玄武区",
		    "320104": "秦淮区",
		    "320105": "建邺区",
		    "320106": "鼓楼区",
		    "320111": "浦口区",
		    "320113": "栖霞区",
		    "320114": "雨花台区",
		    "320115": "江宁区",
		    "320116": "六合区",
		    "320124": "溧水区",
		    "320125": "高淳区",
		    "320126": "其它区",
		    "320200": "无锡市",
		    "320202": "崇安区",
		    "320203": "南长区",
		    "320204": "北塘区",
		    "320205": "锡山区",
		    "320206": "惠山区",
		    "320211": "滨湖区",
		    "320281": "江阴市",
		    "320282": "宜兴市",
		    "320297": "其它区",
		    "320300": "徐州市",
		    "320302": "鼓楼区",
		    "320303": "云龙区",
		    "320305": "贾汪区",
		    "320311": "泉山区",
		    "320321": "丰县",
		    "320322": "沛县",
		    "320323": "铜山区",
		    "320324": "睢宁县",
		    "320381": "新沂市",
		    "320382": "邳州市",
		    "320383": "其它区",
		    "320400": "常州市",
		    "320402": "天宁区",
		    "320404": "钟楼区",
		    "320405": "戚墅堰区",
		    "320411": "新北区",
		    "320412": "武进区",
		    "320481": "溧阳市",
		    "320482": "金坛市",
		    "320483": "其它区",
		    "320500": "苏州市",
		    "320505": "虎丘区",
		    "320506": "吴中区",
		    "320507": "相城区",
		    "320508": "姑苏区",
		    "320581": "常熟市",
		    "320582": "张家港市",
		    "320583": "昆山市",
		    "320584": "吴江区",
		    "320585": "太仓市",
		    "320596": "其它区",
		    "320600": "南通市",
		    "320602": "崇川区",
		    "320611": "港闸区",
		    "320612": "通州区",
		    "320621": "海安县",
		    "320623": "如东县",
		    "320681": "启东市",
		    "320682": "如皋市",
		    "320684": "海门市",
		    "320694": "其它区",
		    "320700": "连云港市",
		    "320703": "连云区",
		    "320705": "新浦区",
		    "320706": "海州区",
		    "320721": "赣榆县",
		    "320722": "东海县",
		    "320723": "灌云县",
		    "320724": "灌南县",
		    "320725": "其它区",
		    "320800": "淮安市",
		    "320802": "清河区",
		    "320803": "淮安区",
		    "320804": "淮阴区",
		    "320811": "清浦区",
		    "320826": "涟水县",
		    "320829": "洪泽县",
		    "320830": "盱眙县",
		    "320831": "金湖县",
		    "320832": "其它区",
		    "320900": "盐城市",
		    "320902": "亭湖区",
		    "320903": "盐都区",
		    "320921": "响水县",
		    "320922": "滨海县",
		    "320923": "阜宁县",
		    "320924": "射阳县",
		    "320925": "建湖县",
		    "320981": "东台市",
		    "320982": "大丰市",
		    "320983": "其它区",
		    "321000": "扬州市",
		    "321002": "广陵区",
		    "321003": "邗江区",
		    "321023": "宝应县",
		    "321081": "仪征市",
		    "321084": "高邮市",
		    "321088": "江都区",
		    "321093": "其它区",
		    "321100": "镇江市",
		    "321102": "京口区",
		    "321111": "润州区",
		    "321112": "丹徒区",
		    "321181": "丹阳市",
		    "321182": "扬中市",
		    "321183": "句容市",
		    "321184": "其它区",
		    "321200": "泰州市",
		    "321202": "海陵区",
		    "321203": "高港区",
		    "321281": "兴化市",
		    "321282": "靖江市",
		    "321283": "泰兴市",
		    "321284": "姜堰区",
		    "321285": "其它区",
		    "321300": "宿迁市",
		    "321302": "宿城区",
		    "321311": "宿豫区",
		    "321322": "沭阳县",
		    "321323": "泗阳县",
		    "321324": "泗洪县",
		    "321325": "其它区",
		    "330000": "浙江省",
		    "330100": "杭州市",
		    "330102": "上城区",
		    "330103": "下城区",
		    "330104": "江干区",
		    "330105": "拱墅区",
		    "330106": "西湖区",
		    "330108": "滨江区",
		    "330109": "萧山区",
		    "330110": "余杭区",
		    "330122": "桐庐县",
		    "330127": "淳安县",
		    "330182": "建德市",
		    "330183": "富阳市",
		    "330185": "临安市",
		    "330186": "其它区",
		    "330200": "宁波市",
		    "330203": "海曙区",
		    "330204": "江东区",
		    "330205": "江北区",
		    "330206": "北仑区",
		    "330211": "镇海区",
		    "330212": "鄞州区",
		    "330225": "象山县",
		    "330226": "宁海县",
		    "330281": "余姚市",
		    "330282": "慈溪市",
		    "330283": "奉化市",
		    "330284": "其它区",
		    "330300": "温州市",
		    "330302": "鹿城区",
		    "330303": "龙湾区",
		    "330304": "瓯海区",
		    "330322": "洞头县",
		    "330324": "永嘉县",
		    "330326": "平阳县",
		    "330327": "苍南县",
		    "330328": "文成县",
		    "330329": "泰顺县",
		    "330381": "瑞安市",
		    "330382": "乐清市",
		    "330383": "其它区",
		    "330400": "嘉兴市",
		    "330402": "南湖区",
		    "330411": "秀洲区",
		    "330421": "嘉善县",
		    "330424": "海盐县",
		    "330481": "海宁市",
		    "330482": "平湖市",
		    "330483": "桐乡市",
		    "330484": "其它区",
		    "330500": "湖州市",
		    "330502": "吴兴区",
		    "330503": "南浔区",
		    "330521": "德清县",
		    "330522": "长兴县",
		    "330523": "安吉县",
		    "330524": "其它区",
		    "330600": "绍兴市",
		    "330602": "越城区",
		    "330621": "绍兴县",
		    "330624": "新昌县",
		    "330681": "诸暨市",
		    "330682": "上虞市",
		    "330683": "嵊州市",
		    "330684": "其它区",
		    "330700": "金华市",
		    "330702": "婺城区",
		    "330703": "金东区",
		    "330723": "武义县",
		    "330726": "浦江县",
		    "330727": "磐安县",
		    "330781": "兰溪市",
		    "330782": "义乌市",
		    "330783": "东阳市",
		    "330784": "永康市",
		    "330785": "其它区",
		    "330800": "衢州市",
		    "330802": "柯城区",
		    "330803": "衢江区",
		    "330822": "常山县",
		    "330824": "开化县",
		    "330825": "龙游县",
		    "330881": "江山市",
		    "330882": "其它区",
		    "330900": "舟山市",
		    "330902": "定海区",
		    "330903": "普陀区",
		    "330921": "岱山县",
		    "330922": "嵊泗县",
		    "330923": "其它区",
		    "331000": "台州市",
		    "331002": "椒江区",
		    "331003": "黄岩区",
		    "331004": "路桥区",
		    "331021": "玉环县",
		    "331022": "三门县",
		    "331023": "天台县",
		    "331024": "仙居县",
		    "331081": "温岭市",
		    "331082": "临海市",
		    "331083": "其它区",
		    "331100": "丽水市",
		    "331102": "莲都区",
		    "331121": "青田县",
		    "331122": "缙云县",
		    "331123": "遂昌县",
		    "331124": "松阳县",
		    "331125": "云和县",
		    "331126": "庆元县",
		    "331127": "景宁畲族自治县",
		    "331181": "龙泉市",
		    "331182": "其它区",
		    "340000": "安徽省",
		    "340100": "合肥市",
		    "340102": "瑶海区",
		    "340103": "庐阳区",
		    "340104": "蜀山区",
		    "340111": "包河区",
		    "340121": "长丰县",
		    "340122": "肥东县",
		    "340123": "肥西县",
		    "340192": "其它区",
		    "340200": "芜湖市",
		    "340202": "镜湖区",
		    "340203": "弋江区",
		    "340207": "鸠江区",
		    "340208": "三山区",
		    "340221": "芜湖县",
		    "340222": "繁昌县",
		    "340223": "南陵县",
		    "340224": "其它区",
		    "340300": "蚌埠市",
		    "340302": "龙子湖区",
		    "340303": "蚌山区",
		    "340304": "禹会区",
		    "340311": "淮上区",
		    "340321": "怀远县",
		    "340322": "五河县",
		    "340323": "固镇县",
		    "340324": "其它区",
		    "340400": "淮南市",
		    "340402": "大通区",
		    "340403": "田家庵区",
		    "340404": "谢家集区",
		    "340405": "八公山区",
		    "340406": "潘集区",
		    "340421": "凤台县",
		    "340422": "其它区",
		    "340500": "马鞍山市",
		    "340503": "花山区",
		    "340504": "雨山区",
		    "340506": "博望区",
		    "340521": "当涂县",
		    "340522": "其它区",
		    "340600": "淮北市",
		    "340602": "杜集区",
		    "340603": "相山区",
		    "340604": "烈山区",
		    "340621": "濉溪县",
		    "340622": "其它区",
		    "340700": "铜陵市",
		    "340702": "铜官山区",
		    "340703": "狮子山区",
		    "340711": "郊区",
		    "340721": "铜陵县",
		    "340722": "其它区",
		    "340800": "安庆市",
		    "340802": "迎江区",
		    "340803": "大观区",
		    "340811": "宜秀区",
		    "340822": "怀宁县",
		    "340823": "枞阳县",
		    "340824": "潜山县",
		    "340825": "太湖县",
		    "340826": "宿松县",
		    "340827": "望江县",
		    "340828": "岳西县",
		    "340881": "桐城市",
		    "340882": "其它区",
		    "341000": "黄山市",
		    "341002": "屯溪区",
		    "341003": "黄山区",
		    "341004": "徽州区",
		    "341021": "歙县",
		    "341022": "休宁县",
		    "341023": "黟县",
		    "341024": "祁门县",
		    "341025": "其它区",
		    "341100": "滁州市",
		    "341102": "琅琊区",
		    "341103": "南谯区",
		    "341122": "来安县",
		    "341124": "全椒县",
		    "341125": "定远县",
		    "341126": "凤阳县",
		    "341181": "天长市",
		    "341182": "明光市",
		    "341183": "其它区",
		    "341200": "阜阳市",
		    "341202": "颍州区",
		    "341203": "颍东区",
		    "341204": "颍泉区",
		    "341221": "临泉县",
		    "341222": "太和县",
		    "341225": "阜南县",
		    "341226": "颍上县",
		    "341282": "界首市",
		    "341283": "其它区",
		    "341300": "宿州市",
		    "341302": "埇桥区",
		    "341321": "砀山县",
		    "341322": "萧县",
		    "341323": "灵璧县",
		    "341324": "泗县",
		    "341325": "其它区",
		    "341400": "巢湖市",
		    "341421": "庐江县",
		    "341422": "无为县",
		    "341423": "含山县",
		    "341424": "和县",
		    "341500": "六安市",
		    "341502": "金安区",
		    "341503": "裕安区",
		    "341521": "寿县",
		    "341522": "霍邱县",
		    "341523": "舒城县",
		    "341524": "金寨县",
		    "341525": "霍山县",
		    "341526": "其它区",
		    "341600": "亳州市",
		    "341602": "谯城区",
		    "341621": "涡阳县",
		    "341622": "蒙城县",
		    "341623": "利辛县",
		    "341624": "其它区",
		    "341700": "池州市",
		    "341702": "贵池区",
		    "341721": "东至县",
		    "341722": "石台县",
		    "341723": "青阳县",
		    "341724": "其它区",
		    "341800": "宣城市",
		    "341802": "宣州区",
		    "341821": "郎溪县",
		    "341822": "广德县",
		    "341823": "泾县",
		    "341824": "绩溪县",
		    "341825": "旌德县",
		    "341881": "宁国市",
		    "341882": "其它区",
		    "350000": "福建省",
		    "350100": "福州市",
		    "350102": "鼓楼区",
		    "350103": "台江区",
		    "350104": "仓山区",
		    "350105": "马尾区",
		    "350111": "晋安区",
		    "350121": "闽侯县",
		    "350122": "连江县",
		    "350123": "罗源县",
		    "350124": "闽清县",
		    "350125": "永泰县",
		    "350128": "平潭县",
		    "350181": "福清市",
		    "350182": "长乐市",
		    "350183": "其它区",
		    "350200": "厦门市",
		    "350203": "思明区",
		    "350205": "海沧区",
		    "350206": "湖里区",
		    "350211": "集美区",
		    "350212": "同安区",
		    "350213": "翔安区",
		    "350214": "其它区",
		    "350300": "莆田市",
		    "350302": "城厢区",
		    "350303": "涵江区",
		    "350304": "荔城区",
		    "350305": "秀屿区",
		    "350322": "仙游县",
		    "350323": "其它区",
		    "350400": "三明市",
		    "350402": "梅列区",
		    "350403": "三元区",
		    "350421": "明溪县",
		    "350423": "清流县",
		    "350424": "宁化县",
		    "350425": "大田县",
		    "350426": "尤溪县",
		    "350427": "沙县",
		    "350428": "将乐县",
		    "350429": "泰宁县",
		    "350430": "建宁县",
		    "350481": "永安市",
		    "350482": "其它区",
		    "350500": "泉州市",
		    "350502": "鲤城区",
		    "350503": "丰泽区",
		    "350504": "洛江区",
		    "350505": "泉港区",
		    "350521": "惠安县",
		    "350524": "安溪县",
		    "350525": "永春县",
		    "350526": "德化县",
		    "350527": "金门县",
		    "350581": "石狮市",
		    "350582": "晋江市",
		    "350583": "南安市",
		    "350584": "其它区",
		    "350600": "漳州市",
		    "350602": "芗城区",
		    "350603": "龙文区",
		    "350622": "云霄县",
		    "350623": "漳浦县",
		    "350624": "诏安县",
		    "350625": "长泰县",
		    "350626": "东山县",
		    "350627": "南靖县",
		    "350628": "平和县",
		    "350629": "华安县",
		    "350681": "龙海市",
		    "350682": "其它区",
		    "350700": "南平市",
		    "350702": "延平区",
		    "350721": "顺昌县",
		    "350722": "浦城县",
		    "350723": "光泽县",
		    "350724": "松溪县",
		    "350725": "政和县",
		    "350781": "邵武市",
		    "350782": "武夷山市",
		    "350783": "建瓯市",
		    "350784": "建阳市",
		    "350785": "其它区",
		    "350800": "龙岩市",
		    "350802": "新罗区",
		    "350821": "长汀县",
		    "350822": "永定县",
		    "350823": "上杭县",
		    "350824": "武平县",
		    "350825": "连城县",
		    "350881": "漳平市",
		    "350882": "其它区",
		    "350900": "宁德市",
		    "350902": "蕉城区",
		    "350921": "霞浦县",
		    "350922": "古田县",
		    "350923": "屏南县",
		    "350924": "寿宁县",
		    "350925": "周宁县",
		    "350926": "柘荣县",
		    "350981": "福安市",
		    "350982": "福鼎市",
		    "350983": "其它区",
		    "360000": "江西省",
		    "360100": "南昌市",
		    "360102": "东湖区",
		    "360103": "西湖区",
		    "360104": "青云谱区",
		    "360105": "湾里区",
		    "360111": "青山湖区",
		    "360121": "南昌县",
		    "360122": "新建县",
		    "360123": "安义县",
		    "360124": "进贤县",
		    "360128": "其它区",
		    "360200": "景德镇市",
		    "360202": "昌江区",
		    "360203": "珠山区",
		    "360222": "浮梁县",
		    "360281": "乐平市",
		    "360282": "其它区",
		    "360300": "萍乡市",
		    "360302": "安源区",
		    "360313": "湘东区",
		    "360321": "莲花县",
		    "360322": "上栗县",
		    "360323": "芦溪县",
		    "360324": "其它区",
		    "360400": "九江市",
		    "360402": "庐山区",
		    "360403": "浔阳区",
		    "360421": "九江县",
		    "360423": "武宁县",
		    "360424": "修水县",
		    "360425": "永修县",
		    "360426": "德安县",
		    "360427": "星子县",
		    "360428": "都昌县",
		    "360429": "湖口县",
		    "360430": "彭泽县",
		    "360481": "瑞昌市",
		    "360482": "其它区",
		    "360483": "共青城市",
		    "360500": "新余市",
		    "360502": "渝水区",
		    "360521": "分宜县",
		    "360522": "其它区",
		    "360600": "鹰潭市",
		    "360602": "月湖区",
		    "360622": "余江县",
		    "360681": "贵溪市",
		    "360682": "其它区",
		    "360700": "赣州市",
		    "360702": "章贡区",
		    "360721": "赣县",
		    "360722": "信丰县",
		    "360723": "大余县",
		    "360724": "上犹县",
		    "360725": "崇义县",
		    "360726": "安远县",
		    "360727": "龙南县",
		    "360728": "定南县",
		    "360729": "全南县",
		    "360730": "宁都县",
		    "360731": "于都县",
		    "360732": "兴国县",
		    "360733": "会昌县",
		    "360734": "寻乌县",
		    "360735": "石城县",
		    "360781": "瑞金市",
		    "360782": "南康市",
		    "360783": "其它区",
		    "360800": "吉安市",
		    "360802": "吉州区",
		    "360803": "青原区",
		    "360821": "吉安县",
		    "360822": "吉水县",
		    "360823": "峡江县",
		    "360824": "新干县",
		    "360825": "永丰县",
		    "360826": "泰和县",
		    "360827": "遂川县",
		    "360828": "万安县",
		    "360829": "安福县",
		    "360830": "永新县",
		    "360881": "井冈山市",
		    "360882": "其它区",
		    "360900": "宜春市",
		    "360902": "袁州区",
		    "360921": "奉新县",
		    "360922": "万载县",
		    "360923": "上高县",
		    "360924": "宜丰县",
		    "360925": "靖安县",
		    "360926": "铜鼓县",
		    "360981": "丰城市",
		    "360982": "樟树市",
		    "360983": "高安市",
		    "360984": "其它区",
		    "361000": "抚州市",
		    "361002": "临川区",
		    "361021": "南城县",
		    "361022": "黎川县",
		    "361023": "南丰县",
		    "361024": "崇仁县",
		    "361025": "乐安县",
		    "361026": "宜黄县",
		    "361027": "金溪县",
		    "361028": "资溪县",
		    "361029": "东乡县",
		    "361030": "广昌县",
		    "361031": "其它区",
		    "361100": "上饶市",
		    "361102": "信州区",
		    "361121": "上饶县",
		    "361122": "广丰县",
		    "361123": "玉山县",
		    "361124": "铅山县",
		    "361125": "横峰县",
		    "361126": "弋阳县",
		    "361127": "余干县",
		    "361128": "鄱阳县",
		    "361129": "万年县",
		    "361130": "婺源县",
		    "361181": "德兴市",
		    "361182": "其它区",
		    "370000": "山东省",
		    "370100": "济南市",
		    "370102": "历下区",
		    "370103": "市中区",
		    "370104": "槐荫区",
		    "370105": "天桥区",
		    "370112": "历城区",
		    "370113": "长清区",
		    "370124": "平阴县",
		    "370125": "济阳县",
		    "370126": "商河县",
		    "370181": "章丘市",
		    "370182": "其它区",
		    "370200": "青岛市",
		    "370202": "市南区",
		    "370203": "市北区",
		    "370211": "黄岛区",
		    "370212": "崂山区",
		    "370213": "李沧区",
		    "370214": "城阳区",
		    "370281": "胶州市",
		    "370282": "即墨市",
		    "370283": "平度市",
		    "370285": "莱西市",
		    "370286": "其它区",
		    "370300": "淄博市",
		    "370302": "淄川区",
		    "370303": "张店区",
		    "370304": "博山区",
		    "370305": "临淄区",
		    "370306": "周村区",
		    "370321": "桓台县",
		    "370322": "高青县",
		    "370323": "沂源县",
		    "370324": "其它区",
		    "370400": "枣庄市",
		    "370402": "市中区",
		    "370403": "薛城区",
		    "370404": "峄城区",
		    "370405": "台儿庄区",
		    "370406": "山亭区",
		    "370481": "滕州市",
		    "370482": "其它区",
		    "370500": "东营市",
		    "370502": "东营区",
		    "370503": "河口区",
		    "370521": "垦利县",
		    "370522": "利津县",
		    "370523": "广饶县",
		    "370591": "其它区",
		    "370600": "烟台市",
		    "370602": "芝罘区",
		    "370611": "福山区",
		    "370612": "牟平区",
		    "370613": "莱山区",
		    "370634": "长岛县",
		    "370681": "龙口市",
		    "370682": "莱阳市",
		    "370683": "莱州市",
		    "370684": "蓬莱市",
		    "370685": "招远市",
		    "370686": "栖霞市",
		    "370687": "海阳市",
		    "370688": "其它区",
		    "370700": "潍坊市",
		    "370702": "潍城区",
		    "370703": "寒亭区",
		    "370704": "坊子区",
		    "370705": "奎文区",
		    "370724": "临朐县",
		    "370725": "昌乐县",
		    "370781": "青州市",
		    "370782": "诸城市",
		    "370783": "寿光市",
		    "370784": "安丘市",
		    "370785": "高密市",
		    "370786": "昌邑市",
		    "370787": "其它区",
		    "370800": "济宁市",
		    "370802": "市中区",
		    "370811": "任城区",
		    "370826": "微山县",
		    "370827": "鱼台县",
		    "370828": "金乡县",
		    "370829": "嘉祥县",
		    "370830": "汶上县",
		    "370831": "泗水县",
		    "370832": "梁山县",
		    "370881": "曲阜市",
		    "370882": "兖州市",
		    "370883": "邹城市",
		    "370884": "其它区",
		    "370900": "泰安市",
		    "370902": "泰山区",
		    "370903": "岱岳区",
		    "370921": "宁阳县",
		    "370923": "东平县",
		    "370982": "新泰市",
		    "370983": "肥城市",
		    "370984": "其它区",
		    "371000": "威海市",
		    "371002": "环翠区",
		    "371081": "文登市",
		    "371082": "荣成市",
		    "371083": "乳山市",
		    "371084": "其它区",
		    "371100": "日照市",
		    "371102": "东港区",
		    "371103": "岚山区",
		    "371121": "五莲县",
		    "371122": "莒县",
		    "371123": "其它区",
		    "371200": "莱芜市",
		    "371202": "莱城区",
		    "371203": "钢城区",
		    "371204": "其它区",
		    "371300": "临沂市",
		    "371302": "兰山区",
		    "371311": "罗庄区",
		    "371312": "河东区",
		    "371321": "沂南县",
		    "371322": "郯城县",
		    "371323": "沂水县",
		    "371324": "苍山县",
		    "371325": "费县",
		    "371326": "平邑县",
		    "371327": "莒南县",
		    "371328": "蒙阴县",
		    "371329": "临沭县",
		    "371330": "其它区",
		    "371400": "德州市",
		    "371402": "德城区",
		    "371421": "陵县",
		    "371422": "宁津县",
		    "371423": "庆云县",
		    "371424": "临邑县",
		    "371425": "齐河县",
		    "371426": "平原县",
		    "371427": "夏津县",
		    "371428": "武城县",
		    "371481": "乐陵市",
		    "371482": "禹城市",
		    "371483": "其它区",
		    "371500": "聊城市",
		    "371502": "东昌府区",
		    "371521": "阳谷县",
		    "371522": "莘县",
		    "371523": "茌平县",
		    "371524": "东阿县",
		    "371525": "冠县",
		    "371526": "高唐县",
		    "371581": "临清市",
		    "371582": "其它区",
		    "371600": "滨州市",
		    "371602": "滨城区",
		    "371621": "惠民县",
		    "371622": "阳信县",
		    "371623": "无棣县",
		    "371624": "沾化县",
		    "371625": "博兴县",
		    "371626": "邹平县",
		    "371627": "其它区",
		    "371700": "菏泽市",
		    "371702": "牡丹区",
		    "371721": "曹县",
		    "371722": "单县",
		    "371723": "成武县",
		    "371724": "巨野县",
		    "371725": "郓城县",
		    "371726": "鄄城县",
		    "371727": "定陶县",
		    "371728": "东明县",
		    "371729": "其它区",
		    "410000": "河南省",
		    "410100": "郑州市",
		    "410102": "中原区",
		    "410103": "二七区",
		    "410104": "管城回族区",
		    "410105": "金水区",
		    "410106": "上街区",
		    "410108": "惠济区",
		    "410122": "中牟县",
		    "410181": "巩义市",
		    "410182": "荥阳市",
		    "410183": "新密市",
		    "410184": "新郑市",
		    "410185": "登封市",
		    "410188": "其它区",
		    "410200": "开封市",
		    "410202": "龙亭区",
		    "410203": "顺河回族区",
		    "410204": "鼓楼区",
		    "410205": "禹王台区",
		    "410211": "金明区",
		    "410221": "杞县",
		    "410222": "通许县",
		    "410223": "尉氏县",
		    "410224": "开封县",
		    "410225": "兰考县",
		    "410226": "其它区",
		    "410300": "洛阳市",
		    "410302": "老城区",
		    "410303": "西工区",
		    "410304": "瀍河回族区",
		    "410305": "涧西区",
		    "410306": "吉利区",
		    "410307": "洛龙区",
		    "410322": "孟津县",
		    "410323": "新安县",
		    "410324": "栾川县",
		    "410325": "嵩县",
		    "410326": "汝阳县",
		    "410327": "宜阳县",
		    "410328": "洛宁县",
		    "410329": "伊川县",
		    "410381": "偃师市",
		    "410400": "平顶山市",
		    "410402": "新华区",
		    "410403": "卫东区",
		    "410404": "石龙区",
		    "410411": "湛河区",
		    "410421": "宝丰县",
		    "410422": "叶县",
		    "410423": "鲁山县",
		    "410425": "郏县",
		    "410481": "舞钢市",
		    "410482": "汝州市",
		    "410483": "其它区",
		    "410500": "安阳市",
		    "410502": "文峰区",
		    "410503": "北关区",
		    "410505": "殷都区",
		    "410506": "龙安区",
		    "410522": "安阳县",
		    "410523": "汤阴县",
		    "410526": "滑县",
		    "410527": "内黄县",
		    "410581": "林州市",
		    "410582": "其它区",
		    "410600": "鹤壁市",
		    "410602": "鹤山区",
		    "410603": "山城区",
		    "410611": "淇滨区",
		    "410621": "浚县",
		    "410622": "淇县",
		    "410623": "其它区",
		    "410700": "新乡市",
		    "410702": "红旗区",
		    "410703": "卫滨区",
		    "410704": "凤泉区",
		    "410711": "牧野区",
		    "410721": "新乡县",
		    "410724": "获嘉县",
		    "410725": "原阳县",
		    "410726": "延津县",
		    "410727": "封丘县",
		    "410728": "长垣县",
		    "410781": "卫辉市",
		    "410782": "辉县市",
		    "410783": "其它区",
		    "410800": "焦作市",
		    "410802": "解放区",
		    "410803": "中站区",
		    "410804": "马村区",
		    "410811": "山阳区",
		    "410821": "修武县",
		    "410822": "博爱县",
		    "410823": "武陟县",
		    "410825": "温县",
		    "410881": "济源市",
		    "410882": "沁阳市",
		    "410883": "孟州市",
		    "410884": "其它区",
		    "410900": "濮阳市",
		    "410902": "华龙区",
		    "410922": "清丰县",
		    "410923": "南乐县",
		    "410926": "范县",
		    "410927": "台前县",
		    "410928": "濮阳县",
		    "410929": "其它区",
		    "411000": "许昌市",
		    "411002": "魏都区",
		    "411023": "许昌县",
		    "411024": "鄢陵县",
		    "411025": "襄城县",
		    "411081": "禹州市",
		    "411082": "长葛市",
		    "411083": "其它区",
		    "411100": "漯河市",
		    "411102": "源汇区",
		    "411103": "郾城区",
		    "411104": "召陵区",
		    "411121": "舞阳县",
		    "411122": "临颍县",
		    "411123": "其它区",
		    "411200": "三门峡市",
		    "411202": "湖滨区",
		    "411221": "渑池县",
		    "411222": "陕县",
		    "411224": "卢氏县",
		    "411281": "义马市",
		    "411282": "灵宝市",
		    "411283": "其它区",
		    "411300": "南阳市",
		    "411302": "宛城区",
		    "411303": "卧龙区",
		    "411321": "南召县",
		    "411322": "方城县",
		    "411323": "西峡县",
		    "411324": "镇平县",
		    "411325": "内乡县",
		    "411326": "淅川县",
		    "411327": "社旗县",
		    "411328": "唐河县",
		    "411329": "新野县",
		    "411330": "桐柏县",
		    "411381": "邓州市",
		    "411382": "其它区",
		    "411400": "商丘市",
		    "411402": "梁园区",
		    "411403": "睢阳区",
		    "411421": "民权县",
		    "411422": "睢县",
		    "411423": "宁陵县",
		    "411424": "柘城县",
		    "411425": "虞城县",
		    "411426": "夏邑县",
		    "411481": "永城市",
		    "411482": "其它区",
		    "411500": "信阳市",
		    "411502": "浉河区",
		    "411503": "平桥区",
		    "411521": "罗山县",
		    "411522": "光山县",
		    "411523": "新县",
		    "411524": "商城县",
		    "411525": "固始县",
		    "411526": "潢川县",
		    "411527": "淮滨县",
		    "411528": "息县",
		    "411529": "其它区",
		    "411600": "周口市",
		    "411602": "川汇区",
		    "411621": "扶沟县",
		    "411622": "西华县",
		    "411623": "商水县",
		    "411624": "沈丘县",
		    "411625": "郸城县",
		    "411626": "淮阳县",
		    "411627": "太康县",
		    "411628": "鹿邑县",
		    "411681": "项城市",
		    "411682": "其它区",
		    "411700": "驻马店市",
		    "411702": "驿城区",
		    "411721": "西平县",
		    "411722": "上蔡县",
		    "411723": "平舆县",
		    "411724": "正阳县",
		    "411725": "确山县",
		    "411726": "泌阳县",
		    "411727": "汝南县",
		    "411728": "遂平县",
		    "411729": "新蔡县",
		    "411730": "其它区",
		    "420000": "湖北省",
		    "420100": "武汉市",
		    "420102": "江岸区",
		    "420103": "江汉区",
		    "420104": "硚口区",
		    "420105": "汉阳区",
		    "420106": "武昌区",
		    "420107": "青山区",
		    "420111": "洪山区",
		    "420112": "东西湖区",
		    "420113": "汉南区",
		    "420114": "蔡甸区",
		    "420115": "江夏区",
		    "420116": "黄陂区",
		    "420117": "新洲区",
		    "420118": "其它区",
		    "420200": "黄石市",
		    "420202": "黄石港区",
		    "420203": "西塞山区",
		    "420204": "下陆区",
		    "420205": "铁山区",
		    "420222": "阳新县",
		    "420281": "大冶市",
		    "420282": "其它区",
		    "420300": "十堰市",
		    "420302": "茅箭区",
		    "420303": "张湾区",
		    "420321": "郧县",
		    "420322": "郧西县",
		    "420323": "竹山县",
		    "420324": "竹溪县",
		    "420325": "房县",
		    "420381": "丹江口市",
		    "420383": "其它区",
		    "420500": "宜昌市",
		    "420502": "西陵区",
		    "420503": "伍家岗区",
		    "420504": "点军区",
		    "420505": "猇亭区",
		    "420506": "夷陵区",
		    "420525": "远安县",
		    "420526": "兴山县",
		    "420527": "秭归县",
		    "420528": "长阳土家族自治县",
		    "420529": "五峰土家族自治县",
		    "420581": "宜都市",
		    "420582": "当阳市",
		    "420583": "枝江市",
		    "420584": "其它区",
		    "420600": "襄阳市",
		    "420602": "襄城区",
		    "420606": "樊城区",
		    "420607": "襄州区",
		    "420624": "南漳县",
		    "420625": "谷城县",
		    "420626": "保康县",
		    "420682": "老河口市",
		    "420683": "枣阳市",
		    "420684": "宜城市",
		    "420685": "其它区",
		    "420700": "鄂州市",
		    "420702": "梁子湖区",
		    "420703": "华容区",
		    "420704": "鄂城区",
		    "420705": "其它区",
		    "420800": "荆门市",
		    "420802": "东宝区",
		    "420804": "掇刀区",
		    "420821": "京山县",
		    "420822": "沙洋县",
		    "420881": "钟祥市",
		    "420882": "其它区",
		    "420900": "孝感市",
		    "420902": "孝南区",
		    "420921": "孝昌县",
		    "420922": "大悟县",
		    "420923": "云梦县",
		    "420981": "应城市",
		    "420982": "安陆市",
		    "420984": "汉川市",
		    "420985": "其它区",
		    "421000": "荆州市",
		    "421002": "沙市区",
		    "421003": "荆州区",
		    "421022": "公安县",
		    "421023": "监利县",
		    "421024": "江陵县",
		    "421081": "石首市",
		    "421083": "洪湖市",
		    "421087": "松滋市",
		    "421088": "其它区",
		    "421100": "黄冈市",
		    "421102": "黄州区",
		    "421121": "团风县",
		    "421122": "红安县",
		    "421123": "罗田县",
		    "421124": "英山县",
		    "421125": "浠水县",
		    "421126": "蕲春县",
		    "421127": "黄梅县",
		    "421181": "麻城市",
		    "421182": "武穴市",
		    "421183": "其它区",
		    "421200": "咸宁市",
		    "421202": "咸安区",
		    "421221": "嘉鱼县",
		    "421222": "通城县",
		    "421223": "崇阳县",
		    "421224": "通山县",
		    "421281": "赤壁市",
		    "421283": "其它区",
		    "421300": "随州市",
		    "421302": "曾都区",
		    "421321": "随县",
		    "421381": "广水市",
		    "421382": "其它区",
		    "422800": "恩施土家族苗族自治州",
		    "422801": "恩施市",
		    "422802": "利川市",
		    "422822": "建始县",
		    "422823": "巴东县",
		    "422825": "宣恩县",
		    "422826": "咸丰县",
		    "422827": "来凤县",
		    "422828": "鹤峰县",
		    "422829": "其它区",
		    "429004": "仙桃市",
		    "429005": "潜江市",
		    "429006": "天门市",
		    "429021": "神农架林区",
		    "430000": "湖南省",
		    "430100": "长沙市",
		    "430102": "芙蓉区",
		    "430103": "天心区",
		    "430104": "岳麓区",
		    "430105": "开福区",
		    "430111": "雨花区",
		    "430121": "长沙县",
		    "430122": "望城区",
		    "430124": "宁乡县",
		    "430181": "浏阳市",
		    "430182": "其它区",
		    "430200": "株洲市",
		    "430202": "荷塘区",
		    "430203": "芦淞区",
		    "430204": "石峰区",
		    "430211": "天元区",
		    "430221": "株洲县",
		    "430223": "攸县",
		    "430224": "茶陵县",
		    "430225": "炎陵县",
		    "430281": "醴陵市",
		    "430282": "其它区",
		    "430300": "湘潭市",
		    "430302": "雨湖区",
		    "430304": "岳塘区",
		    "430321": "湘潭县",
		    "430381": "湘乡市",
		    "430382": "韶山市",
		    "430383": "其它区",
		    "430400": "衡阳市",
		    "430405": "珠晖区",
		    "430406": "雁峰区",
		    "430407": "石鼓区",
		    "430408": "蒸湘区",
		    "430412": "南岳区",
		    "430421": "衡阳县",
		    "430422": "衡南县",
		    "430423": "衡山县",
		    "430424": "衡东县",
		    "430426": "祁东县",
		    "430481": "耒阳市",
		    "430482": "常宁市",
		    "430483": "其它区",
		    "430500": "邵阳市",
		    "430502": "双清区",
		    "430503": "大祥区",
		    "430511": "北塔区",
		    "430521": "邵东县",
		    "430522": "新邵县",
		    "430523": "邵阳县",
		    "430524": "隆回县",
		    "430525": "洞口县",
		    "430527": "绥宁县",
		    "430528": "新宁县",
		    "430529": "城步苗族自治县",
		    "430581": "武冈市",
		    "430582": "其它区",
		    "430600": "岳阳市",
		    "430602": "岳阳楼区",
		    "430603": "云溪区",
		    "430611": "君山区",
		    "430621": "岳阳县",
		    "430623": "华容县",
		    "430624": "湘阴县",
		    "430626": "平江县",
		    "430681": "汨罗市",
		    "430682": "临湘市",
		    "430683": "其它区",
		    "430700": "常德市",
		    "430702": "武陵区",
		    "430703": "鼎城区",
		    "430721": "安乡县",
		    "430722": "汉寿县",
		    "430723": "澧县",
		    "430724": "临澧县",
		    "430725": "桃源县",
		    "430726": "石门县",
		    "430781": "津市市",
		    "430782": "其它区",
		    "430800": "张家界市",
		    "430802": "永定区",
		    "430811": "武陵源区",
		    "430821": "慈利县",
		    "430822": "桑植县",
		    "430823": "其它区",
		    "430900": "益阳市",
		    "430902": "资阳区",
		    "430903": "赫山区",
		    "430921": "南县",
		    "430922": "桃江县",
		    "430923": "安化县",
		    "430981": "沅江市",
		    "430982": "其它区",
		    "431000": "郴州市",
		    "431002": "北湖区",
		    "431003": "苏仙区",
		    "431021": "桂阳县",
		    "431022": "宜章县",
		    "431023": "永兴县",
		    "431024": "嘉禾县",
		    "431025": "临武县",
		    "431026": "汝城县",
		    "431027": "桂东县",
		    "431028": "安仁县",
		    "431081": "资兴市",
		    "431082": "其它区",
		    "431100": "永州市",
		    "431102": "零陵区",
		    "431103": "冷水滩区",
		    "431121": "祁阳县",
		    "431122": "东安县",
		    "431123": "双牌县",
		    "431124": "道县",
		    "431125": "江永县",
		    "431126": "宁远县",
		    "431127": "蓝山县",
		    "431128": "新田县",
		    "431129": "江华瑶族自治县",
		    "431130": "其它区",
		    "431200": "怀化市",
		    "431202": "鹤城区",
		    "431221": "中方县",
		    "431222": "沅陵县",
		    "431223": "辰溪县",
		    "431224": "溆浦县",
		    "431225": "会同县",
		    "431226": "麻阳苗族自治县",
		    "431227": "新晃侗族自治县",
		    "431228": "芷江侗族自治县",
		    "431229": "靖州苗族侗族自治县",
		    "431230": "通道侗族自治县",
		    "431281": "洪江市",
		    "431282": "其它区",
		    "431300": "娄底市",
		    "431302": "娄星区",
		    "431321": "双峰县",
		    "431322": "新化县",
		    "431381": "冷水江市",
		    "431382": "涟源市",
		    "431383": "其它区",
		    "433100": "湘西土家族苗族自治州",
		    "433101": "吉首市",
		    "433122": "泸溪县",
		    "433123": "凤凰县",
		    "433124": "花垣县",
		    "433125": "保靖县",
		    "433126": "古丈县",
		    "433127": "永顺县",
		    "433130": "龙山县",
		    "433131": "其它区",
		    "440000": "广东省",
		    "440100": "广州市",
		    "440103": "荔湾区",
		    "440104": "越秀区",
		    "440105": "海珠区",
		    "440106": "天河区",
		    "440111": "白云区",
		    "440112": "黄埔区",
		    "440113": "番禺区",
		    "440114": "花都区",
		    "440115": "南沙区",
		    "440116": "萝岗区",
		    "440183": "增城市",
		    "440184": "从化市",
		    "440189": "其它区",
		    "440200": "韶关市",
		    "440203": "武江区",
		    "440204": "浈江区",
		    "440205": "曲江区",
		    "440222": "始兴县",
		    "440224": "仁化县",
		    "440229": "翁源县",
		    "440232": "乳源瑶族自治县",
		    "440233": "新丰县",
		    "440281": "乐昌市",
		    "440282": "南雄市",
		    "440283": "其它区",
		    "440300": "深圳市",
		    "440303": "罗湖区",
		    "440304": "福田区",
		    "440305": "南山区",
		    "440306": "宝安区",
		    "440307": "龙岗区",
		    "440308": "盐田区",
		    "440309": "其它区",
		    "440320": "光明新区",
		    "440321": "坪山新区",
		    "440322": "大鹏新区",
		    "440323": "龙华新区",
		    "440400": "珠海市",
		    "440402": "香洲区",
		    "440403": "斗门区",
		    "440404": "金湾区",
		    "440488": "其它区",
		    "440500": "汕头市",
		    "440507": "龙湖区",
		    "440511": "金平区",
		    "440512": "濠江区",
		    "440513": "潮阳区",
		    "440514": "潮南区",
		    "440515": "澄海区",
		    "440523": "南澳县",
		    "440524": "其它区",
		    "440600": "佛山市",
		    "440604": "禅城区",
		    "440605": "南海区",
		    "440606": "顺德区",
		    "440607": "三水区",
		    "440608": "高明区",
		    "440609": "其它区",
		    "440700": "江门市",
		    "440703": "蓬江区",
		    "440704": "江海区",
		    "440705": "新会区",
		    "440781": "台山市",
		    "440783": "开平市",
		    "440784": "鹤山市",
		    "440785": "恩平市",
		    "440786": "其它区",
		    "440800": "湛江市",
		    "440802": "赤坎区",
		    "440803": "霞山区",
		    "440804": "坡头区",
		    "440811": "麻章区",
		    "440823": "遂溪县",
		    "440825": "徐闻县",
		    "440881": "廉江市",
		    "440882": "雷州市",
		    "440883": "吴川市",
		    "440884": "其它区",
		    "440900": "茂名市",
		    "440902": "茂南区",
		    "440903": "茂港区",
		    "440923": "电白县",
		    "440981": "高州市",
		    "440982": "化州市",
		    "440983": "信宜市",
		    "440984": "其它区",
		    "441200": "肇庆市",
		    "441202": "端州区",
		    "441203": "鼎湖区",
		    "441223": "广宁县",
		    "441224": "怀集县",
		    "441225": "封开县",
		    "441226": "德庆县",
		    "441283": "高要市",
		    "441284": "四会市",
		    "441285": "其它区",
		    "441300": "惠州市",
		    "441302": "惠城区",
		    "441303": "惠阳区",
		    "441322": "博罗县",
		    "441323": "惠东县",
		    "441324": "龙门县",
		    "441325": "其它区",
		    "441400": "梅州市",
		    "441402": "梅江区",
		    "441421": "梅县",
		    "441422": "大埔县",
		    "441423": "丰顺县",
		    "441424": "五华县",
		    "441426": "平远县",
		    "441427": "蕉岭县",
		    "441481": "兴宁市",
		    "441482": "其它区",
		    "441500": "汕尾市",
		    "441502": "城区",
		    "441521": "海丰县",
		    "441523": "陆河县",
		    "441581": "陆丰市",
		    "441582": "其它区",
		    "441600": "河源市",
		    "441602": "源城区",
		    "441621": "紫金县",
		    "441622": "龙川县",
		    "441623": "连平县",
		    "441624": "和平县",
		    "441625": "东源县",
		    "441626": "其它区",
		    "441700": "阳江市",
		    "441702": "江城区",
		    "441721": "阳西县",
		    "441723": "阳东县",
		    "441781": "阳春市",
		    "441782": "其它区",
		    "441800": "清远市",
		    "441802": "清城区",
		    "441821": "佛冈县",
		    "441823": "阳山县",
		    "441825": "连山壮族瑶族自治县",
		    "441826": "连南瑶族自治县",
		    "441827": "清新区",
		    "441881": "英德市",
		    "441882": "连州市",
		    "441883": "其它区",
		    "441900": "东莞市",
		    "442000": "中山市",
		    "442101": "东沙群岛",
		    "445100": "潮州市",
		    "445102": "湘桥区",
		    "445121": "潮安区",
		    "445122": "饶平县",
		    "445186": "其它区",
		    "445200": "揭阳市",
		    "445202": "榕城区",
		    "445221": "揭东区",
		    "445222": "揭西县",
		    "445224": "惠来县",
		    "445281": "普宁市",
		    "445285": "其它区",
		    "445300": "云浮市",
		    "445302": "云城区",
		    "445321": "新兴县",
		    "445322": "郁南县",
		    "445323": "云安县",
		    "445381": "罗定市",
		    "445382": "其它区",
		    "450000": "广西壮族自治区",
		    "450100": "南宁市",
		    "450102": "兴宁区",
		    "450103": "青秀区",
		    "450105": "江南区",
		    "450107": "西乡塘区",
		    "450108": "良庆区",
		    "450109": "邕宁区",
		    "450122": "武鸣县",
		    "450123": "隆安县",
		    "450124": "马山县",
		    "450125": "上林县",
		    "450126": "宾阳县",
		    "450127": "横县",
		    "450128": "其它区",
		    "450200": "柳州市",
		    "450202": "城中区",
		    "450203": "鱼峰区",
		    "450204": "柳南区",
		    "450205": "柳北区",
		    "450221": "柳江县",
		    "450222": "柳城县",
		    "450223": "鹿寨县",
		    "450224": "融安县",
		    "450225": "融水苗族自治县",
		    "450226": "三江侗族自治县",
		    "450227": "其它区",
		    "450300": "桂林市",
		    "450302": "秀峰区",
		    "450303": "叠彩区",
		    "450304": "象山区",
		    "450305": "七星区",
		    "450311": "雁山区",
		    "450321": "阳朔县",
		    "450322": "临桂区",
		    "450323": "灵川县",
		    "450324": "全州县",
		    "450325": "兴安县",
		    "450326": "永福县",
		    "450327": "灌阳县",
		    "450328": "龙胜各族自治县",
		    "450329": "资源县",
		    "450330": "平乐县",
		    "450331": "荔浦县",
		    "450332": "恭城瑶族自治县",
		    "450333": "其它区",
		    "450400": "梧州市",
		    "450403": "万秀区",
		    "450405": "长洲区",
		    "450406": "龙圩区",
		    "450421": "苍梧县",
		    "450422": "藤县",
		    "450423": "蒙山县",
		    "450481": "岑溪市",
		    "450482": "其它区",
		    "450500": "北海市",
		    "450502": "海城区",
		    "450503": "银海区",
		    "450512": "铁山港区",
		    "450521": "合浦县",
		    "450522": "其它区",
		    "450600": "防城港市",
		    "450602": "港口区",
		    "450603": "防城区",
		    "450621": "上思县",
		    "450681": "东兴市",
		    "450682": "其它区",
		    "450700": "钦州市",
		    "450702": "钦南区",
		    "450703": "钦北区",
		    "450721": "灵山县",
		    "450722": "浦北县",
		    "450723": "其它区",
		    "450800": "贵港市",
		    "450802": "港北区",
		    "450803": "港南区",
		    "450804": "覃塘区",
		    "450821": "平南县",
		    "450881": "桂平市",
		    "450882": "其它区",
		    "450900": "玉林市",
		    "450902": "玉州区",
		    "450903": "福绵区",
		    "450921": "容县",
		    "450922": "陆川县",
		    "450923": "博白县",
		    "450924": "兴业县",
		    "450981": "北流市",
		    "450982": "其它区",
		    "451000": "百色市",
		    "451002": "右江区",
		    "451021": "田阳县",
		    "451022": "田东县",
		    "451023": "平果县",
		    "451024": "德保县",
		    "451025": "靖西县",
		    "451026": "那坡县",
		    "451027": "凌云县",
		    "451028": "乐业县",
		    "451029": "田林县",
		    "451030": "西林县",
		    "451031": "隆林各族自治县",
		    "451032": "其它区",
		    "451100": "贺州市",
		    "451102": "八步区",
		    "451119": "平桂管理区",
		    "451121": "昭平县",
		    "451122": "钟山县",
		    "451123": "富川瑶族自治县",
		    "451124": "其它区",
		    "451200": "河池市",
		    "451202": "金城江区",
		    "451221": "南丹县",
		    "451222": "天峨县",
		    "451223": "凤山县",
		    "451224": "东兰县",
		    "451225": "罗城仫佬族自治县",
		    "451226": "环江毛南族自治县",
		    "451227": "巴马瑶族自治县",
		    "451228": "都安瑶族自治县",
		    "451229": "大化瑶族自治县",
		    "451281": "宜州市",
		    "451282": "其它区",
		    "451300": "来宾市",
		    "451302": "兴宾区",
		    "451321": "忻城县",
		    "451322": "象州县",
		    "451323": "武宣县",
		    "451324": "金秀瑶族自治县",
		    "451381": "合山市",
		    "451382": "其它区",
		    "451400": "崇左市",
		    "451402": "江州区",
		    "451421": "扶绥县",
		    "451422": "宁明县",
		    "451423": "龙州县",
		    "451424": "大新县",
		    "451425": "天等县",
		    "451481": "凭祥市",
		    "451482": "其它区",
		    "460000": "海南省",
		    "460100": "海口市",
		    "460105": "秀英区",
		    "460106": "龙华区",
		    "460107": "琼山区",
		    "460108": "美兰区",
		    "460109": "其它区",
		    "460200": "三亚市",
		    "460300": "三沙市",
		    "460321": "西沙群岛",
		    "460322": "南沙群岛",
		    "460323": "中沙群岛的岛礁及其海域",
		    "469001": "五指山市",
		    "469002": "琼海市",
		    "469003": "儋州市",
		    "469005": "文昌市",
		    "469006": "万宁市",
		    "469007": "东方市",
		    "469025": "定安县",
		    "469026": "屯昌县",
		    "469027": "澄迈县",
		    "469028": "临高县",
		    "469030": "白沙黎族自治县",
		    "469031": "昌江黎族自治县",
		    "469033": "乐东黎族自治县",
		    "469034": "陵水黎族自治县",
		    "469035": "保亭黎族苗族自治县",
		    "469036": "琼中黎族苗族自治县",
		    "471005": "其它区",
		    "500000": "重庆",
		    "500100": "重庆市",
		    "500101": "万州区",
		    "500102": "涪陵区",
		    "500103": "渝中区",
		    "500104": "大渡口区",
		    "500105": "江北区",
		    "500106": "沙坪坝区",
		    "500107": "九龙坡区",
		    "500108": "南岸区",
		    "500109": "北碚区",
		    "500110": "万盛区",
		    "500111": "双桥区",
		    "500112": "渝北区",
		    "500113": "巴南区",
		    "500114": "黔江区",
		    "500115": "长寿区",
		    "500222": "綦江区",
		    "500223": "潼南县",
		    "500224": "铜梁县",
		    "500225": "大足区",
		    "500226": "荣昌县",
		    "500227": "璧山县",
		    "500228": "梁平县",
		    "500229": "城口县",
		    "500230": "丰都县",
		    "500231": "垫江县",
		    "500232": "武隆县",
		    "500233": "忠县",
		    "500234": "开县",
		    "500235": "云阳县",
		    "500236": "奉节县",
		    "500237": "巫山县",
		    "500238": "巫溪县",
		    "500240": "石柱土家族自治县",
		    "500241": "秀山土家族苗族自治县",
		    "500242": "酉阳土家族苗族自治县",
		    "500243": "彭水苗族土家族自治县",
		    "500381": "江津区",
		    "500382": "合川区",
		    "500383": "永川区",
		    "500384": "南川区",
		    "500385": "其它区",
		    "510000": "四川省",
		    "510100": "成都市",
		    "510104": "锦江区",
		    "510105": "青羊区",
		    "510106": "金牛区",
		    "510107": "武侯区",
		    "510108": "成华区",
		    "510112": "龙泉驿区",
		    "510113": "青白江区",
		    "510114": "新都区",
		    "510115": "温江区",
		    "510121": "金堂县",
		    "510122": "双流县",
		    "510124": "郫县",
		    "510129": "大邑县",
		    "510131": "蒲江县",
		    "510132": "新津县",
		    "510181": "都江堰市",
		    "510182": "彭州市",
		    "510183": "邛崃市",
		    "510184": "崇州市",
		    "510185": "其它区",
		    "510300": "自贡市",
		    "510302": "自流井区",
		    "510303": "贡井区",
		    "510304": "大安区",
		    "510311": "沿滩区",
		    "510321": "荣县",
		    "510322": "富顺县",
		    "510323": "其它区",
		    "510400": "攀枝花市",
		    "510402": "东区",
		    "510403": "西区",
		    "510411": "仁和区",
		    "510421": "米易县",
		    "510422": "盐边县",
		    "510423": "其它区",
		    "510500": "泸州市",
		    "510502": "江阳区",
		    "510503": "纳溪区",
		    "510504": "龙马潭区",
		    "510521": "泸县",
		    "510522": "合江县",
		    "510524": "叙永县",
		    "510525": "古蔺县",
		    "510526": "其它区",
		    "510600": "德阳市",
		    "510603": "旌阳区",
		    "510623": "中江县",
		    "510626": "罗江县",
		    "510681": "广汉市",
		    "510682": "什邡市",
		    "510683": "绵竹市",
		    "510684": "其它区",
		    "510700": "绵阳市",
		    "510703": "涪城区",
		    "510704": "游仙区",
		    "510722": "三台县",
		    "510723": "盐亭县",
		    "510724": "安县",
		    "510725": "梓潼县",
		    "510726": "北川羌族自治县",
		    "510727": "平武县",
		    "510781": "江油市",
		    "510782": "其它区",
		    "510800": "广元市",
		    "510802": "利州区",
		    "510811": "昭化区",
		    "510812": "朝天区",
		    "510821": "旺苍县",
		    "510822": "青川县",
		    "510823": "剑阁县",
		    "510824": "苍溪县",
		    "510825": "其它区",
		    "510900": "遂宁市",
		    "510903": "船山区",
		    "510904": "安居区",
		    "510921": "蓬溪县",
		    "510922": "射洪县",
		    "510923": "大英县",
		    "510924": "其它区",
		    "511000": "内江市",
		    "511002": "市中区",
		    "511011": "东兴区",
		    "511024": "威远县",
		    "511025": "资中县",
		    "511028": "隆昌县",
		    "511029": "其它区",
		    "511100": "乐山市",
		    "511102": "市中区",
		    "511111": "沙湾区",
		    "511112": "五通桥区",
		    "511113": "金口河区",
		    "511123": "犍为县",
		    "511124": "井研县",
		    "511126": "夹江县",
		    "511129": "沐川县",
		    "511132": "峨边彝族自治县",
		    "511133": "马边彝族自治县",
		    "511181": "峨眉山市",
		    "511182": "其它区",
		    "511300": "南充市",
		    "511302": "顺庆区",
		    "511303": "高坪区",
		    "511304": "嘉陵区",
		    "511321": "南部县",
		    "511322": "营山县",
		    "511323": "蓬安县",
		    "511324": "仪陇县",
		    "511325": "西充县",
		    "511381": "阆中市",
		    "511382": "其它区",
		    "511400": "眉山市",
		    "511402": "东坡区",
		    "511421": "仁寿县",
		    "511422": "彭山县",
		    "511423": "洪雅县",
		    "511424": "丹棱县",
		    "511425": "青神县",
		    "511426": "其它区",
		    "511500": "宜宾市",
		    "511502": "翠屏区",
		    "511521": "宜宾县",
		    "511522": "南溪区",
		    "511523": "江安县",
		    "511524": "长宁县",
		    "511525": "高县",
		    "511526": "珙县",
		    "511527": "筠连县",
		    "511528": "兴文县",
		    "511529": "屏山县",
		    "511530": "其它区",
		    "511600": "广安市",
		    "511602": "广安区",
		    "511603": "前锋区",
		    "511621": "岳池县",
		    "511622": "武胜县",
		    "511623": "邻水县",
		    "511681": "华蓥市",
		    "511683": "其它区",
		    "511700": "达州市",
		    "511702": "通川区",
		    "511721": "达川区",
		    "511722": "宣汉县",
		    "511723": "开江县",
		    "511724": "大竹县",
		    "511725": "渠县",
		    "511781": "万源市",
		    "511782": "其它区",
		    "511800": "雅安市",
		    "511802": "雨城区",
		    "511821": "名山区",
		    "511822": "荥经县",
		    "511823": "汉源县",
		    "511824": "石棉县",
		    "511825": "天全县",
		    "511826": "芦山县",
		    "511827": "宝兴县",
		    "511828": "其它区",
		    "511900": "巴中市",
		    "511902": "巴州区",
		    "511903": "恩阳区",
		    "511921": "通江县",
		    "511922": "南江县",
		    "511923": "平昌县",
		    "511924": "其它区",
		    "512000": "资阳市",
		    "512002": "雁江区",
		    "512021": "安岳县",
		    "512022": "乐至县",
		    "512081": "简阳市",
		    "512082": "其它区",
		    "513200": "阿坝藏族羌族自治州",
		    "513221": "汶川县",
		    "513222": "理县",
		    "513223": "茂县",
		    "513224": "松潘县",
		    "513225": "九寨沟县",
		    "513226": "金川县",
		    "513227": "小金县",
		    "513228": "黑水县",
		    "513229": "马尔康县",
		    "513230": "壤塘县",
		    "513231": "阿坝县",
		    "513232": "若尔盖县",
		    "513233": "红原县",
		    "513234": "其它区",
		    "513300": "甘孜藏族自治州",
		    "513321": "康定县",
		    "513322": "泸定县",
		    "513323": "丹巴县",
		    "513324": "九龙县",
		    "513325": "雅江县",
		    "513326": "道孚县",
		    "513327": "炉霍县",
		    "513328": "甘孜县",
		    "513329": "新龙县",
		    "513330": "德格县",
		    "513331": "白玉县",
		    "513332": "石渠县",
		    "513333": "色达县",
		    "513334": "理塘县",
		    "513335": "巴塘县",
		    "513336": "乡城县",
		    "513337": "稻城县",
		    "513338": "得荣县",
		    "513339": "其它区",
		    "513400": "凉山彝族自治州",
		    "513401": "西昌市",
		    "513422": "木里藏族自治县",
		    "513423": "盐源县",
		    "513424": "德昌县",
		    "513425": "会理县",
		    "513426": "会东县",
		    "513427": "宁南县",
		    "513428": "普格县",
		    "513429": "布拖县",
		    "513430": "金阳县",
		    "513431": "昭觉县",
		    "513432": "喜德县",
		    "513433": "冕宁县",
		    "513434": "越西县",
		    "513435": "甘洛县",
		    "513436": "美姑县",
		    "513437": "雷波县",
		    "513438": "其它区",
		    "520000": "贵州省",
		    "520100": "贵阳市",
		    "520102": "南明区",
		    "520103": "云岩区",
		    "520111": "花溪区",
		    "520112": "乌当区",
		    "520113": "白云区",
		    "520121": "开阳县",
		    "520122": "息烽县",
		    "520123": "修文县",
		    "520151": "观山湖区",
		    "520181": "清镇市",
		    "520182": "其它区",
		    "520200": "六盘水市",
		    "520201": "钟山区",
		    "520203": "六枝特区",
		    "520221": "水城县",
		    "520222": "盘县",
		    "520223": "其它区",
		    "520300": "遵义市",
		    "520302": "红花岗区",
		    "520303": "汇川区",
		    "520321": "遵义县",
		    "520322": "桐梓县",
		    "520323": "绥阳县",
		    "520324": "正安县",
		    "520325": "道真仡佬族苗族自治县",
		    "520326": "务川仡佬族苗族自治县",
		    "520327": "凤冈县",
		    "520328": "湄潭县",
		    "520329": "余庆县",
		    "520330": "习水县",
		    "520381": "赤水市",
		    "520382": "仁怀市",
		    "520383": "其它区",
		    "520400": "安顺市",
		    "520402": "西秀区",
		    "520421": "平坝县",
		    "520422": "普定县",
		    "520423": "镇宁布依族苗族自治县",
		    "520424": "关岭布依族苗族自治县",
		    "520425": "紫云苗族布依族自治县",
		    "520426": "其它区",
		    "522200": "铜仁市",
		    "522201": "碧江区",
		    "522222": "江口县",
		    "522223": "玉屏侗族自治县",
		    "522224": "石阡县",
		    "522225": "思南县",
		    "522226": "印江土家族苗族自治县",
		    "522227": "德江县",
		    "522228": "沿河土家族自治县",
		    "522229": "松桃苗族自治县",
		    "522230": "万山区",
		    "522231": "其它区",
		    "522300": "黔西南布依族苗族自治州",
		    "522301": "兴义市",
		    "522322": "兴仁县",
		    "522323": "普安县",
		    "522324": "晴隆县",
		    "522325": "贞丰县",
		    "522326": "望谟县",
		    "522327": "册亨县",
		    "522328": "安龙县",
		    "522329": "其它区",
		    "522400": "毕节市",
		    "522401": "七星关区",
		    "522422": "大方县",
		    "522423": "黔西县",
		    "522424": "金沙县",
		    "522425": "织金县",
		    "522426": "纳雍县",
		    "522427": "威宁彝族回族苗族自治县",
		    "522428": "赫章县",
		    "522429": "其它区",
		    "522600": "黔东南苗族侗族自治州",
		    "522601": "凯里市",
		    "522622": "黄平县",
		    "522623": "施秉县",
		    "522624": "三穗县",
		    "522625": "镇远县",
		    "522626": "岑巩县",
		    "522627": "天柱县",
		    "522628": "锦屏县",
		    "522629": "剑河县",
		    "522630": "台江县",
		    "522631": "黎平县",
		    "522632": "榕江县",
		    "522633": "从江县",
		    "522634": "雷山县",
		    "522635": "麻江县",
		    "522636": "丹寨县",
		    "522637": "其它区",
		    "522700": "黔南布依族苗族自治州",
		    "522701": "都匀市",
		    "522702": "福泉市",
		    "522722": "荔波县",
		    "522723": "贵定县",
		    "522725": "瓮安县",
		    "522726": "独山县",
		    "522727": "平塘县",
		    "522728": "罗甸县",
		    "522729": "长顺县",
		    "522730": "龙里县",
		    "522731": "惠水县",
		    "522732": "三都水族自治县",
		    "522733": "其它区",
		    "530000": "云南省",
		    "530100": "昆明市",
		    "530102": "五华区",
		    "530103": "盘龙区",
		    "530111": "官渡区",
		    "530112": "西山区",
		    "530113": "东川区",
		    "530121": "呈贡区",
		    "530122": "晋宁县",
		    "530124": "富民县",
		    "530125": "宜良县",
		    "530126": "石林彝族自治县",
		    "530127": "嵩明县",
		    "530128": "禄劝彝族苗族自治县",
		    "530129": "寻甸回族彝族自治县",
		    "530181": "安宁市",
		    "530182": "其它区",
		    "530300": "曲靖市",
		    "530302": "麒麟区",
		    "530321": "马龙县",
		    "530322": "陆良县",
		    "530323": "师宗县",
		    "530324": "罗平县",
		    "530325": "富源县",
		    "530326": "会泽县",
		    "530328": "沾益县",
		    "530381": "宣威市",
		    "530382": "其它区",
		    "530400": "玉溪市",
		    "530402": "红塔区",
		    "530421": "江川县",
		    "530422": "澄江县",
		    "530423": "通海县",
		    "530424": "华宁县",
		    "530425": "易门县",
		    "530426": "峨山彝族自治县",
		    "530427": "新平彝族傣族自治县",
		    "530428": "元江哈尼族彝族傣族自治县",
		    "530429": "其它区",
		    "530500": "保山市",
		    "530502": "隆阳区",
		    "530521": "施甸县",
		    "530522": "腾冲县",
		    "530523": "龙陵县",
		    "530524": "昌宁县",
		    "530525": "其它区",
		    "530600": "昭通市",
		    "530602": "昭阳区",
		    "530621": "鲁甸县",
		    "530622": "巧家县",
		    "530623": "盐津县",
		    "530624": "大关县",
		    "530625": "永善县",
		    "530626": "绥江县",
		    "530627": "镇雄县",
		    "530628": "彝良县",
		    "530629": "威信县",
		    "530630": "水富县",
		    "530631": "其它区",
		    "530700": "丽江市",
		    "530702": "古城区",
		    "530721": "玉龙纳西族自治县",
		    "530722": "永胜县",
		    "530723": "华坪县",
		    "530724": "宁蒗彝族自治县",
		    "530725": "其它区",
		    "530800": "普洱市",
		    "530802": "思茅区",
		    "530821": "宁洱哈尼族彝族自治县",
		    "530822": "墨江哈尼族自治县",
		    "530823": "景东彝族自治县",
		    "530824": "景谷傣族彝族自治县",
		    "530825": "镇沅彝族哈尼族拉祜族自治县",
		    "530826": "江城哈尼族彝族自治县",
		    "530827": "孟连傣族拉祜族佤族自治县",
		    "530828": "澜沧拉祜族自治县",
		    "530829": "西盟佤族自治县",
		    "530830": "其它区",
		    "530900": "临沧市",
		    "530902": "临翔区",
		    "530921": "凤庆县",
		    "530922": "云县",
		    "530923": "永德县",
		    "530924": "镇康县",
		    "530925": "双江拉祜族佤族布朗族傣族自治县",
		    "530926": "耿马傣族佤族自治县",
		    "530927": "沧源佤族自治县",
		    "530928": "其它区",
		    "532300": "楚雄彝族自治州",
		    "532301": "楚雄市",
		    "532322": "双柏县",
		    "532323": "牟定县",
		    "532324": "南华县",
		    "532325": "姚安县",
		    "532326": "大姚县",
		    "532327": "永仁县",
		    "532328": "元谋县",
		    "532329": "武定县",
		    "532331": "禄丰县",
		    "532332": "其它区",
		    "532500": "红河哈尼族彝族自治州",
		    "532501": "个旧市",
		    "532502": "开远市",
		    "532522": "蒙自市",
		    "532523": "屏边苗族自治县",
		    "532524": "建水县",
		    "532525": "石屏县",
		    "532526": "弥勒市",
		    "532527": "泸西县",
		    "532528": "元阳县",
		    "532529": "红河县",
		    "532530": "金平苗族瑶族傣族自治县",
		    "532531": "绿春县",
		    "532532": "河口瑶族自治县",
		    "532533": "其它区",
		    "532600": "文山壮族苗族自治州",
		    "532621": "文山市",
		    "532622": "砚山县",
		    "532623": "西畴县",
		    "532624": "麻栗坡县",
		    "532625": "马关县",
		    "532626": "丘北县",
		    "532627": "广南县",
		    "532628": "富宁县",
		    "532629": "其它区",
		    "532800": "西双版纳傣族自治州",
		    "532801": "景洪市",
		    "532822": "勐海县",
		    "532823": "勐腊县",
		    "532824": "其它区",
		    "532900": "大理白族自治州",
		    "532901": "大理市",
		    "532922": "漾濞彝族自治县",
		    "532923": "祥云县",
		    "532924": "宾川县",
		    "532925": "弥渡县",
		    "532926": "南涧彝族自治县",
		    "532927": "巍山彝族回族自治县",
		    "532928": "永平县",
		    "532929": "云龙县",
		    "532930": "洱源县",
		    "532931": "剑川县",
		    "532932": "鹤庆县",
		    "532933": "其它区",
		    "533100": "德宏傣族景颇族自治州",
		    "533102": "瑞丽市",
		    "533103": "芒市",
		    "533122": "梁河县",
		    "533123": "盈江县",
		    "533124": "陇川县",
		    "533125": "其它区",
		    "533300": "怒江傈僳族自治州",
		    "533321": "泸水县",
		    "533323": "福贡县",
		    "533324": "贡山独龙族怒族自治县",
		    "533325": "兰坪白族普米族自治县",
		    "533326": "其它区",
		    "533400": "迪庆藏族自治州",
		    "533421": "香格里拉县",
		    "533422": "德钦县",
		    "533423": "维西傈僳族自治县",
		    "533424": "其它区",
		    "540000": "西藏自治区",
		    "540100": "拉萨市",
		    "540102": "城关区",
		    "540121": "林周县",
		    "540122": "当雄县",
		    "540123": "尼木县",
		    "540124": "曲水县",
		    "540125": "堆龙德庆县",
		    "540126": "达孜县",
		    "540127": "墨竹工卡县",
		    "540128": "其它区",
		    "542100": "昌都地区",
		    "542121": "昌都县",
		    "542122": "江达县",
		    "542123": "贡觉县",
		    "542124": "类乌齐县",
		    "542125": "丁青县",
		    "542126": "察雅县",
		    "542127": "八宿县",
		    "542128": "左贡县",
		    "542129": "芒康县",
		    "542132": "洛隆县",
		    "542133": "边坝县",
		    "542134": "其它区",
		    "542200": "山南地区",
		    "542221": "乃东县",
		    "542222": "扎囊县",
		    "542223": "贡嘎县",
		    "542224": "桑日县",
		    "542225": "琼结县",
		    "542226": "曲松县",
		    "542227": "措美县",
		    "542228": "洛扎县",
		    "542229": "加查县",
		    "542231": "隆子县",
		    "542232": "错那县",
		    "542233": "浪卡子县",
		    "542234": "其它区",
		    "542300": "日喀则地区",
		    "542301": "日喀则市",
		    "542322": "南木林县",
		    "542323": "江孜县",
		    "542324": "定日县",
		    "542325": "萨迦县",
		    "542326": "拉孜县",
		    "542327": "昂仁县",
		    "542328": "谢通门县",
		    "542329": "白朗县",
		    "542330": "仁布县",
		    "542331": "康马县",
		    "542332": "定结县",
		    "542333": "仲巴县",
		    "542334": "亚东县",
		    "542335": "吉隆县",
		    "542336": "聂拉木县",
		    "542337": "萨嘎县",
		    "542338": "岗巴县",
		    "542339": "其它区",
		    "542400": "那曲地区",
		    "542421": "那曲县",
		    "542422": "嘉黎县",
		    "542423": "比如县",
		    "542424": "聂荣县",
		    "542425": "安多县",
		    "542426": "申扎县",
		    "542427": "索县",
		    "542428": "班戈县",
		    "542429": "巴青县",
		    "542430": "尼玛县",
		    "542431": "其它区",
		    "542432": "双湖县",
		    "542500": "阿里地区",
		    "542521": "普兰县",
		    "542522": "札达县",
		    "542523": "噶尔县",
		    "542524": "日土县",
		    "542525": "革吉县",
		    "542526": "改则县",
		    "542527": "措勤县",
		    "542528": "其它区",
		    "542600": "林芝地区",
		    "542621": "林芝县",
		    "542622": "工布江达县",
		    "542623": "米林县",
		    "542624": "墨脱县",
		    "542625": "波密县",
		    "542626": "察隅县",
		    "542627": "朗县",
		    "542628": "其它区",
		    "610000": "陕西省",
		    "610100": "西安市",
		    "610102": "新城区",
		    "610103": "碑林区",
		    "610104": "莲湖区",
		    "610111": "灞桥区",
		    "610112": "未央区",
		    "610113": "雁塔区",
		    "610114": "阎良区",
		    "610115": "临潼区",
		    "610116": "长安区",
		    "610122": "蓝田县",
		    "610124": "周至县",
		    "610125": "户县",
		    "610126": "高陵县",
		    "610127": "其它区",
		    "610200": "铜川市",
		    "610202": "王益区",
		    "610203": "印台区",
		    "610204": "耀州区",
		    "610222": "宜君县",
		    "610223": "其它区",
		    "610300": "宝鸡市",
		    "610302": "渭滨区",
		    "610303": "金台区",
		    "610304": "陈仓区",
		    "610322": "凤翔县",
		    "610323": "岐山县",
		    "610324": "扶风县",
		    "610326": "眉县",
		    "610327": "陇县",
		    "610328": "千阳县",
		    "610329": "麟游县",
		    "610330": "凤县",
		    "610331": "太白县",
		    "610332": "其它区",
		    "610400": "咸阳市",
		    "610402": "秦都区",
		    "610403": "杨陵区",
		    "610404": "渭城区",
		    "610422": "三原县",
		    "610423": "泾阳县",
		    "610424": "乾县",
		    "610425": "礼泉县",
		    "610426": "永寿县",
		    "610427": "彬县",
		    "610428": "长武县",
		    "610429": "旬邑县",
		    "610430": "淳化县",
		    "610431": "武功县",
		    "610481": "兴平市",
		    "610482": "其它区",
		    "610500": "渭南市",
		    "610502": "临渭区",
		    "610521": "华县",
		    "610522": "潼关县",
		    "610523": "大荔县",
		    "610524": "合阳县",
		    "610525": "澄城县",
		    "610526": "蒲城县",
		    "610527": "白水县",
		    "610528": "富平县",
		    "610581": "韩城市",
		    "610582": "华阴市",
		    "610583": "其它区",
		    "610600": "延安市",
		    "610602": "宝塔区",
		    "610621": "延长县",
		    "610622": "延川县",
		    "610623": "子长县",
		    "610624": "安塞县",
		    "610625": "志丹县",
		    "610626": "吴起县",
		    "610627": "甘泉县",
		    "610628": "富县",
		    "610629": "洛川县",
		    "610630": "宜川县",
		    "610631": "黄龙县",
		    "610632": "黄陵县",
		    "610633": "其它区",
		    "610700": "汉中市",
		    "610702": "汉台区",
		    "610721": "南郑县",
		    "610722": "城固县",
		    "610723": "洋县",
		    "610724": "西乡县",
		    "610725": "勉县",
		    "610726": "宁强县",
		    "610727": "略阳县",
		    "610728": "镇巴县",
		    "610729": "留坝县",
		    "610730": "佛坪县",
		    "610731": "其它区",
		    "610800": "榆林市",
		    "610802": "榆阳区",
		    "610821": "神木县",
		    "610822": "府谷县",
		    "610823": "横山县",
		    "610824": "靖边县",
		    "610825": "定边县",
		    "610826": "绥德县",
		    "610827": "米脂县",
		    "610828": "佳县",
		    "610829": "吴堡县",
		    "610830": "清涧县",
		    "610831": "子洲县",
		    "610832": "其它区",
		    "610900": "安康市",
		    "610902": "汉滨区",
		    "610921": "汉阴县",
		    "610922": "石泉县",
		    "610923": "宁陕县",
		    "610924": "紫阳县",
		    "610925": "岚皋县",
		    "610926": "平利县",
		    "610927": "镇坪县",
		    "610928": "旬阳县",
		    "610929": "白河县",
		    "610930": "其它区",
		    "611000": "商洛市",
		    "611002": "商州区",
		    "611021": "洛南县",
		    "611022": "丹凤县",
		    "611023": "商南县",
		    "611024": "山阳县",
		    "611025": "镇安县",
		    "611026": "柞水县",
		    "611027": "其它区",
		    "620000": "甘肃省",
		    "620100": "兰州市",
		    "620102": "城关区",
		    "620103": "七里河区",
		    "620104": "西固区",
		    "620105": "安宁区",
		    "620111": "红古区",
		    "620121": "永登县",
		    "620122": "皋兰县",
		    "620123": "榆中县",
		    "620124": "其它区",
		    "620200": "嘉峪关市",
		    "620300": "金昌市",
		    "620302": "金川区",
		    "620321": "永昌县",
		    "620322": "其它区",
		    "620400": "白银市",
		    "620402": "白银区",
		    "620403": "平川区",
		    "620421": "靖远县",
		    "620422": "会宁县",
		    "620423": "景泰县",
		    "620424": "其它区",
		    "620500": "天水市",
		    "620502": "秦州区",
		    "620503": "麦积区",
		    "620521": "清水县",
		    "620522": "秦安县",
		    "620523": "甘谷县",
		    "620524": "武山县",
		    "620525": "张家川回族自治县",
		    "620526": "其它区",
		    "620600": "武威市",
		    "620602": "凉州区",
		    "620621": "民勤县",
		    "620622": "古浪县",
		    "620623": "天祝藏族自治县",
		    "620624": "其它区",
		    "620700": "张掖市",
		    "620702": "甘州区",
		    "620721": "肃南裕固族自治县",
		    "620722": "民乐县",
		    "620723": "临泽县",
		    "620724": "高台县",
		    "620725": "山丹县",
		    "620726": "其它区",
		    "620800": "平凉市",
		    "620802": "崆峒区",
		    "620821": "泾川县",
		    "620822": "灵台县",
		    "620823": "崇信县",
		    "620824": "华亭县",
		    "620825": "庄浪县",
		    "620826": "静宁县",
		    "620827": "其它区",
		    "620900": "酒泉市",
		    "620902": "肃州区",
		    "620921": "金塔县",
		    "620922": "瓜州县",
		    "620923": "肃北蒙古族自治县",
		    "620924": "阿克塞哈萨克族自治县",
		    "620981": "玉门市",
		    "620982": "敦煌市",
		    "620983": "其它区",
		    "621000": "庆阳市",
		    "621002": "西峰区",
		    "621021": "庆城县",
		    "621022": "环县",
		    "621023": "华池县",
		    "621024": "合水县",
		    "621025": "正宁县",
		    "621026": "宁县",
		    "621027": "镇原县",
		    "621028": "其它区",
		    "621100": "定西市",
		    "621102": "安定区",
		    "621121": "通渭县",
		    "621122": "陇西县",
		    "621123": "渭源县",
		    "621124": "临洮县",
		    "621125": "漳县",
		    "621126": "岷县",
		    "621127": "其它区",
		    "621200": "陇南市",
		    "621202": "武都区",
		    "621221": "成县",
		    "621222": "文县",
		    "621223": "宕昌县",
		    "621224": "康县",
		    "621225": "西和县",
		    "621226": "礼县",
		    "621227": "徽县",
		    "621228": "两当县",
		    "621229": "其它区",
		    "622900": "临夏回族自治州",
		    "622901": "临夏市",
		    "622921": "临夏县",
		    "622922": "康乐县",
		    "622923": "永靖县",
		    "622924": "广河县",
		    "622925": "和政县",
		    "622926": "东乡族自治县",
		    "622927": "积石山保安族东乡族撒拉族自治县",
		    "622928": "其它区",
		    "623000": "甘南藏族自治州",
		    "623001": "合作市",
		    "623021": "临潭县",
		    "623022": "卓尼县",
		    "623023": "舟曲县",
		    "623024": "迭部县",
		    "623025": "玛曲县",
		    "623026": "碌曲县",
		    "623027": "夏河县",
		    "623028": "其它区",
		    "630000": "青海省",
		    "630100": "西宁市",
		    "630102": "城东区",
		    "630103": "城中区",
		    "630104": "城西区",
		    "630105": "城北区",
		    "630121": "大通回族土族自治县",
		    "630122": "湟中县",
		    "630123": "湟源县",
		    "630124": "其它区",
		    "632100": "海东市",
		    "632121": "平安县",
		    "632122": "民和回族土族自治县",
		    "632123": "乐都区",
		    "632126": "互助土族自治县",
		    "632127": "化隆回族自治县",
		    "632128": "循化撒拉族自治县",
		    "632129": "其它区",
		    "632200": "海北藏族自治州",
		    "632221": "门源回族自治县",
		    "632222": "祁连县",
		    "632223": "海晏县",
		    "632224": "刚察县",
		    "632225": "其它区",
		    "632300": "黄南藏族自治州",
		    "632321": "同仁县",
		    "632322": "尖扎县",
		    "632323": "泽库县",
		    "632324": "河南蒙古族自治县",
		    "632325": "其它区",
		    "632500": "海南藏族自治州",
		    "632521": "共和县",
		    "632522": "同德县",
		    "632523": "贵德县",
		    "632524": "兴海县",
		    "632525": "贵南县",
		    "632526": "其它区",
		    "632600": "果洛藏族自治州",
		    "632621": "玛沁县",
		    "632622": "班玛县",
		    "632623": "甘德县",
		    "632624": "达日县",
		    "632625": "久治县",
		    "632626": "玛多县",
		    "632627": "其它区",
		    "632700": "玉树藏族自治州",
		    "632721": "玉树市",
		    "632722": "杂多县",
		    "632723": "称多县",
		    "632724": "治多县",
		    "632725": "囊谦县",
		    "632726": "曲麻莱县",
		    "632727": "其它区",
		    "632800": "海西蒙古族藏族自治州",
		    "632801": "格尔木市",
		    "632802": "德令哈市",
		    "632821": "乌兰县",
		    "632822": "都兰县",
		    "632823": "天峻县",
		    "632824": "其它区",
		    "640000": "宁夏回族自治区",
		    "640100": "银川市",
		    "640104": "兴庆区",
		    "640105": "西夏区",
		    "640106": "金凤区",
		    "640121": "永宁县",
		    "640122": "贺兰县",
		    "640181": "灵武市",
		    "640182": "其它区",
		    "640200": "石嘴山市",
		    "640202": "大武口区",
		    "640205": "惠农区",
		    "640221": "平罗县",
		    "640222": "其它区",
		    "640300": "吴忠市",
		    "640302": "利通区",
		    "640303": "红寺堡区",
		    "640323": "盐池县",
		    "640324": "同心县",
		    "640381": "青铜峡市",
		    "640382": "其它区",
		    "640400": "固原市",
		    "640402": "原州区",
		    "640422": "西吉县",
		    "640423": "隆德县",
		    "640424": "泾源县",
		    "640425": "彭阳县",
		    "640426": "其它区",
		    "640500": "中卫市",
		    "640502": "沙坡头区",
		    "640521": "中宁县",
		    "640522": "海原县",
		    "640523": "其它区",
		    "650000": "新疆维吾尔自治区",
		    "650100": "乌鲁木齐市",
		    "650102": "天山区",
		    "650103": "沙依巴克区",
		    "650104": "新市区",
		    "650105": "水磨沟区",
		    "650106": "头屯河区",
		    "650107": "达坂城区",
		    "650109": "米东区",
		    "650121": "乌鲁木齐县",
		    "650122": "其它区",
		    "650200": "克拉玛依市",
		    "650202": "独山子区",
		    "650203": "克拉玛依区",
		    "650204": "白碱滩区",
		    "650205": "乌尔禾区",
		    "650206": "其它区",
		    "652100": "吐鲁番地区",
		    "652101": "吐鲁番市",
		    "652122": "鄯善县",
		    "652123": "托克逊县",
		    "652124": "其它区",
		    "652200": "哈密地区",
		    "652201": "哈密市",
		    "652222": "巴里坤哈萨克自治县",
		    "652223": "伊吾县",
		    "652224": "其它区",
		    "652300": "昌吉回族自治州",
		    "652301": "昌吉市",
		    "652302": "阜康市",
		    "652323": "呼图壁县",
		    "652324": "玛纳斯县",
		    "652325": "奇台县",
		    "652327": "吉木萨尔县",
		    "652328": "木垒哈萨克自治县",
		    "652329": "其它区",
		    "652700": "博尔塔拉蒙古自治州",
		    "652701": "博乐市",
		    "652702": "阿拉山口市",
		    "652722": "精河县",
		    "652723": "温泉县",
		    "652724": "其它区",
		    "652800": "巴音郭楞蒙古自治州",
		    "652801": "库尔勒市",
		    "652822": "轮台县",
		    "652823": "尉犁县",
		    "652824": "若羌县",
		    "652825": "且末县",
		    "652826": "焉耆回族自治县",
		    "652827": "和静县",
		    "652828": "和硕县",
		    "652829": "博湖县",
		    "652830": "其它区",
		    "652900": "阿克苏地区",
		    "652901": "阿克苏市",
		    "652922": "温宿县",
		    "652923": "库车县",
		    "652924": "沙雅县",
		    "652925": "新和县",
		    "652926": "拜城县",
		    "652927": "乌什县",
		    "652928": "阿瓦提县",
		    "652929": "柯坪县",
		    "652930": "其它区",
		    "653000": "克孜勒苏柯尔克孜自治州",
		    "653001": "阿图什市",
		    "653022": "阿克陶县",
		    "653023": "阿合奇县",
		    "653024": "乌恰县",
		    "653025": "其它区",
		    "653100": "喀什地区",
		    "653101": "喀什市",
		    "653121": "疏附县",
		    "653122": "疏勒县",
		    "653123": "英吉沙县",
		    "653124": "泽普县",
		    "653125": "莎车县",
		    "653126": "叶城县",
		    "653127": "麦盖提县",
		    "653128": "岳普湖县",
		    "653129": "伽师县",
		    "653130": "巴楚县",
		    "653131": "塔什库尔干塔吉克自治县",
		    "653132": "其它区",
		    "653200": "和田地区",
		    "653201": "和田市",
		    "653221": "和田县",
		    "653222": "墨玉县",
		    "653223": "皮山县",
		    "653224": "洛浦县",
		    "653225": "策勒县",
		    "653226": "于田县",
		    "653227": "民丰县",
		    "653228": "其它区",
		    "654000": "伊犁哈萨克自治州",
		    "654002": "伊宁市",
		    "654003": "奎屯市",
		    "654021": "伊宁县",
		    "654022": "察布查尔锡伯自治县",
		    "654023": "霍城县",
		    "654024": "巩留县",
		    "654025": "新源县",
		    "654026": "昭苏县",
		    "654027": "特克斯县",
		    "654028": "尼勒克县",
		    "654029": "其它区",
		    "654200": "塔城地区",
		    "654201": "塔城市",
		    "654202": "乌苏市",
		    "654221": "额敏县",
		    "654223": "沙湾县",
		    "654224": "托里县",
		    "654225": "裕民县",
		    "654226": "和布克赛尔蒙古自治县",
		    "654227": "其它区",
		    "654300": "阿勒泰地区",
		    "654301": "阿勒泰市",
		    "654321": "布尔津县",
		    "654322": "富蕴县",
		    "654323": "福海县",
		    "654324": "哈巴河县",
		    "654325": "青河县",
		    "654326": "吉木乃县",
		    "654327": "其它区",
		    "659001": "石河子市",
		    "659002": "阿拉尔市",
		    "659003": "图木舒克市",
		    "659004": "五家渠市",
		    "710000": "台湾",
		    "710100": "台北市",
		    "710101": "中正区",
		    "710102": "大同区",
		    "710103": "中山区",
		    "710104": "松山区",
		    "710105": "大安区",
		    "710106": "万华区",
		    "710107": "信义区",
		    "710108": "士林区",
		    "710109": "北投区",
		    "710110": "内湖区",
		    "710111": "南港区",
		    "710112": "文山区",
		    "710113": "其它区",
		    "710200": "高雄市",
		    "710201": "新兴区",
		    "710202": "前金区",
		    "710203": "芩雅区",
		    "710204": "盐埕区",
		    "710205": "鼓山区",
		    "710206": "旗津区",
		    "710207": "前镇区",
		    "710208": "三民区",
		    "710209": "左营区",
		    "710210": "楠梓区",
		    "710211": "小港区",
		    "710212": "其它区",
		    "710241": "苓雅区",
		    "710242": "仁武区",
		    "710243": "大社区",
		    "710244": "冈山区",
		    "710245": "路竹区",
		    "710246": "阿莲区",
		    "710247": "田寮区",
		    "710248": "燕巢区",
		    "710249": "桥头区",
		    "710250": "梓官区",
		    "710251": "弥陀区",
		    "710252": "永安区",
		    "710253": "湖内区",
		    "710254": "凤山区",
		    "710255": "大寮区",
		    "710256": "林园区",
		    "710257": "鸟松区",
		    "710258": "大树区",
		    "710259": "旗山区",
		    "710260": "美浓区",
		    "710261": "六龟区",
		    "710262": "内门区",
		    "710263": "杉林区",
		    "710264": "甲仙区",
		    "710265": "桃源区",
		    "710266": "那玛夏区",
		    "710267": "茂林区",
		    "710268": "茄萣区",
		    "710300": "台南市",
		    "710301": "中西区",
		    "710302": "东区",
		    "710303": "南区",
		    "710304": "北区",
		    "710305": "安平区",
		    "710306": "安南区",
		    "710307": "其它区",
		    "710339": "永康区",
		    "710340": "归仁区",
		    "710341": "新化区",
		    "710342": "左镇区",
		    "710343": "玉井区",
		    "710344": "楠西区",
		    "710345": "南化区",
		    "710346": "仁德区",
		    "710347": "关庙区",
		    "710348": "龙崎区",
		    "710349": "官田区",
		    "710350": "麻豆区",
		    "710351": "佳里区",
		    "710352": "西港区",
		    "710353": "七股区",
		    "710354": "将军区",
		    "710355": "学甲区",
		    "710356": "北门区",
		    "710357": "新营区",
		    "710358": "后壁区",
		    "710359": "白河区",
		    "710360": "东山区",
		    "710361": "六甲区",
		    "710362": "下营区",
		    "710363": "柳营区",
		    "710364": "盐水区",
		    "710365": "善化区",
		    "710366": "大内区",
		    "710367": "山上区",
		    "710368": "新市区",
		    "710369": "安定区",
		    "710400": "台中市",
		    "710401": "中区",
		    "710402": "东区",
		    "710403": "南区",
		    "710404": "西区",
		    "710405": "北区",
		    "710406": "北屯区",
		    "710407": "西屯区",
		    "710408": "南屯区",
		    "710409": "其它区",
		    "710431": "太平区",
		    "710432": "大里区",
		    "710433": "雾峰区",
		    "710434": "乌日区",
		    "710435": "丰原区",
		    "710436": "后里区",
		    "710437": "石冈区",
		    "710438": "东势区",
		    "710439": "和平区",
		    "710440": "新社区",
		    "710441": "潭子区",
		    "710442": "大雅区",
		    "710443": "神冈区",
		    "710444": "大肚区",
		    "710445": "沙鹿区",
		    "710446": "龙井区",
		    "710447": "梧栖区",
		    "710448": "清水区",
		    "710449": "大甲区",
		    "710450": "外埔区",
		    "710451": "大安区",
		    "710500": "金门县",
		    "710507": "金沙镇",
		    "710508": "金湖镇",
		    "710509": "金宁乡",
		    "710510": "金城镇",
		    "710511": "烈屿乡",
		    "710512": "乌坵乡",
		    "710600": "南投县",
		    "710614": "南投市",
		    "710615": "中寮乡",
		    "710616": "草屯镇",
		    "710617": "国姓乡",
		    "710618": "埔里镇",
		    "710619": "仁爱乡",
		    "710620": "名间乡",
		    "710621": "集集镇",
		    "710622": "水里乡",
		    "710623": "鱼池乡",
		    "710624": "信义乡",
		    "710625": "竹山镇",
		    "710626": "鹿谷乡",
		    "710700": "基隆市",
		    "710701": "仁爱区",
		    "710702": "信义区",
		    "710703": "中正区",
		    "710704": "中山区",
		    "710705": "安乐区",
		    "710706": "暖暖区",
		    "710707": "七堵区",
		    "710708": "其它区",
		    "710800": "新竹市",
		    "710801": "东区",
		    "710802": "北区",
		    "710803": "香山区",
		    "710804": "其它区",
		    "710900": "嘉义市",
		    "710901": "东区",
		    "710902": "西区",
		    "710903": "其它区",
		    "711100": "新北市",
		    "711130": "万里区",
		    "711131": "金山区",
		    "711132": "板桥区",
		    "711133": "汐止区",
		    "711134": "深坑区",
		    "711135": "石碇区",
		    "711136": "瑞芳区",
		    "711137": "平溪区",
		    "711138": "双溪区",
		    "711139": "贡寮区",
		    "711140": "新店区",
		    "711141": "坪林区",
		    "711142": "乌来区",
		    "711143": "永和区",
		    "711144": "中和区",
		    "711145": "土城区",
		    "711146": "三峡区",
		    "711147": "树林区",
		    "711148": "莺歌区",
		    "711149": "三重区",
		    "711150": "新庄区",
		    "711151": "泰山区",
		    "711152": "林口区",
		    "711153": "芦洲区",
		    "711154": "五股区",
		    "711155": "八里区",
		    "711156": "淡水区",
		    "711157": "三芝区",
		    "711158": "石门区",
		    "711200": "宜兰县",
		    "711214": "宜兰市",
		    "711215": "头城镇",
		    "711216": "礁溪乡",
		    "711217": "壮围乡",
		    "711218": "员山乡",
		    "711219": "罗东镇",
		    "711220": "三星乡",
		    "711221": "大同乡",
		    "711222": "五结乡",
		    "711223": "冬山乡",
		    "711224": "苏澳镇",
		    "711225": "南澳乡",
		    "711226": "钓鱼台",
		    "711300": "新竹县",
		    "711314": "竹北市",
		    "711315": "湖口乡",
		    "711316": "新丰乡",
		    "711317": "新埔镇",
		    "711318": "关西镇",
		    "711319": "芎林乡",
		    "711320": "宝山乡",
		    "711321": "竹东镇",
		    "711322": "五峰乡",
		    "711323": "横山乡",
		    "711324": "尖石乡",
		    "711325": "北埔乡",
		    "711326": "峨眉乡",
		    "711400": "桃园县",
		    "711414": "中坜市",
		    "711415": "平镇市",
		    "711416": "龙潭乡",
		    "711417": "杨梅市",
		    "711418": "新屋乡",
		    "711419": "观音乡",
		    "711420": "桃园市",
		    "711421": "龟山乡",
		    "711422": "八德市",
		    "711423": "大溪镇",
		    "711424": "复兴乡",
		    "711425": "大园乡",
		    "711426": "芦竹乡",
		    "711500": "苗栗县",
		    "711519": "竹南镇",
		    "711520": "头份镇",
		    "711521": "三湾乡",
		    "711522": "南庄乡",
		    "711523": "狮潭乡",
		    "711524": "后龙镇",
		    "711525": "通霄镇",
		    "711526": "苑里镇",
		    "711527": "苗栗市",
		    "711528": "造桥乡",
		    "711529": "头屋乡",
		    "711530": "公馆乡",
		    "711531": "大湖乡",
		    "711532": "泰安乡",
		    "711533": "铜锣乡",
		    "711534": "三义乡",
		    "711535": "西湖乡",
		    "711536": "卓兰镇",
		    "711700": "彰化县",
		    "711727": "彰化市",
		    "711728": "芬园乡",
		    "711729": "花坛乡",
		    "711730": "秀水乡",
		    "711731": "鹿港镇",
		    "711732": "福兴乡",
		    "711733": "线西乡",
		    "711734": "和美镇",
		    "711735": "伸港乡",
		    "711736": "员林镇",
		    "711737": "社头乡",
		    "711738": "永靖乡",
		    "711739": "埔心乡",
		    "711740": "溪湖镇",
		    "711741": "大村乡",
		    "711742": "埔盐乡",
		    "711743": "田中镇",
		    "711744": "北斗镇",
		    "711745": "田尾乡",
		    "711746": "埤头乡",
		    "711747": "溪州乡",
		    "711748": "竹塘乡",
		    "711749": "二林镇",
		    "711750": "大城乡",
		    "711751": "芳苑乡",
		    "711752": "二水乡",
		    "711900": "嘉义县",
		    "711919": "番路乡",
		    "711920": "梅山乡",
		    "711921": "竹崎乡",
		    "711922": "阿里山乡",
		    "711923": "中埔乡",
		    "711924": "大埔乡",
		    "711925": "水上乡",
		    "711926": "鹿草乡",
		    "711927": "太保市",
		    "711928": "朴子市",
		    "711929": "东石乡",
		    "711930": "六脚乡",
		    "711931": "新港乡",
		    "711932": "民雄乡",
		    "711933": "大林镇",
		    "711934": "溪口乡",
		    "711935": "义竹乡",
		    "711936": "布袋镇",
		    "712100": "云林县",
		    "712121": "斗南镇",
		    "712122": "大埤乡",
		    "712123": "虎尾镇",
		    "712124": "土库镇",
		    "712125": "褒忠乡",
		    "712126": "东势乡",
		    "712127": "台西乡",
		    "712128": "仑背乡",
		    "712129": "麦寮乡",
		    "712130": "斗六市",
		    "712131": "林内乡",
		    "712132": "古坑乡",
		    "712133": "莿桐乡",
		    "712134": "西螺镇",
		    "712135": "二仑乡",
		    "712136": "北港镇",
		    "712137": "水林乡",
		    "712138": "口湖乡",
		    "712139": "四湖乡",
		    "712140": "元长乡",
		    "712400": "屏东县",
		    "712434": "屏东市",
		    "712435": "三地门乡",
		    "712436": "雾台乡",
		    "712437": "玛家乡",
		    "712438": "九如乡",
		    "712439": "里港乡",
		    "712440": "高树乡",
		    "712441": "盐埔乡",
		    "712442": "长治乡",
		    "712443": "麟洛乡",
		    "712444": "竹田乡",
		    "712445": "内埔乡",
		    "712446": "万丹乡",
		    "712447": "潮州镇",
		    "712448": "泰武乡",
		    "712449": "来义乡",
		    "712450": "万峦乡",
		    "712451": "崁顶乡",
		    "712452": "新埤乡",
		    "712453": "南州乡",
		    "712454": "林边乡",
		    "712455": "东港镇",
		    "712456": "琉球乡",
		    "712457": "佳冬乡",
		    "712458": "新园乡",
		    "712459": "枋寮乡",
		    "712460": "枋山乡",
		    "712461": "春日乡",
		    "712462": "狮子乡",
		    "712463": "车城乡",
		    "712464": "牡丹乡",
		    "712465": "恒春镇",
		    "712466": "满州乡",
		    "712500": "台东县",
		    "712517": "台东市",
		    "712518": "绿岛乡",
		    "712519": "兰屿乡",
		    "712520": "延平乡",
		    "712521": "卑南乡",
		    "712522": "鹿野乡",
		    "712523": "关山镇",
		    "712524": "海端乡",
		    "712525": "池上乡",
		    "712526": "东河乡",
		    "712527": "成功镇",
		    "712528": "长滨乡",
		    "712529": "金峰乡",
		    "712530": "大武乡",
		    "712531": "达仁乡",
		    "712532": "太麻里乡",
		    "712600": "花莲县",
		    "712615": "花莲市",
		    "712616": "新城乡",
		    "712617": "太鲁阁",
		    "712618": "秀林乡",
		    "712619": "吉安乡",
		    "712620": "寿丰乡",
		    "712621": "凤林镇",
		    "712622": "光复乡",
		    "712623": "丰滨乡",
		    "712624": "瑞穗乡",
		    "712625": "万荣乡",
		    "712626": "玉里镇",
		    "712627": "卓溪乡",
		    "712628": "富里乡",
		    "712700": "澎湖县",
		    "712707": "马公市",
		    "712708": "西屿乡",
		    "712709": "望安乡",
		    "712710": "七美乡",
		    "712711": "白沙乡",
		    "712712": "湖西乡",
		    "712800": "连江县",
		    "712805": "南竿乡",
		    "712806": "北竿乡",
		    "712807": "莒光乡",
		    "712808": "东引乡",
		    "810000": "香港特别行政区",
		    "810100": "香港岛",
		    "810101": "中西区",
		    "810102": "湾仔",
		    "810103": "东区",
		    "810104": "南区",
		    "810200": "九龙",
		    "810201": "九龙城区",
		    "810202": "油尖旺区",
		    "810203": "深水埗区",
		    "810204": "黄大仙区",
		    "810205": "观塘区",
		    "810300": "新界",
		    "810301": "北区",
		    "810302": "大埔区",
		    "810303": "沙田区",
		    "810304": "西贡区",
		    "810305": "元朗区",
		    "810306": "屯门区",
		    "810307": "荃湾区",
		    "810308": "葵青区",
		    "810309": "离岛区",
		    "820000": "澳门特别行政区",
		    "820100": "澳门半岛",
		    "820200": "离岛",
		    "990000": "海外",
		    "990100": "海外"
		}

		// id pid/parentId name children
		function tree(list) {
		    var mapped = {}
		    for (var i = 0, item; i < list.length; i++) {
		        item = list[i]
		        if (!item || !item.id) continue
		        mapped[item.id] = item
		    }

		    var result = []
		    for (var ii = 0; ii < list.length; ii++) {
		        item = list[ii]

		        if (!item) continue
		            /* jshint -W041 */
		        if (item.pid == undefined && item.parentId == undefined) {
		            result.push(item)
		            continue
		        }
		        var parent = mapped[item.pid] || mapped[item.parentId]
		        if (!parent) continue
		        if (!parent.children) parent.children = []
		        parent.children.push(item)
		    }
		    return result
		}

		var DICT_FIXED = function() {
		    var fixed = []
		    for (var id in DICT) {
		        var pid = id.slice(2, 6) === '0000' ? undefined :
		            id.slice(4, 6) == '00' ? (id.slice(0, 2) + '0000') :
		            id.slice(0, 4) + '00'
		        fixed.push({
		            id: id,
		            pid: pid,
		            name: DICT[id]
		        })
		    }
		    return tree(fixed)
		}()

		module.exports = DICT_FIXED

	/***/ },
	/* 19 */
	/***/ function(module, exports, __webpack_require__) {

		/*
		    ## Miscellaneous
		*/
		var DICT = __webpack_require__(18)
		module.exports = {
			// Dice
			d4: function() {
				return this.natural(1, 4)
			},
			d6: function() {
				return this.natural(1, 6)
			},
			d8: function() {
				return this.natural(1, 8)
			},
			d12: function() {
				return this.natural(1, 12)
			},
			d20: function() {
				return this.natural(1, 20)
			},
			d100: function() {
				return this.natural(1, 100)
			},
			/*
			    随机生成一个 GUID。

			    http://www.broofa.com/2008/09/javascript-uuid-function/
			    [UUID 规范](http://www.ietf.org/rfc/rfc4122.txt)
			        UUIDs (Universally Unique IDentifier)
			        GUIDs (Globally Unique IDentifier)
			        The formal definition of the UUID string representation is provided by the following ABNF [7]:
			            UUID                   = time-low "-" time-mid "-"
			                                   time-high-and-version "-"
			                                   clock-seq-and-reserved
			                                   clock-seq-low "-" node
			            time-low               = 4hexOctet
			            time-mid               = 2hexOctet
			            time-high-and-version  = 2hexOctet
			            clock-seq-and-reserved = hexOctet
			            clock-seq-low          = hexOctet
			            node                   = 6hexOctet
			            hexOctet               = hexDigit hexDigit
			            hexDigit =
			                "0" / "1" / "2" / "3" / "4" / "5" / "6" / "7" / "8" / "9" /
			                "a" / "b" / "c" / "d" / "e" / "f" /
			                "A" / "B" / "C" / "D" / "E" / "F"
			    
			    https://github.com/victorquinn/chancejs/blob/develop/chance.js#L1349
			*/
			guid: function() {
				var pool = "abcdefABCDEF1234567890",
					guid = this.string(pool, 8) + '-' +
					this.string(pool, 4) + '-' +
					this.string(pool, 4) + '-' +
					this.string(pool, 4) + '-' +
					this.string(pool, 12);
				return guid
			},
			uuid: function() {
				return this.guid()
			},
			/*
			    随机生成一个 18 位身份证。

			    [身份证](http://baike.baidu.com/view/1697.htm#4)
			        地址码 6 + 出生日期码 8 + 顺序码 3 + 校验码 1
			    [《中华人民共和国行政区划代码》国家标准(GB/T2260)](http://zhidao.baidu.com/question/1954561.html)
			*/
			id: function() {
				var id,
					sum = 0,
					rank = [
						"7", "9", "10", "5", "8", "4", "2", "1", "6", "3", "7", "9", "10", "5", "8", "4", "2"
					],
					last = [
						"1", "0", "X", "9", "8", "7", "6", "5", "4", "3", "2"
					]

				id = this.pick(DICT).id +
					this.date('yyyyMMdd') +
					this.string('number', 3)

				for (var i = 0; i < id.length; i++) {
					sum += id[i] * rank[i];
				}
				id += last[sum % 11];

				return id
			},

			/*
			    生成一个全局的自增整数。
			    类似自增主键（auto increment primary key）。
			*/
			increment: function() {
				var key = 0
				return function(step) {
					return key += (+step || 1) // step?
				}
			}(),
			inc: function(step) {
				return this.increment(step)
			}
		}

	/***/ },
	/* 20 */
	/***/ function(module, exports, __webpack_require__) {

		var Parser = __webpack_require__(21)
		var Handler = __webpack_require__(22)
		module.exports = {
			Parser: Parser,
			Handler: Handler
		}

	/***/ },
	/* 21 */
	/***/ function(module, exports) {

		// https://github.com/nuysoft/regexp
		// forked from https://github.com/ForbesLindesay/regexp

		function parse(n) {
		    if ("string" != typeof n) {
		        var l = new TypeError("The regexp to parse must be represented as a string.");
		        throw l;
		    }
		    return index = 1, cgs = {}, parser.parse(n);
		}

		function Token(n) {
		    this.type = n, this.offset = Token.offset(), this.text = Token.text();
		}

		function Alternate(n, l) {
		    Token.call(this, "alternate"), this.left = n, this.right = l;
		}

		function Match(n) {
		    Token.call(this, "match"), this.body = n.filter(Boolean);
		}

		function Group(n, l) {
		    Token.call(this, n), this.body = l;
		}

		function CaptureGroup(n) {
		    Group.call(this, "capture-group"), this.index = cgs[this.offset] || (cgs[this.offset] = index++), 
		    this.body = n;
		}

		function Quantified(n, l) {
		    Token.call(this, "quantified"), this.body = n, this.quantifier = l;
		}

		function Quantifier(n, l) {
		    Token.call(this, "quantifier"), this.min = n, this.max = l, this.greedy = !0;
		}

		function CharSet(n, l) {
		    Token.call(this, "charset"), this.invert = n, this.body = l;
		}

		function CharacterRange(n, l) {
		    Token.call(this, "range"), this.start = n, this.end = l;
		}

		function Literal(n) {
		    Token.call(this, "literal"), this.body = n, this.escaped = this.body != this.text;
		}

		function Unicode(n) {
		    Token.call(this, "unicode"), this.code = n.toUpperCase();
		}

		function Hex(n) {
		    Token.call(this, "hex"), this.code = n.toUpperCase();
		}

		function Octal(n) {
		    Token.call(this, "octal"), this.code = n.toUpperCase();
		}

		function BackReference(n) {
		    Token.call(this, "back-reference"), this.code = n.toUpperCase();
		}

		function ControlCharacter(n) {
		    Token.call(this, "control-character"), this.code = n.toUpperCase();
		}

		var parser = function() {
		    function n(n, l) {
		        function u() {
		            this.constructor = n;
		        }
		        u.prototype = l.prototype, n.prototype = new u();
		    }
		    function l(n, l, u, t, r) {
		        function e(n, l) {
		            function u(n) {
		                function l(n) {
		                    return n.charCodeAt(0).toString(16).toUpperCase();
		                }
		                return n.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\x08/g, "\\b").replace(/\t/g, "\\t").replace(/\n/g, "\\n").replace(/\f/g, "\\f").replace(/\r/g, "\\r").replace(/[\x00-\x07\x0B\x0E\x0F]/g, function(n) {
		                    return "\\x0" + l(n);
		                }).replace(/[\x10-\x1F\x80-\xFF]/g, function(n) {
		                    return "\\x" + l(n);
		                }).replace(/[\u0180-\u0FFF]/g, function(n) {
		                    return "\\u0" + l(n);
		                }).replace(/[\u1080-\uFFFF]/g, function(n) {
		                    return "\\u" + l(n);
		                });
		            }
		            var t, r;
		            switch (n.length) {
		              case 0:
		                t = "end of input";
		                break;

		              case 1:
		                t = n[0];
		                break;

		              default:
		                t = n.slice(0, -1).join(", ") + " or " + n[n.length - 1];
		            }
		            return r = l ? '"' + u(l) + '"' : "end of input", "Expected " + t + " but " + r + " found.";
		        }
		        this.expected = n, this.found = l, this.offset = u, this.line = t, this.column = r, 
		        this.name = "SyntaxError", this.message = e(n, l);
		    }
		    function u(n) {
		        function u() {
		            return n.substring(Lt, qt);
		        }
		        function t() {
		            return Lt;
		        }
		        function r(l) {
		            function u(l, u, t) {
		                var r, e;
		                for (r = u; t > r; r++) e = n.charAt(r), "\n" === e ? (l.seenCR || l.line++, l.column = 1, 
		                l.seenCR = !1) : "\r" === e || "\u2028" === e || "\u2029" === e ? (l.line++, l.column = 1, 
		                l.seenCR = !0) : (l.column++, l.seenCR = !1);
		            }
		            return Mt !== l && (Mt > l && (Mt = 0, Dt = {
		                line: 1,
		                column: 1,
		                seenCR: !1
		            }), u(Dt, Mt, l), Mt = l), Dt;
		        }
		        function e(n) {
		            Ht > qt || (qt > Ht && (Ht = qt, Ot = []), Ot.push(n));
		        }
		        function o(n) {
		            var l = 0;
		            for (n.sort(); l < n.length; ) n[l - 1] === n[l] ? n.splice(l, 1) : l++;
		        }
		        function c() {
		            var l, u, t, r, o;
		            return l = qt, u = i(), null !== u ? (t = qt, 124 === n.charCodeAt(qt) ? (r = fl, 
		            qt++) : (r = null, 0 === Wt && e(sl)), null !== r ? (o = c(), null !== o ? (r = [ r, o ], 
		            t = r) : (qt = t, t = il)) : (qt = t, t = il), null === t && (t = al), null !== t ? (Lt = l, 
		            u = hl(u, t), null === u ? (qt = l, l = u) : l = u) : (qt = l, l = il)) : (qt = l, 
		            l = il), l;
		        }
		        function i() {
		            var n, l, u, t, r;
		            if (n = qt, l = f(), null === l && (l = al), null !== l) if (u = qt, Wt++, t = d(), 
		            Wt--, null === t ? u = al : (qt = u, u = il), null !== u) {
		                for (t = [], r = h(), null === r && (r = a()); null !== r; ) t.push(r), r = h(), 
		                null === r && (r = a());
		                null !== t ? (r = s(), null === r && (r = al), null !== r ? (Lt = n, l = dl(l, t, r), 
		                null === l ? (qt = n, n = l) : n = l) : (qt = n, n = il)) : (qt = n, n = il);
		            } else qt = n, n = il; else qt = n, n = il;
		            return n;
		        }
		        function a() {
		            var n;
		            return n = x(), null === n && (n = Q(), null === n && (n = B())), n;
		        }
		        function f() {
		            var l, u;
		            return l = qt, 94 === n.charCodeAt(qt) ? (u = pl, qt++) : (u = null, 0 === Wt && e(vl)), 
		            null !== u && (Lt = l, u = wl()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function s() {
		            var l, u;
		            return l = qt, 36 === n.charCodeAt(qt) ? (u = Al, qt++) : (u = null, 0 === Wt && e(Cl)), 
		            null !== u && (Lt = l, u = gl()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function h() {
		            var n, l, u;
		            return n = qt, l = a(), null !== l ? (u = d(), null !== u ? (Lt = n, l = bl(l, u), 
		            null === l ? (qt = n, n = l) : n = l) : (qt = n, n = il)) : (qt = n, n = il), n;
		        }
		        function d() {
		            var n, l, u;
		            return Wt++, n = qt, l = p(), null !== l ? (u = k(), null === u && (u = al), null !== u ? (Lt = n, 
		            l = Tl(l, u), null === l ? (qt = n, n = l) : n = l) : (qt = n, n = il)) : (qt = n, 
		            n = il), Wt--, null === n && (l = null, 0 === Wt && e(kl)), n;
		        }
		        function p() {
		            var n;
		            return n = v(), null === n && (n = w(), null === n && (n = A(), null === n && (n = C(), 
		            null === n && (n = g(), null === n && (n = b()))))), n;
		        }
		        function v() {
		            var l, u, t, r, o, c;
		            return l = qt, 123 === n.charCodeAt(qt) ? (u = xl, qt++) : (u = null, 0 === Wt && e(yl)), 
		            null !== u ? (t = T(), null !== t ? (44 === n.charCodeAt(qt) ? (r = ml, qt++) : (r = null, 
		            0 === Wt && e(Rl)), null !== r ? (o = T(), null !== o ? (125 === n.charCodeAt(qt) ? (c = Fl, 
		            qt++) : (c = null, 0 === Wt && e(Ql)), null !== c ? (Lt = l, u = Sl(t, o), null === u ? (qt = l, 
		            l = u) : l = u) : (qt = l, l = il)) : (qt = l, l = il)) : (qt = l, l = il)) : (qt = l, 
		            l = il)) : (qt = l, l = il), l;
		        }
		        function w() {
		            var l, u, t, r;
		            return l = qt, 123 === n.charCodeAt(qt) ? (u = xl, qt++) : (u = null, 0 === Wt && e(yl)), 
		            null !== u ? (t = T(), null !== t ? (n.substr(qt, 2) === Ul ? (r = Ul, qt += 2) : (r = null, 
		            0 === Wt && e(El)), null !== r ? (Lt = l, u = Gl(t), null === u ? (qt = l, l = u) : l = u) : (qt = l, 
		            l = il)) : (qt = l, l = il)) : (qt = l, l = il), l;
		        }
		        function A() {
		            var l, u, t, r;
		            return l = qt, 123 === n.charCodeAt(qt) ? (u = xl, qt++) : (u = null, 0 === Wt && e(yl)), 
		            null !== u ? (t = T(), null !== t ? (125 === n.charCodeAt(qt) ? (r = Fl, qt++) : (r = null, 
		            0 === Wt && e(Ql)), null !== r ? (Lt = l, u = Bl(t), null === u ? (qt = l, l = u) : l = u) : (qt = l, 
		            l = il)) : (qt = l, l = il)) : (qt = l, l = il), l;
		        }
		        function C() {
		            var l, u;
		            return l = qt, 43 === n.charCodeAt(qt) ? (u = jl, qt++) : (u = null, 0 === Wt && e($l)), 
		            null !== u && (Lt = l, u = ql()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function g() {
		            var l, u;
		            return l = qt, 42 === n.charCodeAt(qt) ? (u = Ll, qt++) : (u = null, 0 === Wt && e(Ml)), 
		            null !== u && (Lt = l, u = Dl()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function b() {
		            var l, u;
		            return l = qt, 63 === n.charCodeAt(qt) ? (u = Hl, qt++) : (u = null, 0 === Wt && e(Ol)), 
		            null !== u && (Lt = l, u = Wl()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function k() {
		            var l;
		            return 63 === n.charCodeAt(qt) ? (l = Hl, qt++) : (l = null, 0 === Wt && e(Ol)), 
		            l;
		        }
		        function T() {
		            var l, u, t;
		            if (l = qt, u = [], zl.test(n.charAt(qt)) ? (t = n.charAt(qt), qt++) : (t = null, 
		            0 === Wt && e(Il)), null !== t) for (;null !== t; ) u.push(t), zl.test(n.charAt(qt)) ? (t = n.charAt(qt), 
		            qt++) : (t = null, 0 === Wt && e(Il)); else u = il;
		            return null !== u && (Lt = l, u = Jl(u)), null === u ? (qt = l, l = u) : l = u, 
		            l;
		        }
		        function x() {
		            var l, u, t, r;
		            return l = qt, 40 === n.charCodeAt(qt) ? (u = Kl, qt++) : (u = null, 0 === Wt && e(Nl)), 
		            null !== u ? (t = R(), null === t && (t = F(), null === t && (t = m(), null === t && (t = y()))), 
		            null !== t ? (41 === n.charCodeAt(qt) ? (r = Pl, qt++) : (r = null, 0 === Wt && e(Vl)), 
		            null !== r ? (Lt = l, u = Xl(t), null === u ? (qt = l, l = u) : l = u) : (qt = l, 
		            l = il)) : (qt = l, l = il)) : (qt = l, l = il), l;
		        }
		        function y() {
		            var n, l;
		            return n = qt, l = c(), null !== l && (Lt = n, l = Yl(l)), null === l ? (qt = n, 
		            n = l) : n = l, n;
		        }
		        function m() {
		            var l, u, t;
		            return l = qt, n.substr(qt, 2) === Zl ? (u = Zl, qt += 2) : (u = null, 0 === Wt && e(_l)), 
		            null !== u ? (t = c(), null !== t ? (Lt = l, u = nu(t), null === u ? (qt = l, l = u) : l = u) : (qt = l, 
		            l = il)) : (qt = l, l = il), l;
		        }
		        function R() {
		            var l, u, t;
		            return l = qt, n.substr(qt, 2) === lu ? (u = lu, qt += 2) : (u = null, 0 === Wt && e(uu)), 
		            null !== u ? (t = c(), null !== t ? (Lt = l, u = tu(t), null === u ? (qt = l, l = u) : l = u) : (qt = l, 
		            l = il)) : (qt = l, l = il), l;
		        }
		        function F() {
		            var l, u, t;
		            return l = qt, n.substr(qt, 2) === ru ? (u = ru, qt += 2) : (u = null, 0 === Wt && e(eu)), 
		            null !== u ? (t = c(), null !== t ? (Lt = l, u = ou(t), null === u ? (qt = l, l = u) : l = u) : (qt = l, 
		            l = il)) : (qt = l, l = il), l;
		        }
		        function Q() {
		            var l, u, t, r, o;
		            if (Wt++, l = qt, 91 === n.charCodeAt(qt) ? (u = iu, qt++) : (u = null, 0 === Wt && e(au)), 
		            null !== u) if (94 === n.charCodeAt(qt) ? (t = pl, qt++) : (t = null, 0 === Wt && e(vl)), 
		            null === t && (t = al), null !== t) {
		                for (r = [], o = S(), null === o && (o = U()); null !== o; ) r.push(o), o = S(), 
		                null === o && (o = U());
		                null !== r ? (93 === n.charCodeAt(qt) ? (o = fu, qt++) : (o = null, 0 === Wt && e(su)), 
		                null !== o ? (Lt = l, u = hu(t, r), null === u ? (qt = l, l = u) : l = u) : (qt = l, 
		                l = il)) : (qt = l, l = il);
		            } else qt = l, l = il; else qt = l, l = il;
		            return Wt--, null === l && (u = null, 0 === Wt && e(cu)), l;
		        }
		        function S() {
		            var l, u, t, r;
		            return Wt++, l = qt, u = U(), null !== u ? (45 === n.charCodeAt(qt) ? (t = pu, qt++) : (t = null, 
		            0 === Wt && e(vu)), null !== t ? (r = U(), null !== r ? (Lt = l, u = wu(u, r), null === u ? (qt = l, 
		            l = u) : l = u) : (qt = l, l = il)) : (qt = l, l = il)) : (qt = l, l = il), Wt--, 
		            null === l && (u = null, 0 === Wt && e(du)), l;
		        }
		        function U() {
		            var n, l;
		            return Wt++, n = G(), null === n && (n = E()), Wt--, null === n && (l = null, 0 === Wt && e(Au)), 
		            n;
		        }
		        function E() {
		            var l, u;
		            return l = qt, Cu.test(n.charAt(qt)) ? (u = n.charAt(qt), qt++) : (u = null, 0 === Wt && e(gu)), 
		            null !== u && (Lt = l, u = bu(u)), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function G() {
		            var n;
		            return n = L(), null === n && (n = Y(), null === n && (n = H(), null === n && (n = O(), 
		            null === n && (n = W(), null === n && (n = z(), null === n && (n = I(), null === n && (n = J(), 
		            null === n && (n = K(), null === n && (n = N(), null === n && (n = P(), null === n && (n = V(), 
		            null === n && (n = X(), null === n && (n = _(), null === n && (n = nl(), null === n && (n = ll(), 
		            null === n && (n = ul(), null === n && (n = tl()))))))))))))))))), n;
		        }
		        function B() {
		            var n;
		            return n = j(), null === n && (n = q(), null === n && (n = $())), n;
		        }
		        function j() {
		            var l, u;
		            return l = qt, 46 === n.charCodeAt(qt) ? (u = ku, qt++) : (u = null, 0 === Wt && e(Tu)), 
		            null !== u && (Lt = l, u = xu()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function $() {
		            var l, u;
		            return Wt++, l = qt, mu.test(n.charAt(qt)) ? (u = n.charAt(qt), qt++) : (u = null, 
		            0 === Wt && e(Ru)), null !== u && (Lt = l, u = bu(u)), null === u ? (qt = l, l = u) : l = u, 
		            Wt--, null === l && (u = null, 0 === Wt && e(yu)), l;
		        }
		        function q() {
		            var n;
		            return n = M(), null === n && (n = D(), null === n && (n = Y(), null === n && (n = H(), 
		            null === n && (n = O(), null === n && (n = W(), null === n && (n = z(), null === n && (n = I(), 
		            null === n && (n = J(), null === n && (n = K(), null === n && (n = N(), null === n && (n = P(), 
		            null === n && (n = V(), null === n && (n = X(), null === n && (n = Z(), null === n && (n = _(), 
		            null === n && (n = nl(), null === n && (n = ll(), null === n && (n = ul(), null === n && (n = tl()))))))))))))))))))), 
		            n;
		        }
		        function L() {
		            var l, u;
		            return l = qt, n.substr(qt, 2) === Fu ? (u = Fu, qt += 2) : (u = null, 0 === Wt && e(Qu)), 
		            null !== u && (Lt = l, u = Su()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function M() {
		            var l, u;
		            return l = qt, n.substr(qt, 2) === Fu ? (u = Fu, qt += 2) : (u = null, 0 === Wt && e(Qu)), 
		            null !== u && (Lt = l, u = Uu()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function D() {
		            var l, u;
		            return l = qt, n.substr(qt, 2) === Eu ? (u = Eu, qt += 2) : (u = null, 0 === Wt && e(Gu)), 
		            null !== u && (Lt = l, u = Bu()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function H() {
		            var l, u;
		            return l = qt, n.substr(qt, 2) === ju ? (u = ju, qt += 2) : (u = null, 0 === Wt && e($u)), 
		            null !== u && (Lt = l, u = qu()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function O() {
		            var l, u;
		            return l = qt, n.substr(qt, 2) === Lu ? (u = Lu, qt += 2) : (u = null, 0 === Wt && e(Mu)), 
		            null !== u && (Lt = l, u = Du()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function W() {
		            var l, u;
		            return l = qt, n.substr(qt, 2) === Hu ? (u = Hu, qt += 2) : (u = null, 0 === Wt && e(Ou)), 
		            null !== u && (Lt = l, u = Wu()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function z() {
		            var l, u;
		            return l = qt, n.substr(qt, 2) === zu ? (u = zu, qt += 2) : (u = null, 0 === Wt && e(Iu)), 
		            null !== u && (Lt = l, u = Ju()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function I() {
		            var l, u;
		            return l = qt, n.substr(qt, 2) === Ku ? (u = Ku, qt += 2) : (u = null, 0 === Wt && e(Nu)), 
		            null !== u && (Lt = l, u = Pu()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function J() {
		            var l, u;
		            return l = qt, n.substr(qt, 2) === Vu ? (u = Vu, qt += 2) : (u = null, 0 === Wt && e(Xu)), 
		            null !== u && (Lt = l, u = Yu()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function K() {
		            var l, u;
		            return l = qt, n.substr(qt, 2) === Zu ? (u = Zu, qt += 2) : (u = null, 0 === Wt && e(_u)), 
		            null !== u && (Lt = l, u = nt()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function N() {
		            var l, u;
		            return l = qt, n.substr(qt, 2) === lt ? (u = lt, qt += 2) : (u = null, 0 === Wt && e(ut)), 
		            null !== u && (Lt = l, u = tt()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function P() {
		            var l, u;
		            return l = qt, n.substr(qt, 2) === rt ? (u = rt, qt += 2) : (u = null, 0 === Wt && e(et)), 
		            null !== u && (Lt = l, u = ot()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function V() {
		            var l, u;
		            return l = qt, n.substr(qt, 2) === ct ? (u = ct, qt += 2) : (u = null, 0 === Wt && e(it)), 
		            null !== u && (Lt = l, u = at()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function X() {
		            var l, u;
		            return l = qt, n.substr(qt, 2) === ft ? (u = ft, qt += 2) : (u = null, 0 === Wt && e(st)), 
		            null !== u && (Lt = l, u = ht()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function Y() {
		            var l, u, t;
		            return l = qt, n.substr(qt, 2) === dt ? (u = dt, qt += 2) : (u = null, 0 === Wt && e(pt)), 
		            null !== u ? (n.length > qt ? (t = n.charAt(qt), qt++) : (t = null, 0 === Wt && e(vt)), 
		            null !== t ? (Lt = l, u = wt(t), null === u ? (qt = l, l = u) : l = u) : (qt = l, 
		            l = il)) : (qt = l, l = il), l;
		        }
		        function Z() {
		            var l, u, t;
		            return l = qt, 92 === n.charCodeAt(qt) ? (u = At, qt++) : (u = null, 0 === Wt && e(Ct)), 
		            null !== u ? (gt.test(n.charAt(qt)) ? (t = n.charAt(qt), qt++) : (t = null, 0 === Wt && e(bt)), 
		            null !== t ? (Lt = l, u = kt(t), null === u ? (qt = l, l = u) : l = u) : (qt = l, 
		            l = il)) : (qt = l, l = il), l;
		        }
		        function _() {
		            var l, u, t, r;
		            if (l = qt, n.substr(qt, 2) === Tt ? (u = Tt, qt += 2) : (u = null, 0 === Wt && e(xt)), 
		            null !== u) {
		                if (t = [], yt.test(n.charAt(qt)) ? (r = n.charAt(qt), qt++) : (r = null, 0 === Wt && e(mt)), 
		                null !== r) for (;null !== r; ) t.push(r), yt.test(n.charAt(qt)) ? (r = n.charAt(qt), 
		                qt++) : (r = null, 0 === Wt && e(mt)); else t = il;
		                null !== t ? (Lt = l, u = Rt(t), null === u ? (qt = l, l = u) : l = u) : (qt = l, 
		                l = il);
		            } else qt = l, l = il;
		            return l;
		        }
		        function nl() {
		            var l, u, t, r;
		            if (l = qt, n.substr(qt, 2) === Ft ? (u = Ft, qt += 2) : (u = null, 0 === Wt && e(Qt)), 
		            null !== u) {
		                if (t = [], St.test(n.charAt(qt)) ? (r = n.charAt(qt), qt++) : (r = null, 0 === Wt && e(Ut)), 
		                null !== r) for (;null !== r; ) t.push(r), St.test(n.charAt(qt)) ? (r = n.charAt(qt), 
		                qt++) : (r = null, 0 === Wt && e(Ut)); else t = il;
		                null !== t ? (Lt = l, u = Et(t), null === u ? (qt = l, l = u) : l = u) : (qt = l, 
		                l = il);
		            } else qt = l, l = il;
		            return l;
		        }
		        function ll() {
		            var l, u, t, r;
		            if (l = qt, n.substr(qt, 2) === Gt ? (u = Gt, qt += 2) : (u = null, 0 === Wt && e(Bt)), 
		            null !== u) {
		                if (t = [], St.test(n.charAt(qt)) ? (r = n.charAt(qt), qt++) : (r = null, 0 === Wt && e(Ut)), 
		                null !== r) for (;null !== r; ) t.push(r), St.test(n.charAt(qt)) ? (r = n.charAt(qt), 
		                qt++) : (r = null, 0 === Wt && e(Ut)); else t = il;
		                null !== t ? (Lt = l, u = jt(t), null === u ? (qt = l, l = u) : l = u) : (qt = l, 
		                l = il);
		            } else qt = l, l = il;
		            return l;
		        }
		        function ul() {
		            var l, u;
		            return l = qt, n.substr(qt, 2) === Tt ? (u = Tt, qt += 2) : (u = null, 0 === Wt && e(xt)), 
		            null !== u && (Lt = l, u = $t()), null === u ? (qt = l, l = u) : l = u, l;
		        }
		        function tl() {
		            var l, u, t;
		            return l = qt, 92 === n.charCodeAt(qt) ? (u = At, qt++) : (u = null, 0 === Wt && e(Ct)), 
		            null !== u ? (n.length > qt ? (t = n.charAt(qt), qt++) : (t = null, 0 === Wt && e(vt)), 
		            null !== t ? (Lt = l, u = bu(t), null === u ? (qt = l, l = u) : l = u) : (qt = l, 
		            l = il)) : (qt = l, l = il), l;
		        }
		        var rl, el = arguments.length > 1 ? arguments[1] : {}, ol = {
		            regexp: c
		        }, cl = c, il = null, al = "", fl = "|", sl = '"|"', hl = function(n, l) {
		            return l ? new Alternate(n, l[1]) : n;
		        }, dl = function(n, l, u) {
		            return new Match([ n ].concat(l).concat([ u ]));
		        }, pl = "^", vl = '"^"', wl = function() {
		            return new Token("start");
		        }, Al = "$", Cl = '"$"', gl = function() {
		            return new Token("end");
		        }, bl = function(n, l) {
		            return new Quantified(n, l);
		        }, kl = "Quantifier", Tl = function(n, l) {
		            return l && (n.greedy = !1), n;
		        }, xl = "{", yl = '"{"', ml = ",", Rl = '","', Fl = "}", Ql = '"}"', Sl = function(n, l) {
		            return new Quantifier(n, l);
		        }, Ul = ",}", El = '",}"', Gl = function(n) {
		            return new Quantifier(n, 1/0);
		        }, Bl = function(n) {
		            return new Quantifier(n, n);
		        }, jl = "+", $l = '"+"', ql = function() {
		            return new Quantifier(1, 1/0);
		        }, Ll = "*", Ml = '"*"', Dl = function() {
		            return new Quantifier(0, 1/0);
		        }, Hl = "?", Ol = '"?"', Wl = function() {
		            return new Quantifier(0, 1);
		        }, zl = /^[0-9]/, Il = "[0-9]", Jl = function(n) {
		            return +n.join("");
		        }, Kl = "(", Nl = '"("', Pl = ")", Vl = '")"', Xl = function(n) {
		            return n;
		        }, Yl = function(n) {
		            return new CaptureGroup(n);
		        }, Zl = "?:", _l = '"?:"', nu = function(n) {
		            return new Group("non-capture-group", n);
		        }, lu = "?=", uu = '"?="', tu = function(n) {
		            return new Group("positive-lookahead", n);
		        }, ru = "?!", eu = '"?!"', ou = function(n) {
		            return new Group("negative-lookahead", n);
		        }, cu = "CharacterSet", iu = "[", au = '"["', fu = "]", su = '"]"', hu = function(n, l) {
		            return new CharSet(!!n, l);
		        }, du = "CharacterRange", pu = "-", vu = '"-"', wu = function(n, l) {
		            return new CharacterRange(n, l);
		        }, Au = "Character", Cu = /^[^\\\]]/, gu = "[^\\\\\\]]", bu = function(n) {
		            return new Literal(n);
		        }, ku = ".", Tu = '"."', xu = function() {
		            return new Token("any-character");
		        }, yu = "Literal", mu = /^[^|\\\/.[()?+*$\^]/, Ru = "[^|\\\\\\/.[()?+*$\\^]", Fu = "\\b", Qu = '"\\\\b"', Su = function() {
		            return new Token("backspace");
		        }, Uu = function() {
		            return new Token("word-boundary");
		        }, Eu = "\\B", Gu = '"\\\\B"', Bu = function() {
		            return new Token("non-word-boundary");
		        }, ju = "\\d", $u = '"\\\\d"', qu = function() {
		            return new Token("digit");
		        }, Lu = "\\D", Mu = '"\\\\D"', Du = function() {
		            return new Token("non-digit");
		        }, Hu = "\\f", Ou = '"\\\\f"', Wu = function() {
		            return new Token("form-feed");
		        }, zu = "\\n", Iu = '"\\\\n"', Ju = function() {
		            return new Token("line-feed");
		        }, Ku = "\\r", Nu = '"\\\\r"', Pu = function() {
		            return new Token("carriage-return");
		        }, Vu = "\\s", Xu = '"\\\\s"', Yu = function() {
		            return new Token("white-space");
		        }, Zu = "\\S", _u = '"\\\\S"', nt = function() {
		            return new Token("non-white-space");
		        }, lt = "\\t", ut = '"\\\\t"', tt = function() {
		            return new Token("tab");
		        }, rt = "\\v", et = '"\\\\v"', ot = function() {
		            return new Token("vertical-tab");
		        }, ct = "\\w", it = '"\\\\w"', at = function() {
		            return new Token("word");
		        }, ft = "\\W", st = '"\\\\W"', ht = function() {
		            return new Token("non-word");
		        }, dt = "\\c", pt = '"\\\\c"', vt = "any character", wt = function(n) {
		            return new ControlCharacter(n);
		        }, At = "\\", Ct = '"\\\\"', gt = /^[1-9]/, bt = "[1-9]", kt = function(n) {
		            return new BackReference(n);
		        }, Tt = "\\0", xt = '"\\\\0"', yt = /^[0-7]/, mt = "[0-7]", Rt = function(n) {
		            return new Octal(n.join(""));
		        }, Ft = "\\x", Qt = '"\\\\x"', St = /^[0-9a-fA-F]/, Ut = "[0-9a-fA-F]", Et = function(n) {
		            return new Hex(n.join(""));
		        }, Gt = "\\u", Bt = '"\\\\u"', jt = function(n) {
		            return new Unicode(n.join(""));
		        }, $t = function() {
		            return new Token("null-character");
		        }, qt = 0, Lt = 0, Mt = 0, Dt = {
		            line: 1,
		            column: 1,
		            seenCR: !1
		        }, Ht = 0, Ot = [], Wt = 0;
		        if ("startRule" in el) {
		            if (!(el.startRule in ol)) throw new Error("Can't start parsing from rule \"" + el.startRule + '".');
		            cl = ol[el.startRule];
		        }
		        if (Token.offset = t, Token.text = u, rl = cl(), null !== rl && qt === n.length) return rl;
		        throw o(Ot), Lt = Math.max(qt, Ht), new l(Ot, Lt < n.length ? n.charAt(Lt) : null, Lt, r(Lt).line, r(Lt).column);
		    }
		    return n(l, Error), {
		        SyntaxError: l,
		        parse: u
		    };
		}(), index = 1, cgs = {};

		module.exports = parser

	/***/ },
	/* 22 */
	/***/ function(module, exports, __webpack_require__) {

		/*
		    ## RegExp Handler

		    https://github.com/ForbesLindesay/regexp
		    https://github.com/dmajda/pegjs
		    http://www.regexper.com/

		    每个节点的结构
		        {
		            type: '',
		            offset: number,
		            text: '',
		            body: {},
		            escaped: true/false
		        }

		    type 可选值
		        alternate             |         选择
		        match                 匹配
		        capture-group         ()        捕获组
		        non-capture-group     (?:...)   非捕获组
		        positive-lookahead    (?=p)     零宽正向先行断言
		        negative-lookahead    (?!p)     零宽负向先行断言
		        quantified            a*        重复节点
		        quantifier            *         量词
		        charset               []        字符集
		        range                 {m, n}    范围
		        literal               a         直接量字符
		        unicode               \uxxxx    Unicode
		        hex                   \x        十六进制
		        octal                 八进制
		        back-reference        \n        反向引用
		        control-character     \cX       控制字符

		        // Token
		        start               ^       开头
		        end                 $       结尾
		        any-character       .       任意字符
		        backspace           [\b]    退格直接量
		        word-boundary       \b      单词边界
		        non-word-boundary   \B      非单词边界
		        digit               \d      ASCII 数字，[0-9]
		        non-digit           \D      非 ASCII 数字，[^0-9]
		        form-feed           \f      换页符
		        line-feed           \n      换行符
		        carriage-return     \r      回车符
		        white-space         \s      空白符
		        non-white-space     \S      非空白符
		        tab                 \t      制表符
		        vertical-tab        \v      垂直制表符
		        word                \w      ASCII 字符，[a-zA-Z0-9]
		        non-word            \W      非 ASCII 字符，[^a-zA-Z0-9]
		        null-character      \o      NUL 字符
		 */

		var Util = __webpack_require__(3)
		var Random = __webpack_require__(5)
		    /*
		        
		    */
		var Handler = {
		    extend: Util.extend
		}

		// http://en.wikipedia.org/wiki/ASCII#ASCII_printable_code_chart
		/*var ASCII_CONTROL_CODE_CHART = {
		    '@': ['\u0000'],
		    A: ['\u0001'],
		    B: ['\u0002'],
		    C: ['\u0003'],
		    D: ['\u0004'],
		    E: ['\u0005'],
		    F: ['\u0006'],
		    G: ['\u0007', '\a'],
		    H: ['\u0008', '\b'],
		    I: ['\u0009', '\t'],
		    J: ['\u000A', '\n'],
		    K: ['\u000B', '\v'],
		    L: ['\u000C', '\f'],
		    M: ['\u000D', '\r'],
		    N: ['\u000E'],
		    O: ['\u000F'],
		    P: ['\u0010'],
		    Q: ['\u0011'],
		    R: ['\u0012'],
		    S: ['\u0013'],
		    T: ['\u0014'],
		    U: ['\u0015'],
		    V: ['\u0016'],
		    W: ['\u0017'],
		    X: ['\u0018'],
		    Y: ['\u0019'],
		    Z: ['\u001A'],
		    '[': ['\u001B', '\e'],
		    '\\': ['\u001C'],
		    ']': ['\u001D'],
		    '^': ['\u001E'],
		    '_': ['\u001F']
		}*/

		// ASCII printable code chart
		// var LOWER = 'abcdefghijklmnopqrstuvwxyz'
		// var UPPER = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
		// var NUMBER = '0123456789'
		// var SYMBOL = ' !"#$%&\'()*+,-./' + ':;<=>?@' + '[\\]^_`' + '{|}~'
		var LOWER = ascii(97, 122)
		var UPPER = ascii(65, 90)
		var NUMBER = ascii(48, 57)
		var OTHER = ascii(32, 47) + ascii(58, 64) + ascii(91, 96) + ascii(123, 126) // 排除 95 _ ascii(91, 94) + ascii(96, 96)
		var PRINTABLE = ascii(32, 126)
		var SPACE = ' \f\n\r\t\v\u00A0\u2028\u2029'
		var CHARACTER_CLASSES = {
		    '\\w': LOWER + UPPER + NUMBER + '_', // ascii(95, 95)
		    '\\W': OTHER.replace('_', ''),
		    '\\s': SPACE,
		    '\\S': function() {
		        var result = PRINTABLE
		        for (var i = 0; i < SPACE.length; i++) {
		            result = result.replace(SPACE[i], '')
		        }
		        return result
		    }(),
		    '\\d': NUMBER,
		    '\\D': LOWER + UPPER + OTHER
		}

		function ascii(from, to) {
		    var result = ''
		    for (var i = from; i <= to; i++) {
		        result += String.fromCharCode(i)
		    }
		    return result
		}

		// var ast = RegExpParser.parse(regexp.source)
		Handler.gen = function(node, result, cache) {
		    cache = cache || {
		        guid: 1
		    }
		    return Handler[node.type] ? Handler[node.type](node, result, cache) :
		        Handler.token(node, result, cache)
		}

		Handler.extend({
		    /* jshint unused:false */
		    token: function(node, result, cache) {
		        switch (node.type) {
		            case 'start':
		            case 'end':
		                return ''
		            case 'any-character':
		                return Random.character()
		            case 'backspace':
		                return ''
		            case 'word-boundary': // TODO
		                return ''
		            case 'non-word-boundary': // TODO
		                break
		            case 'digit':
		                return Random.pick(
		                    NUMBER.split('')
		                )
		            case 'non-digit':
		                return Random.pick(
		                    (LOWER + UPPER + OTHER).split('')
		                )
		            case 'form-feed':
		                break
		            case 'line-feed':
		                return node.body || node.text
		            case 'carriage-return':
		                break
		            case 'white-space':
		                return Random.pick(
		                    SPACE.split('')
		                )
		            case 'non-white-space':
		                return Random.pick(
		                    (LOWER + UPPER + NUMBER).split('')
		                )
		            case 'tab':
		                break
		            case 'vertical-tab':
		                break
		            case 'word': // \w [a-zA-Z0-9]
		                return Random.pick(
		                    (LOWER + UPPER + NUMBER).split('')
		                )
		            case 'non-word': // \W [^a-zA-Z0-9]
		                return Random.pick(
		                    OTHER.replace('_', '').split('')
		                )
		            case 'null-character':
		                break
		        }
		        return node.body || node.text
		    },
		    /*
		        {
		            type: 'alternate',
		            offset: 0,
		            text: '',
		            left: {
		                boyd: []
		            },
		            right: {
		                boyd: []
		            }
		        }
		    */
		    alternate: function(node, result, cache) {
		        // node.left/right {}
		        return this.gen(
		            Random.boolean() ? node.left : node.right,
		            result,
		            cache
		        )
		    },
		    /*
		        {
		            type: 'match',
		            offset: 0,
		            text: '',
		            body: []
		        }
		    */
		    match: function(node, result, cache) {
		        result = ''
		            // node.body []
		        for (var i = 0; i < node.body.length; i++) {
		            result += this.gen(node.body[i], result, cache)
		        }
		        return result
		    },
		    // ()
		    'capture-group': function(node, result, cache) {
		        // node.body {}
		        result = this.gen(node.body, result, cache)
		        cache[cache.guid++] = result
		        return result
		    },
		    // (?:...)
		    'non-capture-group': function(node, result, cache) {
		        // node.body {}
		        return this.gen(node.body, result, cache)
		    },
		    // (?=p)
		    'positive-lookahead': function(node, result, cache) {
		        // node.body
		        return this.gen(node.body, result, cache)
		    },
		    // (?!p)
		    'negative-lookahead': function(node, result, cache) {
		        // node.body
		        return ''
		    },
		    /*
		        {
		            type: 'quantified',
		            offset: 3,
		            text: 'c*',
		            body: {
		                type: 'literal',
		                offset: 3,
		                text: 'c',
		                body: 'c',
		                escaped: false
		            },
		            quantifier: {
		                type: 'quantifier',
		                offset: 4,
		                text: '*',
		                min: 0,
		                max: Infinity,
		                greedy: true
		            }
		        }
		    */
		    quantified: function(node, result, cache) {
		        result = ''
		            // node.quantifier {}
		        var count = this.quantifier(node.quantifier);
		        // node.body {}
		        for (var i = 0; i < count; i++) {
		            result += this.gen(node.body, result, cache)
		        }
		        return result
		    },
		    /*
		        quantifier: {
		            type: 'quantifier',
		            offset: 4,
		            text: '*',
		            min: 0,
		            max: Infinity,
		            greedy: true
		        }
		    */
		    quantifier: function(node, result, cache) {
		        var min = Math.max(node.min, 0)
		        var max = isFinite(node.max) ? node.max :
		            min + Random.integer(3, 7)
		        return Random.integer(min, max)
		    },
		    /*
		        
		    */
		    charset: function(node, result, cache) {
		        // node.invert
		        if (node.invert) return this['invert-charset'](node, result, cache)

		        // node.body []
		        var literal = Random.pick(node.body)
		        return this.gen(literal, result, cache)
		    },
		    'invert-charset': function(node, result, cache) {
		        var pool = PRINTABLE
		        for (var i = 0, item; i < node.body.length; i++) {
		            item = node.body[i]
		            switch (item.type) {
		                case 'literal':
		                    pool = pool.replace(item.body, '')
		                    break
		                case 'range':
		                    var min = this.gen(item.start, result, cache).charCodeAt()
		                    var max = this.gen(item.end, result, cache).charCodeAt()
		                    for (var ii = min; ii <= max; ii++) {
		                        pool = pool.replace(String.fromCharCode(ii), '')
		                    }
		                    /* falls through */
		                default:
		                    var characters = CHARACTER_CLASSES[item.text]
		                    if (characters) {
		                        for (var iii = 0; iii <= characters.length; iii++) {
		                            pool = pool.replace(characters[iii], '')
		                        }
		                    }
		            }
		        }
		        return Random.pick(pool.split(''))
		    },
		    range: function(node, result, cache) {
		        // node.start, node.end
		        var min = this.gen(node.start, result, cache).charCodeAt()
		        var max = this.gen(node.end, result, cache).charCodeAt()
		        return String.fromCharCode(
		            Random.integer(min, max)
		        )
		    },
		    literal: function(node, result, cache) {
		        return node.escaped ? node.body : node.text
		    },
		    // Unicode \u
		    unicode: function(node, result, cache) {
		        return String.fromCharCode(
		            parseInt(node.code, 16)
		        )
		    },
		    // 十六进制 \xFF
		    hex: function(node, result, cache) {
		        return String.fromCharCode(
		            parseInt(node.code, 16)
		        )
		    },
		    // 八进制 \0
		    octal: function(node, result, cache) {
		        return String.fromCharCode(
		            parseInt(node.code, 8)
		        )
		    },
		    // 反向引用
		    'back-reference': function(node, result, cache) {
		        return cache[node.code] || ''
		    },
		    /*
		        http://en.wikipedia.org/wiki/C0_and_C1_control_codes
		    */
		    CONTROL_CHARACTER_MAP: function() {
		        var CONTROL_CHARACTER = '@ A B C D E F G H I J K L M N O P Q R S T U V W X Y Z [ \\ ] ^ _'.split(' ')
		        var CONTROL_CHARACTER_UNICODE = '\u0000 \u0001 \u0002 \u0003 \u0004 \u0005 \u0006 \u0007 \u0008 \u0009 \u000A \u000B \u000C \u000D \u000E \u000F \u0010 \u0011 \u0012 \u0013 \u0014 \u0015 \u0016 \u0017 \u0018 \u0019 \u001A \u001B \u001C \u001D \u001E \u001F'.split(' ')
		        var map = {}
		        for (var i = 0; i < CONTROL_CHARACTER.length; i++) {
		            map[CONTROL_CHARACTER[i]] = CONTROL_CHARACTER_UNICODE[i]
		        }
		        return map
		    }(),
		    'control-character': function(node, result, cache) {
		        return this.CONTROL_CHARACTER_MAP[node.code]
		    }
		})

		module.exports = Handler

	/***/ },
	/* 23 */
	/***/ function(module, exports, __webpack_require__) {

		module.exports = __webpack_require__(24)

	/***/ },
	/* 24 */
	/***/ function(module, exports, __webpack_require__) {

		/*
		    ## toJSONSchema

		    把 Mock.js 风格的数据模板转换成 JSON Schema。

		    > [JSON Schema](http://json-schema.org/)
		 */
		var Constant = __webpack_require__(2)
		var Util = __webpack_require__(3)
		var Parser = __webpack_require__(4)

		function toJSONSchema(template, name, path /* Internal Use Only */ ) {
		    // type rule properties items
		    path = path || []
		    var result = {
		        name: typeof name === 'string' ? name.replace(Constant.RE_KEY, '$1') : name,
		        template: template,
		        type: Util.type(template), // 可能不准确，例如 { 'name|1': [{}, {} ...] }
		        rule: Parser.parse(name)
		    }
		    result.path = path.slice(0)
		    result.path.push(name === undefined ? 'ROOT' : result.name)

		    switch (result.type) {
		        case 'array':
		            result.items = []
		            Util.each(template, function(value, index) {
		                result.items.push(
		                    toJSONSchema(value, index, result.path)
		                )
		            })
		            break
		        case 'object':
		            result.properties = []
		            Util.each(template, function(value, name) {
		                result.properties.push(
		                    toJSONSchema(value, name, result.path)
		                )
		            })
		            break
		    }

		    return result

		}

		module.exports = toJSONSchema


	/***/ },
	/* 25 */
	/***/ function(module, exports, __webpack_require__) {

		module.exports = __webpack_require__(26)

	/***/ },
	/* 26 */
	/***/ function(module, exports, __webpack_require__) {

		/*
		    ## valid(template, data)

		    校验真实数据 data 是否与数据模板 template 匹配。
		    
		    实现思路：
		    1. 解析规则。
		        先把数据模板 template 解析为更方便机器解析的 JSON-Schame
		        name               属性名 
		        type               属性值类型
		        template           属性值模板
		        properties         对象属性数组
		        items              数组元素数组
		        rule               属性值生成规则
		    2. 递归验证规则。
		        然后用 JSON-Schema 校验真实数据，校验项包括属性名、值类型、值、值生成规则。

		    提示信息 
		    https://github.com/fge/json-schema-validator/blob/master/src/main/resources/com/github/fge/jsonschema/validator/validation.properties
		    [JSON-Schama validator](http://json-schema-validator.herokuapp.com/)
		    [Regexp Demo](http://demos.forbeslindesay.co.uk/regexp/)
		*/
		var Constant = __webpack_require__(2)
		var Util = __webpack_require__(3)
		var toJSONSchema = __webpack_require__(23)

		function valid(template, data) {
		    var schema = toJSONSchema(template)
		    var result = Diff.diff(schema, data)
		    for (var i = 0; i < result.length; i++) {
		        // console.log(template, data)
		        // console.warn(Assert.message(result[i]))
		    }
		    return result
		}

		/*
		    ## name
		        有生成规则：比较解析后的 name
		        无生成规则：直接比较
		    ## type
		        无类型转换：直接比较
		        有类型转换：先试着解析 template，然后再检查？
		    ## value vs. template
		        基本类型
		            无生成规则：直接比较
		            有生成规则：
		                number
		                    min-max.dmin-dmax
		                    min-max.dcount
		                    count.dmin-dmax
		                    count.dcount
		                    +step
		                    整数部分
		                    小数部分
		                boolean 
		                string  
		                    min-max
		                    count
		    ## properties
		        对象
		            有生成规则：检测期望的属性个数，继续递归
		            无生成规则：检测全部的属性个数，继续递归
		    ## items
		        数组
		            有生成规则：
		                `'name|1': [{}, {} ...]`            其中之一，继续递归
		                `'name|+1': [{}, {} ...]`           顺序检测，继续递归
		                `'name|min-max': [{}, {} ...]`      检测个数，继续递归
		                `'name|count': [{}, {} ...]`        检测个数，继续递归
		            无生成规则：检测全部的元素个数，继续递归
		*/
		var Diff = {
		    diff: function diff(schema, data, name /* Internal Use Only */ ) {
		        var result = []

		        // 先检测名称 name 和类型 type，如果匹配，才有必要继续检测
		        if (
		            this.name(schema, data, name, result) &&
		            this.type(schema, data, name, result)
		        ) {
		            this.value(schema, data, name, result)
		            this.properties(schema, data, name, result)
		            this.items(schema, data, name, result)
		        }

		        return result
		    },
		    /* jshint unused:false */
		    name: function(schema, data, name, result) {
		        var length = result.length

		        Assert.equal('name', schema.path, name + '', schema.name + '', result)

		        return result.length === length
		    },
		    type: function(schema, data, name, result) {
		        var length = result.length

		        switch (schema.type) {
		            case 'string':
		                // 跳过含有『占位符』的属性值，因为『占位符』返回值的类型可能和模板不一致，例如 '@int' 会返回一个整形值
		                if (schema.template.match(Constant.RE_PLACEHOLDER)) return true
		                break
		            case 'array':
		                if (schema.rule.parameters) {
		                    // name|count: array
		                    if (schema.rule.min !== undefined && schema.rule.max === undefined) {
		                        // 跳过 name|1: array，因为最终值的类型（很可能）不是数组，也不一定与 `array` 中的类型一致
		                        if (schema.rule.count === 1) return true
		                    }
		                    // 跳过 name|+inc: array
		                    if (schema.rule.parameters[2]) return true
		                }
		                break
		            case 'function':
		                // 跳过 `'name': function`，因为函数可以返回任何类型的值。
		                return true
		        }

		        Assert.equal('type', schema.path, Util.type(data), schema.type, result)

		        return result.length === length
		    },
		    value: function(schema, data, name, result) {
		        var length = result.length

		        var rule = schema.rule
		        var templateType = schema.type
		        if (templateType === 'object' || templateType === 'array' || templateType === 'function') return true

		        // 无生成规则
		        if (!rule.parameters) {
		            switch (templateType) {
		                case 'regexp':
		                    Assert.match('value', schema.path, data, schema.template, result)
		                    return result.length === length
		                case 'string':
		                    // 同样跳过含有『占位符』的属性值，因为『占位符』的返回值会通常会与模板不一致
		                    if (schema.template.match(Constant.RE_PLACEHOLDER)) return result.length === length
		                    break
		            }
		            Assert.equal('value', schema.path, data, schema.template, result)
		            return result.length === length
		        }

		        // 有生成规则
		        var actualRepeatCount
		        switch (templateType) {
		            case 'number':
		                var parts = (data + '').split('.')
		                parts[0] = +parts[0]

		                // 整数部分
		                // |min-max
		                if (rule.min !== undefined && rule.max !== undefined) {
		                    Assert.greaterThanOrEqualTo('value', schema.path, parts[0], Math.min(rule.min, rule.max), result)
		                        // , 'numeric instance is lower than the required minimum (minimum: {expected}, found: {actual})')
		                    Assert.lessThanOrEqualTo('value', schema.path, parts[0], Math.max(rule.min, rule.max), result)
		                }
		                // |count
		                if (rule.min !== undefined && rule.max === undefined) {
		                    Assert.equal('value', schema.path, parts[0], rule.min, result, '[value] ' + name)
		                }

		                // 小数部分
		                if (rule.decimal) {
		                    // |dmin-dmax
		                    if (rule.dmin !== undefined && rule.dmax !== undefined) {
		                        Assert.greaterThanOrEqualTo('value', schema.path, parts[1].length, rule.dmin, result)
		                        Assert.lessThanOrEqualTo('value', schema.path, parts[1].length, rule.dmax, result)
		                    }
		                    // |dcount
		                    if (rule.dmin !== undefined && rule.dmax === undefined) {
		                        Assert.equal('value', schema.path, parts[1].length, rule.dmin, result)
		                    }
		                }

		                break

		            case 'boolean':
		                break

		            case 'string':
		                // 'aaa'.match(/a/g)
		                actualRepeatCount = data.match(new RegExp(schema.template, 'g'))
		                actualRepeatCount = actualRepeatCount ? actualRepeatCount.length : 0

		                // |min-max
		                if (rule.min !== undefined && rule.max !== undefined) {
		                    Assert.greaterThanOrEqualTo('repeat count', schema.path, actualRepeatCount, rule.min, result)
		                    Assert.lessThanOrEqualTo('repeat count', schema.path, actualRepeatCount, rule.max, result)
		                }
		                // |count
		                if (rule.min !== undefined && rule.max === undefined) {
		                    Assert.equal('repeat count', schema.path, actualRepeatCount, rule.min, result)
		                }

		                break

		            case 'regexp':
		                actualRepeatCount = data.match(new RegExp(schema.template.source.replace(/^\^|\$$/g, ''), 'g'))
		                actualRepeatCount = actualRepeatCount ? actualRepeatCount.length : 0

		                // |min-max
		                if (rule.min !== undefined && rule.max !== undefined) {
		                    Assert.greaterThanOrEqualTo('repeat count', schema.path, actualRepeatCount, rule.min, result)
		                    Assert.lessThanOrEqualTo('repeat count', schema.path, actualRepeatCount, rule.max, result)
		                }
		                // |count
		                if (rule.min !== undefined && rule.max === undefined) {
		                    Assert.equal('repeat count', schema.path, actualRepeatCount, rule.min, result)
		                }
		                break
		        }

		        return result.length === length
		    },
		    properties: function(schema, data, name, result) {
		        var length = result.length

		        var rule = schema.rule
		        var keys = Util.keys(data)
		        if (!schema.properties) return

		        // 无生成规则
		        if (!schema.rule.parameters) {
		            Assert.equal('properties length', schema.path, keys.length, schema.properties.length, result)
		        } else {
		            // 有生成规则
		            // |min-max
		            if (rule.min !== undefined && rule.max !== undefined) {
		                Assert.greaterThanOrEqualTo('properties length', schema.path, keys.length, Math.min(rule.min, rule.max), result)
		                Assert.lessThanOrEqualTo('properties length', schema.path, keys.length, Math.max(rule.min, rule.max), result)
		            }
		            // |count
		            if (rule.min !== undefined && rule.max === undefined) {
		                // |1, |>1
		                if (rule.count !== 1) Assert.equal('properties length', schema.path, keys.length, rule.min, result)
		            }
		        }

		        if (result.length !== length) return false

		        for (var i = 0; i < keys.length; i++) {
		            result.push.apply(
		                result,
		                this.diff(
		                    function() {
		                        var property
		                        Util.each(schema.properties, function(item /*, index*/ ) {
		                            if (item.name === keys[i]) property = item
		                        })
		                        return property || schema.properties[i]
		                    }(),
		                    data[keys[i]],
		                    keys[i]
		                )
		            )
		        }

		        return result.length === length
		    },
		    items: function(schema, data, name, result) {
		        var length = result.length

		        if (!schema.items) return

		        var rule = schema.rule

		        // 无生成规则
		        if (!schema.rule.parameters) {
		            Assert.equal('items length', schema.path, data.length, schema.items.length, result)
		        } else {
		            // 有生成规则
		            // |min-max
		            if (rule.min !== undefined && rule.max !== undefined) {
		                Assert.greaterThanOrEqualTo('items', schema.path, data.length, (Math.min(rule.min, rule.max) * schema.items.length), result,
		                    '[{utype}] array is too short: {path} must have at least {expected} elements but instance has {actual} elements')
		                Assert.lessThanOrEqualTo('items', schema.path, data.length, (Math.max(rule.min, rule.max) * schema.items.length), result,
		                    '[{utype}] array is too long: {path} must have at most {expected} elements but instance has {actual} elements')
		            }
		            // |count
		            if (rule.min !== undefined && rule.max === undefined) {
		                // |1, |>1
		                if (rule.count === 1) return result.length === length
		                else Assert.equal('items length', schema.path, data.length, (rule.min * schema.items.length), result)
		            }
		            // |+inc
		            if (rule.parameters[2]) return result.length === length
		        }

		        if (result.length !== length) return false

		        for (var i = 0; i < data.length; i++) {
		            result.push.apply(
		                result,
		                this.diff(
		                    schema.items[i % schema.items.length],
		                    data[i],
		                    i % schema.items.length
		                )
		            )
		        }

		        return result.length === length
		    }
		}

		/*
		    完善、友好的提示信息
		    
		    Equal, not equal to, greater than, less than, greater than or equal to, less than or equal to
		    路径 验证类型 描述 

		    Expect path.name is less than or equal to expected, but path.name is actual.

		    Expect path.name is less than or equal to expected, but path.name is actual.
		    Expect path.name is greater than or equal to expected, but path.name is actual.

		*/
		var Assert = {
		    message: function(item) {
		        return (item.message ||
		                '[{utype}] Expect {path}\'{ltype} {action} {expected}, but is {actual}')
		            .replace('{utype}', item.type.toUpperCase())
		            .replace('{ltype}', item.type.toLowerCase())
		            .replace('{path}', Util.isArray(item.path) && item.path.join('.') || item.path)
		            .replace('{action}', item.action)
		            .replace('{expected}', item.expected)
		            .replace('{actual}', item.actual)
		    },
		    equal: function(type, path, actual, expected, result, message) {
		        if (actual === expected) return true
		        switch (type) {
		            case 'type':
		                // 正则模板 === 字符串最终值
		                if (expected === 'regexp' && actual === 'string') return true
		                break
		        }

		        var item = {
		            path: path,
		            type: type,
		            actual: actual,
		            expected: expected,
		            action: 'is equal to',
		            message: message
		        }
		        item.message = Assert.message(item)
		        result.push(item)
		        return false
		    },
		    // actual matches expected
		    match: function(type, path, actual, expected, result, message) {
		        if (expected.test(actual)) return true

		        var item = {
		            path: path,
		            type: type,
		            actual: actual,
		            expected: expected,
		            action: 'matches',
		            message: message
		        }
		        item.message = Assert.message(item)
		        result.push(item)
		        return false
		    },
		    notEqual: function(type, path, actual, expected, result, message) {
		        if (actual !== expected) return true
		        var item = {
		            path: path,
		            type: type,
		            actual: actual,
		            expected: expected,
		            action: 'is not equal to',
		            message: message
		        }
		        item.message = Assert.message(item)
		        result.push(item)
		        return false
		    },
		    greaterThan: function(type, path, actual, expected, result, message) {
		        if (actual > expected) return true
		        var item = {
		            path: path,
		            type: type,
		            actual: actual,
		            expected: expected,
		            action: 'is greater than',
		            message: message
		        }
		        item.message = Assert.message(item)
		        result.push(item)
		        return false
		    },
		    lessThan: function(type, path, actual, expected, result, message) {
		        if (actual < expected) return true
		        var item = {
		            path: path,
		            type: type,
		            actual: actual,
		            expected: expected,
		            action: 'is less to',
		            message: message
		        }
		        item.message = Assert.message(item)
		        result.push(item)
		        return false
		    },
		    greaterThanOrEqualTo: function(type, path, actual, expected, result, message) {
		        if (actual >= expected) return true
		        var item = {
		            path: path,
		            type: type,
		            actual: actual,
		            expected: expected,
		            action: 'is greater than or equal to',
		            message: message
		        }
		        item.message = Assert.message(item)
		        result.push(item)
		        return false
		    },
		    lessThanOrEqualTo: function(type, path, actual, expected, result, message) {
		        if (actual <= expected) return true
		        var item = {
		            path: path,
		            type: type,
		            actual: actual,
		            expected: expected,
		            action: 'is less than or equal to',
		            message: message
		        }
		        item.message = Assert.message(item)
		        result.push(item)
		        return false
		    }
		}

		valid.Diff = Diff
		valid.Assert = Assert

		module.exports = valid

	/***/ },
	/* 27 */
	/***/ function(module, exports, __webpack_require__) {

		module.exports = __webpack_require__(28)

	/***/ },
	/* 28 */
	/***/ function(module, exports, __webpack_require__) {

		/* global window, document, location, Event, setTimeout */
		/*
		    ## MockXMLHttpRequest

		    期望的功能：
		    1. 完整地覆盖原生 XHR 的行为
		    2. 完整地模拟原生 XHR 的行为
		    3. 在发起请求时，自动检测是否需要拦截
		    4. 如果不必拦截，则执行原生 XHR 的行为
		    5. 如果需要拦截，则执行虚拟 XHR 的行为
		    6. 兼容 XMLHttpRequest 和 ActiveXObject
		        new window.XMLHttpRequest()
		        new window.ActiveXObject("Microsoft.XMLHTTP")

		    关键方法的逻辑：
		    * new   此时尚无法确定是否需要拦截，所以创建原生 XHR 对象是必须的。
		    * open  此时可以取到 URL，可以决定是否进行拦截。
		    * send  此时已经确定了请求方式。

		    规范：
		    http://xhr.spec.whatwg.org/
		    http://www.w3.org/TR/XMLHttpRequest2/

		    参考实现：
		    https://github.com/philikon/MockHttpRequest/blob/master/lib/mock.js
		    https://github.com/trek/FakeXMLHttpRequest/blob/master/fake_xml_http_request.js
		    https://github.com/ilinsky/xmlhttprequest/blob/master/XMLHttpRequest.js
		    https://github.com/firebug/firebug-lite/blob/master/content/lite/xhr.js
		    https://github.com/thx/RAP/blob/master/lab/rap.plugin.xinglie.js

		    **需不需要全面重写 XMLHttpRequest？**
		        http://xhr.spec.whatwg.org/#interface-xmlhttprequest
		        关键属性 readyState、status、statusText、response、responseText、responseXML 是 readonly，所以，试图通过修改这些状态，来模拟响应是不可行的。
		        因此，唯一的办法是模拟整个 XMLHttpRequest，就像 jQuery 对事件模型的封装。

		    // Event handlers
		    onloadstart         loadstart
		    onprogress          progress
		    onabort             abort
		    onerror             error
		    onload              load
		    ontimeout           timeout
		    onloadend           loadend
		    onreadystatechange  readystatechange
		 */

		var Util = __webpack_require__(3)

		// 备份原生 XMLHttpRequest
		window._XMLHttpRequest = window.XMLHttpRequest
		window._ActiveXObject = window.ActiveXObject

		/*
		    PhantomJS
		    TypeError: '[object EventConstructor]' is not a constructor (evaluating 'new Event("readystatechange")')

		    https://github.com/bluerail/twitter-bootstrap-rails-confirm/issues/18
		    https://github.com/ariya/phantomjs/issues/11289
		*/
		try {
		    new window.Event('custom')
		} catch (exception) {
		    window.Event = function(type, bubbles, cancelable, detail) {
		        var event = document.createEvent('CustomEvent') // MUST be 'CustomEvent'
		        event.initCustomEvent(type, bubbles, cancelable, detail)
		        return event
		    }
		}

		var XHR_STATES = {
		    // The object has been constructed.
		    UNSENT: 0,
		    // The open() method has been successfully invoked.
		    OPENED: 1,
		    // All redirects (if any) have been followed and all HTTP headers of the response have been received.
		    HEADERS_RECEIVED: 2,
		    // The response's body is being received.
		    LOADING: 3,
		    // The data transfer has been completed or something went wrong during the transfer (e.g. infinite redirects).
		    DONE: 4
		}

		var XHR_EVENTS = 'readystatechange loadstart progress abort error load timeout loadend'.split(' ')
		var XHR_REQUEST_PROPERTIES = 'timeout withCredentials'.split(' ')
		var XHR_RESPONSE_PROPERTIES = 'readyState responseURL status statusText responseType response responseText responseXML'.split(' ')

		// https://github.com/trek/FakeXMLHttpRequest/blob/master/fake_xml_http_request.js#L32
		var HTTP_STATUS_CODES = {
		    100: "Continue",
		    101: "Switching Protocols",
		    200: "OK",
		    201: "Created",
		    202: "Accepted",
		    203: "Non-Authoritative Information",
		    204: "No Content",
		    205: "Reset Content",
		    206: "Partial Content",
		    300: "Multiple Choice",
		    301: "Moved Permanently",
		    302: "Found",
		    303: "See Other",
		    304: "Not Modified",
		    305: "Use Proxy",
		    307: "Temporary Redirect",
		    400: "Bad Request",
		    401: "Unauthorized",
		    402: "Payment Required",
		    403: "Forbidden",
		    404: "Not Found",
		    405: "Method Not Allowed",
		    406: "Not Acceptable",
		    407: "Proxy Authentication Required",
		    408: "Request Timeout",
		    409: "Conflict",
		    410: "Gone",
		    411: "Length Required",
		    412: "Precondition Failed",
		    413: "Request Entity Too Large",
		    414: "Request-URI Too Long",
		    415: "Unsupported Media Type",
		    416: "Requested Range Not Satisfiable",
		    417: "Expectation Failed",
		    422: "Unprocessable Entity",
		    500: "Internal Server Error",
		    501: "Not Implemented",
		    502: "Bad Gateway",
		    503: "Service Unavailable",
		    504: "Gateway Timeout",
		    505: "HTTP Version Not Supported"
		}

		/*
		    MockXMLHttpRequest
		*/

		function MockXMLHttpRequest() {
		    // 初始化 custom 对象，用于存储自定义属性
		    this.custom = {
		        events: {},
		        requestHeaders: {},
		        responseHeaders: {}
		    }
		}

		MockXMLHttpRequest._settings = {
		    timeout: '10-100',
		    /*
		        timeout: 50,
		        timeout: '10-100',
		     */
		}

		MockXMLHttpRequest.setup = function(settings) {
		    Util.extend(MockXMLHttpRequest._settings, settings)
		    return MockXMLHttpRequest._settings
		}

		Util.extend(MockXMLHttpRequest, XHR_STATES)
		Util.extend(MockXMLHttpRequest.prototype, XHR_STATES)

		// 标记当前对象为 MockXMLHttpRequest
		MockXMLHttpRequest.prototype.mock = true

		// 是否拦截 Ajax 请求
		MockXMLHttpRequest.prototype.match = false

		// 初始化 Request 相关的属性和方法
		Util.extend(MockXMLHttpRequest.prototype, {
		    // https://xhr.spec.whatwg.org/#the-open()-method
		    // Sets the request method, request URL, and synchronous flag.
		    open: function(method, url, async, username, password) {
		        var that = this

		        Util.extend(this.custom, {
		            method: method,
		            url: url,
		            async: typeof async === 'boolean' ? async : true,
		            username: username,
		            password: password,
		            options: {
		                url: url,
		                type: method
		            }
		        })

		        this.custom.timeout = function(timeout) {
		            if (typeof timeout === 'number') return timeout
		            if (typeof timeout === 'string' && !~timeout.indexOf('-')) return parseInt(timeout, 10)
		            if (typeof timeout === 'string' && ~timeout.indexOf('-')) {
		                var tmp = timeout.split('-')
		                var min = parseInt(tmp[0], 10)
		                var max = parseInt(tmp[1], 10)
		                return Math.round(Math.random() * (max - min)) + min
		            }
		        }(MockXMLHttpRequest._settings.timeout)

		        // 查找与请求参数匹配的数据模板
		        var item = find(this.custom.options)

		        function handle(event) {
		            // 同步属性 NativeXMLHttpRequest => MockXMLHttpRequest
		            for (var i = 0; i < XHR_RESPONSE_PROPERTIES.length; i++) {
		                try {
		                    that[XHR_RESPONSE_PROPERTIES[i]] = xhr[XHR_RESPONSE_PROPERTIES[i]]
		                } catch (e) {}
		            }
		            // 触发 MockXMLHttpRequest 上的同名事件
		            that.dispatchEvent(new Event(event.type /*, false, false, that*/ ))
		        }

		        // 如果未找到匹配的数据模板，则采用原生 XHR 发送请求。
		        if (!item) {
		            // 创建原生 XHR 对象，调用原生 open()，监听所有原生事件
		            var xhr = createNativeXMLHttpRequest()
		            this.custom.xhr = xhr

		            // 初始化所有事件，用于监听原生 XHR 对象的事件
		            for (var i = 0; i < XHR_EVENTS.length; i++) {
		                xhr.addEventListener(XHR_EVENTS[i], handle)
		            }

		            // xhr.open()
		            if (username) xhr.open(method, url, async, username, password)
		            else xhr.open(method, url, async)

		            // 同步属性 MockXMLHttpRequest => NativeXMLHttpRequest
		            for (var j = 0; j < XHR_REQUEST_PROPERTIES.length; j++) {
		                try {
		                    xhr[XHR_REQUEST_PROPERTIES[j]] = that[XHR_REQUEST_PROPERTIES[j]]
		                } catch (e) {}
		            }

		            return
		        }

		        // 找到了匹配的数据模板，开始拦截 XHR 请求
		        this.match = true
		        this.custom.template = item
		        this.readyState = MockXMLHttpRequest.OPENED
		        this.dispatchEvent(new Event('readystatechange' /*, false, false, this*/ ))
		    },
		    // https://xhr.spec.whatwg.org/#the-setrequestheader()-method
		    // Combines a header in author request headers.
		    setRequestHeader: function(name, value) {
		        // 原生 XHR
		        if (!this.match) {
		            this.custom.xhr.setRequestHeader(name, value)
		            return
		        }

		        // 拦截 XHR
		        var requestHeaders = this.custom.requestHeaders
		        if (requestHeaders[name]) requestHeaders[name] += ',' + value
		        else requestHeaders[name] = value
		    },
		    timeout: 0,
		    withCredentials: false,
		    upload: {},
		    // https://xhr.spec.whatwg.org/#the-send()-method
		    // Initiates the request.
		    send: function send(data) {
		        var that = this
		        this.custom.options.body = data

		        // 原生 XHR
		        if (!this.match) {
		            this.custom.xhr.send(data)
		            return
		        }

		        // 拦截 XHR

		        // X-Requested-With header
		        this.setRequestHeader('X-Requested-With', 'MockXMLHttpRequest')

		        // loadstart The fetch initiates.
		        this.dispatchEvent(new Event('loadstart' /*, false, false, this*/ ))

		        if (this.custom.async) setTimeout(done, this.custom.timeout) // 异步
		        else done() // 同步

		        function done() {
		            that.readyState = MockXMLHttpRequest.HEADERS_RECEIVED
		            that.dispatchEvent(new Event('readystatechange' /*, false, false, that*/ ))
		            that.readyState = MockXMLHttpRequest.LOADING
		            that.dispatchEvent(new Event('readystatechange' /*, false, false, that*/ ))

		            that.status = 200
		            that.statusText = HTTP_STATUS_CODES[200]

		            // fix #92 #93 by @qddegtya
		            that.response = that.responseText = JSON.stringify(
		                convert(that.custom.template, that.custom.options),
		                null, 4
		            )

		            that.readyState = MockXMLHttpRequest.DONE
		            that.dispatchEvent(new Event('readystatechange' /*, false, false, that*/ ))
		            that.dispatchEvent(new Event('load' /*, false, false, that*/ ));
		            that.dispatchEvent(new Event('loadend' /*, false, false, that*/ ));
		        }
		    },
		    // https://xhr.spec.whatwg.org/#the-abort()-method
		    // Cancels any network activity.
		    abort: function abort() {
		        // 原生 XHR
		        if (!this.match) {
		            this.custom.xhr.abort()
		            return
		        }

		        // 拦截 XHR
		        this.readyState = MockXMLHttpRequest.UNSENT
		        this.dispatchEvent(new Event('abort', false, false, this))
		        this.dispatchEvent(new Event('error', false, false, this))
		    }
		})

		// 初始化 Response 相关的属性和方法
		Util.extend(MockXMLHttpRequest.prototype, {
		    responseURL: '',
		    status: MockXMLHttpRequest.UNSENT,
		    statusText: '',
		    // https://xhr.spec.whatwg.org/#the-getresponseheader()-method
		    getResponseHeader: function(name) {
		        // 原生 XHR
		        if (!this.match) {
		            return this.custom.xhr.getResponseHeader(name)
		        }

		        // 拦截 XHR
		        return this.custom.responseHeaders[name.toLowerCase()]
		    },
		    // https://xhr.spec.whatwg.org/#the-getallresponseheaders()-method
		    // http://www.utf8-chartable.de/
		    getAllResponseHeaders: function() {
		        // 原生 XHR
		        if (!this.match) {
		            return this.custom.xhr.getAllResponseHeaders()
		        }

		        // 拦截 XHR
		        var responseHeaders = this.custom.responseHeaders
		        var headers = ''
		        for (var h in responseHeaders) {
		            if (!responseHeaders.hasOwnProperty(h)) continue
		            headers += h + ': ' + responseHeaders[h] + '\r\n'
		        }
		        return headers
		    },
		    overrideMimeType: function( /*mime*/ ) {},
		    responseType: '', // '', 'text', 'arraybuffer', 'blob', 'document', 'json'
		    response: null,
		    responseText: '',
		    responseXML: null
		})

		// EventTarget
		Util.extend(MockXMLHttpRequest.prototype, {
		    addEventListener: function addEventListener(type, handle) {
		        var events = this.custom.events
		        if (!events[type]) events[type] = []
		        events[type].push(handle)
		    },
		    removeEventListener: function removeEventListener(type, handle) {
		        var handles = this.custom.events[type] || []
		        for (var i = 0; i < handles.length; i++) {
		            if (handles[i] === handle) {
		                handles.splice(i--, 1)
		            }
		        }
		    },
		    dispatchEvent: function dispatchEvent(event) {
		        var handles = this.custom.events[event.type] || []
		        for (var i = 0; i < handles.length; i++) {
		            handles[i].call(this, event)
		        }

		        var ontype = 'on' + event.type
		        if (this[ontype]) this[ontype](event)
		    }
		})

		// Inspired by jQuery
		function createNativeXMLHttpRequest() {
		    var isLocal = function() {
		        var rlocalProtocol = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/
		        var rurl = /^([\w.+-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/
		        var ajaxLocation = location.href
		        var ajaxLocParts = rurl.exec(ajaxLocation.toLowerCase()) || []
		        return rlocalProtocol.test(ajaxLocParts[1])
		    }()

		    return window.ActiveXObject ?
		        (!isLocal && createStandardXHR() || createActiveXHR()) : createStandardXHR()

		    function createStandardXHR() {
		        try {
		            return new window._XMLHttpRequest();
		        } catch (e) {}
		    }

		    function createActiveXHR() {
		        try {
		            return new window._ActiveXObject("Microsoft.XMLHTTP");
		        } catch (e) {}
		    }
		}


		// 查找与请求参数匹配的数据模板：URL，Type
		function find(options) {

		    for (var sUrlType in MockXMLHttpRequest.Mock._mocked) {
		        var item = MockXMLHttpRequest.Mock._mocked[sUrlType]
		        if (
		            (!item.rurl || match(item.rurl, options.url)) &&
		            (!item.rtype || match(item.rtype, options.type.toLowerCase()))
		        ) {
		            // console.log('[mock]', options.url, '>', item.rurl)
		            return item
		        }
		    }

		    function match(expected, actual) {
		        if (Util.type(expected) === 'string') {
		            return expected === actual
		        }
		        if (Util.type(expected) === 'regexp') {
		            return expected.test(actual)
		        }
		    }

		}

		// 数据模板 ＝> 响应数据
		function convert(item, options) {
		    return Util.isFunction(item.template) ?
		        item.template(options) : MockXMLHttpRequest.Mock.mock(item.template)
		}

		module.exports = MockXMLHttpRequest

	/***/ }
	/******/ ])
	});
	;

/***/ },

/***/ 904:
/***/ function(module, exports, __webpack_require__) {

	/* ***** BEGIN LICENSE BLOCK *****
	 * Distributed under the BSD license:
	 *
	 * Copyright (c) 2010, Ajax.org B.V.
	 * All rights reserved.
	 *
	 * Redistribution and use in source and binary forms, with or without
	 * modification, are permitted provided that the following conditions are met:
	 *     * Redistributions of source code must retain the above copyright
	 *       notice, this list of conditions and the following disclaimer.
	 *     * Redistributions in binary form must reproduce the above copyright
	 *       notice, this list of conditions and the following disclaimer in the
	 *       documentation and/or other materials provided with the distribution.
	 *     * Neither the name of Ajax.org B.V. nor the
	 *       names of its contributors may be used to endorse or promote products
	 *       derived from this software without specific prior written permission.
	 *
	 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
	 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
	 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
	 * DISCLAIMED. IN NO EVENT SHALL AJAX.ORG B.V. BE LIABLE FOR ANY
	 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
	 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
	 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
	 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
	 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
	 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	 *
	 * ***** END LICENSE BLOCK ***** */

	/**
	 * Define a module along with a payload
	 * @param module a name for the payload
	 * @param payload a function to call with (acequire, exports, module) params
	 */

	(function() {

	var ACE_NAMESPACE = "ace";

	var global = (function() { return this; })();
	if (!global && typeof window != "undefined") global = window; // strict mode


	if (!ACE_NAMESPACE && typeof acequirejs !== "undefined")
	    return;


	var define = function(module, deps, payload) {
	    if (typeof module !== "string") {
	        if (define.original)
	            define.original.apply(this, arguments);
	        else {
	            console.error("dropping module because define wasn\'t a string.");
	            console.trace();
	        }
	        return;
	    }
	    if (arguments.length == 2)
	        payload = deps;
	    if (!define.modules[module]) {
	        define.payloads[module] = payload;
	        define.modules[module] = null;
	    }
	};

	define.modules = {};
	define.payloads = {};

	/**
	 * Get at functionality define()ed using the function above
	 */
	var _acequire = function(parentId, module, callback) {
	    if (typeof module === "string") {
	        var payload = lookup(parentId, module);
	        if (payload != undefined) {
	            callback && callback();
	            return payload;
	        }
	    } else if (Object.prototype.toString.call(module) === "[object Array]") {
	        var params = [];
	        for (var i = 0, l = module.length; i < l; ++i) {
	            var dep = lookup(parentId, module[i]);
	            if (dep == undefined && acequire.original)
	                return;
	            params.push(dep);
	        }
	        return callback && callback.apply(null, params) || true;
	    }
	};

	var acequire = function(module, callback) {
	    var packagedModule = _acequire("", module, callback);
	    if (packagedModule == undefined && acequire.original)
	        return acequire.original.apply(this, arguments);
	    return packagedModule;
	};

	var normalizeModule = function(parentId, moduleName) {
	    // normalize plugin acequires
	    if (moduleName.indexOf("!") !== -1) {
	        var chunks = moduleName.split("!");
	        return normalizeModule(parentId, chunks[0]) + "!" + normalizeModule(parentId, chunks[1]);
	    }
	    // normalize relative acequires
	    if (moduleName.charAt(0) == ".") {
	        var base = parentId.split("/").slice(0, -1).join("/");
	        moduleName = base + "/" + moduleName;

	        while(moduleName.indexOf(".") !== -1 && previous != moduleName) {
	            var previous = moduleName;
	            moduleName = moduleName.replace(/\/\.\//, "/").replace(/[^\/]+\/\.\.\//, "");
	        }
	    }
	    return moduleName;
	};

	/**
	 * Internal function to lookup moduleNames and resolve them by calling the
	 * definition function if needed.
	 */
	var lookup = function(parentId, moduleName) {
	    moduleName = normalizeModule(parentId, moduleName);

	    var module = define.modules[moduleName];
	    if (!module) {
	        module = define.payloads[moduleName];
	        if (typeof module === 'function') {
	            var exports = {};
	            var mod = {
	                id: moduleName,
	                uri: '',
	                exports: exports,
	                packaged: true
	            };

	            var req = function(module, callback) {
	                return _acequire(moduleName, module, callback);
	            };

	            var returnValue = module(req, exports, mod);
	            exports = returnValue || mod.exports;
	            define.modules[moduleName] = exports;
	            delete define.payloads[moduleName];
	        }
	        module = define.modules[moduleName] = exports || module;
	    }
	    return module;
	};

	function exportAce(ns) {
	    var root = global;
	    if (ns) {
	        if (!global[ns])
	            global[ns] = {};
	        root = global[ns];
	    }

	    if (!root.define || !root.define.packaged) {
	        define.original = root.define;
	        root.define = define;
	        root.define.packaged = true;
	    }

	    if (!root.acequire || !root.acequire.packaged) {
	        acequire.original = root.acequire;
	        root.acequire = acequire;
	        root.acequire.packaged = true;
	    }
	}

	exportAce(ACE_NAMESPACE);

	})();

	ace.define("ace/lib/regexp",["require","exports","module"], function(acequire, exports, module) {
	"use strict";

	    var real = {
	            exec: RegExp.prototype.exec,
	            test: RegExp.prototype.test,
	            match: String.prototype.match,
	            replace: String.prototype.replace,
	            split: String.prototype.split
	        },
	        compliantExecNpcg = real.exec.call(/()??/, "")[1] === undefined, // check `exec` handling of nonparticipating capturing groups
	        compliantLastIndexIncrement = function () {
	            var x = /^/g;
	            real.test.call(x, "");
	            return !x.lastIndex;
	        }();

	    if (compliantLastIndexIncrement && compliantExecNpcg)
	        return;
	    RegExp.prototype.exec = function (str) {
	        var match = real.exec.apply(this, arguments),
	            name, r2;
	        if ( typeof(str) == 'string' && match) {
	            if (!compliantExecNpcg && match.length > 1 && indexOf(match, "") > -1) {
	                r2 = RegExp(this.source, real.replace.call(getNativeFlags(this), "g", ""));
	                real.replace.call(str.slice(match.index), r2, function () {
	                    for (var i = 1; i < arguments.length - 2; i++) {
	                        if (arguments[i] === undefined)
	                            match[i] = undefined;
	                    }
	                });
	            }
	            if (this._xregexp && this._xregexp.captureNames) {
	                for (var i = 1; i < match.length; i++) {
	                    name = this._xregexp.captureNames[i - 1];
	                    if (name)
	                       match[name] = match[i];
	                }
	            }
	            if (!compliantLastIndexIncrement && this.global && !match[0].length && (this.lastIndex > match.index))
	                this.lastIndex--;
	        }
	        return match;
	    };
	    if (!compliantLastIndexIncrement) {
	        RegExp.prototype.test = function (str) {
	            var match = real.exec.call(this, str);
	            if (match && this.global && !match[0].length && (this.lastIndex > match.index))
	                this.lastIndex--;
	            return !!match;
	        };
	    }

	    function getNativeFlags (regex) {
	        return (regex.global     ? "g" : "") +
	               (regex.ignoreCase ? "i" : "") +
	               (regex.multiline  ? "m" : "") +
	               (regex.extended   ? "x" : "") + // Proposed for ES4; included in AS3
	               (regex.sticky     ? "y" : "");
	    }

	    function indexOf (array, item, from) {
	        if (Array.prototype.indexOf) // Use the native array method if available
	            return array.indexOf(item, from);
	        for (var i = from || 0; i < array.length; i++) {
	            if (array[i] === item)
	                return i;
	        }
	        return -1;
	    }

	});

	ace.define("ace/lib/es5-shim",["require","exports","module"], function(acequire, exports, module) {

	function Empty() {}

	if (!Function.prototype.bind) {
	    Function.prototype.bind = function bind(that) { // .length is 1
	        var target = this;
	        if (typeof target != "function") {
	            throw new TypeError("Function.prototype.bind called on incompatible " + target);
	        }
	        var args = slice.call(arguments, 1); // for normal call
	        var bound = function () {

	            if (this instanceof bound) {

	                var result = target.apply(
	                    this,
	                    args.concat(slice.call(arguments))
	                );
	                if (Object(result) === result) {
	                    return result;
	                }
	                return this;

	            } else {
	                return target.apply(
	                    that,
	                    args.concat(slice.call(arguments))
	                );

	            }

	        };
	        if(target.prototype) {
	            Empty.prototype = target.prototype;
	            bound.prototype = new Empty();
	            Empty.prototype = null;
	        }
	        return bound;
	    };
	}
	var call = Function.prototype.call;
	var prototypeOfArray = Array.prototype;
	var prototypeOfObject = Object.prototype;
	var slice = prototypeOfArray.slice;
	var _toString = call.bind(prototypeOfObject.toString);
	var owns = call.bind(prototypeOfObject.hasOwnProperty);
	var defineGetter;
	var defineSetter;
	var lookupGetter;
	var lookupSetter;
	var supportsAccessors;
	if ((supportsAccessors = owns(prototypeOfObject, "__defineGetter__"))) {
	    defineGetter = call.bind(prototypeOfObject.__defineGetter__);
	    defineSetter = call.bind(prototypeOfObject.__defineSetter__);
	    lookupGetter = call.bind(prototypeOfObject.__lookupGetter__);
	    lookupSetter = call.bind(prototypeOfObject.__lookupSetter__);
	}
	if ([1,2].splice(0).length != 2) {
	    if(function() { // test IE < 9 to splice bug - see issue #138
	        function makeArray(l) {
	            var a = new Array(l+2);
	            a[0] = a[1] = 0;
	            return a;
	        }
	        var array = [], lengthBefore;
	        
	        array.splice.apply(array, makeArray(20));
	        array.splice.apply(array, makeArray(26));

	        lengthBefore = array.length; //46
	        array.splice(5, 0, "XXX"); // add one element

	        lengthBefore + 1 == array.length

	        if (lengthBefore + 1 == array.length) {
	            return true;// has right splice implementation without bugs
	        }
	    }()) {//IE 6/7
	        var array_splice = Array.prototype.splice;
	        Array.prototype.splice = function(start, deleteCount) {
	            if (!arguments.length) {
	                return [];
	            } else {
	                return array_splice.apply(this, [
	                    start === void 0 ? 0 : start,
	                    deleteCount === void 0 ? (this.length - start) : deleteCount
	                ].concat(slice.call(arguments, 2)))
	            }
	        };
	    } else {//IE8
	        Array.prototype.splice = function(pos, removeCount){
	            var length = this.length;
	            if (pos > 0) {
	                if (pos > length)
	                    pos = length;
	            } else if (pos == void 0) {
	                pos = 0;
	            } else if (pos < 0) {
	                pos = Math.max(length + pos, 0);
	            }

	            if (!(pos+removeCount < length))
	                removeCount = length - pos;

	            var removed = this.slice(pos, pos+removeCount);
	            var insert = slice.call(arguments, 2);
	            var add = insert.length;            
	            if (pos === length) {
	                if (add) {
	                    this.push.apply(this, insert);
	                }
	            } else {
	                var remove = Math.min(removeCount, length - pos);
	                var tailOldPos = pos + remove;
	                var tailNewPos = tailOldPos + add - remove;
	                var tailCount = length - tailOldPos;
	                var lengthAfterRemove = length - remove;

	                if (tailNewPos < tailOldPos) { // case A
	                    for (var i = 0; i < tailCount; ++i) {
	                        this[tailNewPos+i] = this[tailOldPos+i];
	                    }
	                } else if (tailNewPos > tailOldPos) { // case B
	                    for (i = tailCount; i--; ) {
	                        this[tailNewPos+i] = this[tailOldPos+i];
	                    }
	                } // else, add == remove (nothing to do)

	                if (add && pos === lengthAfterRemove) {
	                    this.length = lengthAfterRemove; // truncate array
	                    this.push.apply(this, insert);
	                } else {
	                    this.length = lengthAfterRemove + add; // reserves space
	                    for (i = 0; i < add; ++i) {
	                        this[pos+i] = insert[i];
	                    }
	                }
	            }
	            return removed;
	        };
	    }
	}
	if (!Array.isArray) {
	    Array.isArray = function isArray(obj) {
	        return _toString(obj) == "[object Array]";
	    };
	}
	var boxedString = Object("a"),
	    splitString = boxedString[0] != "a" || !(0 in boxedString);

	if (!Array.prototype.forEach) {
	    Array.prototype.forEach = function forEach(fun /*, thisp*/) {
	        var object = toObject(this),
	            self = splitString && _toString(this) == "[object String]" ?
	                this.split("") :
	                object,
	            thisp = arguments[1],
	            i = -1,
	            length = self.length >>> 0;
	        if (_toString(fun) != "[object Function]") {
	            throw new TypeError(); // TODO message
	        }

	        while (++i < length) {
	            if (i in self) {
	                fun.call(thisp, self[i], i, object);
	            }
	        }
	    };
	}
	if (!Array.prototype.map) {
	    Array.prototype.map = function map(fun /*, thisp*/) {
	        var object = toObject(this),
	            self = splitString && _toString(this) == "[object String]" ?
	                this.split("") :
	                object,
	            length = self.length >>> 0,
	            result = Array(length),
	            thisp = arguments[1];
	        if (_toString(fun) != "[object Function]") {
	            throw new TypeError(fun + " is not a function");
	        }

	        for (var i = 0; i < length; i++) {
	            if (i in self)
	                result[i] = fun.call(thisp, self[i], i, object);
	        }
	        return result;
	    };
	}
	if (!Array.prototype.filter) {
	    Array.prototype.filter = function filter(fun /*, thisp */) {
	        var object = toObject(this),
	            self = splitString && _toString(this) == "[object String]" ?
	                this.split("") :
	                    object,
	            length = self.length >>> 0,
	            result = [],
	            value,
	            thisp = arguments[1];
	        if (_toString(fun) != "[object Function]") {
	            throw new TypeError(fun + " is not a function");
	        }

	        for (var i = 0; i < length; i++) {
	            if (i in self) {
	                value = self[i];
	                if (fun.call(thisp, value, i, object)) {
	                    result.push(value);
	                }
	            }
	        }
	        return result;
	    };
	}
	if (!Array.prototype.every) {
	    Array.prototype.every = function every(fun /*, thisp */) {
	        var object = toObject(this),
	            self = splitString && _toString(this) == "[object String]" ?
	                this.split("") :
	                object,
	            length = self.length >>> 0,
	            thisp = arguments[1];
	        if (_toString(fun) != "[object Function]") {
	            throw new TypeError(fun + " is not a function");
	        }

	        for (var i = 0; i < length; i++) {
	            if (i in self && !fun.call(thisp, self[i], i, object)) {
	                return false;
	            }
	        }
	        return true;
	    };
	}
	if (!Array.prototype.some) {
	    Array.prototype.some = function some(fun /*, thisp */) {
	        var object = toObject(this),
	            self = splitString && _toString(this) == "[object String]" ?
	                this.split("") :
	                object,
	            length = self.length >>> 0,
	            thisp = arguments[1];
	        if (_toString(fun) != "[object Function]") {
	            throw new TypeError(fun + " is not a function");
	        }

	        for (var i = 0; i < length; i++) {
	            if (i in self && fun.call(thisp, self[i], i, object)) {
	                return true;
	            }
	        }
	        return false;
	    };
	}
	if (!Array.prototype.reduce) {
	    Array.prototype.reduce = function reduce(fun /*, initial*/) {
	        var object = toObject(this),
	            self = splitString && _toString(this) == "[object String]" ?
	                this.split("") :
	                object,
	            length = self.length >>> 0;
	        if (_toString(fun) != "[object Function]") {
	            throw new TypeError(fun + " is not a function");
	        }
	        if (!length && arguments.length == 1) {
	            throw new TypeError("reduce of empty array with no initial value");
	        }

	        var i = 0;
	        var result;
	        if (arguments.length >= 2) {
	            result = arguments[1];
	        } else {
	            do {
	                if (i in self) {
	                    result = self[i++];
	                    break;
	                }
	                if (++i >= length) {
	                    throw new TypeError("reduce of empty array with no initial value");
	                }
	            } while (true);
	        }

	        for (; i < length; i++) {
	            if (i in self) {
	                result = fun.call(void 0, result, self[i], i, object);
	            }
	        }

	        return result;
	    };
	}
	if (!Array.prototype.reduceRight) {
	    Array.prototype.reduceRight = function reduceRight(fun /*, initial*/) {
	        var object = toObject(this),
	            self = splitString && _toString(this) == "[object String]" ?
	                this.split("") :
	                object,
	            length = self.length >>> 0;
	        if (_toString(fun) != "[object Function]") {
	            throw new TypeError(fun + " is not a function");
	        }
	        if (!length && arguments.length == 1) {
	            throw new TypeError("reduceRight of empty array with no initial value");
	        }

	        var result, i = length - 1;
	        if (arguments.length >= 2) {
	            result = arguments[1];
	        } else {
	            do {
	                if (i in self) {
	                    result = self[i--];
	                    break;
	                }
	                if (--i < 0) {
	                    throw new TypeError("reduceRight of empty array with no initial value");
	                }
	            } while (true);
	        }

	        do {
	            if (i in this) {
	                result = fun.call(void 0, result, self[i], i, object);
	            }
	        } while (i--);

	        return result;
	    };
	}
	if (!Array.prototype.indexOf || ([0, 1].indexOf(1, 2) != -1)) {
	    Array.prototype.indexOf = function indexOf(sought /*, fromIndex */ ) {
	        var self = splitString && _toString(this) == "[object String]" ?
	                this.split("") :
	                toObject(this),
	            length = self.length >>> 0;

	        if (!length) {
	            return -1;
	        }

	        var i = 0;
	        if (arguments.length > 1) {
	            i = toInteger(arguments[1]);
	        }
	        i = i >= 0 ? i : Math.max(0, length + i);
	        for (; i < length; i++) {
	            if (i in self && self[i] === sought) {
	                return i;
	            }
	        }
	        return -1;
	    };
	}
	if (!Array.prototype.lastIndexOf || ([0, 1].lastIndexOf(0, -3) != -1)) {
	    Array.prototype.lastIndexOf = function lastIndexOf(sought /*, fromIndex */) {
	        var self = splitString && _toString(this) == "[object String]" ?
	                this.split("") :
	                toObject(this),
	            length = self.length >>> 0;

	        if (!length) {
	            return -1;
	        }
	        var i = length - 1;
	        if (arguments.length > 1) {
	            i = Math.min(i, toInteger(arguments[1]));
	        }
	        i = i >= 0 ? i : length - Math.abs(i);
	        for (; i >= 0; i--) {
	            if (i in self && sought === self[i]) {
	                return i;
	            }
	        }
	        return -1;
	    };
	}
	if (!Object.getPrototypeOf) {
	    Object.getPrototypeOf = function getPrototypeOf(object) {
	        return object.__proto__ || (
	            object.constructor ?
	            object.constructor.prototype :
	            prototypeOfObject
	        );
	    };
	}
	if (!Object.getOwnPropertyDescriptor) {
	    var ERR_NON_OBJECT = "Object.getOwnPropertyDescriptor called on a " +
	                         "non-object: ";
	    Object.getOwnPropertyDescriptor = function getOwnPropertyDescriptor(object, property) {
	        if ((typeof object != "object" && typeof object != "function") || object === null)
	            throw new TypeError(ERR_NON_OBJECT + object);
	        if (!owns(object, property))
	            return;

	        var descriptor, getter, setter;
	        descriptor =  { enumerable: true, configurable: true };
	        if (supportsAccessors) {
	            var prototype = object.__proto__;
	            object.__proto__ = prototypeOfObject;

	            var getter = lookupGetter(object, property);
	            var setter = lookupSetter(object, property);
	            object.__proto__ = prototype;

	            if (getter || setter) {
	                if (getter) descriptor.get = getter;
	                if (setter) descriptor.set = setter;
	                return descriptor;
	            }
	        }
	        descriptor.value = object[property];
	        return descriptor;
	    };
	}
	if (!Object.getOwnPropertyNames) {
	    Object.getOwnPropertyNames = function getOwnPropertyNames(object) {
	        return Object.keys(object);
	    };
	}
	if (!Object.create) {
	    var createEmpty;
	    if (Object.prototype.__proto__ === null) {
	        createEmpty = function () {
	            return { "__proto__": null };
	        };
	    } else {
	        createEmpty = function () {
	            var empty = {};
	            for (var i in empty)
	                empty[i] = null;
	            empty.constructor =
	            empty.hasOwnProperty =
	            empty.propertyIsEnumerable =
	            empty.isPrototypeOf =
	            empty.toLocaleString =
	            empty.toString =
	            empty.valueOf =
	            empty.__proto__ = null;
	            return empty;
	        }
	    }

	    Object.create = function create(prototype, properties) {
	        var object;
	        if (prototype === null) {
	            object = createEmpty();
	        } else {
	            if (typeof prototype != "object")
	                throw new TypeError("typeof prototype["+(typeof prototype)+"] != 'object'");
	            var Type = function () {};
	            Type.prototype = prototype;
	            object = new Type();
	            object.__proto__ = prototype;
	        }
	        if (properties !== void 0)
	            Object.defineProperties(object, properties);
	        return object;
	    };
	}

	function doesDefinePropertyWork(object) {
	    try {
	        Object.defineProperty(object, "sentinel", {});
	        return "sentinel" in object;
	    } catch (exception) {
	    }
	}
	if (Object.defineProperty) {
	    var definePropertyWorksOnObject = doesDefinePropertyWork({});
	    var definePropertyWorksOnDom = typeof document == "undefined" ||
	        doesDefinePropertyWork(document.createElement("div"));
	    if (!definePropertyWorksOnObject || !definePropertyWorksOnDom) {
	        var definePropertyFallback = Object.defineProperty;
	    }
	}

	if (!Object.defineProperty || definePropertyFallback) {
	    var ERR_NON_OBJECT_DESCRIPTOR = "Property description must be an object: ";
	    var ERR_NON_OBJECT_TARGET = "Object.defineProperty called on non-object: "
	    var ERR_ACCESSORS_NOT_SUPPORTED = "getters & setters can not be defined " +
	                                      "on this javascript engine";

	    Object.defineProperty = function defineProperty(object, property, descriptor) {
	        if ((typeof object != "object" && typeof object != "function") || object === null)
	            throw new TypeError(ERR_NON_OBJECT_TARGET + object);
	        if ((typeof descriptor != "object" && typeof descriptor != "function") || descriptor === null)
	            throw new TypeError(ERR_NON_OBJECT_DESCRIPTOR + descriptor);
	        if (definePropertyFallback) {
	            try {
	                return definePropertyFallback.call(Object, object, property, descriptor);
	            } catch (exception) {
	            }
	        }
	        if (owns(descriptor, "value")) {

	            if (supportsAccessors && (lookupGetter(object, property) ||
	                                      lookupSetter(object, property)))
	            {
	                var prototype = object.__proto__;
	                object.__proto__ = prototypeOfObject;
	                delete object[property];
	                object[property] = descriptor.value;
	                object.__proto__ = prototype;
	            } else {
	                object[property] = descriptor.value;
	            }
	        } else {
	            if (!supportsAccessors)
	                throw new TypeError(ERR_ACCESSORS_NOT_SUPPORTED);
	            if (owns(descriptor, "get"))
	                defineGetter(object, property, descriptor.get);
	            if (owns(descriptor, "set"))
	                defineSetter(object, property, descriptor.set);
	        }

	        return object;
	    };
	}
	if (!Object.defineProperties) {
	    Object.defineProperties = function defineProperties(object, properties) {
	        for (var property in properties) {
	            if (owns(properties, property))
	                Object.defineProperty(object, property, properties[property]);
	        }
	        return object;
	    };
	}
	if (!Object.seal) {
	    Object.seal = function seal(object) {
	        return object;
	    };
	}
	if (!Object.freeze) {
	    Object.freeze = function freeze(object) {
	        return object;
	    };
	}
	try {
	    Object.freeze(function () {});
	} catch (exception) {
	    Object.freeze = (function freeze(freezeObject) {
	        return function freeze(object) {
	            if (typeof object == "function") {
	                return object;
	            } else {
	                return freezeObject(object);
	            }
	        };
	    })(Object.freeze);
	}
	if (!Object.preventExtensions) {
	    Object.preventExtensions = function preventExtensions(object) {
	        return object;
	    };
	}
	if (!Object.isSealed) {
	    Object.isSealed = function isSealed(object) {
	        return false;
	    };
	}
	if (!Object.isFrozen) {
	    Object.isFrozen = function isFrozen(object) {
	        return false;
	    };
	}
	if (!Object.isExtensible) {
	    Object.isExtensible = function isExtensible(object) {
	        if (Object(object) === object) {
	            throw new TypeError(); // TODO message
	        }
	        var name = '';
	        while (owns(object, name)) {
	            name += '?';
	        }
	        object[name] = true;
	        var returnValue = owns(object, name);
	        delete object[name];
	        return returnValue;
	    };
	}
	if (!Object.keys) {
	    var hasDontEnumBug = true,
	        dontEnums = [
	            "toString",
	            "toLocaleString",
	            "valueOf",
	            "hasOwnProperty",
	            "isPrototypeOf",
	            "propertyIsEnumerable",
	            "constructor"
	        ],
	        dontEnumsLength = dontEnums.length;

	    for (var key in {"toString": null}) {
	        hasDontEnumBug = false;
	    }

	    Object.keys = function keys(object) {

	        if (
	            (typeof object != "object" && typeof object != "function") ||
	            object === null
	        ) {
	            throw new TypeError("Object.keys called on a non-object");
	        }

	        var keys = [];
	        for (var name in object) {
	            if (owns(object, name)) {
	                keys.push(name);
	            }
	        }

	        if (hasDontEnumBug) {
	            for (var i = 0, ii = dontEnumsLength; i < ii; i++) {
	                var dontEnum = dontEnums[i];
	                if (owns(object, dontEnum)) {
	                    keys.push(dontEnum);
	                }
	            }
	        }
	        return keys;
	    };

	}
	if (!Date.now) {
	    Date.now = function now() {
	        return new Date().getTime();
	    };
	}
	var ws = "\x09\x0A\x0B\x0C\x0D\x20\xA0\u1680\u180E\u2000\u2001\u2002\u2003" +
	    "\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028" +
	    "\u2029\uFEFF";
	if (!String.prototype.trim || ws.trim()) {
	    ws = "[" + ws + "]";
	    var trimBeginRegexp = new RegExp("^" + ws + ws + "*"),
	        trimEndRegexp = new RegExp(ws + ws + "*$");
	    String.prototype.trim = function trim() {
	        return String(this).replace(trimBeginRegexp, "").replace(trimEndRegexp, "");
	    };
	}

	function toInteger(n) {
	    n = +n;
	    if (n !== n) { // isNaN
	        n = 0;
	    } else if (n !== 0 && n !== (1/0) && n !== -(1/0)) {
	        n = (n > 0 || -1) * Math.floor(Math.abs(n));
	    }
	    return n;
	}

	function isPrimitive(input) {
	    var type = typeof input;
	    return (
	        input === null ||
	        type === "undefined" ||
	        type === "boolean" ||
	        type === "number" ||
	        type === "string"
	    );
	}

	function toPrimitive(input) {
	    var val, valueOf, toString;
	    if (isPrimitive(input)) {
	        return input;
	    }
	    valueOf = input.valueOf;
	    if (typeof valueOf === "function") {
	        val = valueOf.call(input);
	        if (isPrimitive(val)) {
	            return val;
	        }
	    }
	    toString = input.toString;
	    if (typeof toString === "function") {
	        val = toString.call(input);
	        if (isPrimitive(val)) {
	            return val;
	        }
	    }
	    throw new TypeError();
	}
	var toObject = function (o) {
	    if (o == null) { // this matches both null and undefined
	        throw new TypeError("can't convert "+o+" to object");
	    }
	    return Object(o);
	};

	});

	ace.define("ace/lib/fixoldbrowsers",["require","exports","module","ace/lib/regexp","ace/lib/es5-shim"], function(acequire, exports, module) {
	"use strict";

	acequire("./regexp");
	acequire("./es5-shim");

	});

	ace.define("ace/lib/dom",["require","exports","module"], function(acequire, exports, module) {
	"use strict";

	var XHTML_NS = "http://www.w3.org/1999/xhtml";

	exports.getDocumentHead = function(doc) {
	    if (!doc)
	        doc = document;
	    return doc.head || doc.getElementsByTagName("head")[0] || doc.documentElement;
	}

	exports.createElement = function(tag, ns) {
	    return document.createElementNS ?
	           document.createElementNS(ns || XHTML_NS, tag) :
	           document.createElement(tag);
	};

	exports.hasCssClass = function(el, name) {
	    var classes = (el.className + "").split(/\s+/g);
	    return classes.indexOf(name) !== -1;
	};
	exports.addCssClass = function(el, name) {
	    if (!exports.hasCssClass(el, name)) {
	        el.className += " " + name;
	    }
	};
	exports.removeCssClass = function(el, name) {
	    var classes = el.className.split(/\s+/g);
	    while (true) {
	        var index = classes.indexOf(name);
	        if (index == -1) {
	            break;
	        }
	        classes.splice(index, 1);
	    }
	    el.className = classes.join(" ");
	};

	exports.toggleCssClass = function(el, name) {
	    var classes = el.className.split(/\s+/g), add = true;
	    while (true) {
	        var index = classes.indexOf(name);
	        if (index == -1) {
	            break;
	        }
	        add = false;
	        classes.splice(index, 1);
	    }
	    if (add)
	        classes.push(name);

	    el.className = classes.join(" ");
	    return add;
	};
	exports.setCssClass = function(node, className, include) {
	    if (include) {
	        exports.addCssClass(node, className);
	    } else {
	        exports.removeCssClass(node, className);
	    }
	};

	exports.hasCssString = function(id, doc) {
	    var index = 0, sheets;
	    doc = doc || document;

	    if (doc.createStyleSheet && (sheets = doc.styleSheets)) {
	        while (index < sheets.length)
	            if (sheets[index++].owningElement.id === id) return true;
	    } else if ((sheets = doc.getElementsByTagName("style"))) {
	        while (index < sheets.length)
	            if (sheets[index++].id === id) return true;
	    }

	    return false;
	};

	exports.importCssString = function importCssString(cssText, id, doc) {
	    doc = doc || document;
	    if (id && exports.hasCssString(id, doc))
	        return null;
	    
	    var style;
	    
	    if (id)
	        cssText += "\n/*# sourceURL=ace/css/" + id + " */";
	    
	    if (doc.createStyleSheet) {
	        style = doc.createStyleSheet();
	        style.cssText = cssText;
	        if (id)
	            style.owningElement.id = id;
	    } else {
	        style = exports.createElement("style");
	        style.appendChild(doc.createTextNode(cssText));
	        if (id)
	            style.id = id;

	        exports.getDocumentHead(doc).appendChild(style);
	    }
	};

	exports.importCssStylsheet = function(uri, doc) {
	    if (doc.createStyleSheet) {
	        doc.createStyleSheet(uri);
	    } else {
	        var link = exports.createElement('link');
	        link.rel = 'stylesheet';
	        link.href = uri;

	        exports.getDocumentHead(doc).appendChild(link);
	    }
	};

	exports.getInnerWidth = function(element) {
	    return (
	        parseInt(exports.computedStyle(element, "paddingLeft"), 10) +
	        parseInt(exports.computedStyle(element, "paddingRight"), 10) + 
	        element.clientWidth
	    );
	};

	exports.getInnerHeight = function(element) {
	    return (
	        parseInt(exports.computedStyle(element, "paddingTop"), 10) +
	        parseInt(exports.computedStyle(element, "paddingBottom"), 10) +
	        element.clientHeight
	    );
	};

	exports.scrollbarWidth = function(document) {
	    var inner = exports.createElement("ace_inner");
	    inner.style.width = "100%";
	    inner.style.minWidth = "0px";
	    inner.style.height = "200px";
	    inner.style.display = "block";

	    var outer = exports.createElement("ace_outer");
	    var style = outer.style;

	    style.position = "absolute";
	    style.left = "-10000px";
	    style.overflow = "hidden";
	    style.width = "200px";
	    style.minWidth = "0px";
	    style.height = "150px";
	    style.display = "block";

	    outer.appendChild(inner);

	    var body = document.documentElement;
	    body.appendChild(outer);

	    var noScrollbar = inner.offsetWidth;

	    style.overflow = "scroll";
	    var withScrollbar = inner.offsetWidth;

	    if (noScrollbar == withScrollbar) {
	        withScrollbar = outer.clientWidth;
	    }

	    body.removeChild(outer);

	    return noScrollbar-withScrollbar;
	};

	if (typeof document == "undefined") {
	    exports.importCssString = function() {};
	    return;
	}

	if (window.pageYOffset !== undefined) {
	    exports.getPageScrollTop = function() {
	        return window.pageYOffset;
	    };

	    exports.getPageScrollLeft = function() {
	        return window.pageXOffset;
	    };
	}
	else {
	    exports.getPageScrollTop = function() {
	        return document.body.scrollTop;
	    };

	    exports.getPageScrollLeft = function() {
	        return document.body.scrollLeft;
	    };
	}

	if (window.getComputedStyle)
	    exports.computedStyle = function(element, style) {
	        if (style)
	            return (window.getComputedStyle(element, "") || {})[style] || "";
	        return window.getComputedStyle(element, "") || {};
	    };
	else
	    exports.computedStyle = function(element, style) {
	        if (style)
	            return element.currentStyle[style];
	        return element.currentStyle;
	    };
	exports.setInnerHtml = function(el, innerHtml) {
	    var element = el.cloneNode(false);//document.createElement("div");
	    element.innerHTML = innerHtml;
	    el.parentNode.replaceChild(element, el);
	    return element;
	};

	if ("textContent" in document.documentElement) {
	    exports.setInnerText = function(el, innerText) {
	        el.textContent = innerText;
	    };

	    exports.getInnerText = function(el) {
	        return el.textContent;
	    };
	}
	else {
	    exports.setInnerText = function(el, innerText) {
	        el.innerText = innerText;
	    };

	    exports.getInnerText = function(el) {
	        return el.innerText;
	    };
	}

	exports.getParentWindow = function(document) {
	    return document.defaultView || document.parentWindow;
	};

	});

	ace.define("ace/lib/oop",["require","exports","module"], function(acequire, exports, module) {
	"use strict";

	exports.inherits = function(ctor, superCtor) {
	    ctor.super_ = superCtor;
	    ctor.prototype = Object.create(superCtor.prototype, {
	        constructor: {
	            value: ctor,
	            enumerable: false,
	            writable: true,
	            configurable: true
	        }
	    });
	};

	exports.mixin = function(obj, mixin) {
	    for (var key in mixin) {
	        obj[key] = mixin[key];
	    }
	    return obj;
	};

	exports.implement = function(proto, mixin) {
	    exports.mixin(proto, mixin);
	};

	});

	ace.define("ace/lib/keys",["require","exports","module","ace/lib/fixoldbrowsers","ace/lib/oop"], function(acequire, exports, module) {
	"use strict";

	acequire("./fixoldbrowsers");

	var oop = acequire("./oop");
	var Keys = (function() {
	    var ret = {
	        MODIFIER_KEYS: {
	            16: 'Shift', 17: 'Ctrl', 18: 'Alt', 224: 'Meta'
	        },

	        KEY_MODS: {
	            "ctrl": 1, "alt": 2, "option" : 2, "shift": 4,
	            "super": 8, "meta": 8, "command": 8, "cmd": 8
	        },

	        FUNCTION_KEYS : {
	            8  : "Backspace",
	            9  : "Tab",
	            13 : "Return",
	            19 : "Pause",
	            27 : "Esc",
	            32 : "Space",
	            33 : "PageUp",
	            34 : "PageDown",
	            35 : "End",
	            36 : "Home",
	            37 : "Left",
	            38 : "Up",
	            39 : "Right",
	            40 : "Down",
	            44 : "Print",
	            45 : "Insert",
	            46 : "Delete",
	            96 : "Numpad0",
	            97 : "Numpad1",
	            98 : "Numpad2",
	            99 : "Numpad3",
	            100: "Numpad4",
	            101: "Numpad5",
	            102: "Numpad6",
	            103: "Numpad7",
	            104: "Numpad8",
	            105: "Numpad9",
	            '-13': "NumpadEnter",
	            112: "F1",
	            113: "F2",
	            114: "F3",
	            115: "F4",
	            116: "F5",
	            117: "F6",
	            118: "F7",
	            119: "F8",
	            120: "F9",
	            121: "F10",
	            122: "F11",
	            123: "F12",
	            144: "Numlock",
	            145: "Scrolllock"
	        },

	        PRINTABLE_KEYS: {
	           32: ' ',  48: '0',  49: '1',  50: '2',  51: '3',  52: '4', 53:  '5',
	           54: '6',  55: '7',  56: '8',  57: '9',  59: ';',  61: '=', 65:  'a',
	           66: 'b',  67: 'c',  68: 'd',  69: 'e',  70: 'f',  71: 'g', 72:  'h',
	           73: 'i',  74: 'j',  75: 'k',  76: 'l',  77: 'm',  78: 'n', 79:  'o',
	           80: 'p',  81: 'q',  82: 'r',  83: 's',  84: 't',  85: 'u', 86:  'v',
	           87: 'w',  88: 'x',  89: 'y',  90: 'z', 107: '+', 109: '-', 110: '.',
	          186: ';', 187: '=', 188: ',', 189: '-', 190: '.', 191: '/', 192: '`',
	          219: '[', 220: '\\',221: ']', 222: "'", 111: '/', 106: '*'
	        }
	    };
	    var name, i;
	    for (i in ret.FUNCTION_KEYS) {
	        name = ret.FUNCTION_KEYS[i].toLowerCase();
	        ret[name] = parseInt(i, 10);
	    }
	    for (i in ret.PRINTABLE_KEYS) {
	        name = ret.PRINTABLE_KEYS[i].toLowerCase();
	        ret[name] = parseInt(i, 10);
	    }
	    oop.mixin(ret, ret.MODIFIER_KEYS);
	    oop.mixin(ret, ret.PRINTABLE_KEYS);
	    oop.mixin(ret, ret.FUNCTION_KEYS);
	    ret.enter = ret["return"];
	    ret.escape = ret.esc;
	    ret.del = ret["delete"];
	    ret[173] = '-';
	    
	    (function() {
	        var mods = ["cmd", "ctrl", "alt", "shift"];
	        for (var i = Math.pow(2, mods.length); i--;) {            
	            ret.KEY_MODS[i] = mods.filter(function(x) {
	                return i & ret.KEY_MODS[x];
	            }).join("-") + "-";
	        }
	    })();

	    ret.KEY_MODS[0] = "";
	    ret.KEY_MODS[-1] = "input-";

	    return ret;
	})();
	oop.mixin(exports, Keys);

	exports.keyCodeToString = function(keyCode) {
	    var keyString = Keys[keyCode];
	    if (typeof keyString != "string")
	        keyString = String.fromCharCode(keyCode);
	    return keyString.toLowerCase();
	};

	});

	ace.define("ace/lib/useragent",["require","exports","module"], function(acequire, exports, module) {
	"use strict";
	exports.OS = {
	    LINUX: "LINUX",
	    MAC: "MAC",
	    WINDOWS: "WINDOWS"
	};
	exports.getOS = function() {
	    if (exports.isMac) {
	        return exports.OS.MAC;
	    } else if (exports.isLinux) {
	        return exports.OS.LINUX;
	    } else {
	        return exports.OS.WINDOWS;
	    }
	};
	if (typeof navigator != "object")
	    return;

	var os = (navigator.platform.match(/mac|win|linux/i) || ["other"])[0].toLowerCase();
	var ua = navigator.userAgent;
	exports.isWin = (os == "win");
	exports.isMac = (os == "mac");
	exports.isLinux = (os == "linux");
	exports.isIE = 
	    (navigator.appName == "Microsoft Internet Explorer" || navigator.appName.indexOf("MSAppHost") >= 0)
	    ? parseFloat((ua.match(/(?:MSIE |Trident\/[0-9]+[\.0-9]+;.*rv:)([0-9]+[\.0-9]+)/)||[])[1])
	    : parseFloat((ua.match(/(?:Trident\/[0-9]+[\.0-9]+;.*rv:)([0-9]+[\.0-9]+)/)||[])[1]); // for ie
	    
	exports.isOldIE = exports.isIE && exports.isIE < 9;
	exports.isGecko = exports.isMozilla = (window.Controllers || window.controllers) && window.navigator.product === "Gecko";
	exports.isOldGecko = exports.isGecko && parseInt((ua.match(/rv:(\d+)/)||[])[1], 10) < 4;
	exports.isOpera = window.opera && Object.prototype.toString.call(window.opera) == "[object Opera]";
	exports.isWebKit = parseFloat(ua.split("WebKit/")[1]) || undefined;

	exports.isChrome = parseFloat(ua.split(" Chrome/")[1]) || undefined;

	exports.isAIR = ua.indexOf("AdobeAIR") >= 0;

	exports.isIPad = ua.indexOf("iPad") >= 0;

	exports.isTouchPad = ua.indexOf("TouchPad") >= 0;

	exports.isChromeOS = ua.indexOf(" CrOS ") >= 0;

	});

	ace.define("ace/lib/event",["require","exports","module","ace/lib/keys","ace/lib/useragent"], function(acequire, exports, module) {
	"use strict";

	var keys = acequire("./keys");
	var useragent = acequire("./useragent");

	var pressedKeys = null;
	var ts = 0;

	exports.addListener = function(elem, type, callback) {
	    if (elem.addEventListener) {
	        return elem.addEventListener(type, callback, false);
	    }
	    if (elem.attachEvent) {
	        var wrapper = function() {
	            callback.call(elem, window.event);
	        };
	        callback._wrapper = wrapper;
	        elem.attachEvent("on" + type, wrapper);
	    }
	};

	exports.removeListener = function(elem, type, callback) {
	    if (elem.removeEventListener) {
	        return elem.removeEventListener(type, callback, false);
	    }
	    if (elem.detachEvent) {
	        elem.detachEvent("on" + type, callback._wrapper || callback);
	    }
	};
	exports.stopEvent = function(e) {
	    exports.stopPropagation(e);
	    exports.preventDefault(e);
	    return false;
	};

	exports.stopPropagation = function(e) {
	    if (e.stopPropagation)
	        e.stopPropagation();
	    else
	        e.cancelBubble = true;
	};

	exports.preventDefault = function(e) {
	    if (e.preventDefault)
	        e.preventDefault();
	    else
	        e.returnValue = false;
	};
	exports.getButton = function(e) {
	    if (e.type == "dblclick")
	        return 0;
	    if (e.type == "contextmenu" || (useragent.isMac && (e.ctrlKey && !e.altKey && !e.shiftKey)))
	        return 2;
	    if (e.preventDefault) {
	        return e.button;
	    }
	    else {
	        return {1:0, 2:2, 4:1}[e.button];
	    }
	};

	exports.capture = function(el, eventHandler, releaseCaptureHandler) {
	    function onMouseUp(e) {
	        eventHandler && eventHandler(e);
	        releaseCaptureHandler && releaseCaptureHandler(e);

	        exports.removeListener(document, "mousemove", eventHandler, true);
	        exports.removeListener(document, "mouseup", onMouseUp, true);
	        exports.removeListener(document, "dragstart", onMouseUp, true);
	    }

	    exports.addListener(document, "mousemove", eventHandler, true);
	    exports.addListener(document, "mouseup", onMouseUp, true);
	    exports.addListener(document, "dragstart", onMouseUp, true);
	    
	    return onMouseUp;
	};

	exports.addTouchMoveListener = function (el, callback) {
	    if ("ontouchmove" in el) {
	        var startx, starty;
	        exports.addListener(el, "touchstart", function (e) {
	            var touchObj = e.changedTouches[0];
	            startx = touchObj.clientX;
	            starty = touchObj.clientY;
	        });
	        exports.addListener(el, "touchmove", function (e) {
	            var factor = 1,
	            touchObj = e.changedTouches[0];

	            e.wheelX = -(touchObj.clientX - startx) / factor;
	            e.wheelY = -(touchObj.clientY - starty) / factor;

	            startx = touchObj.clientX;
	            starty = touchObj.clientY;

	            callback(e);
	        });
	    } 
	};

	exports.addMouseWheelListener = function(el, callback) {
	    if ("onmousewheel" in el) {
	        exports.addListener(el, "mousewheel", function(e) {
	            var factor = 8;
	            if (e.wheelDeltaX !== undefined) {
	                e.wheelX = -e.wheelDeltaX / factor;
	                e.wheelY = -e.wheelDeltaY / factor;
	            } else {
	                e.wheelX = 0;
	                e.wheelY = -e.wheelDelta / factor;
	            }
	            callback(e);
	        });
	    } else if ("onwheel" in el) {
	        exports.addListener(el, "wheel",  function(e) {
	            var factor = 0.35;
	            switch (e.deltaMode) {
	                case e.DOM_DELTA_PIXEL:
	                    e.wheelX = e.deltaX * factor || 0;
	                    e.wheelY = e.deltaY * factor || 0;
	                    break;
	                case e.DOM_DELTA_LINE:
	                case e.DOM_DELTA_PAGE:
	                    e.wheelX = (e.deltaX || 0) * 5;
	                    e.wheelY = (e.deltaY || 0) * 5;
	                    break;
	            }
	            
	            callback(e);
	        });
	    } else {
	        exports.addListener(el, "DOMMouseScroll", function(e) {
	            if (e.axis && e.axis == e.HORIZONTAL_AXIS) {
	                e.wheelX = (e.detail || 0) * 5;
	                e.wheelY = 0;
	            } else {
	                e.wheelX = 0;
	                e.wheelY = (e.detail || 0) * 5;
	            }
	            callback(e);
	        });
	    }
	};

	exports.addMultiMouseDownListener = function(elements, timeouts, eventHandler, callbackName) {
	    var clicks = 0;
	    var startX, startY, timer; 
	    var eventNames = {
	        2: "dblclick",
	        3: "tripleclick",
	        4: "quadclick"
	    };

	    function onMousedown(e) {
	        if (exports.getButton(e) !== 0) {
	            clicks = 0;
	        } else if (e.detail > 1) {
	            clicks++;
	            if (clicks > 4)
	                clicks = 1;
	        } else {
	            clicks = 1;
	        }
	        if (useragent.isIE) {
	            var isNewClick = Math.abs(e.clientX - startX) > 5 || Math.abs(e.clientY - startY) > 5;
	            if (!timer || isNewClick)
	                clicks = 1;
	            if (timer)
	                clearTimeout(timer);
	            timer = setTimeout(function() {timer = null}, timeouts[clicks - 1] || 600);

	            if (clicks == 1) {
	                startX = e.clientX;
	                startY = e.clientY;
	            }
	        }
	        
	        e._clicks = clicks;

	        eventHandler[callbackName]("mousedown", e);

	        if (clicks > 4)
	            clicks = 0;
	        else if (clicks > 1)
	            return eventHandler[callbackName](eventNames[clicks], e);
	    }
	    function onDblclick(e) {
	        clicks = 2;
	        if (timer)
	            clearTimeout(timer);
	        timer = setTimeout(function() {timer = null}, timeouts[clicks - 1] || 600);
	        eventHandler[callbackName]("mousedown", e);
	        eventHandler[callbackName](eventNames[clicks], e);
	    }
	    if (!Array.isArray(elements))
	        elements = [elements];
	    elements.forEach(function(el) {
	        exports.addListener(el, "mousedown", onMousedown);
	        if (useragent.isOldIE)
	            exports.addListener(el, "dblclick", onDblclick);
	    });
	};

	var getModifierHash = useragent.isMac && useragent.isOpera && !("KeyboardEvent" in window)
	    ? function(e) {
	        return 0 | (e.metaKey ? 1 : 0) | (e.altKey ? 2 : 0) | (e.shiftKey ? 4 : 0) | (e.ctrlKey ? 8 : 0);
	    }
	    : function(e) {
	        return 0 | (e.ctrlKey ? 1 : 0) | (e.altKey ? 2 : 0) | (e.shiftKey ? 4 : 0) | (e.metaKey ? 8 : 0);
	    };

	exports.getModifierString = function(e) {
	    return keys.KEY_MODS[getModifierHash(e)];
	};

	function normalizeCommandKeys(callback, e, keyCode) {
	    var hashId = getModifierHash(e);

	    if (!useragent.isMac && pressedKeys) {
	        if (e.getModifierState && (e.getModifierState("OS") || e.getModifierState("Win")))
	            hashId |= 8;
	        if (pressedKeys.altGr) {
	            if ((3 & hashId) != 3)
	                pressedKeys.altGr = 0;
	            else
	                return;
	        }
	        if (keyCode === 18 || keyCode === 17) {
	            var location = "location" in e ? e.location : e.keyLocation;
	            if (keyCode === 17 && location === 1) {
	                if (pressedKeys[keyCode] == 1)
	                    ts = e.timeStamp;
	            } else if (keyCode === 18 && hashId === 3 && location === 2) {
	                var dt = e.timeStamp - ts;
	                if (dt < 50)
	                    pressedKeys.altGr = true;
	            }
	        }
	    }
	    
	    if (keyCode in keys.MODIFIER_KEYS) {
	        keyCode = -1;
	    }
	    if (hashId & 8 && (keyCode >= 91 && keyCode <= 93)) {
	        keyCode = -1;
	    }
	    
	    if (!hashId && keyCode === 13) {
	        var location = "location" in e ? e.location : e.keyLocation;
	        if (location === 3) {
	            callback(e, hashId, -keyCode);
	            if (e.defaultPrevented)
	                return;
	        }
	    }
	    
	    if (useragent.isChromeOS && hashId & 8) {
	        callback(e, hashId, keyCode);
	        if (e.defaultPrevented)
	            return;
	        else
	            hashId &= ~8;
	    }
	    if (!hashId && !(keyCode in keys.FUNCTION_KEYS) && !(keyCode in keys.PRINTABLE_KEYS)) {
	        return false;
	    }
	    
	    return callback(e, hashId, keyCode);
	}


	exports.addCommandKeyListener = function(el, callback) {
	    var addListener = exports.addListener;
	    if (useragent.isOldGecko || (useragent.isOpera && !("KeyboardEvent" in window))) {
	        var lastKeyDownKeyCode = null;
	        addListener(el, "keydown", function(e) {
	            lastKeyDownKeyCode = e.keyCode;
	        });
	        addListener(el, "keypress", function(e) {
	            return normalizeCommandKeys(callback, e, lastKeyDownKeyCode);
	        });
	    } else {
	        var lastDefaultPrevented = null;

	        addListener(el, "keydown", function(e) {
	            pressedKeys[e.keyCode] = (pressedKeys[e.keyCode] || 0) + 1;
	            var result = normalizeCommandKeys(callback, e, e.keyCode);
	            lastDefaultPrevented = e.defaultPrevented;
	            return result;
	        });

	        addListener(el, "keypress", function(e) {
	            if (lastDefaultPrevented && (e.ctrlKey || e.altKey || e.shiftKey || e.metaKey)) {
	                exports.stopEvent(e);
	                lastDefaultPrevented = null;
	            }
	        });

	        addListener(el, "keyup", function(e) {
	            pressedKeys[e.keyCode] = null;
	        });

	        if (!pressedKeys) {
	            resetPressedKeys();
	            addListener(window, "focus", resetPressedKeys);
	        }
	    }
	};
	function resetPressedKeys() {
	    pressedKeys = Object.create(null);
	}

	if (typeof window == "object" && window.postMessage && !useragent.isOldIE) {
	    var postMessageId = 1;
	    exports.nextTick = function(callback, win) {
	        win = win || window;
	        var messageName = "zero-timeout-message-" + postMessageId;
	        exports.addListener(win, "message", function listener(e) {
	            if (e.data == messageName) {
	                exports.stopPropagation(e);
	                exports.removeListener(win, "message", listener);
	                callback();
	            }
	        });
	        win.postMessage(messageName, "*");
	    };
	}


	exports.nextFrame = typeof window == "object" && (window.requestAnimationFrame
	    || window.mozRequestAnimationFrame
	    || window.webkitRequestAnimationFrame
	    || window.msRequestAnimationFrame
	    || window.oRequestAnimationFrame);

	if (exports.nextFrame)
	    exports.nextFrame = exports.nextFrame.bind(window);
	else
	    exports.nextFrame = function(callback) {
	        setTimeout(callback, 17);
	    };
	});

	ace.define("ace/lib/lang",["require","exports","module"], function(acequire, exports, module) {
	"use strict";

	exports.last = function(a) {
	    return a[a.length - 1];
	};

	exports.stringReverse = function(string) {
	    return string.split("").reverse().join("");
	};

	exports.stringRepeat = function (string, count) {
	    var result = '';
	    while (count > 0) {
	        if (count & 1)
	            result += string;

	        if (count >>= 1)
	            string += string;
	    }
	    return result;
	};

	var trimBeginRegexp = /^\s\s*/;
	var trimEndRegexp = /\s\s*$/;

	exports.stringTrimLeft = function (string) {
	    return string.replace(trimBeginRegexp, '');
	};

	exports.stringTrimRight = function (string) {
	    return string.replace(trimEndRegexp, '');
	};

	exports.copyObject = function(obj) {
	    var copy = {};
	    for (var key in obj) {
	        copy[key] = obj[key];
	    }
	    return copy;
	};

	exports.copyArray = function(array){
	    var copy = [];
	    for (var i=0, l=array.length; i<l; i++) {
	        if (array[i] && typeof array[i] == "object")
	            copy[i] = this.copyObject(array[i]);
	        else 
	            copy[i] = array[i];
	    }
	    return copy;
	};

	exports.deepCopy = function deepCopy(obj) {
	    if (typeof obj !== "object" || !obj)
	        return obj;
	    var copy;
	    if (Array.isArray(obj)) {
	        copy = [];
	        for (var key = 0; key < obj.length; key++) {
	            copy[key] = deepCopy(obj[key]);
	        }
	        return copy;
	    }
	    if (Object.prototype.toString.call(obj) !== "[object Object]")
	        return obj;
	    
	    copy = {};
	    for (var key in obj)
	        copy[key] = deepCopy(obj[key]);
	    return copy;
	};

	exports.arrayToMap = function(arr) {
	    var map = {};
	    for (var i=0; i<arr.length; i++) {
	        map[arr[i]] = 1;
	    }
	    return map;

	};

	exports.createMap = function(props) {
	    var map = Object.create(null);
	    for (var i in props) {
	        map[i] = props[i];
	    }
	    return map;
	};
	exports.arrayRemove = function(array, value) {
	  for (var i = 0; i <= array.length; i++) {
	    if (value === array[i]) {
	      array.splice(i, 1);
	    }
	  }
	};

	exports.escapeRegExp = function(str) {
	    return str.replace(/([.*+?^${}()|[\]\/\\])/g, '\\$1');
	};

	exports.escapeHTML = function(str) {
	    return str.replace(/&/g, "&#38;").replace(/"/g, "&#34;").replace(/'/g, "&#39;").replace(/</g, "&#60;");
	};

	exports.getMatchOffsets = function(string, regExp) {
	    var matches = [];

	    string.replace(regExp, function(str) {
	        matches.push({
	            offset: arguments[arguments.length-2],
	            length: str.length
	        });
	    });

	    return matches;
	};
	exports.deferredCall = function(fcn) {
	    var timer = null;
	    var callback = function() {
	        timer = null;
	        fcn();
	    };

	    var deferred = function(timeout) {
	        deferred.cancel();
	        timer = setTimeout(callback, timeout || 0);
	        return deferred;
	    };

	    deferred.schedule = deferred;

	    deferred.call = function() {
	        this.cancel();
	        fcn();
	        return deferred;
	    };

	    deferred.cancel = function() {
	        clearTimeout(timer);
	        timer = null;
	        return deferred;
	    };
	    
	    deferred.isPending = function() {
	        return timer;
	    };

	    return deferred;
	};


	exports.delayedCall = function(fcn, defaultTimeout) {
	    var timer = null;
	    var callback = function() {
	        timer = null;
	        fcn();
	    };

	    var _self = function(timeout) {
	        if (timer == null)
	            timer = setTimeout(callback, timeout || defaultTimeout);
	    };

	    _self.delay = function(timeout) {
	        timer && clearTimeout(timer);
	        timer = setTimeout(callback, timeout || defaultTimeout);
	    };
	    _self.schedule = _self;

	    _self.call = function() {
	        this.cancel();
	        fcn();
	    };

	    _self.cancel = function() {
	        timer && clearTimeout(timer);
	        timer = null;
	    };

	    _self.isPending = function() {
	        return timer;
	    };

	    return _self;
	};
	});

	ace.define("ace/keyboard/textinput",["require","exports","module","ace/lib/event","ace/lib/useragent","ace/lib/dom","ace/lib/lang"], function(acequire, exports, module) {
	"use strict";

	var event = acequire("../lib/event");
	var useragent = acequire("../lib/useragent");
	var dom = acequire("../lib/dom");
	var lang = acequire("../lib/lang");
	var BROKEN_SETDATA = useragent.isChrome < 18;
	var USE_IE_MIME_TYPE =  useragent.isIE;

	var TextInput = function(parentNode, host) {
	    var text = dom.createElement("textarea");
	    text.className = "ace_text-input";

	    if (useragent.isTouchPad)
	        text.setAttribute("x-palm-disable-auto-cap", true);

	    text.setAttribute("wrap", "off");
	    text.setAttribute("autocorrect", "off");
	    text.setAttribute("autocapitalize", "off");
	    text.setAttribute("spellcheck", false);

	    text.style.opacity = "0";
	    if (useragent.isOldIE) text.style.top = "-1000px";
	    parentNode.insertBefore(text, parentNode.firstChild);

	    var PLACEHOLDER = "\x01\x01";

	    var copied = false;
	    var pasted = false;
	    var inComposition = false;
	    var tempStyle = '';
	    var isSelectionEmpty = true;
	    try { var isFocused = document.activeElement === text; } catch(e) {}
	    
	    event.addListener(text, "blur", function(e) {
	        host.onBlur(e);
	        isFocused = false;
	    });
	    event.addListener(text, "focus", function(e) {
	        isFocused = true;
	        host.onFocus(e);
	        resetSelection();
	    });
	    this.focus = function() {
	        if (tempStyle) return text.focus();
	        var top = text.style.top;
	        text.style.position = "fixed";
	        text.style.top = "0px";
	        text.focus();
	        setTimeout(function() {
	            text.style.position = "";
	            if (text.style.top == "0px")
	                text.style.top = top;
	        }, 0);
	    };
	    this.blur = function() {
	        text.blur();
	    };
	    this.isFocused = function() {
	        return isFocused;
	    };
	    var syncSelection = lang.delayedCall(function() {
	        isFocused && resetSelection(isSelectionEmpty);
	    });
	    var syncValue = lang.delayedCall(function() {
	         if (!inComposition) {
	            text.value = PLACEHOLDER;
	            isFocused && resetSelection();
	         }
	    });

	    function resetSelection(isEmpty) {
	        if (inComposition)
	            return;
	        inComposition = true;
	        
	        if (inputHandler) {
	            selectionStart = 0;
	            selectionEnd = isEmpty ? 0 : text.value.length - 1;
	        } else {
	            var selectionStart = isEmpty ? 2 : 1;
	            var selectionEnd = 2;
	        }
	        try {
	            text.setSelectionRange(selectionStart, selectionEnd);
	        } catch(e){}
	        
	        inComposition = false;
	    }

	    function resetValue() {
	        if (inComposition)
	            return;
	        text.value = PLACEHOLDER;
	        if (useragent.isWebKit)
	            syncValue.schedule();
	    }

	    useragent.isWebKit || host.addEventListener('changeSelection', function() {
	        if (host.selection.isEmpty() != isSelectionEmpty) {
	            isSelectionEmpty = !isSelectionEmpty;
	            syncSelection.schedule();
	        }
	    });

	    resetValue();
	    if (isFocused)
	        host.onFocus();


	    var isAllSelected = function(text) {
	        return text.selectionStart === 0 && text.selectionEnd === text.value.length;
	    };
	    if (!text.setSelectionRange && text.createTextRange) {
	        text.setSelectionRange = function(selectionStart, selectionEnd) {
	            var range = this.createTextRange();
	            range.collapse(true);
	            range.moveStart('character', selectionStart);
	            range.moveEnd('character', selectionEnd);
	            range.select();
	        };
	        isAllSelected = function(text) {
	            try {
	                var range = text.ownerDocument.selection.createRange();
	            }catch(e) {}
	            if (!range || range.parentElement() != text) return false;
	                return range.text == text.value;
	        }
	    }
	    if (useragent.isOldIE) {
	        var inPropertyChange = false;
	        var onPropertyChange = function(e){
	            if (inPropertyChange)
	                return;
	            var data = text.value;
	            if (inComposition || !data || data == PLACEHOLDER)
	                return;
	            if (e && data == PLACEHOLDER[0])
	                return syncProperty.schedule();

	            sendText(data);
	            inPropertyChange = true;
	            resetValue();
	            inPropertyChange = false;
	        };
	        var syncProperty = lang.delayedCall(onPropertyChange);
	        event.addListener(text, "propertychange", onPropertyChange);

	        var keytable = { 13:1, 27:1 };
	        event.addListener(text, "keyup", function (e) {
	            if (inComposition && (!text.value || keytable[e.keyCode]))
	                setTimeout(onCompositionEnd, 0);
	            if ((text.value.charCodeAt(0)||0) < 129) {
	                return syncProperty.call();
	            }
	            inComposition ? onCompositionUpdate() : onCompositionStart();
	        });
	        event.addListener(text, "keydown", function (e) {
	            syncProperty.schedule(50);
	        });
	    }

	    var onSelect = function(e) {
	        if (copied) {
	            copied = false;
	        } else if (isAllSelected(text)) {
	            host.selectAll();
	            resetSelection();
	        } else if (inputHandler) {
	            resetSelection(host.selection.isEmpty());
	        }
	    };

	    var inputHandler = null;
	    this.setInputHandler = function(cb) {inputHandler = cb};
	    this.getInputHandler = function() {return inputHandler};
	    var afterContextMenu = false;
	    
	    var sendText = function(data) {
	        if (inputHandler) {
	            data = inputHandler(data);
	            inputHandler = null;
	        }
	        if (pasted) {
	            resetSelection();
	            if (data)
	                host.onPaste(data);
	            pasted = false;
	        } else if (data == PLACEHOLDER.charAt(0)) {
	            if (afterContextMenu)
	                host.execCommand("del", {source: "ace"});
	            else // some versions of android do not fire keydown when pressing backspace
	                host.execCommand("backspace", {source: "ace"});
	        } else {
	            if (data.substring(0, 2) == PLACEHOLDER)
	                data = data.substr(2);
	            else if (data.charAt(0) == PLACEHOLDER.charAt(0))
	                data = data.substr(1);
	            else if (data.charAt(data.length - 1) == PLACEHOLDER.charAt(0))
	                data = data.slice(0, -1);
	            if (data.charAt(data.length - 1) == PLACEHOLDER.charAt(0))
	                data = data.slice(0, -1);
	            
	            if (data)
	                host.onTextInput(data);
	        }
	        if (afterContextMenu)
	            afterContextMenu = false;
	    };
	    var onInput = function(e) {
	        if (inComposition)
	            return;
	        var data = text.value;
	        sendText(data);
	        resetValue();
	    };
	    
	    var handleClipboardData = function(e, data, forceIEMime) {
	        var clipboardData = e.clipboardData || window.clipboardData;
	        if (!clipboardData || BROKEN_SETDATA)
	            return;
	        var mime = USE_IE_MIME_TYPE || forceIEMime ? "Text" : "text/plain";
	        try {
	            if (data) {
	                return clipboardData.setData(mime, data) !== false;
	            } else {
	                return clipboardData.getData(mime);
	            }
	        } catch(e) {
	            if (!forceIEMime)
	                return handleClipboardData(e, data, true);
	        }
	    };

	    var doCopy = function(e, isCut) {
	        var data = host.getCopyText();
	        if (!data)
	            return event.preventDefault(e);

	        if (handleClipboardData(e, data)) {
	            isCut ? host.onCut() : host.onCopy();
	            event.preventDefault(e);
	        } else {
	            copied = true;
	            text.value = data;
	            text.select();
	            setTimeout(function(){
	                copied = false;
	                resetValue();
	                resetSelection();
	                isCut ? host.onCut() : host.onCopy();
	            });
	        }
	    };
	    
	    var onCut = function(e) {
	        doCopy(e, true);
	    };
	    
	    var onCopy = function(e) {
	        doCopy(e, false);
	    };
	    
	    var onPaste = function(e) {
	        var data = handleClipboardData(e);
	        if (typeof data == "string") {
	            if (data)
	                host.onPaste(data, e);
	            if (useragent.isIE)
	                setTimeout(resetSelection);
	            event.preventDefault(e);
	        }
	        else {
	            text.value = "";
	            pasted = true;
	        }
	    };

	    event.addCommandKeyListener(text, host.onCommandKey.bind(host));

	    event.addListener(text, "select", onSelect);

	    event.addListener(text, "input", onInput);

	    event.addListener(text, "cut", onCut);
	    event.addListener(text, "copy", onCopy);
	    event.addListener(text, "paste", onPaste);
	    if (!('oncut' in text) || !('oncopy' in text) || !('onpaste' in text)){
	        event.addListener(parentNode, "keydown", function(e) {
	            if ((useragent.isMac && !e.metaKey) || !e.ctrlKey)
	                return;

	            switch (e.keyCode) {
	                case 67:
	                    onCopy(e);
	                    break;
	                case 86:
	                    onPaste(e);
	                    break;
	                case 88:
	                    onCut(e);
	                    break;
	            }
	        });
	    }
	    var onCompositionStart = function(e) {
	        if (inComposition || !host.onCompositionStart || host.$readOnly) 
	            return;
	        inComposition = {};
	        inComposition.canUndo = host.session.$undoManager;
	        host.onCompositionStart();
	        setTimeout(onCompositionUpdate, 0);
	        host.on("mousedown", onCompositionEnd);
	        if (inComposition.canUndo && !host.selection.isEmpty()) {
	            host.insert("");
	            host.session.markUndoGroup();
	            host.selection.clearSelection();
	        }
	        host.session.markUndoGroup();
	    };

	    var onCompositionUpdate = function() {
	        if (!inComposition || !host.onCompositionUpdate || host.$readOnly)
	            return;
	        var val = text.value.replace(/\x01/g, "");
	        if (inComposition.lastValue === val) return;
	        
	        host.onCompositionUpdate(val);
	        if (inComposition.lastValue)
	            host.undo();
	        if (inComposition.canUndo)
	            inComposition.lastValue = val;
	        if (inComposition.lastValue) {
	            var r = host.selection.getRange();
	            host.insert(inComposition.lastValue);
	            host.session.markUndoGroup();
	            inComposition.range = host.selection.getRange();
	            host.selection.setRange(r);
	            host.selection.clearSelection();
	        }
	    };

	    var onCompositionEnd = function(e) {
	        if (!host.onCompositionEnd || host.$readOnly) return;
	        var c = inComposition;
	        inComposition = false;
	        var timer = setTimeout(function() {
	            timer = null;
	            var str = text.value.replace(/\x01/g, "");
	            if (inComposition)
	                return;
	            else if (str == c.lastValue)
	                resetValue();
	            else if (!c.lastValue && str) {
	                resetValue();
	                sendText(str);
	            }
	        });
	        inputHandler = function compositionInputHandler(str) {
	            if (timer)
	                clearTimeout(timer);
	            str = str.replace(/\x01/g, "");
	            if (str == c.lastValue)
	                return "";
	            if (c.lastValue && timer)
	                host.undo();
	            return str;
	        };
	        host.onCompositionEnd();
	        host.removeListener("mousedown", onCompositionEnd);
	        if (e.type == "compositionend" && c.range) {
	            host.selection.setRange(c.range);
	        }
	        if (useragent.isChrome && useragent.isChrome >= 53) {
	          onInput();
	        }
	    };
	    
	    

	    var syncComposition = lang.delayedCall(onCompositionUpdate, 50);

	    event.addListener(text, "compositionstart", onCompositionStart);
	    if (useragent.isGecko) {
	        event.addListener(text, "text", function(){syncComposition.schedule()});
	    } else {
	        event.addListener(text, "keyup", function(){syncComposition.schedule()});
	        event.addListener(text, "keydown", function(){syncComposition.schedule()});
	    }
	    event.addListener(text, "compositionend", onCompositionEnd);

	    this.getElement = function() {
	        return text;
	    };

	    this.setReadOnly = function(readOnly) {
	       text.readOnly = readOnly;
	    };

	    this.onContextMenu = function(e) {
	        afterContextMenu = true;
	        resetSelection(host.selection.isEmpty());
	        host._emit("nativecontextmenu", {target: host, domEvent: e});
	        this.moveToMouse(e, true);
	    };
	    
	    this.moveToMouse = function(e, bringToFront) {
	        if (!bringToFront && useragent.isOldIE)
	            return;
	        if (!tempStyle)
	            tempStyle = text.style.cssText;
	        text.style.cssText = (bringToFront ? "z-index:100000;" : "")
	            + "height:" + text.style.height + ";"
	            + (useragent.isIE ? "opacity:0.1;" : "");

	        var rect = host.container.getBoundingClientRect();
	        var style = dom.computedStyle(host.container);
	        var top = rect.top + (parseInt(style.borderTopWidth) || 0);
	        var left = rect.left + (parseInt(rect.borderLeftWidth) || 0);
	        var maxTop = rect.bottom - top - text.clientHeight -2;
	        var move = function(e) {
	            text.style.left = e.clientX - left - 2 + "px";
	            text.style.top = Math.min(e.clientY - top - 2, maxTop) + "px";
	        }; 
	        move(e);

	        if (e.type != "mousedown")
	            return;

	        if (host.renderer.$keepTextAreaAtCursor)
	            host.renderer.$keepTextAreaAtCursor = null;

	        clearTimeout(closeTimeout);
	        if (useragent.isWin && !useragent.isOldIE)
	            event.capture(host.container, move, onContextMenuClose);
	    };

	    this.onContextMenuClose = onContextMenuClose;
	    var closeTimeout;
	    function onContextMenuClose() {
	        clearTimeout(closeTimeout);
	        closeTimeout = setTimeout(function () {
	            if (tempStyle) {
	                text.style.cssText = tempStyle;
	                tempStyle = '';
	            }
	            if (host.renderer.$keepTextAreaAtCursor == null) {
	                host.renderer.$keepTextAreaAtCursor = true;
	                host.renderer.$moveTextAreaToCursor();
	            }
	        }, useragent.isOldIE ? 200 : 0);
	    }

	    var onContextMenu = function(e) {
	        host.textInput.onContextMenu(e);
	        onContextMenuClose();
	    };
	    event.addListener(text, "mouseup", onContextMenu);
	    event.addListener(text, "mousedown", function(e) {
	        e.preventDefault();
	        onContextMenuClose();
	    });
	    event.addListener(host.renderer.scroller, "contextmenu", onContextMenu);
	    event.addListener(text, "contextmenu", onContextMenu);
	};

	exports.TextInput = TextInput;
	});

	ace.define("ace/mouse/default_handlers",["require","exports","module","ace/lib/dom","ace/lib/event","ace/lib/useragent"], function(acequire, exports, module) {
	"use strict";

	var dom = acequire("../lib/dom");
	var event = acequire("../lib/event");
	var useragent = acequire("../lib/useragent");

	var DRAG_OFFSET = 0; // pixels

	function DefaultHandlers(mouseHandler) {
	    mouseHandler.$clickSelection = null;

	    var editor = mouseHandler.editor;
	    editor.setDefaultHandler("mousedown", this.onMouseDown.bind(mouseHandler));
	    editor.setDefaultHandler("dblclick", this.onDoubleClick.bind(mouseHandler));
	    editor.setDefaultHandler("tripleclick", this.onTripleClick.bind(mouseHandler));
	    editor.setDefaultHandler("quadclick", this.onQuadClick.bind(mouseHandler));
	    editor.setDefaultHandler("mousewheel", this.onMouseWheel.bind(mouseHandler));
	    editor.setDefaultHandler("touchmove", this.onTouchMove.bind(mouseHandler));

	    var exports = ["select", "startSelect", "selectEnd", "selectAllEnd", "selectByWordsEnd",
	        "selectByLinesEnd", "dragWait", "dragWaitEnd", "focusWait"];

	    exports.forEach(function(x) {
	        mouseHandler[x] = this[x];
	    }, this);

	    mouseHandler.selectByLines = this.extendSelectionBy.bind(mouseHandler, "getLineRange");
	    mouseHandler.selectByWords = this.extendSelectionBy.bind(mouseHandler, "getWordRange");
	}

	(function() {

	    this.onMouseDown = function(ev) {
	        var inSelection = ev.inSelection();
	        var pos = ev.getDocumentPosition();
	        this.mousedownEvent = ev;
	        var editor = this.editor;

	        var button = ev.getButton();
	        if (button !== 0) {
	            var selectionRange = editor.getSelectionRange();
	            var selectionEmpty = selectionRange.isEmpty();
	            editor.$blockScrolling++;
	            if (selectionEmpty || button == 1)
	                editor.selection.moveToPosition(pos);
	            editor.$blockScrolling--;
	            if (button == 2)
	                editor.textInput.onContextMenu(ev.domEvent);
	            return; // stopping event here breaks contextmenu on ff mac
	        }

	        this.mousedownEvent.time = Date.now();
	        if (inSelection && !editor.isFocused()) {
	            editor.focus();
	            if (this.$focusTimout && !this.$clickSelection && !editor.inMultiSelectMode) {
	                this.setState("focusWait");
	                this.captureMouse(ev);
	                return;
	            }
	        }

	        this.captureMouse(ev);
	        this.startSelect(pos, ev.domEvent._clicks > 1);
	        return ev.preventDefault();
	    };

	    this.startSelect = function(pos, waitForClickSelection) {
	        pos = pos || this.editor.renderer.screenToTextCoordinates(this.x, this.y);
	        var editor = this.editor;
	        editor.$blockScrolling++;
	        if (this.mousedownEvent.getShiftKey())
	            editor.selection.selectToPosition(pos);
	        else if (!waitForClickSelection)
	            editor.selection.moveToPosition(pos);
	        if (!waitForClickSelection)
	            this.select();
	        if (editor.renderer.scroller.setCapture) {
	            editor.renderer.scroller.setCapture();
	        }
	        editor.setStyle("ace_selecting");
	        this.setState("select");
	        editor.$blockScrolling--;
	    };

	    this.select = function() {
	        var anchor, editor = this.editor;
	        var cursor = editor.renderer.screenToTextCoordinates(this.x, this.y);
	        editor.$blockScrolling++;
	        if (this.$clickSelection) {
	            var cmp = this.$clickSelection.comparePoint(cursor);

	            if (cmp == -1) {
	                anchor = this.$clickSelection.end;
	            } else if (cmp == 1) {
	                anchor = this.$clickSelection.start;
	            } else {
	                var orientedRange = calcRangeOrientation(this.$clickSelection, cursor);
	                cursor = orientedRange.cursor;
	                anchor = orientedRange.anchor;
	            }
	            editor.selection.setSelectionAnchor(anchor.row, anchor.column);
	        }
	        editor.selection.selectToPosition(cursor);
	        editor.$blockScrolling--;
	        editor.renderer.scrollCursorIntoView();
	    };

	    this.extendSelectionBy = function(unitName) {
	        var anchor, editor = this.editor;
	        var cursor = editor.renderer.screenToTextCoordinates(this.x, this.y);
	        var range = editor.selection[unitName](cursor.row, cursor.column);
	        editor.$blockScrolling++;
	        if (this.$clickSelection) {
	            var cmpStart = this.$clickSelection.comparePoint(range.start);
	            var cmpEnd = this.$clickSelection.comparePoint(range.end);

	            if (cmpStart == -1 && cmpEnd <= 0) {
	                anchor = this.$clickSelection.end;
	                if (range.end.row != cursor.row || range.end.column != cursor.column)
	                    cursor = range.start;
	            } else if (cmpEnd == 1 && cmpStart >= 0) {
	                anchor = this.$clickSelection.start;
	                if (range.start.row != cursor.row || range.start.column != cursor.column)
	                    cursor = range.end;
	            } else if (cmpStart == -1 && cmpEnd == 1) {
	                cursor = range.end;
	                anchor = range.start;
	            } else {
	                var orientedRange = calcRangeOrientation(this.$clickSelection, cursor);
	                cursor = orientedRange.cursor;
	                anchor = orientedRange.anchor;
	            }
	            editor.selection.setSelectionAnchor(anchor.row, anchor.column);
	        }
	        editor.selection.selectToPosition(cursor);
	        editor.$blockScrolling--;
	        editor.renderer.scrollCursorIntoView();
	    };

	    this.selectEnd =
	    this.selectAllEnd =
	    this.selectByWordsEnd =
	    this.selectByLinesEnd = function() {
	        this.$clickSelection = null;
	        this.editor.unsetStyle("ace_selecting");
	        if (this.editor.renderer.scroller.releaseCapture) {
	            this.editor.renderer.scroller.releaseCapture();
	        }
	    };

	    this.focusWait = function() {
	        var distance = calcDistance(this.mousedownEvent.x, this.mousedownEvent.y, this.x, this.y);
	        var time = Date.now();

	        if (distance > DRAG_OFFSET || time - this.mousedownEvent.time > this.$focusTimout)
	            this.startSelect(this.mousedownEvent.getDocumentPosition());
	    };

	    this.onDoubleClick = function(ev) {
	        var pos = ev.getDocumentPosition();
	        var editor = this.editor;
	        var session = editor.session;

	        var range = session.getBracketRange(pos);
	        if (range) {
	            if (range.isEmpty()) {
	                range.start.column--;
	                range.end.column++;
	            }
	            this.setState("select");
	        } else {
	            range = editor.selection.getWordRange(pos.row, pos.column);
	            this.setState("selectByWords");
	        }
	        this.$clickSelection = range;
	        this.select();
	    };

	    this.onTripleClick = function(ev) {
	        var pos = ev.getDocumentPosition();
	        var editor = this.editor;

	        this.setState("selectByLines");
	        var range = editor.getSelectionRange();
	        if (range.isMultiLine() && range.contains(pos.row, pos.column)) {
	            this.$clickSelection = editor.selection.getLineRange(range.start.row);
	            this.$clickSelection.end = editor.selection.getLineRange(range.end.row).end;
	        } else {
	            this.$clickSelection = editor.selection.getLineRange(pos.row);
	        }
	        this.select();
	    };

	    this.onQuadClick = function(ev) {
	        var editor = this.editor;

	        editor.selectAll();
	        this.$clickSelection = editor.getSelectionRange();
	        this.setState("selectAll");
	    };

	    this.onMouseWheel = function(ev) {
	        if (ev.getAccelKey())
	            return;
	        if (ev.getShiftKey() && ev.wheelY && !ev.wheelX) {
	            ev.wheelX = ev.wheelY;
	            ev.wheelY = 0;
	        }

	        var t = ev.domEvent.timeStamp;
	        var dt = t - (this.$lastScrollTime||0);
	        
	        var editor = this.editor;
	        var isScrolable = editor.renderer.isScrollableBy(ev.wheelX * ev.speed, ev.wheelY * ev.speed);
	        if (isScrolable || dt < 200) {
	            this.$lastScrollTime = t;
	            editor.renderer.scrollBy(ev.wheelX * ev.speed, ev.wheelY * ev.speed);
	            return ev.stop();
	        }
	    };
	    
	    this.onTouchMove = function (ev) {
	        var t = ev.domEvent.timeStamp;
	        var dt = t - (this.$lastScrollTime || 0);

	        var editor = this.editor;
	        var isScrolable = editor.renderer.isScrollableBy(ev.wheelX * ev.speed, ev.wheelY * ev.speed);
	        if (isScrolable || dt < 200) {
	            this.$lastScrollTime = t;
	            editor.renderer.scrollBy(ev.wheelX * ev.speed, ev.wheelY * ev.speed);
	            return ev.stop();
	        }
	    };

	}).call(DefaultHandlers.prototype);

	exports.DefaultHandlers = DefaultHandlers;

	function calcDistance(ax, ay, bx, by) {
	    return Math.sqrt(Math.pow(bx - ax, 2) + Math.pow(by - ay, 2));
	}

	function calcRangeOrientation(range, cursor) {
	    if (range.start.row == range.end.row)
	        var cmp = 2 * cursor.column - range.start.column - range.end.column;
	    else if (range.start.row == range.end.row - 1 && !range.start.column && !range.end.column)
	        var cmp = cursor.column - 4;
	    else
	        var cmp = 2 * cursor.row - range.start.row - range.end.row;

	    if (cmp < 0)
	        return {cursor: range.start, anchor: range.end};
	    else
	        return {cursor: range.end, anchor: range.start};
	}

	});

	ace.define("ace/tooltip",["require","exports","module","ace/lib/oop","ace/lib/dom"], function(acequire, exports, module) {
	"use strict";

	var oop = acequire("./lib/oop");
	var dom = acequire("./lib/dom");
	function Tooltip (parentNode) {
	    this.isOpen = false;
	    this.$element = null;
	    this.$parentNode = parentNode;
	}

	(function() {
	    this.$init = function() {
	        this.$element = dom.createElement("div");
	        this.$element.className = "ace_tooltip";
	        this.$element.style.display = "none";
	        this.$parentNode.appendChild(this.$element);
	        return this.$element;
	    };
	    this.getElement = function() {
	        return this.$element || this.$init();
	    };
	    this.setText = function(text) {
	        dom.setInnerText(this.getElement(), text);
	    };
	    this.setHtml = function(html) {
	        this.getElement().innerHTML = html;
	    };
	    this.setPosition = function(x, y) {
	        this.getElement().style.left = x + "px";
	        this.getElement().style.top = y + "px";
	    };
	    this.setClassName = function(className) {
	        dom.addCssClass(this.getElement(), className);
	    };
	    this.show = function(text, x, y) {
	        if (text != null)
	            this.setText(text);
	        if (x != null && y != null)
	            this.setPosition(x, y);
	        if (!this.isOpen) {
	            this.getElement().style.display = "block";
	            this.isOpen = true;
	        }
	    };

	    this.hide = function() {
	        if (this.isOpen) {
	            this.getElement().style.display = "none";
	            this.isOpen = false;
	        }
	    };
	    this.getHeight = function() {
	        return this.getElement().offsetHeight;
	    };
	    this.getWidth = function() {
	        return this.getElement().offsetWidth;
	    };

	}).call(Tooltip.prototype);

	exports.Tooltip = Tooltip;
	});

	ace.define("ace/mouse/default_gutter_handler",["require","exports","module","ace/lib/dom","ace/lib/oop","ace/lib/event","ace/tooltip"], function(acequire, exports, module) {
	"use strict";
	var dom = acequire("../lib/dom");
	var oop = acequire("../lib/oop");
	var event = acequire("../lib/event");
	var Tooltip = acequire("../tooltip").Tooltip;

	function GutterHandler(mouseHandler) {
	    var editor = mouseHandler.editor;
	    var gutter = editor.renderer.$gutterLayer;
	    var tooltip = new GutterTooltip(editor.container);

	    mouseHandler.editor.setDefaultHandler("guttermousedown", function(e) {
	        if (!editor.isFocused() || e.getButton() != 0)
	            return;
	        var gutterRegion = gutter.getRegion(e);

	        if (gutterRegion == "foldWidgets")
	            return;

	        var row = e.getDocumentPosition().row;
	        var selection = editor.session.selection;

	        if (e.getShiftKey())
	            selection.selectTo(row, 0);
	        else {
	            if (e.domEvent.detail == 2) {
	                editor.selectAll();
	                return e.preventDefault();
	            }
	            mouseHandler.$clickSelection = editor.selection.getLineRange(row);
	        }
	        mouseHandler.setState("selectByLines");
	        mouseHandler.captureMouse(e);
	        return e.preventDefault();
	    });


	    var tooltipTimeout, mouseEvent, tooltipAnnotation;

	    function showTooltip() {
	        var row = mouseEvent.getDocumentPosition().row;
	        var annotation = gutter.$annotations[row];
	        if (!annotation)
	            return hideTooltip();

	        var maxRow = editor.session.getLength();
	        if (row == maxRow) {
	            var screenRow = editor.renderer.pixelToScreenCoordinates(0, mouseEvent.y).row;
	            var pos = mouseEvent.$pos;
	            if (screenRow > editor.session.documentToScreenRow(pos.row, pos.column))
	                return hideTooltip();
	        }

	        if (tooltipAnnotation == annotation)
	            return;
	        tooltipAnnotation = annotation.text.join("<br/>");

	        tooltip.setHtml(tooltipAnnotation);
	        tooltip.show();
	        editor._signal("showGutterTooltip", tooltip);
	        editor.on("mousewheel", hideTooltip);

	        if (mouseHandler.$tooltipFollowsMouse) {
	            moveTooltip(mouseEvent);
	        } else {
	            var gutterElement = mouseEvent.domEvent.target;
	            var rect = gutterElement.getBoundingClientRect();
	            var style = tooltip.getElement().style;
	            style.left = rect.right + "px";
	            style.top = rect.bottom + "px";
	        }
	    }

	    function hideTooltip() {
	        if (tooltipTimeout)
	            tooltipTimeout = clearTimeout(tooltipTimeout);
	        if (tooltipAnnotation) {
	            tooltip.hide();
	            tooltipAnnotation = null;
	            editor._signal("hideGutterTooltip", tooltip);
	            editor.removeEventListener("mousewheel", hideTooltip);
	        }
	    }

	    function moveTooltip(e) {
	        tooltip.setPosition(e.x, e.y);
	    }

	    mouseHandler.editor.setDefaultHandler("guttermousemove", function(e) {
	        var target = e.domEvent.target || e.domEvent.srcElement;
	        if (dom.hasCssClass(target, "ace_fold-widget"))
	            return hideTooltip();

	        if (tooltipAnnotation && mouseHandler.$tooltipFollowsMouse)
	            moveTooltip(e);

	        mouseEvent = e;
	        if (tooltipTimeout)
	            return;
	        tooltipTimeout = setTimeout(function() {
	            tooltipTimeout = null;
	            if (mouseEvent && !mouseHandler.isMousePressed)
	                showTooltip();
	            else
	                hideTooltip();
	        }, 50);
	    });

	    event.addListener(editor.renderer.$gutter, "mouseout", function(e) {
	        mouseEvent = null;
	        if (!tooltipAnnotation || tooltipTimeout)
	            return;

	        tooltipTimeout = setTimeout(function() {
	            tooltipTimeout = null;
	            hideTooltip();
	        }, 50);
	    });
	    
	    editor.on("changeSession", hideTooltip);
	}

	function GutterTooltip(parentNode) {
	    Tooltip.call(this, parentNode);
	}

	oop.inherits(GutterTooltip, Tooltip);

	(function(){
	    this.setPosition = function(x, y) {
	        var windowWidth = window.innerWidth || document.documentElement.clientWidth;
	        var windowHeight = window.innerHeight || document.documentElement.clientHeight;
	        var width = this.getWidth();
	        var height = this.getHeight();
	        x += 15;
	        y += 15;
	        if (x + width > windowWidth) {
	            x -= (x + width) - windowWidth;
	        }
	        if (y + height > windowHeight) {
	            y -= 20 + height;
	        }
	        Tooltip.prototype.setPosition.call(this, x, y);
	    };

	}).call(GutterTooltip.prototype);



	exports.GutterHandler = GutterHandler;

	});

	ace.define("ace/mouse/mouse_event",["require","exports","module","ace/lib/event","ace/lib/useragent"], function(acequire, exports, module) {
	"use strict";

	var event = acequire("../lib/event");
	var useragent = acequire("../lib/useragent");
	var MouseEvent = exports.MouseEvent = function(domEvent, editor) {
	    this.domEvent = domEvent;
	    this.editor = editor;
	    
	    this.x = this.clientX = domEvent.clientX;
	    this.y = this.clientY = domEvent.clientY;

	    this.$pos = null;
	    this.$inSelection = null;
	    
	    this.propagationStopped = false;
	    this.defaultPrevented = false;
	};

	(function() {  
	    
	    this.stopPropagation = function() {
	        event.stopPropagation(this.domEvent);
	        this.propagationStopped = true;
	    };
	    
	    this.preventDefault = function() {
	        event.preventDefault(this.domEvent);
	        this.defaultPrevented = true;
	    };
	    
	    this.stop = function() {
	        this.stopPropagation();
	        this.preventDefault();
	    };
	    this.getDocumentPosition = function() {
	        if (this.$pos)
	            return this.$pos;
	        
	        this.$pos = this.editor.renderer.screenToTextCoordinates(this.clientX, this.clientY);
	        return this.$pos;
	    };
	    this.inSelection = function() {
	        if (this.$inSelection !== null)
	            return this.$inSelection;
	            
	        var editor = this.editor;
	        

	        var selectionRange = editor.getSelectionRange();
	        if (selectionRange.isEmpty())
	            this.$inSelection = false;
	        else {
	            var pos = this.getDocumentPosition();
	            this.$inSelection = selectionRange.contains(pos.row, pos.column);
	        }

	        return this.$inSelection;
	    };
	    this.getButton = function() {
	        return event.getButton(this.domEvent);
	    };
	    this.getShiftKey = function() {
	        return this.domEvent.shiftKey;
	    };
	    
	    this.getAccelKey = useragent.isMac
	        ? function() { return this.domEvent.metaKey; }
	        : function() { return this.domEvent.ctrlKey; };
	    
	}).call(MouseEvent.prototype);

	});

	ace.define("ace/mouse/dragdrop_handler",["require","exports","module","ace/lib/dom","ace/lib/event","ace/lib/useragent"], function(acequire, exports, module) {
	"use strict";

	var dom = acequire("../lib/dom");
	var event = acequire("../lib/event");
	var useragent = acequire("../lib/useragent");

	var AUTOSCROLL_DELAY = 200;
	var SCROLL_CURSOR_DELAY = 200;
	var SCROLL_CURSOR_HYSTERESIS = 5;

	function DragdropHandler(mouseHandler) {

	    var editor = mouseHandler.editor;

	    var blankImage = dom.createElement("img");
	    blankImage.src = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==";
	    if (useragent.isOpera)
	        blankImage.style.cssText = "width:1px;height:1px;position:fixed;top:0;left:0;z-index:2147483647;opacity:0;";

	    var exports = ["dragWait", "dragWaitEnd", "startDrag", "dragReadyEnd", "onMouseDrag"];

	     exports.forEach(function(x) {
	         mouseHandler[x] = this[x];
	    }, this);
	    editor.addEventListener("mousedown", this.onMouseDown.bind(mouseHandler));


	    var mouseTarget = editor.container;
	    var dragSelectionMarker, x, y;
	    var timerId, range;
	    var dragCursor, counter = 0;
	    var dragOperation;
	    var isInternal;
	    var autoScrollStartTime;
	    var cursorMovedTime;
	    var cursorPointOnCaretMoved;

	    this.onDragStart = function(e) {
	        if (this.cancelDrag || !mouseTarget.draggable) {
	            var self = this;
	            setTimeout(function(){
	                self.startSelect();
	                self.captureMouse(e);
	            }, 0);
	            return e.preventDefault();
	        }
	        range = editor.getSelectionRange();

	        var dataTransfer = e.dataTransfer;
	        dataTransfer.effectAllowed = editor.getReadOnly() ? "copy" : "copyMove";
	        if (useragent.isOpera) {
	            editor.container.appendChild(blankImage);
	            blankImage.scrollTop = 0;
	        }
	        dataTransfer.setDragImage && dataTransfer.setDragImage(blankImage, 0, 0);
	        if (useragent.isOpera) {
	            editor.container.removeChild(blankImage);
	        }
	        dataTransfer.clearData();
	        dataTransfer.setData("Text", editor.session.getTextRange());

	        isInternal = true;
	        this.setState("drag");
	    };

	    this.onDragEnd = function(e) {
	        mouseTarget.draggable = false;
	        isInternal = false;
	        this.setState(null);
	        if (!editor.getReadOnly()) {
	            var dropEffect = e.dataTransfer.dropEffect;
	            if (!dragOperation && dropEffect == "move")
	                editor.session.remove(editor.getSelectionRange());
	            editor.renderer.$cursorLayer.setBlinking(true);
	        }
	        this.editor.unsetStyle("ace_dragging");
	        this.editor.renderer.setCursorStyle("");
	    };

	    this.onDragEnter = function(e) {
	        if (editor.getReadOnly() || !canAccept(e.dataTransfer))
	            return;
	        x = e.clientX;
	        y = e.clientY;
	        if (!dragSelectionMarker)
	            addDragMarker();
	        counter++;
	        e.dataTransfer.dropEffect = dragOperation = getDropEffect(e);
	        return event.preventDefault(e);
	    };

	    this.onDragOver = function(e) {
	        if (editor.getReadOnly() || !canAccept(e.dataTransfer))
	            return;
	        x = e.clientX;
	        y = e.clientY;
	        if (!dragSelectionMarker) {
	            addDragMarker();
	            counter++;
	        }
	        if (onMouseMoveTimer !== null)
	            onMouseMoveTimer = null;

	        e.dataTransfer.dropEffect = dragOperation = getDropEffect(e);
	        return event.preventDefault(e);
	    };

	    this.onDragLeave = function(e) {
	        counter--;
	        if (counter <= 0 && dragSelectionMarker) {
	            clearDragMarker();
	            dragOperation = null;
	            return event.preventDefault(e);
	        }
	    };

	    this.onDrop = function(e) {
	        if (!dragCursor)
	            return;
	        var dataTransfer = e.dataTransfer;
	        if (isInternal) {
	            switch (dragOperation) {
	                case "move":
	                    if (range.contains(dragCursor.row, dragCursor.column)) {
	                        range = {
	                            start: dragCursor,
	                            end: dragCursor
	                        };
	                    } else {
	                        range = editor.moveText(range, dragCursor);
	                    }
	                    break;
	                case "copy":
	                    range = editor.moveText(range, dragCursor, true);
	                    break;
	            }
	        } else {
	            var dropData = dataTransfer.getData('Text');
	            range = {
	                start: dragCursor,
	                end: editor.session.insert(dragCursor, dropData)
	            };
	            editor.focus();
	            dragOperation = null;
	        }
	        clearDragMarker();
	        return event.preventDefault(e);
	    };

	    event.addListener(mouseTarget, "dragstart", this.onDragStart.bind(mouseHandler));
	    event.addListener(mouseTarget, "dragend", this.onDragEnd.bind(mouseHandler));
	    event.addListener(mouseTarget, "dragenter", this.onDragEnter.bind(mouseHandler));
	    event.addListener(mouseTarget, "dragover", this.onDragOver.bind(mouseHandler));
	    event.addListener(mouseTarget, "dragleave", this.onDragLeave.bind(mouseHandler));
	    event.addListener(mouseTarget, "drop", this.onDrop.bind(mouseHandler));

	    function scrollCursorIntoView(cursor, prevCursor) {
	        var now = Date.now();
	        var vMovement = !prevCursor || cursor.row != prevCursor.row;
	        var hMovement = !prevCursor || cursor.column != prevCursor.column;
	        if (!cursorMovedTime || vMovement || hMovement) {
	            editor.$blockScrolling += 1;
	            editor.moveCursorToPosition(cursor);
	            editor.$blockScrolling -= 1;
	            cursorMovedTime = now;
	            cursorPointOnCaretMoved = {x: x, y: y};
	        } else {
	            var distance = calcDistance(cursorPointOnCaretMoved.x, cursorPointOnCaretMoved.y, x, y);
	            if (distance > SCROLL_CURSOR_HYSTERESIS) {
	                cursorMovedTime = null;
	            } else if (now - cursorMovedTime >= SCROLL_CURSOR_DELAY) {
	                editor.renderer.scrollCursorIntoView();
	                cursorMovedTime = null;
	            }
	        }
	    }

	    function autoScroll(cursor, prevCursor) {
	        var now = Date.now();
	        var lineHeight = editor.renderer.layerConfig.lineHeight;
	        var characterWidth = editor.renderer.layerConfig.characterWidth;
	        var editorRect = editor.renderer.scroller.getBoundingClientRect();
	        var offsets = {
	           x: {
	               left: x - editorRect.left,
	               right: editorRect.right - x
	           },
	           y: {
	               top: y - editorRect.top,
	               bottom: editorRect.bottom - y
	           }
	        };
	        var nearestXOffset = Math.min(offsets.x.left, offsets.x.right);
	        var nearestYOffset = Math.min(offsets.y.top, offsets.y.bottom);
	        var scrollCursor = {row: cursor.row, column: cursor.column};
	        if (nearestXOffset / characterWidth <= 2) {
	            scrollCursor.column += (offsets.x.left < offsets.x.right ? -3 : +2);
	        }
	        if (nearestYOffset / lineHeight <= 1) {
	            scrollCursor.row += (offsets.y.top < offsets.y.bottom ? -1 : +1);
	        }
	        var vScroll = cursor.row != scrollCursor.row;
	        var hScroll = cursor.column != scrollCursor.column;
	        var vMovement = !prevCursor || cursor.row != prevCursor.row;
	        if (vScroll || (hScroll && !vMovement)) {
	            if (!autoScrollStartTime)
	                autoScrollStartTime = now;
	            else if (now - autoScrollStartTime >= AUTOSCROLL_DELAY)
	                editor.renderer.scrollCursorIntoView(scrollCursor);
	        } else {
	            autoScrollStartTime = null;
	        }
	    }

	    function onDragInterval() {
	        var prevCursor = dragCursor;
	        dragCursor = editor.renderer.screenToTextCoordinates(x, y);
	        scrollCursorIntoView(dragCursor, prevCursor);
	        autoScroll(dragCursor, prevCursor);
	    }

	    function addDragMarker() {
	        range = editor.selection.toOrientedRange();
	        dragSelectionMarker = editor.session.addMarker(range, "ace_selection", editor.getSelectionStyle());
	        editor.clearSelection();
	        if (editor.isFocused())
	            editor.renderer.$cursorLayer.setBlinking(false);
	        clearInterval(timerId);
	        onDragInterval();
	        timerId = setInterval(onDragInterval, 20);
	        counter = 0;
	        event.addListener(document, "mousemove", onMouseMove);
	    }

	    function clearDragMarker() {
	        clearInterval(timerId);
	        editor.session.removeMarker(dragSelectionMarker);
	        dragSelectionMarker = null;
	        editor.$blockScrolling += 1;
	        editor.selection.fromOrientedRange(range);
	        editor.$blockScrolling -= 1;
	        if (editor.isFocused() && !isInternal)
	            editor.renderer.$cursorLayer.setBlinking(!editor.getReadOnly());
	        range = null;
	        dragCursor = null;
	        counter = 0;
	        autoScrollStartTime = null;
	        cursorMovedTime = null;
	        event.removeListener(document, "mousemove", onMouseMove);
	    }
	    var onMouseMoveTimer = null;
	    function onMouseMove() {
	        if (onMouseMoveTimer == null) {
	            onMouseMoveTimer = setTimeout(function() {
	                if (onMouseMoveTimer != null && dragSelectionMarker)
	                    clearDragMarker();
	            }, 20);
	        }
	    }

	    function canAccept(dataTransfer) {
	        var types = dataTransfer.types;
	        return !types || Array.prototype.some.call(types, function(type) {
	            return type == 'text/plain' || type == 'Text';
	        });
	    }

	    function getDropEffect(e) {
	        var copyAllowed = ['copy', 'copymove', 'all', 'uninitialized'];
	        var moveAllowed = ['move', 'copymove', 'linkmove', 'all', 'uninitialized'];

	        var copyModifierState = useragent.isMac ? e.altKey : e.ctrlKey;
	        var effectAllowed = "uninitialized";
	        try {
	            effectAllowed = e.dataTransfer.effectAllowed.toLowerCase();
	        } catch (e) {}
	        var dropEffect = "none";

	        if (copyModifierState && copyAllowed.indexOf(effectAllowed) >= 0)
	            dropEffect = "copy";
	        else if (moveAllowed.indexOf(effectAllowed) >= 0)
	            dropEffect = "move";
	        else if (copyAllowed.indexOf(effectAllowed) >= 0)
	            dropEffect = "copy";

	        return dropEffect;
	    }
	}

	(function() {

	    this.dragWait = function() {
	        var interval = Date.now() - this.mousedownEvent.time;
	        if (interval > this.editor.getDragDelay())
	            this.startDrag();
	    };

	    this.dragWaitEnd = function() {
	        var target = this.editor.container;
	        target.draggable = false;
	        this.startSelect(this.mousedownEvent.getDocumentPosition());
	        this.selectEnd();
	    };

	    this.dragReadyEnd = function(e) {
	        this.editor.renderer.$cursorLayer.setBlinking(!this.editor.getReadOnly());
	        this.editor.unsetStyle("ace_dragging");
	        this.editor.renderer.setCursorStyle("");
	        this.dragWaitEnd();
	    };

	    this.startDrag = function(){
	        this.cancelDrag = false;
	        var editor = this.editor;
	        var target = editor.container;
	        target.draggable = true;
	        editor.renderer.$cursorLayer.setBlinking(false);
	        editor.setStyle("ace_dragging");
	        var cursorStyle = useragent.isWin ? "default" : "move";
	        editor.renderer.setCursorStyle(cursorStyle);
	        this.setState("dragReady");
	    };

	    this.onMouseDrag = function(e) {
	        var target = this.editor.container;
	        if (useragent.isIE && this.state == "dragReady") {
	            var distance = calcDistance(this.mousedownEvent.x, this.mousedownEvent.y, this.x, this.y);
	            if (distance > 3)
	                target.dragDrop();
	        }
	        if (this.state === "dragWait") {
	            var distance = calcDistance(this.mousedownEvent.x, this.mousedownEvent.y, this.x, this.y);
	            if (distance > 0) {
	                target.draggable = false;
	                this.startSelect(this.mousedownEvent.getDocumentPosition());
	            }
	        }
	    };

	    this.onMouseDown = function(e) {
	        if (!this.$dragEnabled)
	            return;
	        this.mousedownEvent = e;
	        var editor = this.editor;

	        var inSelection = e.inSelection();
	        var button = e.getButton();
	        var clickCount = e.domEvent.detail || 1;
	        if (clickCount === 1 && button === 0 && inSelection) {
	            if (e.editor.inMultiSelectMode && (e.getAccelKey() || e.getShiftKey()))
	                return;
	            this.mousedownEvent.time = Date.now();
	            var eventTarget = e.domEvent.target || e.domEvent.srcElement;
	            if ("unselectable" in eventTarget)
	                eventTarget.unselectable = "on";
	            if (editor.getDragDelay()) {
	                if (useragent.isWebKit) {
	                    this.cancelDrag = true;
	                    var mouseTarget = editor.container;
	                    mouseTarget.draggable = true;
	                }
	                this.setState("dragWait");
	            } else {
	                this.startDrag();
	            }
	            this.captureMouse(e, this.onMouseDrag.bind(this));
	            e.defaultPrevented = true;
	        }
	    };

	}).call(DragdropHandler.prototype);


	function calcDistance(ax, ay, bx, by) {
	    return Math.sqrt(Math.pow(bx - ax, 2) + Math.pow(by - ay, 2));
	}

	exports.DragdropHandler = DragdropHandler;

	});

	ace.define("ace/lib/net",["require","exports","module","ace/lib/dom"], function(acequire, exports, module) {
	"use strict";
	var dom = acequire("./dom");

	exports.get = function (url, callback) {
	    var xhr = new XMLHttpRequest();
	    xhr.open('GET', url, true);
	    xhr.onreadystatechange = function () {
	        if (xhr.readyState === 4) {
	            callback(xhr.responseText);
	        }
	    };
	    xhr.send(null);
	};

	exports.loadScript = function(path, callback) {
	    var head = dom.getDocumentHead();
	    var s = document.createElement('script');

	    s.src = path;
	    head.appendChild(s);

	    s.onload = s.onreadystatechange = function(_, isAbort) {
	        if (isAbort || !s.readyState || s.readyState == "loaded" || s.readyState == "complete") {
	            s = s.onload = s.onreadystatechange = null;
	            if (!isAbort)
	                callback();
	        }
	    };
	};
	exports.qualifyURL = function(url) {
	    var a = document.createElement('a');
	    a.href = url;
	    return a.href;
	}

	});

	ace.define("ace/lib/event_emitter",["require","exports","module"], function(acequire, exports, module) {
	"use strict";

	var EventEmitter = {};
	var stopPropagation = function() { this.propagationStopped = true; };
	var preventDefault = function() { this.defaultPrevented = true; };

	EventEmitter._emit =
	EventEmitter._dispatchEvent = function(eventName, e) {
	    this._eventRegistry || (this._eventRegistry = {});
	    this._defaultHandlers || (this._defaultHandlers = {});

	    var listeners = this._eventRegistry[eventName] || [];
	    var defaultHandler = this._defaultHandlers[eventName];
	    if (!listeners.length && !defaultHandler)
	        return;

	    if (typeof e != "object" || !e)
	        e = {};

	    if (!e.type)
	        e.type = eventName;
	    if (!e.stopPropagation)
	        e.stopPropagation = stopPropagation;
	    if (!e.preventDefault)
	        e.preventDefault = preventDefault;

	    listeners = listeners.slice();
	    for (var i=0; i<listeners.length; i++) {
	        listeners[i](e, this);
	        if (e.propagationStopped)
	            break;
	    }
	    
	    if (defaultHandler && !e.defaultPrevented)
	        return defaultHandler(e, this);
	};


	EventEmitter._signal = function(eventName, e) {
	    var listeners = (this._eventRegistry || {})[eventName];
	    if (!listeners)
	        return;
	    listeners = listeners.slice();
	    for (var i=0; i<listeners.length; i++)
	        listeners[i](e, this);
	};

	EventEmitter.once = function(eventName, callback) {
	    var _self = this;
	    callback && this.addEventListener(eventName, function newCallback() {
	        _self.removeEventListener(eventName, newCallback);
	        callback.apply(null, arguments);
	    });
	};


	EventEmitter.setDefaultHandler = function(eventName, callback) {
	    var handlers = this._defaultHandlers
	    if (!handlers)
	        handlers = this._defaultHandlers = {_disabled_: {}};
	    
	    if (handlers[eventName]) {
	        var old = handlers[eventName];
	        var disabled = handlers._disabled_[eventName];
	        if (!disabled)
	            handlers._disabled_[eventName] = disabled = [];
	        disabled.push(old);
	        var i = disabled.indexOf(callback);
	        if (i != -1) 
	            disabled.splice(i, 1);
	    }
	    handlers[eventName] = callback;
	};
	EventEmitter.removeDefaultHandler = function(eventName, callback) {
	    var handlers = this._defaultHandlers
	    if (!handlers)
	        return;
	    var disabled = handlers._disabled_[eventName];
	    
	    if (handlers[eventName] == callback) {
	        var old = handlers[eventName];
	        if (disabled)
	            this.setDefaultHandler(eventName, disabled.pop());
	    } else if (disabled) {
	        var i = disabled.indexOf(callback);
	        if (i != -1)
	            disabled.splice(i, 1);
	    }
	};

	EventEmitter.on =
	EventEmitter.addEventListener = function(eventName, callback, capturing) {
	    this._eventRegistry = this._eventRegistry || {};

	    var listeners = this._eventRegistry[eventName];
	    if (!listeners)
	        listeners = this._eventRegistry[eventName] = [];

	    if (listeners.indexOf(callback) == -1)
	        listeners[capturing ? "unshift" : "push"](callback);
	    return callback;
	};

	EventEmitter.off =
	EventEmitter.removeListener =
	EventEmitter.removeEventListener = function(eventName, callback) {
	    this._eventRegistry = this._eventRegistry || {};

	    var listeners = this._eventRegistry[eventName];
	    if (!listeners)
	        return;

	    var index = listeners.indexOf(callback);
	    if (index !== -1)
	        listeners.splice(index, 1);
	};

	EventEmitter.removeAllListeners = function(eventName) {
	    if (this._eventRegistry) this._eventRegistry[eventName] = [];
	};

	exports.EventEmitter = EventEmitter;

	});

	ace.define("ace/lib/app_config",["require","exports","module","ace/lib/oop","ace/lib/event_emitter"], function(acequire, exports, module) {
	"no use strict";

	var oop = acequire("./oop");
	var EventEmitter = acequire("./event_emitter").EventEmitter;

	var optionsProvider = {
	    setOptions: function(optList) {
	        Object.keys(optList).forEach(function(key) {
	            this.setOption(key, optList[key]);
	        }, this);
	    },
	    getOptions: function(optionNames) {
	        var result = {};
	        if (!optionNames) {
	            optionNames = Object.keys(this.$options);
	        } else if (!Array.isArray(optionNames)) {
	            result = optionNames;
	            optionNames = Object.keys(result);
	        }
	        optionNames.forEach(function(key) {
	            result[key] = this.getOption(key);
	        }, this);
	        return result;
	    },
	    setOption: function(name, value) {
	        if (this["$" + name] === value)
	            return;
	        var opt = this.$options[name];
	        if (!opt) {
	            return warn('misspelled option "' + name + '"');
	        }
	        if (opt.forwardTo)
	            return this[opt.forwardTo] && this[opt.forwardTo].setOption(name, value);

	        if (!opt.handlesSet)
	            this["$" + name] = value;
	        if (opt && opt.set)
	            opt.set.call(this, value);
	    },
	    getOption: function(name) {
	        var opt = this.$options[name];
	        if (!opt) {
	            return warn('misspelled option "' + name + '"');
	        }
	        if (opt.forwardTo)
	            return this[opt.forwardTo] && this[opt.forwardTo].getOption(name);
	        return opt && opt.get ? opt.get.call(this) : this["$" + name];
	    }
	};

	function warn(message) {
	    if (typeof console != "undefined" && console.warn)
	        console.warn.apply(console, arguments);
	}

	function reportError(msg, data) {
	    var e = new Error(msg);
	    e.data = data;
	    if (typeof console == "object" && console.error)
	        console.error(e);
	    setTimeout(function() { throw e; });
	}

	var AppConfig = function() {
	    this.$defaultOptions = {};
	};

	(function() {
	    oop.implement(this, EventEmitter);
	    this.defineOptions = function(obj, path, options) {
	        if (!obj.$options)
	            this.$defaultOptions[path] = obj.$options = {};

	        Object.keys(options).forEach(function(key) {
	            var opt = options[key];
	            if (typeof opt == "string")
	                opt = {forwardTo: opt};

	            opt.name || (opt.name = key);
	            obj.$options[opt.name] = opt;
	            if ("initialValue" in opt)
	                obj["$" + opt.name] = opt.initialValue;
	        });
	        oop.implement(obj, optionsProvider);

	        return this;
	    };

	    this.resetOptions = function(obj) {
	        Object.keys(obj.$options).forEach(function(key) {
	            var opt = obj.$options[key];
	            if ("value" in opt)
	                obj.setOption(key, opt.value);
	        });
	    };

	    this.setDefaultValue = function(path, name, value) {
	        var opts = this.$defaultOptions[path] || (this.$defaultOptions[path] = {});
	        if (opts[name]) {
	            if (opts.forwardTo)
	                this.setDefaultValue(opts.forwardTo, name, value);
	            else
	                opts[name].value = value;
	        }
	    };

	    this.setDefaultValues = function(path, optionHash) {
	        Object.keys(optionHash).forEach(function(key) {
	            this.setDefaultValue(path, key, optionHash[key]);
	        }, this);
	    };
	    
	    this.warn = warn;
	    this.reportError = reportError;
	    
	}).call(AppConfig.prototype);

	exports.AppConfig = AppConfig;

	});

	ace.define("ace/config",["require","exports","module","ace/lib/lang","ace/lib/oop","ace/lib/net","ace/lib/app_config"], function(acequire, exports, module) {
	"no use strict";

	var lang = acequire("./lib/lang");
	var oop = acequire("./lib/oop");
	var net = acequire("./lib/net");
	var AppConfig = acequire("./lib/app_config").AppConfig;

	module.exports = exports = new AppConfig();

	var global = (function() {
	    return this || typeof window != "undefined" && window;
	})();

	var options = {
	    packaged: false,
	    workerPath: null,
	    modePath: null,
	    themePath: null,
	    basePath: "",
	    suffix: ".js",
	    $moduleUrls: {}
	};

	exports.get = function(key) {
	    if (!options.hasOwnProperty(key))
	        throw new Error("Unknown config key: " + key);

	    return options[key];
	};

	exports.set = function(key, value) {
	    if (!options.hasOwnProperty(key))
	        throw new Error("Unknown config key: " + key);

	    options[key] = value;
	};

	exports.all = function() {
	    return lang.copyObject(options);
	};
	exports.moduleUrl = function(name, component) {
	    if (options.$moduleUrls[name])
	        return options.$moduleUrls[name];

	    var parts = name.split("/");
	    component = component || parts[parts.length - 2] || "";
	    var sep = component == "snippets" ? "/" : "-";
	    var base = parts[parts.length - 1];
	    if (component == "worker" && sep == "-") {
	        var re = new RegExp("^" + component + "[\\-_]|[\\-_]" + component + "$", "g");
	        base = base.replace(re, "");
	    }

	    if ((!base || base == component) && parts.length > 1)
	        base = parts[parts.length - 2];
	    var path = options[component + "Path"];
	    if (path == null) {
	        path = options.basePath;
	    } else if (sep == "/") {
	        component = sep = "";
	    }
	    if (path && path.slice(-1) != "/")
	        path += "/";
	    return path + component + sep + base + this.get("suffix");
	};

	exports.setModuleUrl = function(name, subst) {
	    return options.$moduleUrls[name] = subst;
	};

	exports.$loading = {};
	exports.loadModule = function(moduleName, onLoad) {
	    var module, moduleType;
	    if (Array.isArray(moduleName)) {
	        moduleType = moduleName[0];
	        moduleName = moduleName[1];
	    }

	    try {
	        module = acequire(moduleName);
	    } catch (e) {}
	    if (module && !exports.$loading[moduleName])
	        return onLoad && onLoad(module);

	    if (!exports.$loading[moduleName])
	        exports.$loading[moduleName] = [];

	    exports.$loading[moduleName].push(onLoad);

	    if (exports.$loading[moduleName].length > 1)
	        return;

	    var afterLoad = function() {
	        acequire([moduleName], function(module) {
	            exports._emit("load.module", {name: moduleName, module: module});
	            var listeners = exports.$loading[moduleName];
	            exports.$loading[moduleName] = null;
	            listeners.forEach(function(onLoad) {
	                onLoad && onLoad(module);
	            });
	        });
	    };

	    if (!exports.get("packaged"))
	        return afterLoad();
	    net.loadScript(exports.moduleUrl(moduleName, moduleType), afterLoad);
	};
	init(true);function init(packaged) {

	    if (!global || !global.document)
	        return;
	    
	    options.packaged = packaged || acequire.packaged || module.packaged || (global.define && __webpack_require__(905).packaged);

	    var scriptOptions = {};
	    var scriptUrl = "";
	    var currentScript = (document.currentScript || document._currentScript ); // native or polyfill
	    var currentDocument = currentScript && currentScript.ownerDocument || document;
	    
	    var scripts = currentDocument.getElementsByTagName("script");
	    for (var i=0; i<scripts.length; i++) {
	        var script = scripts[i];

	        var src = script.src || script.getAttribute("src");
	        if (!src)
	            continue;

	        var attributes = script.attributes;
	        for (var j=0, l=attributes.length; j < l; j++) {
	            var attr = attributes[j];
	            if (attr.name.indexOf("data-ace-") === 0) {
	                scriptOptions[deHyphenate(attr.name.replace(/^data-ace-/, ""))] = attr.value;
	            }
	        }

	        var m = src.match(/^(.*)\/ace(\-\w+)?\.js(\?|$)/);
	        if (m)
	            scriptUrl = m[1];
	    }

	    if (scriptUrl) {
	        scriptOptions.base = scriptOptions.base || scriptUrl;
	        scriptOptions.packaged = true;
	    }

	    scriptOptions.basePath = scriptOptions.base;
	    scriptOptions.workerPath = scriptOptions.workerPath || scriptOptions.base;
	    scriptOptions.modePath = scriptOptions.modePath || scriptOptions.base;
	    scriptOptions.themePath = scriptOptions.themePath || scriptOptions.base;
	    delete scriptOptions.base;

	    for (var key in scriptOptions)
	        if (typeof scriptOptions[key] !== "undefined")
	            exports.set(key, scriptOptions[key]);
	}

	exports.init = init;

	function deHyphenate(str) {
	    return str.replace(/-(.)/g, function(m, m1) { return m1.toUpperCase(); });
	}

	});

	ace.define("ace/mouse/mouse_handler",["require","exports","module","ace/lib/event","ace/lib/useragent","ace/mouse/default_handlers","ace/mouse/default_gutter_handler","ace/mouse/mouse_event","ace/mouse/dragdrop_handler","ace/config"], function(acequire, exports, module) {
	"use strict";

	var event = acequire("../lib/event");
	var useragent = acequire("../lib/useragent");
	var DefaultHandlers = acequire("./default_handlers").DefaultHandlers;
	var DefaultGutterHandler = acequire("./default_gutter_handler").GutterHandler;
	var MouseEvent = acequire("./mouse_event").MouseEvent;
	var DragdropHandler = acequire("./dragdrop_handler").DragdropHandler;
	var config = acequire("../config");

	var MouseHandler = function(editor) {
	    var _self = this;
	    this.editor = editor;

	    new DefaultHandlers(this);
	    new DefaultGutterHandler(this);
	    new DragdropHandler(this);

	    var focusEditor = function(e) {
	        var windowBlurred = !document.hasFocus || !document.hasFocus()
	            || !editor.isFocused() && document.activeElement == (editor.textInput && editor.textInput.getElement())
	        if (windowBlurred)
	            window.focus();
	        editor.focus();
	    };

	    var mouseTarget = editor.renderer.getMouseEventTarget();
	    event.addListener(mouseTarget, "click", this.onMouseEvent.bind(this, "click"));
	    event.addListener(mouseTarget, "mousemove", this.onMouseMove.bind(this, "mousemove"));
	    event.addMultiMouseDownListener([
	        mouseTarget,
	        editor.renderer.scrollBarV && editor.renderer.scrollBarV.inner,
	        editor.renderer.scrollBarH && editor.renderer.scrollBarH.inner,
	        editor.textInput && editor.textInput.getElement()
	    ].filter(Boolean), [400, 300, 250], this, "onMouseEvent");
	    event.addMouseWheelListener(editor.container, this.onMouseWheel.bind(this, "mousewheel"));
	    event.addTouchMoveListener(editor.container, this.onTouchMove.bind(this, "touchmove"));

	    var gutterEl = editor.renderer.$gutter;
	    event.addListener(gutterEl, "mousedown", this.onMouseEvent.bind(this, "guttermousedown"));
	    event.addListener(gutterEl, "click", this.onMouseEvent.bind(this, "gutterclick"));
	    event.addListener(gutterEl, "dblclick", this.onMouseEvent.bind(this, "gutterdblclick"));
	    event.addListener(gutterEl, "mousemove", this.onMouseEvent.bind(this, "guttermousemove"));

	    event.addListener(mouseTarget, "mousedown", focusEditor);
	    event.addListener(gutterEl, "mousedown", focusEditor);
	    if (useragent.isIE && editor.renderer.scrollBarV) {
	        event.addListener(editor.renderer.scrollBarV.element, "mousedown", focusEditor);
	        event.addListener(editor.renderer.scrollBarH.element, "mousedown", focusEditor);
	    }

	    editor.on("mousemove", function(e){
	        if (_self.state || _self.$dragDelay || !_self.$dragEnabled)
	            return;

	        var character = editor.renderer.screenToTextCoordinates(e.x, e.y);
	        var range = editor.session.selection.getRange();
	        var renderer = editor.renderer;

	        if (!range.isEmpty() && range.insideStart(character.row, character.column)) {
	            renderer.setCursorStyle("default");
	        } else {
	            renderer.setCursorStyle("");
	        }
	    });
	};

	(function() {
	    this.onMouseEvent = function(name, e) {
	        this.editor._emit(name, new MouseEvent(e, this.editor));
	    };

	    this.onMouseMove = function(name, e) {
	        var listeners = this.editor._eventRegistry && this.editor._eventRegistry.mousemove;
	        if (!listeners || !listeners.length)
	            return;

	        this.editor._emit(name, new MouseEvent(e, this.editor));
	    };

	    this.onMouseWheel = function(name, e) {
	        var mouseEvent = new MouseEvent(e, this.editor);
	        mouseEvent.speed = this.$scrollSpeed * 2;
	        mouseEvent.wheelX = e.wheelX;
	        mouseEvent.wheelY = e.wheelY;

	        this.editor._emit(name, mouseEvent);
	    };
	    
	    this.onTouchMove = function (name, e) {
	        var mouseEvent = new MouseEvent(e, this.editor);
	        mouseEvent.speed = 1;//this.$scrollSpeed * 2;
	        mouseEvent.wheelX = e.wheelX;
	        mouseEvent.wheelY = e.wheelY;
	        this.editor._emit(name, mouseEvent);
	    };

	    this.setState = function(state) {
	        this.state = state;
	    };

	    this.captureMouse = function(ev, mouseMoveHandler) {
	        this.x = ev.x;
	        this.y = ev.y;

	        this.isMousePressed = true;
	        var renderer = this.editor.renderer;
	        if (renderer.$keepTextAreaAtCursor)
	            renderer.$keepTextAreaAtCursor = null;

	        var self = this;
	        var onMouseMove = function(e) {
	            if (!e) return;
	            if (useragent.isWebKit && !e.which && self.releaseMouse)
	                return self.releaseMouse();

	            self.x = e.clientX;
	            self.y = e.clientY;
	            mouseMoveHandler && mouseMoveHandler(e);
	            self.mouseEvent = new MouseEvent(e, self.editor);
	            self.$mouseMoved = true;
	        };

	        var onCaptureEnd = function(e) {
	            clearInterval(timerId);
	            onCaptureInterval();
	            self[self.state + "End"] && self[self.state + "End"](e);
	            self.state = "";
	            if (renderer.$keepTextAreaAtCursor == null) {
	                renderer.$keepTextAreaAtCursor = true;
	                renderer.$moveTextAreaToCursor();
	            }
	            self.isMousePressed = false;
	            self.$onCaptureMouseMove = self.releaseMouse = null;
	            e && self.onMouseEvent("mouseup", e);
	        };

	        var onCaptureInterval = function() {
	            self[self.state] && self[self.state]();
	            self.$mouseMoved = false;
	        };

	        if (useragent.isOldIE && ev.domEvent.type == "dblclick") {
	            return setTimeout(function() {onCaptureEnd(ev);});
	        }

	        self.$onCaptureMouseMove = onMouseMove;
	        self.releaseMouse = event.capture(this.editor.container, onMouseMove, onCaptureEnd);
	        var timerId = setInterval(onCaptureInterval, 20);
	    };
	    this.releaseMouse = null;
	    this.cancelContextMenu = function() {
	        var stop = function(e) {
	            if (e && e.domEvent && e.domEvent.type != "contextmenu")
	                return;
	            this.editor.off("nativecontextmenu", stop);
	            if (e && e.domEvent)
	                event.stopEvent(e.domEvent);
	        }.bind(this);
	        setTimeout(stop, 10);
	        this.editor.on("nativecontextmenu", stop);
	    };
	}).call(MouseHandler.prototype);

	config.defineOptions(MouseHandler.prototype, "mouseHandler", {
	    scrollSpeed: {initialValue: 2},
	    dragDelay: {initialValue: (useragent.isMac ? 150 : 0)},
	    dragEnabled: {initialValue: true},
	    focusTimout: {initialValue: 0},
	    tooltipFollowsMouse: {initialValue: true}
	});


	exports.MouseHandler = MouseHandler;
	});

	ace.define("ace/mouse/fold_handler",["require","exports","module"], function(acequire, exports, module) {
	"use strict";

	function FoldHandler(editor) {

	    editor.on("click", function(e) {
	        var position = e.getDocumentPosition();
	        var session = editor.session;
	        var fold = session.getFoldAt(position.row, position.column, 1);
	        if (fold) {
	            if (e.getAccelKey())
	                session.removeFold(fold);
	            else
	                session.expandFold(fold);

	            e.stop();
	        }
	    });

	    editor.on("gutterclick", function(e) {
	        var gutterRegion = editor.renderer.$gutterLayer.getRegion(e);

	        if (gutterRegion == "foldWidgets") {
	            var row = e.getDocumentPosition().row;
	            var session = editor.session;
	            if (session.foldWidgets && session.foldWidgets[row])
	                editor.session.onFoldWidgetClick(row, e);
	            if (!editor.isFocused())
	                editor.focus();
	            e.stop();
	        }
	    });

	    editor.on("gutterdblclick", function(e) {
	        var gutterRegion = editor.renderer.$gutterLayer.getRegion(e);

	        if (gutterRegion == "foldWidgets") {
	            var row = e.getDocumentPosition().row;
	            var session = editor.session;
	            var data = session.getParentFoldRangeData(row, true);
	            var range = data.range || data.firstRange;

	            if (range) {
	                row = range.start.row;
	                var fold = session.getFoldAt(row, session.getLine(row).length, 1);

	                if (fold) {
	                    session.removeFold(fold);
	                } else {
	                    session.addFold("...", range);
	                    editor.renderer.scrollCursorIntoView({row: range.start.row, column: 0});
	                }
	            }
	            e.stop();
	        }
	    });
	}

	exports.FoldHandler = FoldHandler;

	});

	ace.define("ace/keyboard/keybinding",["require","exports","module","ace/lib/keys","ace/lib/event"], function(acequire, exports, module) {
	"use strict";

	var keyUtil  = acequire("../lib/keys");
	var event = acequire("../lib/event");

	var KeyBinding = function(editor) {
	    this.$editor = editor;
	    this.$data = {editor: editor};
	    this.$handlers = [];
	    this.setDefaultHandler(editor.commands);
	};

	(function() {
	    this.setDefaultHandler = function(kb) {
	        this.removeKeyboardHandler(this.$defaultHandler);
	        this.$defaultHandler = kb;
	        this.addKeyboardHandler(kb, 0);
	    };

	    this.setKeyboardHandler = function(kb) {
	        var h = this.$handlers;
	        if (h[h.length - 1] == kb)
	            return;

	        while (h[h.length - 1] && h[h.length - 1] != this.$defaultHandler)
	            this.removeKeyboardHandler(h[h.length - 1]);

	        this.addKeyboardHandler(kb, 1);
	    };

	    this.addKeyboardHandler = function(kb, pos) {
	        if (!kb)
	            return;
	        if (typeof kb == "function" && !kb.handleKeyboard)
	            kb.handleKeyboard = kb;
	        var i = this.$handlers.indexOf(kb);
	        if (i != -1)
	            this.$handlers.splice(i, 1);

	        if (pos == undefined)
	            this.$handlers.push(kb);
	        else
	            this.$handlers.splice(pos, 0, kb);

	        if (i == -1 && kb.attach)
	            kb.attach(this.$editor);
	    };

	    this.removeKeyboardHandler = function(kb) {
	        var i = this.$handlers.indexOf(kb);
	        if (i == -1)
	            return false;
	        this.$handlers.splice(i, 1);
	        kb.detach && kb.detach(this.$editor);
	        return true;
	    };

	    this.getKeyboardHandler = function() {
	        return this.$handlers[this.$handlers.length - 1];
	    };
	    
	    this.getStatusText = function() {
	        var data = this.$data;
	        var editor = data.editor;
	        return this.$handlers.map(function(h) {
	            return h.getStatusText && h.getStatusText(editor, data) || "";
	        }).filter(Boolean).join(" ");
	    };

	    this.$callKeyboardHandlers = function(hashId, keyString, keyCode, e) {
	        var toExecute;
	        var success = false;
	        var commands = this.$editor.commands;

	        for (var i = this.$handlers.length; i--;) {
	            toExecute = this.$handlers[i].handleKeyboard(
	                this.$data, hashId, keyString, keyCode, e
	            );
	            if (!toExecute || !toExecute.command)
	                continue;
	            if (toExecute.command == "null") {
	                success = true;
	            } else {
	                success = commands.exec(toExecute.command, this.$editor, toExecute.args, e);
	            }
	            if (success && e && hashId != -1 && 
	                toExecute.passEvent != true && toExecute.command.passEvent != true
	            ) {
	                event.stopEvent(e);
	            }
	            if (success)
	                break;
	        }
	        
	        if (!success && hashId == -1) {
	            toExecute = {command: "insertstring"};
	            success = commands.exec("insertstring", this.$editor, keyString);
	        }
	        
	        if (success && this.$editor._signal)
	            this.$editor._signal("keyboardActivity", toExecute);
	        
	        return success;
	    };

	    this.onCommandKey = function(e, hashId, keyCode) {
	        var keyString = keyUtil.keyCodeToString(keyCode);
	        this.$callKeyboardHandlers(hashId, keyString, keyCode, e);
	    };

	    this.onTextInput = function(text) {
	        this.$callKeyboardHandlers(-1, text);
	    };

	}).call(KeyBinding.prototype);

	exports.KeyBinding = KeyBinding;
	});

	ace.define("ace/range",["require","exports","module"], function(acequire, exports, module) {
	"use strict";
	var comparePoints = function(p1, p2) {
	    return p1.row - p2.row || p1.column - p2.column;
	};
	var Range = function(startRow, startColumn, endRow, endColumn) {
	    this.start = {
	        row: startRow,
	        column: startColumn
	    };

	    this.end = {
	        row: endRow,
	        column: endColumn
	    };
	};

	(function() {
	    this.isEqual = function(range) {
	        return this.start.row === range.start.row &&
	            this.end.row === range.end.row &&
	            this.start.column === range.start.column &&
	            this.end.column === range.end.column;
	    };
	    this.toString = function() {
	        return ("Range: [" + this.start.row + "/" + this.start.column +
	            "] -> [" + this.end.row + "/" + this.end.column + "]");
	    };

	    this.contains = function(row, column) {
	        return this.compare(row, column) == 0;
	    };
	    this.compareRange = function(range) {
	        var cmp,
	            end = range.end,
	            start = range.start;

	        cmp = this.compare(end.row, end.column);
	        if (cmp == 1) {
	            cmp = this.compare(start.row, start.column);
	            if (cmp == 1) {
	                return 2;
	            } else if (cmp == 0) {
	                return 1;
	            } else {
	                return 0;
	            }
	        } else if (cmp == -1) {
	            return -2;
	        } else {
	            cmp = this.compare(start.row, start.column);
	            if (cmp == -1) {
	                return -1;
	            } else if (cmp == 1) {
	                return 42;
	            } else {
	                return 0;
	            }
	        }
	    };
	    this.comparePoint = function(p) {
	        return this.compare(p.row, p.column);
	    };
	    this.containsRange = function(range) {
	        return this.comparePoint(range.start) == 0 && this.comparePoint(range.end) == 0;
	    };
	    this.intersects = function(range) {
	        var cmp = this.compareRange(range);
	        return (cmp == -1 || cmp == 0 || cmp == 1);
	    };
	    this.isEnd = function(row, column) {
	        return this.end.row == row && this.end.column == column;
	    };
	    this.isStart = function(row, column) {
	        return this.start.row == row && this.start.column == column;
	    };
	    this.setStart = function(row, column) {
	        if (typeof row == "object") {
	            this.start.column = row.column;
	            this.start.row = row.row;
	        } else {
	            this.start.row = row;
	            this.start.column = column;
	        }
	    };
	    this.setEnd = function(row, column) {
	        if (typeof row == "object") {
	            this.end.column = row.column;
	            this.end.row = row.row;
	        } else {
	            this.end.row = row;
	            this.end.column = column;
	        }
	    };
	    this.inside = function(row, column) {
	        if (this.compare(row, column) == 0) {
	            if (this.isEnd(row, column) || this.isStart(row, column)) {
	                return false;
	            } else {
	                return true;
	            }
	        }
	        return false;
	    };
	    this.insideStart = function(row, column) {
	        if (this.compare(row, column) == 0) {
	            if (this.isEnd(row, column)) {
	                return false;
	            } else {
	                return true;
	            }
	        }
	        return false;
	    };
	    this.insideEnd = function(row, column) {
	        if (this.compare(row, column) == 0) {
	            if (this.isStart(row, column)) {
	                return false;
	            } else {
	                return true;
	            }
	        }
	        return false;
	    };
	    this.compare = function(row, column) {
	        if (!this.isMultiLine()) {
	            if (row === this.start.row) {
	                return column < this.start.column ? -1 : (column > this.end.column ? 1 : 0);
	            }
	        }

	        if (row < this.start.row)
	            return -1;

	        if (row > this.end.row)
	            return 1;

	        if (this.start.row === row)
	            return column >= this.start.column ? 0 : -1;

	        if (this.end.row === row)
	            return column <= this.end.column ? 0 : 1;

	        return 0;
	    };
	    this.compareStart = function(row, column) {
	        if (this.start.row == row && this.start.column == column) {
	            return -1;
	        } else {
	            return this.compare(row, column);
	        }
	    };
	    this.compareEnd = function(row, column) {
	        if (this.end.row == row && this.end.column == column) {
	            return 1;
	        } else {
	            return this.compare(row, column);
	        }
	    };
	    this.compareInside = function(row, column) {
	        if (this.end.row == row && this.end.column == column) {
	            return 1;
	        } else if (this.start.row == row && this.start.column == column) {
	            return -1;
	        } else {
	            return this.compare(row, column);
	        }
	    };
	    this.clipRows = function(firstRow, lastRow) {
	        if (this.end.row > lastRow)
	            var end = {row: lastRow + 1, column: 0};
	        else if (this.end.row < firstRow)
	            var end = {row: firstRow, column: 0};

	        if (this.start.row > lastRow)
	            var start = {row: lastRow + 1, column: 0};
	        else if (this.start.row < firstRow)
	            var start = {row: firstRow, column: 0};

	        return Range.fromPoints(start || this.start, end || this.end);
	    };
	    this.extend = function(row, column) {
	        var cmp = this.compare(row, column);

	        if (cmp == 0)
	            return this;
	        else if (cmp == -1)
	            var start = {row: row, column: column};
	        else
	            var end = {row: row, column: column};

	        return Range.fromPoints(start || this.start, end || this.end);
	    };

	    this.isEmpty = function() {
	        return (this.start.row === this.end.row && this.start.column === this.end.column);
	    };
	    this.isMultiLine = function() {
	        return (this.start.row !== this.end.row);
	    };
	    this.clone = function() {
	        return Range.fromPoints(this.start, this.end);
	    };
	    this.collapseRows = function() {
	        if (this.end.column == 0)
	            return new Range(this.start.row, 0, Math.max(this.start.row, this.end.row-1), 0)
	        else
	            return new Range(this.start.row, 0, this.end.row, 0)
	    };
	    this.toScreenRange = function(session) {
	        var screenPosStart = session.documentToScreenPosition(this.start);
	        var screenPosEnd = session.documentToScreenPosition(this.end);

	        return new Range(
	            screenPosStart.row, screenPosStart.column,
	            screenPosEnd.row, screenPosEnd.column
	        );
	    };
	    this.moveBy = function(row, column) {
	        this.start.row += row;
	        this.start.column += column;
	        this.end.row += row;
	        this.end.column += column;
	    };

	}).call(Range.prototype);
	Range.fromPoints = function(start, end) {
	    return new Range(start.row, start.column, end.row, end.column);
	};
	Range.comparePoints = comparePoints;

	Range.comparePoints = function(p1, p2) {
	    return p1.row - p2.row || p1.column - p2.column;
	};


	exports.Range = Range;
	});

	ace.define("ace/selection",["require","exports","module","ace/lib/oop","ace/lib/lang","ace/lib/event_emitter","ace/range"], function(acequire, exports, module) {
	"use strict";

	var oop = acequire("./lib/oop");
	var lang = acequire("./lib/lang");
	var EventEmitter = acequire("./lib/event_emitter").EventEmitter;
	var Range = acequire("./range").Range;
	var Selection = function(session) {
	    this.session = session;
	    this.doc = session.getDocument();

	    this.clearSelection();
	    this.lead = this.selectionLead = this.doc.createAnchor(0, 0);
	    this.anchor = this.selectionAnchor = this.doc.createAnchor(0, 0);

	    var self = this;
	    this.lead.on("change", function(e) {
	        self._emit("changeCursor");
	        if (!self.$isEmpty)
	            self._emit("changeSelection");
	        if (!self.$keepDesiredColumnOnChange && e.old.column != e.value.column)
	            self.$desiredColumn = null;
	    });

	    this.selectionAnchor.on("change", function() {
	        if (!self.$isEmpty)
	            self._emit("changeSelection");
	    });
	};

	(function() {

	    oop.implement(this, EventEmitter);
	    this.isEmpty = function() {
	        return (this.$isEmpty || (
	            this.anchor.row == this.lead.row &&
	            this.anchor.column == this.lead.column
	        ));
	    };
	    this.isMultiLine = function() {
	        if (this.isEmpty()) {
	            return false;
	        }

	        return this.getRange().isMultiLine();
	    };
	    this.getCursor = function() {
	        return this.lead.getPosition();
	    };
	    this.setSelectionAnchor = function(row, column) {
	        this.anchor.setPosition(row, column);

	        if (this.$isEmpty) {
	            this.$isEmpty = false;
	            this._emit("changeSelection");
	        }
	    };
	    this.getSelectionAnchor = function() {
	        if (this.$isEmpty)
	            return this.getSelectionLead();
	        else
	            return this.anchor.getPosition();
	    };
	    this.getSelectionLead = function() {
	        return this.lead.getPosition();
	    };
	    this.shiftSelection = function(columns) {
	        if (this.$isEmpty) {
	            this.moveCursorTo(this.lead.row, this.lead.column + columns);
	            return;
	        }

	        var anchor = this.getSelectionAnchor();
	        var lead = this.getSelectionLead();

	        var isBackwards = this.isBackwards();

	        if (!isBackwards || anchor.column !== 0)
	            this.setSelectionAnchor(anchor.row, anchor.column + columns);

	        if (isBackwards || lead.column !== 0) {
	            this.$moveSelection(function() {
	                this.moveCursorTo(lead.row, lead.column + columns);
	            });
	        }
	    };
	    this.isBackwards = function() {
	        var anchor = this.anchor;
	        var lead = this.lead;
	        return (anchor.row > lead.row || (anchor.row == lead.row && anchor.column > lead.column));
	    };
	    this.getRange = function() {
	        var anchor = this.anchor;
	        var lead = this.lead;

	        if (this.isEmpty())
	            return Range.fromPoints(lead, lead);

	        if (this.isBackwards()) {
	            return Range.fromPoints(lead, anchor);
	        }
	        else {
	            return Range.fromPoints(anchor, lead);
	        }
	    };
	    this.clearSelection = function() {
	        if (!this.$isEmpty) {
	            this.$isEmpty = true;
	            this._emit("changeSelection");
	        }
	    };
	    this.selectAll = function() {
	        var lastRow = this.doc.getLength() - 1;
	        this.setSelectionAnchor(0, 0);
	        this.moveCursorTo(lastRow, this.doc.getLine(lastRow).length);
	    };
	    this.setRange =
	    this.setSelectionRange = function(range, reverse) {
	        if (reverse) {
	            this.setSelectionAnchor(range.end.row, range.end.column);
	            this.selectTo(range.start.row, range.start.column);
	        } else {
	            this.setSelectionAnchor(range.start.row, range.start.column);
	            this.selectTo(range.end.row, range.end.column);
	        }
	        if (this.getRange().isEmpty())
	            this.$isEmpty = true;
	        this.$desiredColumn = null;
	    };

	    this.$moveSelection = function(mover) {
	        var lead = this.lead;
	        if (this.$isEmpty)
	            this.setSelectionAnchor(lead.row, lead.column);

	        mover.call(this);
	    };
	    this.selectTo = function(row, column) {
	        this.$moveSelection(function() {
	            this.moveCursorTo(row, column);
	        });
	    };
	    this.selectToPosition = function(pos) {
	        this.$moveSelection(function() {
	            this.moveCursorToPosition(pos);
	        });
	    };
	    this.moveTo = function(row, column) {
	        this.clearSelection();
	        this.moveCursorTo(row, column);
	    };
	    this.moveToPosition = function(pos) {
	        this.clearSelection();
	        this.moveCursorToPosition(pos);
	    };
	    this.selectUp = function() {
	        this.$moveSelection(this.moveCursorUp);
	    };
	    this.selectDown = function() {
	        this.$moveSelection(this.moveCursorDown);
	    };
	    this.selectRight = function() {
	        this.$moveSelection(this.moveCursorRight);
	    };
	    this.selectLeft = function() {
	        this.$moveSelection(this.moveCursorLeft);
	    };
	    this.selectLineStart = function() {
	        this.$moveSelection(this.moveCursorLineStart);
	    };
	    this.selectLineEnd = function() {
	        this.$moveSelection(this.moveCursorLineEnd);
	    };
	    this.selectFileEnd = function() {
	        this.$moveSelection(this.moveCursorFileEnd);
	    };
	    this.selectFileStart = function() {
	        this.$moveSelection(this.moveCursorFileStart);
	    };
	    this.selectWordRight = function() {
	        this.$moveSelection(this.moveCursorWordRight);
	    };
	    this.selectWordLeft = function() {
	        this.$moveSelection(this.moveCursorWordLeft);
	    };
	    this.getWordRange = function(row, column) {
	        if (typeof column == "undefined") {
	            var cursor = row || this.lead;
	            row = cursor.row;
	            column = cursor.column;
	        }
	        return this.session.getWordRange(row, column);
	    };
	    this.selectWord = function() {
	        this.setSelectionRange(this.getWordRange());
	    };
	    this.selectAWord = function() {
	        var cursor = this.getCursor();
	        var range = this.session.getAWordRange(cursor.row, cursor.column);
	        this.setSelectionRange(range);
	    };

	    this.getLineRange = function(row, excludeLastChar) {
	        var rowStart = typeof row == "number" ? row : this.lead.row;
	        var rowEnd;

	        var foldLine = this.session.getFoldLine(rowStart);
	        if (foldLine) {
	            rowStart = foldLine.start.row;
	            rowEnd = foldLine.end.row;
	        } else {
	            rowEnd = rowStart;
	        }
	        if (excludeLastChar === true)
	            return new Range(rowStart, 0, rowEnd, this.session.getLine(rowEnd).length);
	        else
	            return new Range(rowStart, 0, rowEnd + 1, 0);
	    };
	    this.selectLine = function() {
	        this.setSelectionRange(this.getLineRange());
	    };
	    this.moveCursorUp = function() {
	        this.moveCursorBy(-1, 0);
	    };
	    this.moveCursorDown = function() {
	        this.moveCursorBy(1, 0);
	    };
	    this.moveCursorLeft = function() {
	        var cursor = this.lead.getPosition(),
	            fold;

	        if (fold = this.session.getFoldAt(cursor.row, cursor.column, -1)) {
	            this.moveCursorTo(fold.start.row, fold.start.column);
	        } else if (cursor.column === 0) {
	            if (cursor.row > 0) {
	                this.moveCursorTo(cursor.row - 1, this.doc.getLine(cursor.row - 1).length);
	            }
	        }
	        else {
	            var tabSize = this.session.getTabSize();
	            if (this.session.isTabStop(cursor) && this.doc.getLine(cursor.row).slice(cursor.column-tabSize, cursor.column).split(" ").length-1 == tabSize)
	                this.moveCursorBy(0, -tabSize);
	            else
	                this.moveCursorBy(0, -1);
	        }
	    };
	    this.moveCursorRight = function() {
	        var cursor = this.lead.getPosition(),
	            fold;
	        if (fold = this.session.getFoldAt(cursor.row, cursor.column, 1)) {
	            this.moveCursorTo(fold.end.row, fold.end.column);
	        }
	        else if (this.lead.column == this.doc.getLine(this.lead.row).length) {
	            if (this.lead.row < this.doc.getLength() - 1) {
	                this.moveCursorTo(this.lead.row + 1, 0);
	            }
	        }
	        else {
	            var tabSize = this.session.getTabSize();
	            var cursor = this.lead;
	            if (this.session.isTabStop(cursor) && this.doc.getLine(cursor.row).slice(cursor.column, cursor.column+tabSize).split(" ").length-1 == tabSize)
	                this.moveCursorBy(0, tabSize);
	            else
	                this.moveCursorBy(0, 1);
	        }
	    };
	    this.moveCursorLineStart = function() {
	        var row = this.lead.row;
	        var column = this.lead.column;
	        var screenRow = this.session.documentToScreenRow(row, column);
	        var firstColumnPosition = this.session.screenToDocumentPosition(screenRow, 0);
	        var beforeCursor = this.session.getDisplayLine(
	            row, null, firstColumnPosition.row,
	            firstColumnPosition.column
	        );

	        var leadingSpace = beforeCursor.match(/^\s*/);
	        if (leadingSpace[0].length != column && !this.session.$useEmacsStyleLineStart)
	            firstColumnPosition.column += leadingSpace[0].length;
	        this.moveCursorToPosition(firstColumnPosition);
	    };
	    this.moveCursorLineEnd = function() {
	        var lead = this.lead;
	        var lineEnd = this.session.getDocumentLastRowColumnPosition(lead.row, lead.column);
	        if (this.lead.column == lineEnd.column) {
	            var line = this.session.getLine(lineEnd.row);
	            if (lineEnd.column == line.length) {
	                var textEnd = line.search(/\s+$/);
	                if (textEnd > 0)
	                    lineEnd.column = textEnd;
	            }
	        }

	        this.moveCursorTo(lineEnd.row, lineEnd.column);
	    };
	    this.moveCursorFileEnd = function() {
	        var row = this.doc.getLength() - 1;
	        var column = this.doc.getLine(row).length;
	        this.moveCursorTo(row, column);
	    };
	    this.moveCursorFileStart = function() {
	        this.moveCursorTo(0, 0);
	    };
	    this.moveCursorLongWordRight = function() {
	        var row = this.lead.row;
	        var column = this.lead.column;
	        var line = this.doc.getLine(row);
	        var rightOfCursor = line.substring(column);

	        var match;
	        this.session.nonTokenRe.lastIndex = 0;
	        this.session.tokenRe.lastIndex = 0;
	        var fold = this.session.getFoldAt(row, column, 1);
	        if (fold) {
	            this.moveCursorTo(fold.end.row, fold.end.column);
	            return;
	        }
	        if (match = this.session.nonTokenRe.exec(rightOfCursor)) {
	            column += this.session.nonTokenRe.lastIndex;
	            this.session.nonTokenRe.lastIndex = 0;
	            rightOfCursor = line.substring(column);
	        }
	        if (column >= line.length) {
	            this.moveCursorTo(row, line.length);
	            this.moveCursorRight();
	            if (row < this.doc.getLength() - 1)
	                this.moveCursorWordRight();
	            return;
	        }
	        if (match = this.session.tokenRe.exec(rightOfCursor)) {
	            column += this.session.tokenRe.lastIndex;
	            this.session.tokenRe.lastIndex = 0;
	        }

	        this.moveCursorTo(row, column);
	    };
	    this.moveCursorLongWordLeft = function() {
	        var row = this.lead.row;
	        var column = this.lead.column;
	        var fold;
	        if (fold = this.session.getFoldAt(row, column, -1)) {
	            this.moveCursorTo(fold.start.row, fold.start.column);
	            return;
	        }

	        var str = this.session.getFoldStringAt(row, column, -1);
	        if (str == null) {
	            str = this.doc.getLine(row).substring(0, column);
	        }

	        var leftOfCursor = lang.stringReverse(str);
	        var match;
	        this.session.nonTokenRe.lastIndex = 0;
	        this.session.tokenRe.lastIndex = 0;
	        if (match = this.session.nonTokenRe.exec(leftOfCursor)) {
	            column -= this.session.nonTokenRe.lastIndex;
	            leftOfCursor = leftOfCursor.slice(this.session.nonTokenRe.lastIndex);
	            this.session.nonTokenRe.lastIndex = 0;
	        }
	        if (column <= 0) {
	            this.moveCursorTo(row, 0);
	            this.moveCursorLeft();
	            if (row > 0)
	                this.moveCursorWordLeft();
	            return;
	        }
	        if (match = this.session.tokenRe.exec(leftOfCursor)) {
	            column -= this.session.tokenRe.lastIndex;
	            this.session.tokenRe.lastIndex = 0;
	        }

	        this.moveCursorTo(row, column);
	    };

	    this.$shortWordEndIndex = function(rightOfCursor) {
	        var match, index = 0, ch;
	        var whitespaceRe = /\s/;
	        var tokenRe = this.session.tokenRe;

	        tokenRe.lastIndex = 0;
	        if (match = this.session.tokenRe.exec(rightOfCursor)) {
	            index = this.session.tokenRe.lastIndex;
	        } else {
	            while ((ch = rightOfCursor[index]) && whitespaceRe.test(ch))
	                index ++;

	            if (index < 1) {
	                tokenRe.lastIndex = 0;
	                 while ((ch = rightOfCursor[index]) && !tokenRe.test(ch)) {
	                    tokenRe.lastIndex = 0;
	                    index ++;
	                    if (whitespaceRe.test(ch)) {
	                        if (index > 2) {
	                            index--;
	                            break;
	                        } else {
	                            while ((ch = rightOfCursor[index]) && whitespaceRe.test(ch))
	                                index ++;
	                            if (index > 2)
	                                break;
	                        }
	                    }
	                }
	            }
	        }
	        tokenRe.lastIndex = 0;

	        return index;
	    };

	    this.moveCursorShortWordRight = function() {
	        var row = this.lead.row;
	        var column = this.lead.column;
	        var line = this.doc.getLine(row);
	        var rightOfCursor = line.substring(column);

	        var fold = this.session.getFoldAt(row, column, 1);
	        if (fold)
	            return this.moveCursorTo(fold.end.row, fold.end.column);

	        if (column == line.length) {
	            var l = this.doc.getLength();
	            do {
	                row++;
	                rightOfCursor = this.doc.getLine(row);
	            } while (row < l && /^\s*$/.test(rightOfCursor));

	            if (!/^\s+/.test(rightOfCursor))
	                rightOfCursor = "";
	            column = 0;
	        }

	        var index = this.$shortWordEndIndex(rightOfCursor);

	        this.moveCursorTo(row, column + index);
	    };

	    this.moveCursorShortWordLeft = function() {
	        var row = this.lead.row;
	        var column = this.lead.column;

	        var fold;
	        if (fold = this.session.getFoldAt(row, column, -1))
	            return this.moveCursorTo(fold.start.row, fold.start.column);

	        var line = this.session.getLine(row).substring(0, column);
	        if (column === 0) {
	            do {
	                row--;
	                line = this.doc.getLine(row);
	            } while (row > 0 && /^\s*$/.test(line));

	            column = line.length;
	            if (!/\s+$/.test(line))
	                line = "";
	        }

	        var leftOfCursor = lang.stringReverse(line);
	        var index = this.$shortWordEndIndex(leftOfCursor);

	        return this.moveCursorTo(row, column - index);
	    };

	    this.moveCursorWordRight = function() {
	        if (this.session.$selectLongWords)
	            this.moveCursorLongWordRight();
	        else
	            this.moveCursorShortWordRight();
	    };

	    this.moveCursorWordLeft = function() {
	        if (this.session.$selectLongWords)
	            this.moveCursorLongWordLeft();
	        else
	            this.moveCursorShortWordLeft();
	    };
	    this.moveCursorBy = function(rows, chars) {
	        var screenPos = this.session.documentToScreenPosition(
	            this.lead.row,
	            this.lead.column
	        );

	        if (chars === 0) {
	            if (this.$desiredColumn)
	                screenPos.column = this.$desiredColumn;
	            else
	                this.$desiredColumn = screenPos.column;
	        }

	        var docPos = this.session.screenToDocumentPosition(screenPos.row + rows, screenPos.column);
	        
	        if (rows !== 0 && chars === 0 && docPos.row === this.lead.row && docPos.column === this.lead.column) {
	            if (this.session.lineWidgets && this.session.lineWidgets[docPos.row]) {
	                if (docPos.row > 0 || rows > 0)
	                    docPos.row++;
	            }
	        }
	        this.moveCursorTo(docPos.row, docPos.column + chars, chars === 0);
	    };
	    this.moveCursorToPosition = function(position) {
	        this.moveCursorTo(position.row, position.column);
	    };
	    this.moveCursorTo = function(row, column, keepDesiredColumn) {
	        var fold = this.session.getFoldAt(row, column, 1);
	        if (fold) {
	            row = fold.start.row;
	            column = fold.start.column;
	        }

	        this.$keepDesiredColumnOnChange = true;
	        this.lead.setPosition(row, column);
	        this.$keepDesiredColumnOnChange = false;

	        if (!keepDesiredColumn)
	            this.$desiredColumn = null;
	    };
	    this.moveCursorToScreen = function(row, column, keepDesiredColumn) {
	        var pos = this.session.screenToDocumentPosition(row, column);
	        this.moveCursorTo(pos.row, pos.column, keepDesiredColumn);
	    };
	    this.detach = function() {
	        this.lead.detach();
	        this.anchor.detach();
	        this.session = this.doc = null;
	    };

	    this.fromOrientedRange = function(range) {
	        this.setSelectionRange(range, range.cursor == range.start);
	        this.$desiredColumn = range.desiredColumn || this.$desiredColumn;
	    };

	    this.toOrientedRange = function(range) {
	        var r = this.getRange();
	        if (range) {
	            range.start.column = r.start.column;
	            range.start.row = r.start.row;
	            range.end.column = r.end.column;
	            range.end.row = r.end.row;
	        } else {
	            range = r;
	        }

	        range.cursor = this.isBackwards() ? range.start : range.end;
	        range.desiredColumn = this.$desiredColumn;
	        return range;
	    };
	    this.getRangeOfMovements = function(func) {
	        var start = this.getCursor();
	        try {
	            func(this);
	            var end = this.getCursor();
	            return Range.fromPoints(start,end);
	        } catch(e) {
	            return Range.fromPoints(start,start);
	        } finally {
	            this.moveCursorToPosition(start);
	        }
	    };

	    this.toJSON = function() {
	        if (this.rangeCount) {
	            var data = this.ranges.map(function(r) {
	                var r1 = r.clone();
	                r1.isBackwards = r.cursor == r.start;
	                return r1;
	            });
	        } else {
	            var data = this.getRange();
	            data.isBackwards = this.isBackwards();
	        }
	        return data;
	    };

	    this.fromJSON = function(data) {
	        if (data.start == undefined) {
	            if (this.rangeList) {
	                this.toSingleRange(data[0]);
	                for (var i = data.length; i--; ) {
	                    var r = Range.fromPoints(data[i].start, data[i].end);
	                    if (data[i].isBackwards)
	                        r.cursor = r.start;
	                    this.addRange(r, true);
	                }
	                return;
	            } else
	                data = data[0];
	        }
	        if (this.rangeList)
	            this.toSingleRange(data);
	        this.setSelectionRange(data, data.isBackwards);
	    };

	    this.isEqual = function(data) {
	        if ((data.length || this.rangeCount) && data.length != this.rangeCount)
	            return false;
	        if (!data.length || !this.ranges)
	            return this.getRange().isEqual(data);

	        for (var i = this.ranges.length; i--; ) {
	            if (!this.ranges[i].isEqual(data[i]))
	                return false;
	        }
	        return true;
	    };

	}).call(Selection.prototype);

	exports.Selection = Selection;
	});

	ace.define("ace/tokenizer",["require","exports","module","ace/config"], function(acequire, exports, module) {
	"use strict";

	var config = acequire("./config");
	var MAX_TOKEN_COUNT = 2000;
	var Tokenizer = function(rules) {
	    this.states = rules;

	    this.regExps = {};
	    this.matchMappings = {};
	    for (var key in this.states) {
	        var state = this.states[key];
	        var ruleRegExps = [];
	        var matchTotal = 0;
	        var mapping = this.matchMappings[key] = {defaultToken: "text"};
	        var flag = "g";

	        var splitterRurles = [];
	        for (var i = 0; i < state.length; i++) {
	            var rule = state[i];
	            if (rule.defaultToken)
	                mapping.defaultToken = rule.defaultToken;
	            if (rule.caseInsensitive)
	                flag = "gi";
	            if (rule.regex == null)
	                continue;

	            if (rule.regex instanceof RegExp)
	                rule.regex = rule.regex.toString().slice(1, -1);
	            var adjustedregex = rule.regex;
	            var matchcount = new RegExp("(?:(" + adjustedregex + ")|(.))").exec("a").length - 2;
	            if (Array.isArray(rule.token)) {
	                if (rule.token.length == 1 || matchcount == 1) {
	                    rule.token = rule.token[0];
	                } else if (matchcount - 1 != rule.token.length) {
	                    this.reportError("number of classes and regexp groups doesn't match", { 
	                        rule: rule,
	                        groupCount: matchcount - 1
	                    });
	                    rule.token = rule.token[0];
	                } else {
	                    rule.tokenArray = rule.token;
	                    rule.token = null;
	                    rule.onMatch = this.$arrayTokens;
	                }
	            } else if (typeof rule.token == "function" && !rule.onMatch) {
	                if (matchcount > 1)
	                    rule.onMatch = this.$applyToken;
	                else
	                    rule.onMatch = rule.token;
	            }

	            if (matchcount > 1) {
	                if (/\\\d/.test(rule.regex)) {
	                    adjustedregex = rule.regex.replace(/\\([0-9]+)/g, function(match, digit) {
	                        return "\\" + (parseInt(digit, 10) + matchTotal + 1);
	                    });
	                } else {
	                    matchcount = 1;
	                    adjustedregex = this.removeCapturingGroups(rule.regex);
	                }
	                if (!rule.splitRegex && typeof rule.token != "string")
	                    splitterRurles.push(rule); // flag will be known only at the very end
	            }

	            mapping[matchTotal] = i;
	            matchTotal += matchcount;

	            ruleRegExps.push(adjustedregex);
	            if (!rule.onMatch)
	                rule.onMatch = null;
	        }
	        
	        if (!ruleRegExps.length) {
	            mapping[0] = 0;
	            ruleRegExps.push("$");
	        }
	        
	        splitterRurles.forEach(function(rule) {
	            rule.splitRegex = this.createSplitterRegexp(rule.regex, flag);
	        }, this);

	        this.regExps[key] = new RegExp("(" + ruleRegExps.join(")|(") + ")|($)", flag);
	    }
	};

	(function() {
	    this.$setMaxTokenCount = function(m) {
	        MAX_TOKEN_COUNT = m | 0;
	    };
	    
	    this.$applyToken = function(str) {
	        var values = this.splitRegex.exec(str).slice(1);
	        var types = this.token.apply(this, values);
	        if (typeof types === "string")
	            return [{type: types, value: str}];

	        var tokens = [];
	        for (var i = 0, l = types.length; i < l; i++) {
	            if (values[i])
	                tokens[tokens.length] = {
	                    type: types[i],
	                    value: values[i]
	                };
	        }
	        return tokens;
	    };

	    this.$arrayTokens = function(str) {
	        if (!str)
	            return [];
	        var values = this.splitRegex.exec(str);
	        if (!values)
	            return "text";
	        var tokens = [];
	        var types = this.tokenArray;
	        for (var i = 0, l = types.length; i < l; i++) {
	            if (values[i + 1])
	                tokens[tokens.length] = {
	                    type: types[i],
	                    value: values[i + 1]
	                };
	        }
	        return tokens;
	    };

	    this.removeCapturingGroups = function(src) {
	        var r = src.replace(
	            /\[(?:\\.|[^\]])*?\]|\\.|\(\?[:=!]|(\()/g,
	            function(x, y) {return y ? "(?:" : x;}
	        );
	        return r;
	    };

	    this.createSplitterRegexp = function(src, flag) {
	        if (src.indexOf("(?=") != -1) {
	            var stack = 0;
	            var inChClass = false;
	            var lastCapture = {};
	            src.replace(/(\\.)|(\((?:\?[=!])?)|(\))|([\[\]])/g, function(
	                m, esc, parenOpen, parenClose, square, index
	            ) {
	                if (inChClass) {
	                    inChClass = square != "]";
	                } else if (square) {
	                    inChClass = true;
	                } else if (parenClose) {
	                    if (stack == lastCapture.stack) {
	                        lastCapture.end = index+1;
	                        lastCapture.stack = -1;
	                    }
	                    stack--;
	                } else if (parenOpen) {
	                    stack++;
	                    if (parenOpen.length != 1) {
	                        lastCapture.stack = stack
	                        lastCapture.start = index;
	                    }
	                }
	                return m;
	            });

	            if (lastCapture.end != null && /^\)*$/.test(src.substr(lastCapture.end)))
	                src = src.substring(0, lastCapture.start) + src.substr(lastCapture.end);
	        }
	        if (src.charAt(0) != "^") src = "^" + src;
	        if (src.charAt(src.length - 1) != "$") src += "$";
	        
	        return new RegExp(src, (flag||"").replace("g", ""));
	    };
	    this.getLineTokens = function(line, startState) {
	        if (startState && typeof startState != "string") {
	            var stack = startState.slice(0);
	            startState = stack[0];
	            if (startState === "#tmp") {
	                stack.shift()
	                startState = stack.shift()
	            }
	        } else
	            var stack = [];

	        var currentState = startState || "start";
	        var state = this.states[currentState];
	        if (!state) {
	            currentState = "start";
	            state = this.states[currentState];
	        }
	        var mapping = this.matchMappings[currentState];
	        var re = this.regExps[currentState];
	        re.lastIndex = 0;

	        var match, tokens = [];
	        var lastIndex = 0;
	        var matchAttempts = 0;

	        var token = {type: null, value: ""};

	        while (match = re.exec(line)) {
	            var type = mapping.defaultToken;
	            var rule = null;
	            var value = match[0];
	            var index = re.lastIndex;

	            if (index - value.length > lastIndex) {
	                var skipped = line.substring(lastIndex, index - value.length);
	                if (token.type == type) {
	                    token.value += skipped;
	                } else {
	                    if (token.type)
	                        tokens.push(token);
	                    token = {type: type, value: skipped};
	                }
	            }

	            for (var i = 0; i < match.length-2; i++) {
	                if (match[i + 1] === undefined)
	                    continue;

	                rule = state[mapping[i]];

	                if (rule.onMatch)
	                    type = rule.onMatch(value, currentState, stack);
	                else
	                    type = rule.token;

	                if (rule.next) {
	                    if (typeof rule.next == "string") {
	                        currentState = rule.next;
	                    } else {
	                        currentState = rule.next(currentState, stack);
	                    }
	                    
	                    state = this.states[currentState];
	                    if (!state) {
	                        this.reportError("state doesn't exist", currentState);
	                        currentState = "start";
	                        state = this.states[currentState];
	                    }
	                    mapping = this.matchMappings[currentState];
	                    lastIndex = index;
	                    re = this.regExps[currentState];
	                    re.lastIndex = index;
	                }
	                break;
	            }

	            if (value) {
	                if (typeof type === "string") {
	                    if ((!rule || rule.merge !== false) && token.type === type) {
	                        token.value += value;
	                    } else {
	                        if (token.type)
	                            tokens.push(token);
	                        token = {type: type, value: value};
	                    }
	                } else if (type) {
	                    if (token.type)
	                        tokens.push(token);
	                    token = {type: null, value: ""};
	                    for (var i = 0; i < type.length; i++)
	                        tokens.push(type[i]);
	                }
	            }

	            if (lastIndex == line.length)
	                break;

	            lastIndex = index;

	            if (matchAttempts++ > MAX_TOKEN_COUNT) {
	                if (matchAttempts > 2 * line.length) {
	                    this.reportError("infinite loop with in ace tokenizer", {
	                        startState: startState,
	                        line: line
	                    });
	                }
	                while (lastIndex < line.length) {
	                    if (token.type)
	                        tokens.push(token);
	                    token = {
	                        value: line.substring(lastIndex, lastIndex += 2000),
	                        type: "overflow"
	                    };
	                }
	                currentState = "start";
	                stack = [];
	                break;
	            }
	        }

	        if (token.type)
	            tokens.push(token);
	        
	        if (stack.length > 1) {
	            if (stack[0] !== currentState)
	                stack.unshift("#tmp", currentState);
	        }
	        return {
	            tokens : tokens,
	            state : stack.length ? stack : currentState
	        };
	    };
	    
	    this.reportError = config.reportError;
	    
	}).call(Tokenizer.prototype);

	exports.Tokenizer = Tokenizer;
	});

	ace.define("ace/mode/text_highlight_rules",["require","exports","module","ace/lib/lang"], function(acequire, exports, module) {
	"use strict";

	var lang = acequire("../lib/lang");

	var TextHighlightRules = function() {

	    this.$rules = {
	        "start" : [{
	            token : "empty_line",
	            regex : '^$'
	        }, {
	            defaultToken : "text"
	        }]
	    };
	};

	(function() {

	    this.addRules = function(rules, prefix) {
	        if (!prefix) {
	            for (var key in rules)
	                this.$rules[key] = rules[key];
	            return;
	        }
	        for (var key in rules) {
	            var state = rules[key];
	            for (var i = 0; i < state.length; i++) {
	                var rule = state[i];
	                if (rule.next || rule.onMatch) {
	                    if (typeof rule.next == "string") {
	                        if (rule.next.indexOf(prefix) !== 0)
	                            rule.next = prefix + rule.next;
	                    }
	                    if (rule.nextState && rule.nextState.indexOf(prefix) !== 0)
	                        rule.nextState = prefix + rule.nextState;
	                }
	            }
	            this.$rules[prefix + key] = state;
	        }
	    };

	    this.getRules = function() {
	        return this.$rules;
	    };

	    this.embedRules = function (HighlightRules, prefix, escapeRules, states, append) {
	        var embedRules = typeof HighlightRules == "function"
	            ? new HighlightRules().getRules()
	            : HighlightRules;
	        if (states) {
	            for (var i = 0; i < states.length; i++)
	                states[i] = prefix + states[i];
	        } else {
	            states = [];
	            for (var key in embedRules)
	                states.push(prefix + key);
	        }

	        this.addRules(embedRules, prefix);

	        if (escapeRules) {
	            var addRules = Array.prototype[append ? "push" : "unshift"];
	            for (var i = 0; i < states.length; i++)
	                addRules.apply(this.$rules[states[i]], lang.deepCopy(escapeRules));
	        }

	        if (!this.$embeds)
	            this.$embeds = [];
	        this.$embeds.push(prefix);
	    };

	    this.getEmbeds = function() {
	        return this.$embeds;
	    };

	    var pushState = function(currentState, stack) {
	        if (currentState != "start" || stack.length)
	            stack.unshift(this.nextState, currentState);
	        return this.nextState;
	    };
	    var popState = function(currentState, stack) {
	        stack.shift();
	        return stack.shift() || "start";
	    };

	    this.normalizeRules = function() {
	        var id = 0;
	        var rules = this.$rules;
	        function processState(key) {
	            var state = rules[key];
	            state.processed = true;
	            for (var i = 0; i < state.length; i++) {
	                var rule = state[i];
	                var toInsert = null;
	                if (Array.isArray(rule)) {
	                    toInsert = rule;
	                    rule = {};
	                }
	                if (!rule.regex && rule.start) {
	                    rule.regex = rule.start;
	                    if (!rule.next)
	                        rule.next = [];
	                    rule.next.push({
	                        defaultToken: rule.token
	                    }, {
	                        token: rule.token + ".end",
	                        regex: rule.end || rule.start,
	                        next: "pop"
	                    });
	                    rule.token = rule.token + ".start";
	                    rule.push = true;
	                }
	                var next = rule.next || rule.push;
	                if (next && Array.isArray(next)) {
	                    var stateName = rule.stateName;
	                    if (!stateName)  {
	                        stateName = rule.token;
	                        if (typeof stateName != "string")
	                            stateName = stateName[0] || "";
	                        if (rules[stateName])
	                            stateName += id++;
	                    }
	                    rules[stateName] = next;
	                    rule.next = stateName;
	                    processState(stateName);
	                } else if (next == "pop") {
	                    rule.next = popState;
	                }

	                if (rule.push) {
	                    rule.nextState = rule.next || rule.push;
	                    rule.next = pushState;
	                    delete rule.push;
	                }

	                if (rule.rules) {
	                    for (var r in rule.rules) {
	                        if (rules[r]) {
	                            if (rules[r].push)
	                                rules[r].push.apply(rules[r], rule.rules[r]);
	                        } else {
	                            rules[r] = rule.rules[r];
	                        }
	                    }
	                }
	                var includeName = typeof rule == "string"
	                    ? rule
	                    : typeof rule.include == "string"
	                    ? rule.include
	                    : "";
	                if (includeName) {
	                    toInsert = rules[includeName];
	                }

	                if (toInsert) {
	                    var args = [i, 1].concat(toInsert);
	                    if (rule.noEscape)
	                        args = args.filter(function(x) {return !x.next;});
	                    state.splice.apply(state, args);
	                    i--;
	                }
	                
	                if (rule.keywordMap) {
	                    rule.token = this.createKeywordMapper(
	                        rule.keywordMap, rule.defaultToken || "text", rule.caseInsensitive
	                    );
	                    delete rule.defaultToken;
	                }
	            }
	        }
	        Object.keys(rules).forEach(processState, this);
	    };

	    this.createKeywordMapper = function(map, defaultToken, ignoreCase, splitChar) {
	        var keywords = Object.create(null);
	        Object.keys(map).forEach(function(className) {
	            var a = map[className];
	            if (ignoreCase)
	                a = a.toLowerCase();
	            var list = a.split(splitChar || "|");
	            for (var i = list.length; i--; )
	                keywords[list[i]] = className;
	        });
	        if (Object.getPrototypeOf(keywords)) {
	            keywords.__proto__ = null;
	        }
	        this.$keywordList = Object.keys(keywords);
	        map = null;
	        return ignoreCase
	            ? function(value) {return keywords[value.toLowerCase()] || defaultToken }
	            : function(value) {return keywords[value] || defaultToken };
	    };

	    this.getKeywords = function() {
	        return this.$keywords;
	    };

	}).call(TextHighlightRules.prototype);

	exports.TextHighlightRules = TextHighlightRules;
	});

	ace.define("ace/mode/behaviour",["require","exports","module"], function(acequire, exports, module) {
	"use strict";

	var Behaviour = function() {
	   this.$behaviours = {};
	};

	(function () {

	    this.add = function (name, action, callback) {
	        switch (undefined) {
	          case this.$behaviours:
	              this.$behaviours = {};
	          case this.$behaviours[name]:
	              this.$behaviours[name] = {};
	        }
	        this.$behaviours[name][action] = callback;
	    }
	    
	    this.addBehaviours = function (behaviours) {
	        for (var key in behaviours) {
	            for (var action in behaviours[key]) {
	                this.add(key, action, behaviours[key][action]);
	            }
	        }
	    }
	    
	    this.remove = function (name) {
	        if (this.$behaviours && this.$behaviours[name]) {
	            delete this.$behaviours[name];
	        }
	    }
	    
	    this.inherit = function (mode, filter) {
	        if (typeof mode === "function") {
	            var behaviours = new mode().getBehaviours(filter);
	        } else {
	            var behaviours = mode.getBehaviours(filter);
	        }
	        this.addBehaviours(behaviours);
	    }
	    
	    this.getBehaviours = function (filter) {
	        if (!filter) {
	            return this.$behaviours;
	        } else {
	            var ret = {}
	            for (var i = 0; i < filter.length; i++) {
	                if (this.$behaviours[filter[i]]) {
	                    ret[filter[i]] = this.$behaviours[filter[i]];
	                }
	            }
	            return ret;
	        }
	    }

	}).call(Behaviour.prototype);

	exports.Behaviour = Behaviour;
	});

	ace.define("ace/token_iterator",["require","exports","module"], function(acequire, exports, module) {
	"use strict";
	var TokenIterator = function(session, initialRow, initialColumn) {
	    this.$session = session;
	    this.$row = initialRow;
	    this.$rowTokens = session.getTokens(initialRow);

	    var token = session.getTokenAt(initialRow, initialColumn);
	    this.$tokenIndex = token ? token.index : -1;
	};

	(function() { 
	    this.stepBackward = function() {
	        this.$tokenIndex -= 1;
	        
	        while (this.$tokenIndex < 0) {
	            this.$row -= 1;
	            if (this.$row < 0) {
	                this.$row = 0;
	                return null;
	            }
	                
	            this.$rowTokens = this.$session.getTokens(this.$row);
	            this.$tokenIndex = this.$rowTokens.length - 1;
	        }
	            
	        return this.$rowTokens[this.$tokenIndex];
	    };   
	    this.stepForward = function() {
	        this.$tokenIndex += 1;
	        var rowCount;
	        while (this.$tokenIndex >= this.$rowTokens.length) {
	            this.$row += 1;
	            if (!rowCount)
	                rowCount = this.$session.getLength();
	            if (this.$row >= rowCount) {
	                this.$row = rowCount - 1;
	                return null;
	            }

	            this.$rowTokens = this.$session.getTokens(this.$row);
	            this.$tokenIndex = 0;
	        }
	            
	        return this.$rowTokens[this.$tokenIndex];
	    };      
	    this.getCurrentToken = function () {
	        return this.$rowTokens[this.$tokenIndex];
	    };      
	    this.getCurrentTokenRow = function () {
	        return this.$row;
	    };     
	    this.getCurrentTokenColumn = function() {
	        var rowTokens = this.$rowTokens;
	        var tokenIndex = this.$tokenIndex;
	        var column = rowTokens[tokenIndex].start;
	        if (column !== undefined)
	            return column;
	            
	        column = 0;
	        while (tokenIndex > 0) {
	            tokenIndex -= 1;
	            column += rowTokens[tokenIndex].value.length;
	        }
	        
	        return column;  
	    };
	    this.getCurrentTokenPosition = function() {
	        return {row: this.$row, column: this.getCurrentTokenColumn()};
	    };
	            
	}).call(TokenIterator.prototype);

	exports.TokenIterator = TokenIterator;
	});

	ace.define("ace/mode/behaviour/cstyle",["require","exports","module","ace/lib/oop","ace/mode/behaviour","ace/token_iterator","ace/lib/lang"], function(acequire, exports, module) {
	"use strict";

	var oop = acequire("../../lib/oop");
	var Behaviour = acequire("../behaviour").Behaviour;
	var TokenIterator = acequire("../../token_iterator").TokenIterator;
	var lang = acequire("../../lib/lang");

	var SAFE_INSERT_IN_TOKENS =
	    ["text", "paren.rparen", "punctuation.operator"];
	var SAFE_INSERT_BEFORE_TOKENS =
	    ["text", "paren.rparen", "punctuation.operator", "comment"];

	var context;
	var contextCache = {};
	var initContext = function(editor) {
	    var id = -1;
	    if (editor.multiSelect) {
	        id = editor.selection.index;
	        if (contextCache.rangeCount != editor.multiSelect.rangeCount)
	            contextCache = {rangeCount: editor.multiSelect.rangeCount};
	    }
	    if (contextCache[id])
	        return context = contextCache[id];
	    context = contextCache[id] = {
	        autoInsertedBrackets: 0,
	        autoInsertedRow: -1,
	        autoInsertedLineEnd: "",
	        maybeInsertedBrackets: 0,
	        maybeInsertedRow: -1,
	        maybeInsertedLineStart: "",
	        maybeInsertedLineEnd: ""
	    };
	};

	var getWrapped = function(selection, selected, opening, closing) {
	    var rowDiff = selection.end.row - selection.start.row;
	    return {
	        text: opening + selected + closing,
	        selection: [
	                0,
	                selection.start.column + 1,
	                rowDiff,
	                selection.end.column + (rowDiff ? 0 : 1)
	            ]
	    };
	};

	var CstyleBehaviour = function() {
	    this.add("braces", "insertion", function(state, action, editor, session, text) {
	        var cursor = editor.getCursorPosition();
	        var line = session.doc.getLine(cursor.row);
	        if (text == '{') {
	            initContext(editor);
	            var selection = editor.getSelectionRange();
	            var selected = session.doc.getTextRange(selection);
	            if (selected !== "" && selected !== "{" && editor.getWrapBehavioursEnabled()) {
	                return getWrapped(selection, selected, '{', '}');
	            } else if (CstyleBehaviour.isSaneInsertion(editor, session)) {
	                if (/[\]\}\)]/.test(line[cursor.column]) || editor.inMultiSelectMode) {
	                    CstyleBehaviour.recordAutoInsert(editor, session, "}");
	                    return {
	                        text: '{}',
	                        selection: [1, 1]
	                    };
	                } else {
	                    CstyleBehaviour.recordMaybeInsert(editor, session, "{");
	                    return {
	                        text: '{',
	                        selection: [1, 1]
	                    };
	                }
	            }
	        } else if (text == '}') {
	            initContext(editor);
	            var rightChar = line.substring(cursor.column, cursor.column + 1);
	            if (rightChar == '}') {
	                var matching = session.$findOpeningBracket('}', {column: cursor.column + 1, row: cursor.row});
	                if (matching !== null && CstyleBehaviour.isAutoInsertedClosing(cursor, line, text)) {
	                    CstyleBehaviour.popAutoInsertedClosing();
	                    return {
	                        text: '',
	                        selection: [1, 1]
	                    };
	                }
	            }
	        } else if (text == "\n" || text == "\r\n") {
	            initContext(editor);
	            var closing = "";
	            if (CstyleBehaviour.isMaybeInsertedClosing(cursor, line)) {
	                closing = lang.stringRepeat("}", context.maybeInsertedBrackets);
	                CstyleBehaviour.clearMaybeInsertedClosing();
	            }
	            var rightChar = line.substring(cursor.column, cursor.column + 1);
	            if (rightChar === '}') {
	                var openBracePos = session.findMatchingBracket({row: cursor.row, column: cursor.column+1}, '}');
	                if (!openBracePos)
	                     return null;
	                var next_indent = this.$getIndent(session.getLine(openBracePos.row));
	            } else if (closing) {
	                var next_indent = this.$getIndent(line);
	            } else {
	                CstyleBehaviour.clearMaybeInsertedClosing();
	                return;
	            }
	            var indent = next_indent + session.getTabString();

	            return {
	                text: '\n' + indent + '\n' + next_indent + closing,
	                selection: [1, indent.length, 1, indent.length]
	            };
	        } else {
	            CstyleBehaviour.clearMaybeInsertedClosing();
	        }
	    });

	    this.add("braces", "deletion", function(state, action, editor, session, range) {
	        var selected = session.doc.getTextRange(range);
	        if (!range.isMultiLine() && selected == '{') {
	            initContext(editor);
	            var line = session.doc.getLine(range.start.row);
	            var rightChar = line.substring(range.end.column, range.end.column + 1);
	            if (rightChar == '}') {
	                range.end.column++;
	                return range;
	            } else {
	                context.maybeInsertedBrackets--;
	            }
	        }
	    });

	    this.add("parens", "insertion", function(state, action, editor, session, text) {
	        if (text == '(') {
	            initContext(editor);
	            var selection = editor.getSelectionRange();
	            var selected = session.doc.getTextRange(selection);
	            if (selected !== "" && editor.getWrapBehavioursEnabled()) {
	                return getWrapped(selection, selected, '(', ')');
	            } else if (CstyleBehaviour.isSaneInsertion(editor, session)) {
	                CstyleBehaviour.recordAutoInsert(editor, session, ")");
	                return {
	                    text: '()',
	                    selection: [1, 1]
	                };
	            }
	        } else if (text == ')') {
	            initContext(editor);
	            var cursor = editor.getCursorPosition();
	            var line = session.doc.getLine(cursor.row);
	            var rightChar = line.substring(cursor.column, cursor.column + 1);
	            if (rightChar == ')') {
	                var matching = session.$findOpeningBracket(')', {column: cursor.column + 1, row: cursor.row});
	                if (matching !== null && CstyleBehaviour.isAutoInsertedClosing(cursor, line, text)) {
	                    CstyleBehaviour.popAutoInsertedClosing();
	                    return {
	                        text: '',
	                        selection: [1, 1]
	                    };
	                }
	            }
	        }
	    });

	    this.add("parens", "deletion", function(state, action, editor, session, range) {
	        var selected = session.doc.getTextRange(range);
	        if (!range.isMultiLine() && selected == '(') {
	            initContext(editor);
	            var line = session.doc.getLine(range.start.row);
	            var rightChar = line.substring(range.start.column + 1, range.start.column + 2);
	            if (rightChar == ')') {
	                range.end.column++;
	                return range;
	            }
	        }
	    });

	    this.add("brackets", "insertion", function(state, action, editor, session, text) {
	        if (text == '[') {
	            initContext(editor);
	            var selection = editor.getSelectionRange();
	            var selected = session.doc.getTextRange(selection);
	            if (selected !== "" && editor.getWrapBehavioursEnabled()) {
	                return getWrapped(selection, selected, '[', ']');
	            } else if (CstyleBehaviour.isSaneInsertion(editor, session)) {
	                CstyleBehaviour.recordAutoInsert(editor, session, "]");
	                return {
	                    text: '[]',
	                    selection: [1, 1]
	                };
	            }
	        } else if (text == ']') {
	            initContext(editor);
	            var cursor = editor.getCursorPosition();
	            var line = session.doc.getLine(cursor.row);
	            var rightChar = line.substring(cursor.column, cursor.column + 1);
	            if (rightChar == ']') {
	                var matching = session.$findOpeningBracket(']', {column: cursor.column + 1, row: cursor.row});
	                if (matching !== null && CstyleBehaviour.isAutoInsertedClosing(cursor, line, text)) {
	                    CstyleBehaviour.popAutoInsertedClosing();
	                    return {
	                        text: '',
	                        selection: [1, 1]
	                    };
	                }
	            }
	        }
	    });

	    this.add("brackets", "deletion", function(state, action, editor, session, range) {
	        var selected = session.doc.getTextRange(range);
	        if (!range.isMultiLine() && selected == '[') {
	            initContext(editor);
	            var line = session.doc.getLine(range.start.row);
	            var rightChar = line.substring(range.start.column + 1, range.start.column + 2);
	            if (rightChar == ']') {
	                range.end.column++;
	                return range;
	            }
	        }
	    });

	    this.add("string_dquotes", "insertion", function(state, action, editor, session, text) {
	        if (text == '"' || text == "'") {
	            if (this.lineCommentStart && this.lineCommentStart.indexOf(text) != -1)
	                return;
	            initContext(editor);
	            var quote = text;
	            var selection = editor.getSelectionRange();
	            var selected = session.doc.getTextRange(selection);
	            if (selected !== "" && selected !== "'" && selected != '"' && editor.getWrapBehavioursEnabled()) {
	                return getWrapped(selection, selected, quote, quote);
	            } else if (!selected) {
	                var cursor = editor.getCursorPosition();
	                var line = session.doc.getLine(cursor.row);
	                var leftChar = line.substring(cursor.column-1, cursor.column);
	                var rightChar = line.substring(cursor.column, cursor.column + 1);

	                var token = session.getTokenAt(cursor.row, cursor.column);
	                var rightToken = session.getTokenAt(cursor.row, cursor.column + 1);
	                if (leftChar == "\\" && token && /escape/.test(token.type))
	                    return null;

	                var stringBefore = token && /string|escape/.test(token.type);
	                var stringAfter = !rightToken || /string|escape/.test(rightToken.type);

	                var pair;
	                if (rightChar == quote) {
	                    pair = stringBefore !== stringAfter;
	                    if (pair && /string\.end/.test(rightToken.type))
	                        pair = false;
	                } else {
	                    if (stringBefore && !stringAfter)
	                        return null; // wrap string with different quote
	                    if (stringBefore && stringAfter)
	                        return null; // do not pair quotes inside strings
	                    var wordRe = session.$mode.tokenRe;
	                    wordRe.lastIndex = 0;
	                    var isWordBefore = wordRe.test(leftChar);
	                    wordRe.lastIndex = 0;
	                    var isWordAfter = wordRe.test(leftChar);
	                    if (isWordBefore || isWordAfter)
	                        return null; // before or after alphanumeric
	                    if (rightChar && !/[\s;,.})\]\\]/.test(rightChar))
	                        return null; // there is rightChar and it isn't closing
	                    pair = true;
	                }
	                return {
	                    text: pair ? quote + quote : "",
	                    selection: [1,1]
	                };
	            }
	        }
	    });

	    this.add("string_dquotes", "deletion", function(state, action, editor, session, range) {
	        var selected = session.doc.getTextRange(range);
	        if (!range.isMultiLine() && (selected == '"' || selected == "'")) {
	            initContext(editor);
	            var line = session.doc.getLine(range.start.row);
	            var rightChar = line.substring(range.start.column + 1, range.start.column + 2);
	            if (rightChar == selected) {
	                range.end.column++;
	                return range;
	            }
	        }
	    });

	};


	CstyleBehaviour.isSaneInsertion = function(editor, session) {
	    var cursor = editor.getCursorPosition();
	    var iterator = new TokenIterator(session, cursor.row, cursor.column);
	    if (!this.$matchTokenType(iterator.getCurrentToken() || "text", SAFE_INSERT_IN_TOKENS)) {
	        var iterator2 = new TokenIterator(session, cursor.row, cursor.column + 1);
	        if (!this.$matchTokenType(iterator2.getCurrentToken() || "text", SAFE_INSERT_IN_TOKENS))
	            return false;
	    }
	    iterator.stepForward();
	    return iterator.getCurrentTokenRow() !== cursor.row ||
	        this.$matchTokenType(iterator.getCurrentToken() || "text", SAFE_INSERT_BEFORE_TOKENS);
	};

	CstyleBehaviour.$matchTokenType = function(token, types) {
	    return types.indexOf(token.type || token) > -1;
	};

	CstyleBehaviour.recordAutoInsert = function(editor, session, bracket) {
	    var cursor = editor.getCursorPosition();
	    var line = session.doc.getLine(cursor.row);
	    if (!this.isAutoInsertedClosing(cursor, line, context.autoInsertedLineEnd[0]))
	        context.autoInsertedBrackets = 0;
	    context.autoInsertedRow = cursor.row;
	    context.autoInsertedLineEnd = bracket + line.substr(cursor.column);
	    context.autoInsertedBrackets++;
	};

	CstyleBehaviour.recordMaybeInsert = function(editor, session, bracket) {
	    var cursor = editor.getCursorPosition();
	    var line = session.doc.getLine(cursor.row);
	    if (!this.isMaybeInsertedClosing(cursor, line))
	        context.maybeInsertedBrackets = 0;
	    context.maybeInsertedRow = cursor.row;
	    context.maybeInsertedLineStart = line.substr(0, cursor.column) + bracket;
	    context.maybeInsertedLineEnd = line.substr(cursor.column);
	    context.maybeInsertedBrackets++;
	};

	CstyleBehaviour.isAutoInsertedClosing = function(cursor, line, bracket) {
	    return context.autoInsertedBrackets > 0 &&
	        cursor.row === context.autoInsertedRow &&
	        bracket === context.autoInsertedLineEnd[0] &&
	        line.substr(cursor.column) === context.autoInsertedLineEnd;
	};

	CstyleBehaviour.isMaybeInsertedClosing = function(cursor, line) {
	    return context.maybeInsertedBrackets > 0 &&
	        cursor.row === context.maybeInsertedRow &&
	        line.substr(cursor.column) === context.maybeInsertedLineEnd &&
	        line.substr(0, cursor.column) == context.maybeInsertedLineStart;
	};

	CstyleBehaviour.popAutoInsertedClosing = function() {
	    context.autoInsertedLineEnd = context.autoInsertedLineEnd.substr(1);
	    context.autoInsertedBrackets--;
	};

	CstyleBehaviour.clearMaybeInsertedClosing = function() {
	    if (context) {
	        context.maybeInsertedBrackets = 0;
	        context.maybeInsertedRow = -1;
	    }
	};



	oop.inherits(CstyleBehaviour, Behaviour);

	exports.CstyleBehaviour = CstyleBehaviour;
	});

	ace.define("ace/unicode",["require","exports","module"], function(acequire, exports, module) {
	"use strict";
	exports.packages = {};

	addUnicodePackage({
	    L:  "0041-005A0061-007A00AA00B500BA00C0-00D600D8-00F600F8-02C102C6-02D102E0-02E402EC02EE0370-037403760377037A-037D03860388-038A038C038E-03A103A3-03F503F7-0481048A-05250531-055605590561-058705D0-05EA05F0-05F20621-064A066E066F0671-06D306D506E506E606EE06EF06FA-06FC06FF07100712-072F074D-07A507B107CA-07EA07F407F507FA0800-0815081A082408280904-0939093D09500958-0961097109720979-097F0985-098C098F09900993-09A809AA-09B009B209B6-09B909BD09CE09DC09DD09DF-09E109F009F10A05-0A0A0A0F0A100A13-0A280A2A-0A300A320A330A350A360A380A390A59-0A5C0A5E0A72-0A740A85-0A8D0A8F-0A910A93-0AA80AAA-0AB00AB20AB30AB5-0AB90ABD0AD00AE00AE10B05-0B0C0B0F0B100B13-0B280B2A-0B300B320B330B35-0B390B3D0B5C0B5D0B5F-0B610B710B830B85-0B8A0B8E-0B900B92-0B950B990B9A0B9C0B9E0B9F0BA30BA40BA8-0BAA0BAE-0BB90BD00C05-0C0C0C0E-0C100C12-0C280C2A-0C330C35-0C390C3D0C580C590C600C610C85-0C8C0C8E-0C900C92-0CA80CAA-0CB30CB5-0CB90CBD0CDE0CE00CE10D05-0D0C0D0E-0D100D12-0D280D2A-0D390D3D0D600D610D7A-0D7F0D85-0D960D9A-0DB10DB3-0DBB0DBD0DC0-0DC60E01-0E300E320E330E40-0E460E810E820E840E870E880E8A0E8D0E94-0E970E99-0E9F0EA1-0EA30EA50EA70EAA0EAB0EAD-0EB00EB20EB30EBD0EC0-0EC40EC60EDC0EDD0F000F40-0F470F49-0F6C0F88-0F8B1000-102A103F1050-1055105A-105D106110651066106E-10701075-1081108E10A0-10C510D0-10FA10FC1100-1248124A-124D1250-12561258125A-125D1260-1288128A-128D1290-12B012B2-12B512B8-12BE12C012C2-12C512C8-12D612D8-13101312-13151318-135A1380-138F13A0-13F41401-166C166F-167F1681-169A16A0-16EA1700-170C170E-17111720-17311740-17511760-176C176E-17701780-17B317D717DC1820-18771880-18A818AA18B0-18F51900-191C1950-196D1970-19741980-19AB19C1-19C71A00-1A161A20-1A541AA71B05-1B331B45-1B4B1B83-1BA01BAE1BAF1C00-1C231C4D-1C4F1C5A-1C7D1CE9-1CEC1CEE-1CF11D00-1DBF1E00-1F151F18-1F1D1F20-1F451F48-1F4D1F50-1F571F591F5B1F5D1F5F-1F7D1F80-1FB41FB6-1FBC1FBE1FC2-1FC41FC6-1FCC1FD0-1FD31FD6-1FDB1FE0-1FEC1FF2-1FF41FF6-1FFC2071207F2090-209421022107210A-211321152119-211D212421262128212A-212D212F-2139213C-213F2145-2149214E218321842C00-2C2E2C30-2C5E2C60-2CE42CEB-2CEE2D00-2D252D30-2D652D6F2D80-2D962DA0-2DA62DA8-2DAE2DB0-2DB62DB8-2DBE2DC0-2DC62DC8-2DCE2DD0-2DD62DD8-2DDE2E2F300530063031-3035303B303C3041-3096309D-309F30A1-30FA30FC-30FF3105-312D3131-318E31A0-31B731F0-31FF3400-4DB54E00-9FCBA000-A48CA4D0-A4FDA500-A60CA610-A61FA62AA62BA640-A65FA662-A66EA67F-A697A6A0-A6E5A717-A71FA722-A788A78BA78CA7FB-A801A803-A805A807-A80AA80C-A822A840-A873A882-A8B3A8F2-A8F7A8FBA90A-A925A930-A946A960-A97CA984-A9B2A9CFAA00-AA28AA40-AA42AA44-AA4BAA60-AA76AA7AAA80-AAAFAAB1AAB5AAB6AAB9-AABDAAC0AAC2AADB-AADDABC0-ABE2AC00-D7A3D7B0-D7C6D7CB-D7FBF900-FA2DFA30-FA6DFA70-FAD9FB00-FB06FB13-FB17FB1DFB1F-FB28FB2A-FB36FB38-FB3CFB3EFB40FB41FB43FB44FB46-FBB1FBD3-FD3DFD50-FD8FFD92-FDC7FDF0-FDFBFE70-FE74FE76-FEFCFF21-FF3AFF41-FF5AFF66-FFBEFFC2-FFC7FFCA-FFCFFFD2-FFD7FFDA-FFDC",
	    Ll: "0061-007A00AA00B500BA00DF-00F600F8-00FF01010103010501070109010B010D010F01110113011501170119011B011D011F01210123012501270129012B012D012F01310133013501370138013A013C013E014001420144014601480149014B014D014F01510153015501570159015B015D015F01610163016501670169016B016D016F0171017301750177017A017C017E-0180018301850188018C018D019201950199-019B019E01A101A301A501A801AA01AB01AD01B001B401B601B901BA01BD-01BF01C601C901CC01CE01D001D201D401D601D801DA01DC01DD01DF01E101E301E501E701E901EB01ED01EF01F001F301F501F901FB01FD01FF02010203020502070209020B020D020F02110213021502170219021B021D021F02210223022502270229022B022D022F02310233-0239023C023F0240024202470249024B024D024F-02930295-02AF037103730377037B-037D039003AC-03CE03D003D103D5-03D703D903DB03DD03DF03E103E303E503E703E903EB03ED03EF-03F303F503F803FB03FC0430-045F04610463046504670469046B046D046F04710473047504770479047B047D047F0481048B048D048F04910493049504970499049B049D049F04A104A304A504A704A904AB04AD04AF04B104B304B504B704B904BB04BD04BF04C204C404C604C804CA04CC04CE04CF04D104D304D504D704D904DB04DD04DF04E104E304E504E704E904EB04ED04EF04F104F304F504F704F904FB04FD04FF05010503050505070509050B050D050F05110513051505170519051B051D051F0521052305250561-05871D00-1D2B1D62-1D771D79-1D9A1E011E031E051E071E091E0B1E0D1E0F1E111E131E151E171E191E1B1E1D1E1F1E211E231E251E271E291E2B1E2D1E2F1E311E331E351E371E391E3B1E3D1E3F1E411E431E451E471E491E4B1E4D1E4F1E511E531E551E571E591E5B1E5D1E5F1E611E631E651E671E691E6B1E6D1E6F1E711E731E751E771E791E7B1E7D1E7F1E811E831E851E871E891E8B1E8D1E8F1E911E931E95-1E9D1E9F1EA11EA31EA51EA71EA91EAB1EAD1EAF1EB11EB31EB51EB71EB91EBB1EBD1EBF1EC11EC31EC51EC71EC91ECB1ECD1ECF1ED11ED31ED51ED71ED91EDB1EDD1EDF1EE11EE31EE51EE71EE91EEB1EED1EEF1EF11EF31EF51EF71EF91EFB1EFD1EFF-1F071F10-1F151F20-1F271F30-1F371F40-1F451F50-1F571F60-1F671F70-1F7D1F80-1F871F90-1F971FA0-1FA71FB0-1FB41FB61FB71FBE1FC2-1FC41FC61FC71FD0-1FD31FD61FD71FE0-1FE71FF2-1FF41FF61FF7210A210E210F2113212F21342139213C213D2146-2149214E21842C30-2C5E2C612C652C662C682C6A2C6C2C712C732C742C76-2C7C2C812C832C852C872C892C8B2C8D2C8F2C912C932C952C972C992C9B2C9D2C9F2CA12CA32CA52CA72CA92CAB2CAD2CAF2CB12CB32CB52CB72CB92CBB2CBD2CBF2CC12CC32CC52CC72CC92CCB2CCD2CCF2CD12CD32CD52CD72CD92CDB2CDD2CDF2CE12CE32CE42CEC2CEE2D00-2D25A641A643A645A647A649A64BA64DA64FA651A653A655A657A659A65BA65DA65FA663A665A667A669A66BA66DA681A683A685A687A689A68BA68DA68FA691A693A695A697A723A725A727A729A72BA72DA72F-A731A733A735A737A739A73BA73DA73FA741A743A745A747A749A74BA74DA74FA751A753A755A757A759A75BA75DA75FA761A763A765A767A769A76BA76DA76FA771-A778A77AA77CA77FA781A783A785A787A78CFB00-FB06FB13-FB17FF41-FF5A",
	    Lu: "0041-005A00C0-00D600D8-00DE01000102010401060108010A010C010E01100112011401160118011A011C011E01200122012401260128012A012C012E01300132013401360139013B013D013F0141014301450147014A014C014E01500152015401560158015A015C015E01600162016401660168016A016C016E017001720174017601780179017B017D018101820184018601870189-018B018E-0191019301940196-0198019C019D019F01A001A201A401A601A701A901AC01AE01AF01B1-01B301B501B701B801BC01C401C701CA01CD01CF01D101D301D501D701D901DB01DE01E001E201E401E601E801EA01EC01EE01F101F401F6-01F801FA01FC01FE02000202020402060208020A020C020E02100212021402160218021A021C021E02200222022402260228022A022C022E02300232023A023B023D023E02410243-02460248024A024C024E03700372037603860388-038A038C038E038F0391-03A103A3-03AB03CF03D2-03D403D803DA03DC03DE03E003E203E403E603E803EA03EC03EE03F403F703F903FA03FD-042F04600462046404660468046A046C046E04700472047404760478047A047C047E0480048A048C048E04900492049404960498049A049C049E04A004A204A404A604A804AA04AC04AE04B004B204B404B604B804BA04BC04BE04C004C104C304C504C704C904CB04CD04D004D204D404D604D804DA04DC04DE04E004E204E404E604E804EA04EC04EE04F004F204F404F604F804FA04FC04FE05000502050405060508050A050C050E05100512051405160518051A051C051E0520052205240531-055610A0-10C51E001E021E041E061E081E0A1E0C1E0E1E101E121E141E161E181E1A1E1C1E1E1E201E221E241E261E281E2A1E2C1E2E1E301E321E341E361E381E3A1E3C1E3E1E401E421E441E461E481E4A1E4C1E4E1E501E521E541E561E581E5A1E5C1E5E1E601E621E641E661E681E6A1E6C1E6E1E701E721E741E761E781E7A1E7C1E7E1E801E821E841E861E881E8A1E8C1E8E1E901E921E941E9E1EA01EA21EA41EA61EA81EAA1EAC1EAE1EB01EB21EB41EB61EB81EBA1EBC1EBE1EC01EC21EC41EC61EC81ECA1ECC1ECE1ED01ED21ED41ED61ED81EDA1EDC1EDE1EE01EE21EE41EE61EE81EEA1EEC1EEE1EF01EF21EF41EF61EF81EFA1EFC1EFE1F08-1F0F1F18-1F1D1F28-1F2F1F38-1F3F1F48-1F4D1F591F5B1F5D1F5F1F68-1F6F1FB8-1FBB1FC8-1FCB1FD8-1FDB1FE8-1FEC1FF8-1FFB21022107210B-210D2110-211221152119-211D212421262128212A-212D2130-2133213E213F214521832C00-2C2E2C602C62-2C642C672C692C6B2C6D-2C702C722C752C7E-2C802C822C842C862C882C8A2C8C2C8E2C902C922C942C962C982C9A2C9C2C9E2CA02CA22CA42CA62CA82CAA2CAC2CAE2CB02CB22CB42CB62CB82CBA2CBC2CBE2CC02CC22CC42CC62CC82CCA2CCC2CCE2CD02CD22CD42CD62CD82CDA2CDC2CDE2CE02CE22CEB2CEDA640A642A644A646A648A64AA64CA64EA650A652A654A656A658A65AA65CA65EA662A664A666A668A66AA66CA680A682A684A686A688A68AA68CA68EA690A692A694A696A722A724A726A728A72AA72CA72EA732A734A736A738A73AA73CA73EA740A742A744A746A748A74AA74CA74EA750A752A754A756A758A75AA75CA75EA760A762A764A766A768A76AA76CA76EA779A77BA77DA77EA780A782A784A786A78BFF21-FF3A",
	    Lt: "01C501C801CB01F21F88-1F8F1F98-1F9F1FA8-1FAF1FBC1FCC1FFC",
	    Lm: "02B0-02C102C6-02D102E0-02E402EC02EE0374037A0559064006E506E607F407F507FA081A0824082809710E460EC610FC17D718431AA71C78-1C7D1D2C-1D611D781D9B-1DBF2071207F2090-20942C7D2D6F2E2F30053031-3035303B309D309E30FC-30FEA015A4F8-A4FDA60CA67FA717-A71FA770A788A9CFAA70AADDFF70FF9EFF9F",
	    Lo: "01BB01C0-01C3029405D0-05EA05F0-05F20621-063F0641-064A066E066F0671-06D306D506EE06EF06FA-06FC06FF07100712-072F074D-07A507B107CA-07EA0800-08150904-0939093D09500958-096109720979-097F0985-098C098F09900993-09A809AA-09B009B209B6-09B909BD09CE09DC09DD09DF-09E109F009F10A05-0A0A0A0F0A100A13-0A280A2A-0A300A320A330A350A360A380A390A59-0A5C0A5E0A72-0A740A85-0A8D0A8F-0A910A93-0AA80AAA-0AB00AB20AB30AB5-0AB90ABD0AD00AE00AE10B05-0B0C0B0F0B100B13-0B280B2A-0B300B320B330B35-0B390B3D0B5C0B5D0B5F-0B610B710B830B85-0B8A0B8E-0B900B92-0B950B990B9A0B9C0B9E0B9F0BA30BA40BA8-0BAA0BAE-0BB90BD00C05-0C0C0C0E-0C100C12-0C280C2A-0C330C35-0C390C3D0C580C590C600C610C85-0C8C0C8E-0C900C92-0CA80CAA-0CB30CB5-0CB90CBD0CDE0CE00CE10D05-0D0C0D0E-0D100D12-0D280D2A-0D390D3D0D600D610D7A-0D7F0D85-0D960D9A-0DB10DB3-0DBB0DBD0DC0-0DC60E01-0E300E320E330E40-0E450E810E820E840E870E880E8A0E8D0E94-0E970E99-0E9F0EA1-0EA30EA50EA70EAA0EAB0EAD-0EB00EB20EB30EBD0EC0-0EC40EDC0EDD0F000F40-0F470F49-0F6C0F88-0F8B1000-102A103F1050-1055105A-105D106110651066106E-10701075-1081108E10D0-10FA1100-1248124A-124D1250-12561258125A-125D1260-1288128A-128D1290-12B012B2-12B512B8-12BE12C012C2-12C512C8-12D612D8-13101312-13151318-135A1380-138F13A0-13F41401-166C166F-167F1681-169A16A0-16EA1700-170C170E-17111720-17311740-17511760-176C176E-17701780-17B317DC1820-18421844-18771880-18A818AA18B0-18F51900-191C1950-196D1970-19741980-19AB19C1-19C71A00-1A161A20-1A541B05-1B331B45-1B4B1B83-1BA01BAE1BAF1C00-1C231C4D-1C4F1C5A-1C771CE9-1CEC1CEE-1CF12135-21382D30-2D652D80-2D962DA0-2DA62DA8-2DAE2DB0-2DB62DB8-2DBE2DC0-2DC62DC8-2DCE2DD0-2DD62DD8-2DDE3006303C3041-3096309F30A1-30FA30FF3105-312D3131-318E31A0-31B731F0-31FF3400-4DB54E00-9FCBA000-A014A016-A48CA4D0-A4F7A500-A60BA610-A61FA62AA62BA66EA6A0-A6E5A7FB-A801A803-A805A807-A80AA80C-A822A840-A873A882-A8B3A8F2-A8F7A8FBA90A-A925A930-A946A960-A97CA984-A9B2AA00-AA28AA40-AA42AA44-AA4BAA60-AA6FAA71-AA76AA7AAA80-AAAFAAB1AAB5AAB6AAB9-AABDAAC0AAC2AADBAADCABC0-ABE2AC00-D7A3D7B0-D7C6D7CB-D7FBF900-FA2DFA30-FA6DFA70-FAD9FB1DFB1F-FB28FB2A-FB36FB38-FB3CFB3EFB40FB41FB43FB44FB46-FBB1FBD3-FD3DFD50-FD8FFD92-FDC7FDF0-FDFBFE70-FE74FE76-FEFCFF66-FF6FFF71-FF9DFFA0-FFBEFFC2-FFC7FFCA-FFCFFFD2-FFD7FFDA-FFDC",
	    M:  "0300-036F0483-04890591-05BD05BF05C105C205C405C505C70610-061A064B-065E067006D6-06DC06DE-06E406E706E806EA-06ED07110730-074A07A6-07B007EB-07F30816-0819081B-08230825-08270829-082D0900-0903093C093E-094E0951-0955096209630981-098309BC09BE-09C409C709C809CB-09CD09D709E209E30A01-0A030A3C0A3E-0A420A470A480A4B-0A4D0A510A700A710A750A81-0A830ABC0ABE-0AC50AC7-0AC90ACB-0ACD0AE20AE30B01-0B030B3C0B3E-0B440B470B480B4B-0B4D0B560B570B620B630B820BBE-0BC20BC6-0BC80BCA-0BCD0BD70C01-0C030C3E-0C440C46-0C480C4A-0C4D0C550C560C620C630C820C830CBC0CBE-0CC40CC6-0CC80CCA-0CCD0CD50CD60CE20CE30D020D030D3E-0D440D46-0D480D4A-0D4D0D570D620D630D820D830DCA0DCF-0DD40DD60DD8-0DDF0DF20DF30E310E34-0E3A0E47-0E4E0EB10EB4-0EB90EBB0EBC0EC8-0ECD0F180F190F350F370F390F3E0F3F0F71-0F840F860F870F90-0F970F99-0FBC0FC6102B-103E1056-1059105E-10601062-10641067-106D1071-10741082-108D108F109A-109D135F1712-17141732-1734175217531772177317B6-17D317DD180B-180D18A91920-192B1930-193B19B0-19C019C819C91A17-1A1B1A55-1A5E1A60-1A7C1A7F1B00-1B041B34-1B441B6B-1B731B80-1B821BA1-1BAA1C24-1C371CD0-1CD21CD4-1CE81CED1CF21DC0-1DE61DFD-1DFF20D0-20F02CEF-2CF12DE0-2DFF302A-302F3099309AA66F-A672A67CA67DA6F0A6F1A802A806A80BA823-A827A880A881A8B4-A8C4A8E0-A8F1A926-A92DA947-A953A980-A983A9B3-A9C0AA29-AA36AA43AA4CAA4DAA7BAAB0AAB2-AAB4AAB7AAB8AABEAABFAAC1ABE3-ABEAABECABEDFB1EFE00-FE0FFE20-FE26",
	    Mn: "0300-036F0483-04870591-05BD05BF05C105C205C405C505C70610-061A064B-065E067006D6-06DC06DF-06E406E706E806EA-06ED07110730-074A07A6-07B007EB-07F30816-0819081B-08230825-08270829-082D0900-0902093C0941-0948094D0951-095509620963098109BC09C1-09C409CD09E209E30A010A020A3C0A410A420A470A480A4B-0A4D0A510A700A710A750A810A820ABC0AC1-0AC50AC70AC80ACD0AE20AE30B010B3C0B3F0B41-0B440B4D0B560B620B630B820BC00BCD0C3E-0C400C46-0C480C4A-0C4D0C550C560C620C630CBC0CBF0CC60CCC0CCD0CE20CE30D41-0D440D4D0D620D630DCA0DD2-0DD40DD60E310E34-0E3A0E47-0E4E0EB10EB4-0EB90EBB0EBC0EC8-0ECD0F180F190F350F370F390F71-0F7E0F80-0F840F860F870F90-0F970F99-0FBC0FC6102D-10301032-10371039103A103D103E10581059105E-10601071-1074108210851086108D109D135F1712-17141732-1734175217531772177317B7-17BD17C617C9-17D317DD180B-180D18A91920-19221927192819321939-193B1A171A181A561A58-1A5E1A601A621A65-1A6C1A73-1A7C1A7F1B00-1B031B341B36-1B3A1B3C1B421B6B-1B731B801B811BA2-1BA51BA81BA91C2C-1C331C361C371CD0-1CD21CD4-1CE01CE2-1CE81CED1DC0-1DE61DFD-1DFF20D0-20DC20E120E5-20F02CEF-2CF12DE0-2DFF302A-302F3099309AA66FA67CA67DA6F0A6F1A802A806A80BA825A826A8C4A8E0-A8F1A926-A92DA947-A951A980-A982A9B3A9B6-A9B9A9BCAA29-AA2EAA31AA32AA35AA36AA43AA4CAAB0AAB2-AAB4AAB7AAB8AABEAABFAAC1ABE5ABE8ABEDFB1EFE00-FE0FFE20-FE26",
	    Mc: "0903093E-09400949-094C094E0982098309BE-09C009C709C809CB09CC09D70A030A3E-0A400A830ABE-0AC00AC90ACB0ACC0B020B030B3E0B400B470B480B4B0B4C0B570BBE0BBF0BC10BC20BC6-0BC80BCA-0BCC0BD70C01-0C030C41-0C440C820C830CBE0CC0-0CC40CC70CC80CCA0CCB0CD50CD60D020D030D3E-0D400D46-0D480D4A-0D4C0D570D820D830DCF-0DD10DD8-0DDF0DF20DF30F3E0F3F0F7F102B102C10311038103B103C105610571062-10641067-106D108310841087-108C108F109A-109C17B617BE-17C517C717C81923-19261929-192B193019311933-193819B0-19C019C819C91A19-1A1B1A551A571A611A631A641A6D-1A721B041B351B3B1B3D-1B411B431B441B821BA11BA61BA71BAA1C24-1C2B1C341C351CE11CF2A823A824A827A880A881A8B4-A8C3A952A953A983A9B4A9B5A9BAA9BBA9BD-A9C0AA2FAA30AA33AA34AA4DAA7BABE3ABE4ABE6ABE7ABE9ABEAABEC",
	    Me: "0488048906DE20DD-20E020E2-20E4A670-A672",
	    N:  "0030-003900B200B300B900BC-00BE0660-066906F0-06F907C0-07C90966-096F09E6-09EF09F4-09F90A66-0A6F0AE6-0AEF0B66-0B6F0BE6-0BF20C66-0C6F0C78-0C7E0CE6-0CEF0D66-0D750E50-0E590ED0-0ED90F20-0F331040-10491090-10991369-137C16EE-16F017E0-17E917F0-17F91810-18191946-194F19D0-19DA1A80-1A891A90-1A991B50-1B591BB0-1BB91C40-1C491C50-1C5920702074-20792080-20892150-21822185-21892460-249B24EA-24FF2776-27932CFD30073021-30293038-303A3192-31953220-32293251-325F3280-328932B1-32BFA620-A629A6E6-A6EFA830-A835A8D0-A8D9A900-A909A9D0-A9D9AA50-AA59ABF0-ABF9FF10-FF19",
	    Nd: "0030-00390660-066906F0-06F907C0-07C90966-096F09E6-09EF0A66-0A6F0AE6-0AEF0B66-0B6F0BE6-0BEF0C66-0C6F0CE6-0CEF0D66-0D6F0E50-0E590ED0-0ED90F20-0F291040-10491090-109917E0-17E91810-18191946-194F19D0-19DA1A80-1A891A90-1A991B50-1B591BB0-1BB91C40-1C491C50-1C59A620-A629A8D0-A8D9A900-A909A9D0-A9D9AA50-AA59ABF0-ABF9FF10-FF19",
	    Nl: "16EE-16F02160-21822185-218830073021-30293038-303AA6E6-A6EF",
	    No: "00B200B300B900BC-00BE09F4-09F90BF0-0BF20C78-0C7E0D70-0D750F2A-0F331369-137C17F0-17F920702074-20792080-20892150-215F21892460-249B24EA-24FF2776-27932CFD3192-31953220-32293251-325F3280-328932B1-32BFA830-A835",
	    P:  "0021-00230025-002A002C-002F003A003B003F0040005B-005D005F007B007D00A100AB00B700BB00BF037E0387055A-055F0589058A05BE05C005C305C605F305F40609060A060C060D061B061E061F066A-066D06D40700-070D07F7-07F90830-083E0964096509700DF40E4F0E5A0E5B0F04-0F120F3A-0F3D0F850FD0-0FD4104A-104F10FB1361-13681400166D166E169B169C16EB-16ED1735173617D4-17D617D8-17DA1800-180A1944194519DE19DF1A1E1A1F1AA0-1AA61AA8-1AAD1B5A-1B601C3B-1C3F1C7E1C7F1CD32010-20272030-20432045-20512053-205E207D207E208D208E2329232A2768-277527C527C627E6-27EF2983-299829D8-29DB29FC29FD2CF9-2CFC2CFE2CFF2E00-2E2E2E302E313001-30033008-30113014-301F3030303D30A030FBA4FEA4FFA60D-A60FA673A67EA6F2-A6F7A874-A877A8CEA8CFA8F8-A8FAA92EA92FA95FA9C1-A9CDA9DEA9DFAA5C-AA5FAADEAADFABEBFD3EFD3FFE10-FE19FE30-FE52FE54-FE61FE63FE68FE6AFE6BFF01-FF03FF05-FF0AFF0C-FF0FFF1AFF1BFF1FFF20FF3B-FF3DFF3FFF5BFF5DFF5F-FF65",
	    Pd: "002D058A05BE140018062010-20152E172E1A301C303030A0FE31FE32FE58FE63FF0D",
	    Ps: "0028005B007B0F3A0F3C169B201A201E2045207D208D23292768276A276C276E27702772277427C527E627E827EA27EC27EE2983298529872989298B298D298F299129932995299729D829DA29FC2E222E242E262E283008300A300C300E3010301430163018301A301DFD3EFE17FE35FE37FE39FE3BFE3DFE3FFE41FE43FE47FE59FE5BFE5DFF08FF3BFF5BFF5FFF62",
	    Pe: "0029005D007D0F3B0F3D169C2046207E208E232A2769276B276D276F27712773277527C627E727E927EB27ED27EF298429862988298A298C298E2990299229942996299829D929DB29FD2E232E252E272E293009300B300D300F3011301530173019301B301E301FFD3FFE18FE36FE38FE3AFE3CFE3EFE40FE42FE44FE48FE5AFE5CFE5EFF09FF3DFF5DFF60FF63",
	    Pi: "00AB2018201B201C201F20392E022E042E092E0C2E1C2E20",
	    Pf: "00BB2019201D203A2E032E052E0A2E0D2E1D2E21",
	    Pc: "005F203F20402054FE33FE34FE4D-FE4FFF3F",
	    Po: "0021-00230025-0027002A002C002E002F003A003B003F0040005C00A100B700BF037E0387055A-055F058905C005C305C605F305F40609060A060C060D061B061E061F066A-066D06D40700-070D07F7-07F90830-083E0964096509700DF40E4F0E5A0E5B0F04-0F120F850FD0-0FD4104A-104F10FB1361-1368166D166E16EB-16ED1735173617D4-17D617D8-17DA1800-18051807-180A1944194519DE19DF1A1E1A1F1AA0-1AA61AA8-1AAD1B5A-1B601C3B-1C3F1C7E1C7F1CD3201620172020-20272030-2038203B-203E2041-20432047-205120532055-205E2CF9-2CFC2CFE2CFF2E002E012E06-2E082E0B2E0E-2E162E182E192E1B2E1E2E1F2E2A-2E2E2E302E313001-3003303D30FBA4FEA4FFA60D-A60FA673A67EA6F2-A6F7A874-A877A8CEA8CFA8F8-A8FAA92EA92FA95FA9C1-A9CDA9DEA9DFAA5C-AA5FAADEAADFABEBFE10-FE16FE19FE30FE45FE46FE49-FE4CFE50-FE52FE54-FE57FE5F-FE61FE68FE6AFE6BFF01-FF03FF05-FF07FF0AFF0CFF0EFF0FFF1AFF1BFF1FFF20FF3CFF61FF64FF65",
	    S:  "0024002B003C-003E005E0060007C007E00A2-00A900AC00AE-00B100B400B600B800D700F702C2-02C502D2-02DF02E5-02EB02ED02EF-02FF03750384038503F604820606-0608060B060E060F06E906FD06FE07F609F209F309FA09FB0AF10B700BF3-0BFA0C7F0CF10CF20D790E3F0F01-0F030F13-0F170F1A-0F1F0F340F360F380FBE-0FC50FC7-0FCC0FCE0FCF0FD5-0FD8109E109F13601390-139917DB194019E0-19FF1B61-1B6A1B74-1B7C1FBD1FBF-1FC11FCD-1FCF1FDD-1FDF1FED-1FEF1FFD1FFE20442052207A-207C208A-208C20A0-20B8210021012103-21062108210921142116-2118211E-2123212521272129212E213A213B2140-2144214A-214D214F2190-2328232B-23E82400-24262440-244A249C-24E92500-26CD26CF-26E126E326E8-26FF2701-27042706-2709270C-27272729-274B274D274F-27522756-275E2761-276727942798-27AF27B1-27BE27C0-27C427C7-27CA27CC27D0-27E527F0-29822999-29D729DC-29FB29FE-2B4C2B50-2B592CE5-2CEA2E80-2E992E9B-2EF32F00-2FD52FF0-2FFB300430123013302030363037303E303F309B309C319031913196-319F31C0-31E33200-321E322A-32503260-327F328A-32B032C0-32FE3300-33FF4DC0-4DFFA490-A4C6A700-A716A720A721A789A78AA828-A82BA836-A839AA77-AA79FB29FDFCFDFDFE62FE64-FE66FE69FF04FF0BFF1C-FF1EFF3EFF40FF5CFF5EFFE0-FFE6FFE8-FFEEFFFCFFFD",
	    Sm: "002B003C-003E007C007E00AC00B100D700F703F60606-060820442052207A-207C208A-208C2140-2144214B2190-2194219A219B21A021A321A621AE21CE21CF21D221D421F4-22FF2308-230B23202321237C239B-23B323DC-23E125B725C125F8-25FF266F27C0-27C427C7-27CA27CC27D0-27E527F0-27FF2900-29822999-29D729DC-29FB29FE-2AFF2B30-2B442B47-2B4CFB29FE62FE64-FE66FF0BFF1C-FF1EFF5CFF5EFFE2FFE9-FFEC",
	    Sc: "002400A2-00A5060B09F209F309FB0AF10BF90E3F17DB20A0-20B8A838FDFCFE69FF04FFE0FFE1FFE5FFE6",
	    Sk: "005E006000A800AF00B400B802C2-02C502D2-02DF02E5-02EB02ED02EF-02FF0375038403851FBD1FBF-1FC11FCD-1FCF1FDD-1FDF1FED-1FEF1FFD1FFE309B309CA700-A716A720A721A789A78AFF3EFF40FFE3",
	    So: "00A600A700A900AE00B000B60482060E060F06E906FD06FE07F609FA0B700BF3-0BF80BFA0C7F0CF10CF20D790F01-0F030F13-0F170F1A-0F1F0F340F360F380FBE-0FC50FC7-0FCC0FCE0FCF0FD5-0FD8109E109F13601390-1399194019E0-19FF1B61-1B6A1B74-1B7C210021012103-21062108210921142116-2118211E-2123212521272129212E213A213B214A214C214D214F2195-2199219C-219F21A121A221A421A521A7-21AD21AF-21CD21D021D121D321D5-21F32300-2307230C-231F2322-2328232B-237B237D-239A23B4-23DB23E2-23E82400-24262440-244A249C-24E92500-25B625B8-25C025C2-25F72600-266E2670-26CD26CF-26E126E326E8-26FF2701-27042706-2709270C-27272729-274B274D274F-27522756-275E2761-276727942798-27AF27B1-27BE2800-28FF2B00-2B2F2B452B462B50-2B592CE5-2CEA2E80-2E992E9B-2EF32F00-2FD52FF0-2FFB300430123013302030363037303E303F319031913196-319F31C0-31E33200-321E322A-32503260-327F328A-32B032C0-32FE3300-33FF4DC0-4DFFA490-A4C6A828-A82BA836A837A839AA77-AA79FDFDFFE4FFE8FFEDFFEEFFFCFFFD",
	    Z:  "002000A01680180E2000-200A20282029202F205F3000",
	    Zs: "002000A01680180E2000-200A202F205F3000",
	    Zl: "2028",
	    Zp: "2029",
	    C:  "0000-001F007F-009F00AD03780379037F-0383038B038D03A20526-05300557055805600588058B-059005C8-05CF05EB-05EF05F5-0605061C061D0620065F06DD070E070F074B074C07B2-07BF07FB-07FF082E082F083F-08FF093A093B094F095609570973-097809800984098D098E0991099209A909B109B3-09B509BA09BB09C509C609C909CA09CF-09D609D8-09DB09DE09E409E509FC-0A000A040A0B-0A0E0A110A120A290A310A340A370A3A0A3B0A3D0A43-0A460A490A4A0A4E-0A500A52-0A580A5D0A5F-0A650A76-0A800A840A8E0A920AA90AB10AB40ABA0ABB0AC60ACA0ACE0ACF0AD1-0ADF0AE40AE50AF00AF2-0B000B040B0D0B0E0B110B120B290B310B340B3A0B3B0B450B460B490B4A0B4E-0B550B58-0B5B0B5E0B640B650B72-0B810B840B8B-0B8D0B910B96-0B980B9B0B9D0BA0-0BA20BA5-0BA70BAB-0BAD0BBA-0BBD0BC3-0BC50BC90BCE0BCF0BD1-0BD60BD8-0BE50BFB-0C000C040C0D0C110C290C340C3A-0C3C0C450C490C4E-0C540C570C5A-0C5F0C640C650C70-0C770C800C810C840C8D0C910CA90CB40CBA0CBB0CC50CC90CCE-0CD40CD7-0CDD0CDF0CE40CE50CF00CF3-0D010D040D0D0D110D290D3A-0D3C0D450D490D4E-0D560D58-0D5F0D640D650D76-0D780D800D810D840D97-0D990DB20DBC0DBE0DBF0DC7-0DC90DCB-0DCE0DD50DD70DE0-0DF10DF5-0E000E3B-0E3E0E5C-0E800E830E850E860E890E8B0E8C0E8E-0E930E980EA00EA40EA60EA80EA90EAC0EBA0EBE0EBF0EC50EC70ECE0ECF0EDA0EDB0EDE-0EFF0F480F6D-0F700F8C-0F8F0F980FBD0FCD0FD9-0FFF10C6-10CF10FD-10FF1249124E124F12571259125E125F1289128E128F12B112B612B712BF12C112C612C712D7131113161317135B-135E137D-137F139A-139F13F5-13FF169D-169F16F1-16FF170D1715-171F1737-173F1754-175F176D17711774-177F17B417B517DE17DF17EA-17EF17FA-17FF180F181A-181F1878-187F18AB-18AF18F6-18FF191D-191F192C-192F193C-193F1941-1943196E196F1975-197F19AC-19AF19CA-19CF19DB-19DD1A1C1A1D1A5F1A7D1A7E1A8A-1A8F1A9A-1A9F1AAE-1AFF1B4C-1B4F1B7D-1B7F1BAB-1BAD1BBA-1BFF1C38-1C3A1C4A-1C4C1C80-1CCF1CF3-1CFF1DE7-1DFC1F161F171F1E1F1F1F461F471F4E1F4F1F581F5A1F5C1F5E1F7E1F7F1FB51FC51FD41FD51FDC1FF01FF11FF51FFF200B-200F202A-202E2060-206F20722073208F2095-209F20B9-20CF20F1-20FF218A-218F23E9-23FF2427-243F244B-245F26CE26E226E4-26E727002705270A270B2728274C274E2753-2755275F27602795-279727B027BF27CB27CD-27CF2B4D-2B4F2B5A-2BFF2C2F2C5F2CF2-2CF82D26-2D2F2D66-2D6E2D70-2D7F2D97-2D9F2DA72DAF2DB72DBF2DC72DCF2DD72DDF2E32-2E7F2E9A2EF4-2EFF2FD6-2FEF2FFC-2FFF3040309730983100-3104312E-3130318F31B8-31BF31E4-31EF321F32FF4DB6-4DBF9FCC-9FFFA48D-A48FA4C7-A4CFA62C-A63FA660A661A674-A67BA698-A69FA6F8-A6FFA78D-A7FAA82C-A82FA83A-A83FA878-A87FA8C5-A8CDA8DA-A8DFA8FC-A8FFA954-A95EA97D-A97FA9CEA9DA-A9DDA9E0-A9FFAA37-AA3FAA4EAA4FAA5AAA5BAA7C-AA7FAAC3-AADAAAE0-ABBFABEEABEFABFA-ABFFD7A4-D7AFD7C7-D7CAD7FC-F8FFFA2EFA2FFA6EFA6FFADA-FAFFFB07-FB12FB18-FB1CFB37FB3DFB3FFB42FB45FBB2-FBD2FD40-FD4FFD90FD91FDC8-FDEFFDFEFDFFFE1A-FE1FFE27-FE2FFE53FE67FE6C-FE6FFE75FEFD-FF00FFBF-FFC1FFC8FFC9FFD0FFD1FFD8FFD9FFDD-FFDFFFE7FFEF-FFFBFFFEFFFF",
	    Cc: "0000-001F007F-009F",
	    Cf: "00AD0600-060306DD070F17B417B5200B-200F202A-202E2060-2064206A-206FFEFFFFF9-FFFB",
	    Co: "E000-F8FF",
	    Cs: "D800-DFFF",
	    Cn: "03780379037F-0383038B038D03A20526-05300557055805600588058B-059005C8-05CF05EB-05EF05F5-05FF06040605061C061D0620065F070E074B074C07B2-07BF07FB-07FF082E082F083F-08FF093A093B094F095609570973-097809800984098D098E0991099209A909B109B3-09B509BA09BB09C509C609C909CA09CF-09D609D8-09DB09DE09E409E509FC-0A000A040A0B-0A0E0A110A120A290A310A340A370A3A0A3B0A3D0A43-0A460A490A4A0A4E-0A500A52-0A580A5D0A5F-0A650A76-0A800A840A8E0A920AA90AB10AB40ABA0ABB0AC60ACA0ACE0ACF0AD1-0ADF0AE40AE50AF00AF2-0B000B040B0D0B0E0B110B120B290B310B340B3A0B3B0B450B460B490B4A0B4E-0B550B58-0B5B0B5E0B640B650B72-0B810B840B8B-0B8D0B910B96-0B980B9B0B9D0BA0-0BA20BA5-0BA70BAB-0BAD0BBA-0BBD0BC3-0BC50BC90BCE0BCF0BD1-0BD60BD8-0BE50BFB-0C000C040C0D0C110C290C340C3A-0C3C0C450C490C4E-0C540C570C5A-0C5F0C640C650C70-0C770C800C810C840C8D0C910CA90CB40CBA0CBB0CC50CC90CCE-0CD40CD7-0CDD0CDF0CE40CE50CF00CF3-0D010D040D0D0D110D290D3A-0D3C0D450D490D4E-0D560D58-0D5F0D640D650D76-0D780D800D810D840D97-0D990DB20DBC0DBE0DBF0DC7-0DC90DCB-0DCE0DD50DD70DE0-0DF10DF5-0E000E3B-0E3E0E5C-0E800E830E850E860E890E8B0E8C0E8E-0E930E980EA00EA40EA60EA80EA90EAC0EBA0EBE0EBF0EC50EC70ECE0ECF0EDA0EDB0EDE-0EFF0F480F6D-0F700F8C-0F8F0F980FBD0FCD0FD9-0FFF10C6-10CF10FD-10FF1249124E124F12571259125E125F1289128E128F12B112B612B712BF12C112C612C712D7131113161317135B-135E137D-137F139A-139F13F5-13FF169D-169F16F1-16FF170D1715-171F1737-173F1754-175F176D17711774-177F17DE17DF17EA-17EF17FA-17FF180F181A-181F1878-187F18AB-18AF18F6-18FF191D-191F192C-192F193C-193F1941-1943196E196F1975-197F19AC-19AF19CA-19CF19DB-19DD1A1C1A1D1A5F1A7D1A7E1A8A-1A8F1A9A-1A9F1AAE-1AFF1B4C-1B4F1B7D-1B7F1BAB-1BAD1BBA-1BFF1C38-1C3A1C4A-1C4C1C80-1CCF1CF3-1CFF1DE7-1DFC1F161F171F1E1F1F1F461F471F4E1F4F1F581F5A1F5C1F5E1F7E1F7F1FB51FC51FD41FD51FDC1FF01FF11FF51FFF2065-206920722073208F2095-209F20B9-20CF20F1-20FF218A-218F23E9-23FF2427-243F244B-245F26CE26E226E4-26E727002705270A270B2728274C274E2753-2755275F27602795-279727B027BF27CB27CD-27CF2B4D-2B4F2B5A-2BFF2C2F2C5F2CF2-2CF82D26-2D2F2D66-2D6E2D70-2D7F2D97-2D9F2DA72DAF2DB72DBF2DC72DCF2DD72DDF2E32-2E7F2E9A2EF4-2EFF2FD6-2FEF2FFC-2FFF3040309730983100-3104312E-3130318F31B8-31BF31E4-31EF321F32FF4DB6-4DBF9FCC-9FFFA48D-A48FA4C7-A4CFA62C-A63FA660A661A674-A67BA698-A69FA6F8-A6FFA78D-A7FAA82C-A82FA83A-A83FA878-A87FA8C5-A8CDA8DA-A8DFA8FC-A8FFA954-A95EA97D-A97FA9CEA9DA-A9DDA9E0-A9FFAA37-AA3FAA4EAA4FAA5AAA5BAA7C-AA7FAAC3-AADAAAE0-ABBFABEEABEFABFA-ABFFD7A4-D7AFD7C7-D7CAD7FC-D7FFFA2EFA2FFA6EFA6FFADA-FAFFFB07-FB12FB18-FB1CFB37FB3DFB3FFB42FB45FBB2-FBD2FD40-FD4FFD90FD91FDC8-FDEFFDFEFDFFFE1A-FE1FFE27-FE2FFE53FE67FE6C-FE6FFE75FEFDFEFEFF00FFBF-FFC1FFC8FFC9FFD0FFD1FFD8FFD9FFDD-FFDFFFE7FFEF-FFF8FFFEFFFF"
	});

	function addUnicodePackage (pack) {
	    var codePoint = /\w{4}/g;
	    for (var name in pack)
	        exports.packages[name] = pack[name].replace(codePoint, "\\u$&");
	}

	});

	ace.define("ace/mode/text",["require","exports","module","ace/tokenizer","ace/mode/text_highlight_rules","ace/mode/behaviour/cstyle","ace/unicode","ace/lib/lang","ace/token_iterator","ace/range"], function(acequire, exports, module) {
	"use strict";

	var Tokenizer = acequire("../tokenizer").Tokenizer;
	var TextHighlightRules = acequire("./text_highlight_rules").TextHighlightRules;
	var CstyleBehaviour = acequire("./behaviour/cstyle").CstyleBehaviour;
	var unicode = acequire("../unicode");
	var lang = acequire("../lib/lang");
	var TokenIterator = acequire("../token_iterator").TokenIterator;
	var Range = acequire("../range").Range;

	var Mode = function() {
	    this.HighlightRules = TextHighlightRules;
	};

	(function() {
	    this.$defaultBehaviour = new CstyleBehaviour();

	    this.tokenRe = new RegExp("^["
	        + unicode.packages.L
	        + unicode.packages.Mn + unicode.packages.Mc
	        + unicode.packages.Nd
	        + unicode.packages.Pc + "\\$_]+", "g"
	    );

	    this.nonTokenRe = new RegExp("^(?:[^"
	        + unicode.packages.L
	        + unicode.packages.Mn + unicode.packages.Mc
	        + unicode.packages.Nd
	        + unicode.packages.Pc + "\\$_]|\\s])+", "g"
	    );

	    this.getTokenizer = function() {
	        if (!this.$tokenizer) {
	            this.$highlightRules = this.$highlightRules || new this.HighlightRules(this.$highlightRuleConfig);
	            this.$tokenizer = new Tokenizer(this.$highlightRules.getRules());
	        }
	        return this.$tokenizer;
	    };

	    this.lineCommentStart = "";
	    this.blockComment = "";

	    this.toggleCommentLines = function(state, session, startRow, endRow) {
	        var doc = session.doc;

	        var ignoreBlankLines = true;
	        var shouldRemove = true;
	        var minIndent = Infinity;
	        var tabSize = session.getTabSize();
	        var insertAtTabStop = false;

	        if (!this.lineCommentStart) {
	            if (!this.blockComment)
	                return false;
	            var lineCommentStart = this.blockComment.start;
	            var lineCommentEnd = this.blockComment.end;
	            var regexpStart = new RegExp("^(\\s*)(?:" + lang.escapeRegExp(lineCommentStart) + ")");
	            var regexpEnd = new RegExp("(?:" + lang.escapeRegExp(lineCommentEnd) + ")\\s*$");

	            var comment = function(line, i) {
	                if (testRemove(line, i))
	                    return;
	                if (!ignoreBlankLines || /\S/.test(line)) {
	                    doc.insertInLine({row: i, column: line.length}, lineCommentEnd);
	                    doc.insertInLine({row: i, column: minIndent}, lineCommentStart);
	                }
	            };

	            var uncomment = function(line, i) {
	                var m;
	                if (m = line.match(regexpEnd))
	                    doc.removeInLine(i, line.length - m[0].length, line.length);
	                if (m = line.match(regexpStart))
	                    doc.removeInLine(i, m[1].length, m[0].length);
	            };

	            var testRemove = function(line, row) {
	                if (regexpStart.test(line))
	                    return true;
	                var tokens = session.getTokens(row);
	                for (var i = 0; i < tokens.length; i++) {
	                    if (tokens[i].type === "comment")
	                        return true;
	                }
	            };
	        } else {
	            if (Array.isArray(this.lineCommentStart)) {
	                var regexpStart = this.lineCommentStart.map(lang.escapeRegExp).join("|");
	                var lineCommentStart = this.lineCommentStart[0];
	            } else {
	                var regexpStart = lang.escapeRegExp(this.lineCommentStart);
	                var lineCommentStart = this.lineCommentStart;
	            }
	            regexpStart = new RegExp("^(\\s*)(?:" + regexpStart + ") ?");
	            
	            insertAtTabStop = session.getUseSoftTabs();

	            var uncomment = function(line, i) {
	                var m = line.match(regexpStart);
	                if (!m) return;
	                var start = m[1].length, end = m[0].length;
	                if (!shouldInsertSpace(line, start, end) && m[0][end - 1] == " ")
	                    end--;
	                doc.removeInLine(i, start, end);
	            };
	            var commentWithSpace = lineCommentStart + " ";
	            var comment = function(line, i) {
	                if (!ignoreBlankLines || /\S/.test(line)) {
	                    if (shouldInsertSpace(line, minIndent, minIndent))
	                        doc.insertInLine({row: i, column: minIndent}, commentWithSpace);
	                    else
	                        doc.insertInLine({row: i, column: minIndent}, lineCommentStart);
	                }
	            };
	            var testRemove = function(line, i) {
	                return regexpStart.test(line);
	            };
	            
	            var shouldInsertSpace = function(line, before, after) {
	                var spaces = 0;
	                while (before-- && line.charAt(before) == " ")
	                    spaces++;
	                if (spaces % tabSize != 0)
	                    return false;
	                var spaces = 0;
	                while (line.charAt(after++) == " ")
	                    spaces++;
	                if (tabSize > 2)
	                    return spaces % tabSize != tabSize - 1;
	                else
	                    return spaces % tabSize == 0;
	                return true;
	            };
	        }

	        function iter(fun) {
	            for (var i = startRow; i <= endRow; i++)
	                fun(doc.getLine(i), i);
	        }


	        var minEmptyLength = Infinity;
	        iter(function(line, i) {
	            var indent = line.search(/\S/);
	            if (indent !== -1) {
	                if (indent < minIndent)
	                    minIndent = indent;
	                if (shouldRemove && !testRemove(line, i))
	                    shouldRemove = false;
	            } else if (minEmptyLength > line.length) {
	                minEmptyLength = line.length;
	            }
	        });

	        if (minIndent == Infinity) {
	            minIndent = minEmptyLength;
	            ignoreBlankLines = false;
	            shouldRemove = false;
	        }

	        if (insertAtTabStop && minIndent % tabSize != 0)
	            minIndent = Math.floor(minIndent / tabSize) * tabSize;

	        iter(shouldRemove ? uncomment : comment);
	    };

	    this.toggleBlockComment = function(state, session, range, cursor) {
	        var comment = this.blockComment;
	        if (!comment)
	            return;
	        if (!comment.start && comment[0])
	            comment = comment[0];

	        var iterator = new TokenIterator(session, cursor.row, cursor.column);
	        var token = iterator.getCurrentToken();

	        var sel = session.selection;
	        var initialRange = session.selection.toOrientedRange();
	        var startRow, colDiff;

	        if (token && /comment/.test(token.type)) {
	            var startRange, endRange;
	            while (token && /comment/.test(token.type)) {
	                var i = token.value.indexOf(comment.start);
	                if (i != -1) {
	                    var row = iterator.getCurrentTokenRow();
	                    var column = iterator.getCurrentTokenColumn() + i;
	                    startRange = new Range(row, column, row, column + comment.start.length);
	                    break;
	                }
	                token = iterator.stepBackward();
	            }

	            var iterator = new TokenIterator(session, cursor.row, cursor.column);
	            var token = iterator.getCurrentToken();
	            while (token && /comment/.test(token.type)) {
	                var i = token.value.indexOf(comment.end);
	                if (i != -1) {
	                    var row = iterator.getCurrentTokenRow();
	                    var column = iterator.getCurrentTokenColumn() + i;
	                    endRange = new Range(row, column, row, column + comment.end.length);
	                    break;
	                }
	                token = iterator.stepForward();
	            }
	            if (endRange)
	                session.remove(endRange);
	            if (startRange) {
	                session.remove(startRange);
	                startRow = startRange.start.row;
	                colDiff = -comment.start.length;
	            }
	        } else {
	            colDiff = comment.start.length;
	            startRow = range.start.row;
	            session.insert(range.end, comment.end);
	            session.insert(range.start, comment.start);
	        }
	        if (initialRange.start.row == startRow)
	            initialRange.start.column += colDiff;
	        if (initialRange.end.row == startRow)
	            initialRange.end.column += colDiff;
	        session.selection.fromOrientedRange(initialRange);
	    };

	    this.getNextLineIndent = function(state, line, tab) {
	        return this.$getIndent(line);
	    };

	    this.checkOutdent = function(state, line, input) {
	        return false;
	    };

	    this.autoOutdent = function(state, doc, row) {
	    };

	    this.$getIndent = function(line) {
	        return line.match(/^\s*/)[0];
	    };

	    this.createWorker = function(session) {
	        return null;
	    };

	    this.createModeDelegates = function (mapping) {
	        this.$embeds = [];
	        this.$modes = {};
	        for (var i in mapping) {
	            if (mapping[i]) {
	                this.$embeds.push(i);
	                this.$modes[i] = new mapping[i]();
	            }
	        }

	        var delegations = ["toggleBlockComment", "toggleCommentLines", "getNextLineIndent", 
	            "checkOutdent", "autoOutdent", "transformAction", "getCompletions"];

	        for (var i = 0; i < delegations.length; i++) {
	            (function(scope) {
	              var functionName = delegations[i];
	              var defaultHandler = scope[functionName];
	              scope[delegations[i]] = function() {
	                  return this.$delegator(functionName, arguments, defaultHandler);
	              };
	            }(this));
	        }
	    };

	    this.$delegator = function(method, args, defaultHandler) {
	        var state = args[0];
	        if (typeof state != "string")
	            state = state[0];
	        for (var i = 0; i < this.$embeds.length; i++) {
	            if (!this.$modes[this.$embeds[i]]) continue;

	            var split = state.split(this.$embeds[i]);
	            if (!split[0] && split[1]) {
	                args[0] = split[1];
	                var mode = this.$modes[this.$embeds[i]];
	                return mode[method].apply(mode, args);
	            }
	        }
	        var ret = defaultHandler.apply(this, args);
	        return defaultHandler ? ret : undefined;
	    };

	    this.transformAction = function(state, action, editor, session, param) {
	        if (this.$behaviour) {
	            var behaviours = this.$behaviour.getBehaviours();
	            for (var key in behaviours) {
	                if (behaviours[key][action]) {
	                    var ret = behaviours[key][action].apply(this, arguments);
	                    if (ret) {
	                        return ret;
	                    }
	                }
	            }
	        }
	    };
	    
	    this.getKeywords = function(append) {
	        if (!this.completionKeywords) {
	            var rules = this.$tokenizer.rules;
	            var completionKeywords = [];
	            for (var rule in rules) {
	                var ruleItr = rules[rule];
	                for (var r = 0, l = ruleItr.length; r < l; r++) {
	                    if (typeof ruleItr[r].token === "string") {
	                        if (/keyword|support|storage/.test(ruleItr[r].token))
	                            completionKeywords.push(ruleItr[r].regex);
	                    }
	                    else if (typeof ruleItr[r].token === "object") {
	                        for (var a = 0, aLength = ruleItr[r].token.length; a < aLength; a++) {    
	                            if (/keyword|support|storage/.test(ruleItr[r].token[a])) {
	                                var rule = ruleItr[r].regex.match(/\(.+?\)/g)[a];
	                                completionKeywords.push(rule.substr(1, rule.length - 2));
	                            }
	                        }
	                    }
	                }
	            }
	            this.completionKeywords = completionKeywords;
	        }
	        if (!append)
	            return this.$keywordList;
	        return completionKeywords.concat(this.$keywordList || []);
	    };
	    
	    this.$createKeywordList = function() {
	        if (!this.$highlightRules)
	            this.getTokenizer();
	        return this.$keywordList = this.$highlightRules.$keywordList || [];
	    };

	    this.getCompletions = function(state, session, pos, prefix) {
	        var keywords = this.$keywordList || this.$createKeywordList();
	        return keywords.map(function(word) {
	            return {
	                name: word,
	                value: word,
	                score: 0,
	                meta: "keyword"
	            };
	        });
	    };

	    this.$id = "ace/mode/text";
	}).call(Mode.prototype);

	exports.Mode = Mode;
	});

	ace.define("ace/apply_delta",["require","exports","module"], function(acequire, exports, module) {
	"use strict";

	function throwDeltaError(delta, errorText){
	    console.log("Invalid Delta:", delta);
	    throw "Invalid Delta: " + errorText;
	}

	function positionInDocument(docLines, position) {
	    return position.row    >= 0 && position.row    <  docLines.length &&
	           position.column >= 0 && position.column <= docLines[position.row].length;
	}

	function validateDelta(docLines, delta) {
	    if (delta.action != "insert" && delta.action != "remove")
	        throwDeltaError(delta, "delta.action must be 'insert' or 'remove'");
	    if (!(delta.lines instanceof Array))
	        throwDeltaError(delta, "delta.lines must be an Array");
	    if (!delta.start || !delta.end)
	       throwDeltaError(delta, "delta.start/end must be an present");
	    var start = delta.start;
	    if (!positionInDocument(docLines, delta.start))
	        throwDeltaError(delta, "delta.start must be contained in document");
	    var end = delta.end;
	    if (delta.action == "remove" && !positionInDocument(docLines, end))
	        throwDeltaError(delta, "delta.end must contained in document for 'remove' actions");
	    var numRangeRows = end.row - start.row;
	    var numRangeLastLineChars = (end.column - (numRangeRows == 0 ? start.column : 0));
	    if (numRangeRows != delta.lines.length - 1 || delta.lines[numRangeRows].length != numRangeLastLineChars)
	        throwDeltaError(delta, "delta.range must match delta lines");
	}

	exports.applyDelta = function(docLines, delta, doNotValidate) {
	    
	    var row = delta.start.row;
	    var startColumn = delta.start.column;
	    var line = docLines[row] || "";
	    switch (delta.action) {
	        case "insert":
	            var lines = delta.lines;
	            if (lines.length === 1) {
	                docLines[row] = line.substring(0, startColumn) + delta.lines[0] + line.substring(startColumn);
	            } else {
	                var args = [row, 1].concat(delta.lines);
	                docLines.splice.apply(docLines, args);
	                docLines[row] = line.substring(0, startColumn) + docLines[row];
	                docLines[row + delta.lines.length - 1] += line.substring(startColumn);
	            }
	            break;
	        case "remove":
	            var endColumn = delta.end.column;
	            var endRow = delta.end.row;
	            if (row === endRow) {
	                docLines[row] = line.substring(0, startColumn) + line.substring(endColumn);
	            } else {
	                docLines.splice(
	                    row, endRow - row + 1,
	                    line.substring(0, startColumn) + docLines[endRow].substring(endColumn)
	                );
	            }
	            break;
	    }
	}
	});

	ace.define("ace/anchor",["require","exports","module","ace/lib/oop","ace/lib/event_emitter"], function(acequire, exports, module) {
	"use strict";

	var oop = acequire("./lib/oop");
	var EventEmitter = acequire("./lib/event_emitter").EventEmitter;

	var Anchor = exports.Anchor = function(doc, row, column) {
	    this.$onChange = this.onChange.bind(this);
	    this.attach(doc);
	    
	    if (typeof column == "undefined")
	        this.setPosition(row.row, row.column);
	    else
	        this.setPosition(row, column);
	};

	(function() {

	    oop.implement(this, EventEmitter);
	    this.getPosition = function() {
	        return this.$clipPositionToDocument(this.row, this.column);
	    };
	    this.getDocument = function() {
	        return this.document;
	    };
	    this.$insertRight = false;
	    this.onChange = function(delta) {
	        if (delta.start.row == delta.end.row && delta.start.row != this.row)
	            return;

	        if (delta.start.row > this.row)
	            return;
	            
	        var point = $getTransformedPoint(delta, {row: this.row, column: this.column}, this.$insertRight);
	        this.setPosition(point.row, point.column, true);
	    };
	    
	    function $pointsInOrder(point1, point2, equalPointsInOrder) {
	        var bColIsAfter = equalPointsInOrder ? point1.column <= point2.column : point1.column < point2.column;
	        return (point1.row < point2.row) || (point1.row == point2.row && bColIsAfter);
	    }
	            
	    function $getTransformedPoint(delta, point, moveIfEqual) {
	        var deltaIsInsert = delta.action == "insert";
	        var deltaRowShift = (deltaIsInsert ? 1 : -1) * (delta.end.row    - delta.start.row);
	        var deltaColShift = (deltaIsInsert ? 1 : -1) * (delta.end.column - delta.start.column);
	        var deltaStart = delta.start;
	        var deltaEnd = deltaIsInsert ? deltaStart : delta.end; // Collapse insert range.
	        if ($pointsInOrder(point, deltaStart, moveIfEqual)) {
	            return {
	                row: point.row,
	                column: point.column
	            };
	        }
	        if ($pointsInOrder(deltaEnd, point, !moveIfEqual)) {
	            return {
	                row: point.row + deltaRowShift,
	                column: point.column + (point.row == deltaEnd.row ? deltaColShift : 0)
	            };
	        }
	        
	        return {
	            row: deltaStart.row,
	            column: deltaStart.column
	        };
	    }
	    this.setPosition = function(row, column, noClip) {
	        var pos;
	        if (noClip) {
	            pos = {
	                row: row,
	                column: column
	            };
	        } else {
	            pos = this.$clipPositionToDocument(row, column);
	        }

	        if (this.row == pos.row && this.column == pos.column)
	            return;

	        var old = {
	            row: this.row,
	            column: this.column
	        };

	        this.row = pos.row;
	        this.column = pos.column;
	        this._signal("change", {
	            old: old,
	            value: pos
	        });
	    };
	    this.detach = function() {
	        this.document.removeEventListener("change", this.$onChange);
	    };
	    this.attach = function(doc) {
	        this.document = doc || this.document;
	        this.document.on("change", this.$onChange);
	    };
	    this.$clipPositionToDocument = function(row, column) {
	        var pos = {};

	        if (row >= this.document.getLength()) {
	            pos.row = Math.max(0, this.document.getLength() - 1);
	            pos.column = this.document.getLine(pos.row).length;
	        }
	        else if (row < 0) {
	            pos.row = 0;
	            pos.column = 0;
	        }
	        else {
	            pos.row = row;
	            pos.column = Math.min(this.document.getLine(pos.row).length, Math.max(0, column));
	        }

	        if (column < 0)
	            pos.column = 0;

	        return pos;
	    };

	}).call(Anchor.prototype);

	});

	ace.define("ace/document",["require","exports","module","ace/lib/oop","ace/apply_delta","ace/lib/event_emitter","ace/range","ace/anchor"], function(acequire, exports, module) {
	"use strict";

	var oop = acequire("./lib/oop");
	var applyDelta = acequire("./apply_delta").applyDelta;
	var EventEmitter = acequire("./lib/event_emitter").EventEmitter;
	var Range = acequire("./range").Range;
	var Anchor = acequire("./anchor").Anchor;

	var Document = function(textOrLines) {
	    this.$lines = [""];
	    if (textOrLines.length === 0) {
	        this.$lines = [""];
	    } else if (Array.isArray(textOrLines)) {
	        this.insertMergedLines({row: 0, column: 0}, textOrLines);
	    } else {
	        this.insert({row: 0, column:0}, textOrLines);
	    }
	};

	(function() {

	    oop.implement(this, EventEmitter);
	    this.setValue = function(text) {
	        var len = this.getLength() - 1;
	        this.remove(new Range(0, 0, len, this.getLine(len).length));
	        this.insert({row: 0, column: 0}, text);
	    };
	    this.getValue = function() {
	        return this.getAllLines().join(this.getNewLineCharacter());
	    };
	    this.createAnchor = function(row, column) {
	        return new Anchor(this, row, column);
	    };
	    if ("aaa".split(/a/).length === 0) {
	        this.$split = function(text) {
	            return text.replace(/\r\n|\r/g, "\n").split("\n");
	        };
	    } else {
	        this.$split = function(text) {
	            return text.split(/\r\n|\r|\n/);
	        };
	    }


	    this.$detectNewLine = function(text) {
	        var match = text.match(/^.*?(\r\n|\r|\n)/m);
	        this.$autoNewLine = match ? match[1] : "\n";
	        this._signal("changeNewLineMode");
	    };
	    this.getNewLineCharacter = function() {
	        switch (this.$newLineMode) {
	          case "windows":
	            return "\r\n";
	          case "unix":
	            return "\n";
	          default:
	            return this.$autoNewLine || "\n";
	        }
	    };

	    this.$autoNewLine = "";
	    this.$newLineMode = "auto";
	    this.setNewLineMode = function(newLineMode) {
	        if (this.$newLineMode === newLineMode)
	            return;

	        this.$newLineMode = newLineMode;
	        this._signal("changeNewLineMode");
	    };
	    this.getNewLineMode = function() {
	        return this.$newLineMode;
	    };
	    this.isNewLine = function(text) {
	        return (text == "\r\n" || text == "\r" || text == "\n");
	    };
	    this.getLine = function(row) {
	        return this.$lines[row] || "";
	    };
	    this.getLines = function(firstRow, lastRow) {
	        return this.$lines.slice(firstRow, lastRow + 1);
	    };
	    this.getAllLines = function() {
	        return this.getLines(0, this.getLength());
	    };
	    this.getLength = function() {
	        return this.$lines.length;
	    };
	    this.getTextRange = function(range) {
	        return this.getLinesForRange(range).join(this.getNewLineCharacter());
	    };
	    this.getLinesForRange = function(range) {
	        var lines;
	        if (range.start.row === range.end.row) {
	            lines = [this.getLine(range.start.row).substring(range.start.column, range.end.column)];
	        } else {
	            lines = this.getLines(range.start.row, range.end.row);
	            lines[0] = (lines[0] || "").substring(range.start.column);
	            var l = lines.length - 1;
	            if (range.end.row - range.start.row == l)
	                lines[l] = lines[l].substring(0, range.end.column);
	        }
	        return lines;
	    };
	    this.insertLines = function(row, lines) {
	        console.warn("Use of document.insertLines is deprecated. Use the insertFullLines method instead.");
	        return this.insertFullLines(row, lines);
	    };
	    this.removeLines = function(firstRow, lastRow) {
	        console.warn("Use of document.removeLines is deprecated. Use the removeFullLines method instead.");
	        return this.removeFullLines(firstRow, lastRow);
	    };
	    this.insertNewLine = function(position) {
	        console.warn("Use of document.insertNewLine is deprecated. Use insertMergedLines(position, ['', '']) instead.");
	        return this.insertMergedLines(position, ["", ""]);
	    };
	    this.insert = function(position, text) {
	        if (this.getLength() <= 1)
	            this.$detectNewLine(text);
	        
	        return this.insertMergedLines(position, this.$split(text));
	    };
	    this.insertInLine = function(position, text) {
	        var start = this.clippedPos(position.row, position.column);
	        var end = this.pos(position.row, position.column + text.length);
	        
	        this.applyDelta({
	            start: start,
	            end: end,
	            action: "insert",
	            lines: [text]
	        }, true);
	        
	        return this.clonePos(end);
	    };
	    
	    this.clippedPos = function(row, column) {
	        var length = this.getLength();
	        if (row === undefined) {
	            row = length;
	        } else if (row < 0) {
	            row = 0;
	        } else if (row >= length) {
	            row = length - 1;
	            column = undefined;
	        }
	        var line = this.getLine(row);
	        if (column == undefined)
	            column = line.length;
	        column = Math.min(Math.max(column, 0), line.length);
	        return {row: row, column: column};
	    };
	    
	    this.clonePos = function(pos) {
	        return {row: pos.row, column: pos.column};
	    };
	    
	    this.pos = function(row, column) {
	        return {row: row, column: column};
	    };
	    
	    this.$clipPosition = function(position) {
	        var length = this.getLength();
	        if (position.row >= length) {
	            position.row = Math.max(0, length - 1);
	            position.column = this.getLine(length - 1).length;
	        } else {
	            position.row = Math.max(0, position.row);
	            position.column = Math.min(Math.max(position.column, 0), this.getLine(position.row).length);
	        }
	        return position;
	    };
	    this.insertFullLines = function(row, lines) {
	        row = Math.min(Math.max(row, 0), this.getLength());
	        var column = 0;
	        if (row < this.getLength()) {
	            lines = lines.concat([""]);
	            column = 0;
	        } else {
	            lines = [""].concat(lines);
	            row--;
	            column = this.$lines[row].length;
	        }
	        this.insertMergedLines({row: row, column: column}, lines);
	    };    
	    this.insertMergedLines = function(position, lines) {
	        var start = this.clippedPos(position.row, position.column);
	        var end = {
	            row: start.row + lines.length - 1,
	            column: (lines.length == 1 ? start.column : 0) + lines[lines.length - 1].length
	        };
	        
	        this.applyDelta({
	            start: start,
	            end: end,
	            action: "insert",
	            lines: lines
	        });
	        
	        return this.clonePos(end);
	    };
	    this.remove = function(range) {
	        var start = this.clippedPos(range.start.row, range.start.column);
	        var end = this.clippedPos(range.end.row, range.end.column);
	        this.applyDelta({
	            start: start,
	            end: end,
	            action: "remove",
	            lines: this.getLinesForRange({start: start, end: end})
	        });
	        return this.clonePos(start);
	    };
	    this.removeInLine = function(row, startColumn, endColumn) {
	        var start = this.clippedPos(row, startColumn);
	        var end = this.clippedPos(row, endColumn);
	        
	        this.applyDelta({
	            start: start,
	            end: end,
	            action: "remove",
	            lines: this.getLinesForRange({start: start, end: end})
	        }, true);
	        
	        return this.clonePos(start);
	    };
	    this.removeFullLines = function(firstRow, lastRow) {
	        firstRow = Math.min(Math.max(0, firstRow), this.getLength() - 1);
	        lastRow  = Math.min(Math.max(0, lastRow ), this.getLength() - 1);
	        var deleteFirstNewLine = lastRow == this.getLength() - 1 && firstRow > 0;
	        var deleteLastNewLine  = lastRow  < this.getLength() - 1;
	        var startRow = ( deleteFirstNewLine ? firstRow - 1                  : firstRow                    );
	        var startCol = ( deleteFirstNewLine ? this.getLine(startRow).length : 0                           );
	        var endRow   = ( deleteLastNewLine  ? lastRow + 1                   : lastRow                     );
	        var endCol   = ( deleteLastNewLine  ? 0                             : this.getLine(endRow).length ); 
	        var range = new Range(startRow, startCol, endRow, endCol);
	        var deletedLines = this.$lines.slice(firstRow, lastRow + 1);
	        
	        this.applyDelta({
	            start: range.start,
	            end: range.end,
	            action: "remove",
	            lines: this.getLinesForRange(range)
	        });
	        return deletedLines;
	    };
	    this.removeNewLine = function(row) {
	        if (row < this.getLength() - 1 && row >= 0) {
	            this.applyDelta({
	                start: this.pos(row, this.getLine(row).length),
	                end: this.pos(row + 1, 0),
	                action: "remove",
	                lines: ["", ""]
	            });
	        }
	    };
	    this.replace = function(range, text) {
	        if (!(range instanceof Range))
	            range = Range.fromPoints(range.start, range.end);
	        if (text.length === 0 && range.isEmpty())
	            return range.start;
	        if (text == this.getTextRange(range))
	            return range.end;

	        this.remove(range);
	        var end;
	        if (text) {
	            end = this.insert(range.start, text);
	        }
	        else {
	            end = range.start;
	        }
	        
	        return end;
	    };
	    this.applyDeltas = function(deltas) {
	        for (var i=0; i<deltas.length; i++) {
	            this.applyDelta(deltas[i]);
	        }
	    };
	    this.revertDeltas = function(deltas) {
	        for (var i=deltas.length-1; i>=0; i--) {
	            this.revertDelta(deltas[i]);
	        }
	    };
	    this.applyDelta = function(delta, doNotValidate) {
	        var isInsert = delta.action == "insert";
	        if (isInsert ? delta.lines.length <= 1 && !delta.lines[0]
	            : !Range.comparePoints(delta.start, delta.end)) {
	            return;
	        }
	        
	        if (isInsert && delta.lines.length > 20000)
	            this.$splitAndapplyLargeDelta(delta, 20000);
	        applyDelta(this.$lines, delta, doNotValidate);
	        this._signal("change", delta);
	    };
	    
	    this.$splitAndapplyLargeDelta = function(delta, MAX) {
	        var lines = delta.lines;
	        var l = lines.length;
	        var row = delta.start.row; 
	        var column = delta.start.column;
	        var from = 0, to = 0;
	        do {
	            from = to;
	            to += MAX - 1;
	            var chunk = lines.slice(from, to);
	            if (to > l) {
	                delta.lines = chunk;
	                delta.start.row = row + from;
	                delta.start.column = column;
	                break;
	            }
	            chunk.push("");
	            this.applyDelta({
	                start: this.pos(row + from, column),
	                end: this.pos(row + to, column = 0),
	                action: delta.action,
	                lines: chunk
	            }, true);
	        } while(true);
	    };
	    this.revertDelta = function(delta) {
	        this.applyDelta({
	            start: this.clonePos(delta.start),
	            end: this.clonePos(delta.end),
	            action: (delta.action == "insert" ? "remove" : "insert"),
	            lines: delta.lines.slice()
	        });
	    };
	    this.indexToPosition = function(index, startRow) {
	        var lines = this.$lines || this.getAllLines();
	        var newlineLength = this.getNewLineCharacter().length;
	        for (var i = startRow || 0, l = lines.length; i < l; i++) {
	            index -= lines[i].length + newlineLength;
	            if (index < 0)
	                return {row: i, column: index + lines[i].length + newlineLength};
	        }
	        return {row: l-1, column: lines[l-1].length};
	    };
	    this.positionToIndex = function(pos, startRow) {
	        var lines = this.$lines || this.getAllLines();
	        var newlineLength = this.getNewLineCharacter().length;
	        var index = 0;
	        var row = Math.min(pos.row, lines.length);
	        for (var i = startRow || 0; i < row; ++i)
	            index += lines[i].length + newlineLength;

	        return index + pos.column;
	    };

	}).call(Document.prototype);

	exports.Document = Document;
	});

	ace.define("ace/background_tokenizer",["require","exports","module","ace/lib/oop","ace/lib/event_emitter"], function(acequire, exports, module) {
	"use strict";

	var oop = acequire("./lib/oop");
	var EventEmitter = acequire("./lib/event_emitter").EventEmitter;

	var BackgroundTokenizer = function(tokenizer, editor) {
	    this.running = false;
	    this.lines = [];
	    this.states = [];
	    this.currentLine = 0;
	    this.tokenizer = tokenizer;

	    var self = this;

	    this.$worker = function() {
	        if (!self.running) { return; }

	        var workerStart = new Date();
	        var currentLine = self.currentLine;
	        var endLine = -1;
	        var doc = self.doc;

	        var startLine = currentLine;
	        while (self.lines[currentLine])
	            currentLine++;
	        
	        var len = doc.getLength();
	        var processedLines = 0;
	        self.running = false;
	        while (currentLine < len) {
	            self.$tokenizeRow(currentLine);
	            endLine = currentLine;
	            do {
	                currentLine++;
	            } while (self.lines[currentLine]);
	            processedLines ++;
	            if ((processedLines % 5 === 0) && (new Date() - workerStart) > 20) {                
	                self.running = setTimeout(self.$worker, 20);
	                break;
	            }
	        }
	        self.currentLine = currentLine;
	        
	        if (startLine <= endLine)
	            self.fireUpdateEvent(startLine, endLine);
	    };
	};

	(function(){

	    oop.implement(this, EventEmitter);
	    this.setTokenizer = function(tokenizer) {
	        this.tokenizer = tokenizer;
	        this.lines = [];
	        this.states = [];

	        this.start(0);
	    };
	    this.setDocument = function(doc) {
	        this.doc = doc;
	        this.lines = [];
	        this.states = [];

	        this.stop();
	    };
	    this.fireUpdateEvent = function(firstRow, lastRow) {
	        var data = {
	            first: firstRow,
	            last: lastRow
	        };
	        this._signal("update", {data: data});
	    };
	    this.start = function(startRow) {
	        this.currentLine = Math.min(startRow || 0, this.currentLine, this.doc.getLength());
	        this.lines.splice(this.currentLine, this.lines.length);
	        this.states.splice(this.currentLine, this.states.length);

	        this.stop();
	        this.running = setTimeout(this.$worker, 700);
	    };
	    
	    this.scheduleStart = function() {
	        if (!this.running)
	            this.running = setTimeout(this.$worker, 700);
	    }

	    this.$updateOnChange = function(delta) {
	        var startRow = delta.start.row;
	        var len = delta.end.row - startRow;

	        if (len === 0) {
	            this.lines[startRow] = null;
	        } else if (delta.action == "remove") {
	            this.lines.splice(startRow, len + 1, null);
	            this.states.splice(startRow, len + 1, null);
	        } else {
	            var args = Array(len + 1);
	            args.unshift(startRow, 1);
	            this.lines.splice.apply(this.lines, args);
	            this.states.splice.apply(this.states, args);
	        }

	        this.currentLine = Math.min(startRow, this.currentLine, this.doc.getLength());

	        this.stop();
	    };
	    this.stop = function() {
	        if (this.running)
	            clearTimeout(this.running);
	        this.running = false;
	    };
	    this.getTokens = function(row) {
	        return this.lines[row] || this.$tokenizeRow(row);
	    };
	    this.getState = function(row) {
	        if (this.currentLine == row)
	            this.$tokenizeRow(row);
	        return this.states[row] || "start";
	    };

	    this.$tokenizeRow = function(row) {
	        var line = this.doc.getLine(row);
	        var state = this.states[row - 1];

	        var data = this.tokenizer.getLineTokens(line, state, row);

	        if (this.states[row] + "" !== data.state + "") {
	            this.states[row] = data.state;
	            this.lines[row + 1] = null;
	            if (this.currentLine > row + 1)
	                this.currentLine = row + 1;
	        } else if (this.currentLine == row) {
	            this.currentLine = row + 1;
	        }

	        return this.lines[row] = data.tokens;
	    };

	}).call(BackgroundTokenizer.prototype);

	exports.BackgroundTokenizer = BackgroundTokenizer;
	});

	ace.define("ace/search_highlight",["require","exports","module","ace/lib/lang","ace/lib/oop","ace/range"], function(acequire, exports, module) {
	"use strict";

	var lang = acequire("./lib/lang");
	var oop = acequire("./lib/oop");
	var Range = acequire("./range").Range;

	var SearchHighlight = function(regExp, clazz, type) {
	    this.setRegexp(regExp);
	    this.clazz = clazz;
	    this.type = type || "text";
	};

	(function() {
	    this.MAX_RANGES = 500;
	    
	    this.setRegexp = function(regExp) {
	        if (this.regExp+"" == regExp+"")
	            return;
	        this.regExp = regExp;
	        this.cache = [];
	    };

	    this.update = function(html, markerLayer, session, config) {
	        if (!this.regExp)
	            return;
	        var start = config.firstRow, end = config.lastRow;

	        for (var i = start; i <= end; i++) {
	            var ranges = this.cache[i];
	            if (ranges == null) {
	                ranges = lang.getMatchOffsets(session.getLine(i), this.regExp);
	                if (ranges.length > this.MAX_RANGES)
	                    ranges = ranges.slice(0, this.MAX_RANGES);
	                ranges = ranges.map(function(match) {
	                    return new Range(i, match.offset, i, match.offset + match.length);
	                });
	                this.cache[i] = ranges.length ? ranges : "";
	            }

	            for (var j = ranges.length; j --; ) {
	                markerLayer.drawSingleLineMarker(
	                    html, ranges[j].toScreenRange(session), this.clazz, config);
	            }
	        }
	    };

	}).call(SearchHighlight.prototype);

	exports.SearchHighlight = SearchHighlight;
	});

	ace.define("ace/edit_session/fold_line",["require","exports","module","ace/range"], function(acequire, exports, module) {
	"use strict";

	var Range = acequire("../range").Range;
	function FoldLine(foldData, folds) {
	    this.foldData = foldData;
	    if (Array.isArray(folds)) {
	        this.folds = folds;
	    } else {
	        folds = this.folds = [ folds ];
	    }

	    var last = folds[folds.length - 1];
	    this.range = new Range(folds[0].start.row, folds[0].start.column,
	                           last.end.row, last.end.column);
	    this.start = this.range.start;
	    this.end   = this.range.end;

	    this.folds.forEach(function(fold) {
	        fold.setFoldLine(this);
	    }, this);
	}

	(function() {
	    this.shiftRow = function(shift) {
	        this.start.row += shift;
	        this.end.row += shift;
	        this.folds.forEach(function(fold) {
	            fold.start.row += shift;
	            fold.end.row += shift;
	        });
	    };

	    this.addFold = function(fold) {
	        if (fold.sameRow) {
	            if (fold.start.row < this.startRow || fold.endRow > this.endRow) {
	                throw new Error("Can't add a fold to this FoldLine as it has no connection");
	            }
	            this.folds.push(fold);
	            this.folds.sort(function(a, b) {
	                return -a.range.compareEnd(b.start.row, b.start.column);
	            });
	            if (this.range.compareEnd(fold.start.row, fold.start.column) > 0) {
	                this.end.row = fold.end.row;
	                this.end.column =  fold.end.column;
	            } else if (this.range.compareStart(fold.end.row, fold.end.column) < 0) {
	                this.start.row = fold.start.row;
	                this.start.column = fold.start.column;
	            }
	        } else if (fold.start.row == this.end.row) {
	            this.folds.push(fold);
	            this.end.row = fold.end.row;
	            this.end.column = fold.end.column;
	        } else if (fold.end.row == this.start.row) {
	            this.folds.unshift(fold);
	            this.start.row = fold.start.row;
	            this.start.column = fold.start.column;
	        } else {
	            throw new Error("Trying to add fold to FoldRow that doesn't have a matching row");
	        }
	        fold.foldLine = this;
	    };

	    this.containsRow = function(row) {
	        return row >= this.start.row && row <= this.end.row;
	    };

	    this.walk = function(callback, endRow, endColumn) {
	        var lastEnd = 0,
	            folds = this.folds,
	            fold,
	            cmp, stop, isNewRow = true;

	        if (endRow == null) {
	            endRow = this.end.row;
	            endColumn = this.end.column;
	        }

	        for (var i = 0; i < folds.length; i++) {
	            fold = folds[i];

	            cmp = fold.range.compareStart(endRow, endColumn);
	            if (cmp == -1) {
	                callback(null, endRow, endColumn, lastEnd, isNewRow);
	                return;
	            }

	            stop = callback(null, fold.start.row, fold.start.column, lastEnd, isNewRow);
	            stop = !stop && callback(fold.placeholder, fold.start.row, fold.start.column, lastEnd);
	            if (stop || cmp === 0) {
	                return;
	            }
	            isNewRow = !fold.sameRow;
	            lastEnd = fold.end.column;
	        }
	        callback(null, endRow, endColumn, lastEnd, isNewRow);
	    };

	    this.getNextFoldTo = function(row, column) {
	        var fold, cmp;
	        for (var i = 0; i < this.folds.length; i++) {
	            fold = this.folds[i];
	            cmp = fold.range.compareEnd(row, column);
	            if (cmp == -1) {
	                return {
	                    fold: fold,
	                    kind: "after"
	                };
	            } else if (cmp === 0) {
	                return {
	                    fold: fold,
	                    kind: "inside"
	                };
	            }
	        }
	        return null;
	    };

	    this.addRemoveChars = function(row, column, len) {
	        var ret = this.getNextFoldTo(row, column),
	            fold, folds;
	        if (ret) {
	            fold = ret.fold;
	            if (ret.kind == "inside"
	                && fold.start.column != column
	                && fold.start.row != row)
	            {
	                window.console && window.console.log(row, column, fold);
	            } else if (fold.start.row == row) {
	                folds = this.folds;
	                var i = folds.indexOf(fold);
	                if (i === 0) {
	                    this.start.column += len;
	                }
	                for (i; i < folds.length; i++) {
	                    fold = folds[i];
	                    fold.start.column += len;
	                    if (!fold.sameRow) {
	                        return;
	                    }
	                    fold.end.column += len;
	                }
	                this.end.column += len;
	            }
	        }
	    };

	    this.split = function(row, column) {
	        var pos = this.getNextFoldTo(row, column);
	        
	        if (!pos || pos.kind == "inside")
	            return null;
	            
	        var fold = pos.fold;
	        var folds = this.folds;
	        var foldData = this.foldData;
	        
	        var i = folds.indexOf(fold);
	        var foldBefore = folds[i - 1];
	        this.end.row = foldBefore.end.row;
	        this.end.column = foldBefore.end.column;
	        folds = folds.splice(i, folds.length - i);

	        var newFoldLine = new FoldLine(foldData, folds);
	        foldData.splice(foldData.indexOf(this) + 1, 0, newFoldLine);
	        return newFoldLine;
	    };

	    this.merge = function(foldLineNext) {
	        var folds = foldLineNext.folds;
	        for (var i = 0; i < folds.length; i++) {
	            this.addFold(folds[i]);
	        }
	        var foldData = this.foldData;
	        foldData.splice(foldData.indexOf(foldLineNext), 1);
	    };

	    this.toString = function() {
	        var ret = [this.range.toString() + ": [" ];

	        this.folds.forEach(function(fold) {
	            ret.push("  " + fold.toString());
	        });
	        ret.push("]");
	        return ret.join("\n");
	    };

	    this.idxToPosition = function(idx) {
	        var lastFoldEndColumn = 0;

	        for (var i = 0; i < this.folds.length; i++) {
	            var fold = this.folds[i];

	            idx -= fold.start.column - lastFoldEndColumn;
	            if (idx < 0) {
	                return {
	                    row: fold.start.row,
	                    column: fold.start.column + idx
	                };
	            }

	            idx -= fold.placeholder.length;
	            if (idx < 0) {
	                return fold.start;
	            }

	            lastFoldEndColumn = fold.end.column;
	        }

	        return {
	            row: this.end.row,
	            column: this.end.column + idx
	        };
	    };
	}).call(FoldLine.prototype);

	exports.FoldLine = FoldLine;
	});

	ace.define("ace/range_list",["require","exports","module","ace/range"], function(acequire, exports, module) {
	"use strict";
	var Range = acequire("./range").Range;
	var comparePoints = Range.comparePoints;

	var RangeList = function() {
	    this.ranges = [];
	};

	(function() {
	    this.comparePoints = comparePoints;

	    this.pointIndex = function(pos, excludeEdges, startIndex) {
	        var list = this.ranges;

	        for (var i = startIndex || 0; i < list.length; i++) {
	            var range = list[i];
	            var cmpEnd = comparePoints(pos, range.end);
	            if (cmpEnd > 0)
	                continue;
	            var cmpStart = comparePoints(pos, range.start);
	            if (cmpEnd === 0)
	                return excludeEdges && cmpStart !== 0 ? -i-2 : i;
	            if (cmpStart > 0 || (cmpStart === 0 && !excludeEdges))
	                return i;

	            return -i-1;
	        }
	        return -i - 1;
	    };

	    this.add = function(range) {
	        var excludeEdges = !range.isEmpty();
	        var startIndex = this.pointIndex(range.start, excludeEdges);
	        if (startIndex < 0)
	            startIndex = -startIndex - 1;

	        var endIndex = this.pointIndex(range.end, excludeEdges, startIndex);

	        if (endIndex < 0)
	            endIndex = -endIndex - 1;
	        else
	            endIndex++;
	        return this.ranges.splice(startIndex, endIndex - startIndex, range);
	    };

	    this.addList = function(list) {
	        var removed = [];
	        for (var i = list.length; i--; ) {
	            removed.push.apply(removed, this.add(list[i]));
	        }
	        return removed;
	    };

	    this.substractPoint = function(pos) {
	        var i = this.pointIndex(pos);

	        if (i >= 0)
	            return this.ranges.splice(i, 1);
	    };
	    this.merge = function() {
	        var removed = [];
	        var list = this.ranges;
	        
	        list = list.sort(function(a, b) {
	            return comparePoints(a.start, b.start);
	        });
	        
	        var next = list[0], range;
	        for (var i = 1; i < list.length; i++) {
	            range = next;
	            next = list[i];
	            var cmp = comparePoints(range.end, next.start);
	            if (cmp < 0)
	                continue;

	            if (cmp == 0 && !range.isEmpty() && !next.isEmpty())
	                continue;

	            if (comparePoints(range.end, next.end) < 0) {
	                range.end.row = next.end.row;
	                range.end.column = next.end.column;
	            }

	            list.splice(i, 1);
	            removed.push(next);
	            next = range;
	            i--;
	        }
	        
	        this.ranges = list;

	        return removed;
	    };

	    this.contains = function(row, column) {
	        return this.pointIndex({row: row, column: column}) >= 0;
	    };

	    this.containsPoint = function(pos) {
	        return this.pointIndex(pos) >= 0;
	    };

	    this.rangeAtPoint = function(pos) {
	        var i = this.pointIndex(pos);
	        if (i >= 0)
	            return this.ranges[i];
	    };


	    this.clipRows = function(startRow, endRow) {
	        var list = this.ranges;
	        if (list[0].start.row > endRow || list[list.length - 1].start.row < startRow)
	            return [];

	        var startIndex = this.pointIndex({row: startRow, column: 0});
	        if (startIndex < 0)
	            startIndex = -startIndex - 1;
	        var endIndex = this.pointIndex({row: endRow, column: 0}, startIndex);
	        if (endIndex < 0)
	            endIndex = -endIndex - 1;

	        var clipped = [];
	        for (var i = startIndex; i < endIndex; i++) {
	            clipped.push(list[i]);
	        }
	        return clipped;
	    };

	    this.removeAll = function() {
	        return this.ranges.splice(0, this.ranges.length);
	    };

	    this.attach = function(session) {
	        if (this.session)
	            this.detach();

	        this.session = session;
	        this.onChange = this.$onChange.bind(this);

	        this.session.on('change', this.onChange);
	    };

	    this.detach = function() {
	        if (!this.session)
	            return;
	        this.session.removeListener('change', this.onChange);
	        this.session = null;
	    };

	    this.$onChange = function(delta) {
	        if (delta.action == "insert"){
	            var start = delta.start;
	            var end = delta.end;
	        } else {
	            var end = delta.start;
	            var start = delta.end;
	        }
	        var startRow = start.row;
	        var endRow = end.row;
	        var lineDif = endRow - startRow;

	        var colDiff = -start.column + end.column;
	        var ranges = this.ranges;

	        for (var i = 0, n = ranges.length; i < n; i++) {
	            var r = ranges[i];
	            if (r.end.row < startRow)
	                continue;
	            if (r.start.row > startRow)
	                break;

	            if (r.start.row == startRow && r.start.column >= start.column ) {
	                if (r.start.column == start.column && this.$insertRight) {
	                } else {
	                    r.start.column += colDiff;
	                    r.start.row += lineDif;
	                }
	            }
	            if (r.end.row == startRow && r.end.column >= start.column) {
	                if (r.end.column == start.column && this.$insertRight) {
	                    continue;
	                }
	                if (r.end.column == start.column && colDiff > 0 && i < n - 1) {                
	                    if (r.end.column > r.start.column && r.end.column == ranges[i+1].start.column)
	                        r.end.column -= colDiff;
	                }
	                r.end.column += colDiff;
	                r.end.row += lineDif;
	            }
	        }

	        if (lineDif != 0 && i < n) {
	            for (; i < n; i++) {
	                var r = ranges[i];
	                r.start.row += lineDif;
	                r.end.row += lineDif;
	            }
	        }
	    };

	}).call(RangeList.prototype);

	exports.RangeList = RangeList;
	});

	ace.define("ace/edit_session/fold",["require","exports","module","ace/range","ace/range_list","ace/lib/oop"], function(acequire, exports, module) {
	"use strict";

	var Range = acequire("../range").Range;
	var RangeList = acequire("../range_list").RangeList;
	var oop = acequire("../lib/oop")
	var Fold = exports.Fold = function(range, placeholder) {
	    this.foldLine = null;
	    this.placeholder = placeholder;
	    this.range = range;
	    this.start = range.start;
	    this.end = range.end;

	    this.sameRow = range.start.row == range.end.row;
	    this.subFolds = this.ranges = [];
	};

	oop.inherits(Fold, RangeList);

	(function() {

	    this.toString = function() {
	        return '"' + this.placeholder + '" ' + this.range.toString();
	    };

	    this.setFoldLine = function(foldLine) {
	        this.foldLine = foldLine;
	        this.subFolds.forEach(function(fold) {
	            fold.setFoldLine(foldLine);
	        });
	    };

	    this.clone = function() {
	        var range = this.range.clone();
	        var fold = new Fold(range, this.placeholder);
	        this.subFolds.forEach(function(subFold) {
	            fold.subFolds.push(subFold.clone());
	        });
	        fold.collapseChildren = this.collapseChildren;
	        return fold;
	    };

	    this.addSubFold = function(fold) {
	        if (this.range.isEqual(fold))
	            return;

	        if (!this.range.containsRange(fold))
	            throw new Error("A fold can't intersect already existing fold" + fold.range + this.range);
	        consumeRange(fold, this.start);

	        var row = fold.start.row, column = fold.start.column;
	        for (var i = 0, cmp = -1; i < this.subFolds.length; i++) {
	            cmp = this.subFolds[i].range.compare(row, column);
	            if (cmp != 1)
	                break;
	        }
	        var afterStart = this.subFolds[i];

	        if (cmp == 0)
	            return afterStart.addSubFold(fold);
	        var row = fold.range.end.row, column = fold.range.end.column;
	        for (var j = i, cmp = -1; j < this.subFolds.length; j++) {
	            cmp = this.subFolds[j].range.compare(row, column);
	            if (cmp != 1)
	                break;
	        }
	        var afterEnd = this.subFolds[j];

	        if (cmp == 0)
	            throw new Error("A fold can't intersect already existing fold" + fold.range + this.range);

	        var consumedFolds = this.subFolds.splice(i, j - i, fold);
	        fold.setFoldLine(this.foldLine);

	        return fold;
	    };
	    
	    this.restoreRange = function(range) {
	        return restoreRange(range, this.start);
	    };

	}).call(Fold.prototype);

	function consumePoint(point, anchor) {
	    point.row -= anchor.row;
	    if (point.row == 0)
	        point.column -= anchor.column;
	}
	function consumeRange(range, anchor) {
	    consumePoint(range.start, anchor);
	    consumePoint(range.end, anchor);
	}
	function restorePoint(point, anchor) {
	    if (point.row == 0)
	        point.column += anchor.column;
	    point.row += anchor.row;
	}
	function restoreRange(range, anchor) {
	    restorePoint(range.start, anchor);
	    restorePoint(range.end, anchor);
	}

	});

	ace.define("ace/edit_session/folding",["require","exports","module","ace/range","ace/edit_session/fold_line","ace/edit_session/fold","ace/token_iterator"], function(acequire, exports, module) {
	"use strict";

	var Range = acequire("../range").Range;
	var FoldLine = acequire("./fold_line").FoldLine;
	var Fold = acequire("./fold").Fold;
	var TokenIterator = acequire("../token_iterator").TokenIterator;

	function Folding() {
	    this.getFoldAt = function(row, column, side) {
	        var foldLine = this.getFoldLine(row);
	        if (!foldLine)
	            return null;

	        var folds = foldLine.folds;
	        for (var i = 0; i < folds.length; i++) {
	            var fold = folds[i];
	            if (fold.range.contains(row, column)) {
	                if (side == 1 && fold.range.isEnd(row, column)) {
	                    continue;
	                } else if (side == -1 && fold.range.isStart(row, column)) {
	                    continue;
	                }
	                return fold;
	            }
	        }
	    };
	    this.getFoldsInRange = function(range) {
	        var start = range.start;
	        var end = range.end;
	        var foldLines = this.$foldData;
	        var foundFolds = [];

	        start.column += 1;
	        end.column -= 1;

	        for (var i = 0; i < foldLines.length; i++) {
	            var cmp = foldLines[i].range.compareRange(range);
	            if (cmp == 2) {
	                continue;
	            }
	            else if (cmp == -2) {
	                break;
	            }

	            var folds = foldLines[i].folds;
	            for (var j = 0; j < folds.length; j++) {
	                var fold = folds[j];
	                cmp = fold.range.compareRange(range);
	                if (cmp == -2) {
	                    break;
	                } else if (cmp == 2) {
	                    continue;
	                } else
	                if (cmp == 42) {
	                    break;
	                }
	                foundFolds.push(fold);
	            }
	        }
	        start.column -= 1;
	        end.column += 1;

	        return foundFolds;
	    };

	    this.getFoldsInRangeList = function(ranges) {
	        if (Array.isArray(ranges)) {
	            var folds = [];
	            ranges.forEach(function(range) {
	                folds = folds.concat(this.getFoldsInRange(range));
	            }, this);
	        } else {
	            var folds = this.getFoldsInRange(ranges);
	        }
	        return folds;
	    };
	    this.getAllFolds = function() {
	        var folds = [];
	        var foldLines = this.$foldData;
	        
	        for (var i = 0; i < foldLines.length; i++)
	            for (var j = 0; j < foldLines[i].folds.length; j++)
	                folds.push(foldLines[i].folds[j]);

	        return folds;
	    };
	    this.getFoldStringAt = function(row, column, trim, foldLine) {
	        foldLine = foldLine || this.getFoldLine(row);
	        if (!foldLine)
	            return null;

	        var lastFold = {
	            end: { column: 0 }
	        };
	        var str, fold;
	        for (var i = 0; i < foldLine.folds.length; i++) {
	            fold = foldLine.folds[i];
	            var cmp = fold.range.compareEnd(row, column);
	            if (cmp == -1) {
	                str = this
	                    .getLine(fold.start.row)
	                    .substring(lastFold.end.column, fold.start.column);
	                break;
	            }
	            else if (cmp === 0) {
	                return null;
	            }
	            lastFold = fold;
	        }
	        if (!str)
	            str = this.getLine(fold.start.row).substring(lastFold.end.column);

	        if (trim == -1)
	            return str.substring(0, column - lastFold.end.column);
	        else if (trim == 1)
	            return str.substring(column - lastFold.end.column);
	        else
	            return str;
	    };

	    this.getFoldLine = function(docRow, startFoldLine) {
	        var foldData = this.$foldData;
	        var i = 0;
	        if (startFoldLine)
	            i = foldData.indexOf(startFoldLine);
	        if (i == -1)
	            i = 0;
	        for (i; i < foldData.length; i++) {
	            var foldLine = foldData[i];
	            if (foldLine.start.row <= docRow && foldLine.end.row >= docRow) {
	                return foldLine;
	            } else if (foldLine.end.row > docRow) {
	                return null;
	            }
	        }
	        return null;
	    };
	    this.getNextFoldLine = function(docRow, startFoldLine) {
	        var foldData = this.$foldData;
	        var i = 0;
	        if (startFoldLine)
	            i = foldData.indexOf(startFoldLine);
	        if (i == -1)
	            i = 0;
	        for (i; i < foldData.length; i++) {
	            var foldLine = foldData[i];
	            if (foldLine.end.row >= docRow) {
	                return foldLine;
	            }
	        }
	        return null;
	    };

	    this.getFoldedRowCount = function(first, last) {
	        var foldData = this.$foldData, rowCount = last-first+1;
	        for (var i = 0; i < foldData.length; i++) {
	            var foldLine = foldData[i],
	                end = foldLine.end.row,
	                start = foldLine.start.row;
	            if (end >= last) {
	                if (start < last) {
	                    if (start >= first)
	                        rowCount -= last-start;
	                    else
	                        rowCount = 0; // in one fold
	                }
	                break;
	            } else if (end >= first){
	                if (start >= first) // fold inside range
	                    rowCount -=  end-start;
	                else
	                    rowCount -=  end-first+1;
	            }
	        }
	        return rowCount;
	    };

	    this.$addFoldLine = function(foldLine) {
	        this.$foldData.push(foldLine);
	        this.$foldData.sort(function(a, b) {
	            return a.start.row - b.start.row;
	        });
	        return foldLine;
	    };
	    this.addFold = function(placeholder, range) {
	        var foldData = this.$foldData;
	        var added = false;
	        var fold;
	        
	        if (placeholder instanceof Fold)
	            fold = placeholder;
	        else {
	            fold = new Fold(range, placeholder);
	            fold.collapseChildren = range.collapseChildren;
	        }
	        this.$clipRangeToDocument(fold.range);

	        var startRow = fold.start.row;
	        var startColumn = fold.start.column;
	        var endRow = fold.end.row;
	        var endColumn = fold.end.column;
	        if (!(startRow < endRow || 
	            startRow == endRow && startColumn <= endColumn - 2))
	            throw new Error("The range has to be at least 2 characters width");

	        var startFold = this.getFoldAt(startRow, startColumn, 1);
	        var endFold = this.getFoldAt(endRow, endColumn, -1);
	        if (startFold && endFold == startFold)
	            return startFold.addSubFold(fold);

	        if (startFold && !startFold.range.isStart(startRow, startColumn))
	            this.removeFold(startFold);
	        
	        if (endFold && !endFold.range.isEnd(endRow, endColumn))
	            this.removeFold(endFold);
	        var folds = this.getFoldsInRange(fold.range);
	        if (folds.length > 0) {
	            this.removeFolds(folds);
	            folds.forEach(function(subFold) {
	                fold.addSubFold(subFold);
	            });
	        }

	        for (var i = 0; i < foldData.length; i++) {
	            var foldLine = foldData[i];
	            if (endRow == foldLine.start.row) {
	                foldLine.addFold(fold);
	                added = true;
	                break;
	            } else if (startRow == foldLine.end.row) {
	                foldLine.addFold(fold);
	                added = true;
	                if (!fold.sameRow) {
	                    var foldLineNext = foldData[i + 1];
	                    if (foldLineNext && foldLineNext.start.row == endRow) {
	                        foldLine.merge(foldLineNext);
	                        break;
	                    }
	                }
	                break;
	            } else if (endRow <= foldLine.start.row) {
	                break;
	            }
	        }

	        if (!added)
	            foldLine = this.$addFoldLine(new FoldLine(this.$foldData, fold));

	        if (this.$useWrapMode)
	            this.$updateWrapData(foldLine.start.row, foldLine.start.row);
	        else
	            this.$updateRowLengthCache(foldLine.start.row, foldLine.start.row);
	        this.$modified = true;
	        this._signal("changeFold", { data: fold, action: "add" });

	        return fold;
	    };

	    this.addFolds = function(folds) {
	        folds.forEach(function(fold) {
	            this.addFold(fold);
	        }, this);
	    };

	    this.removeFold = function(fold) {
	        var foldLine = fold.foldLine;
	        var startRow = foldLine.start.row;
	        var endRow = foldLine.end.row;

	        var foldLines = this.$foldData;
	        var folds = foldLine.folds;
	        if (folds.length == 1) {
	            foldLines.splice(foldLines.indexOf(foldLine), 1);
	        } else
	        if (foldLine.range.isEnd(fold.end.row, fold.end.column)) {
	            folds.pop();
	            foldLine.end.row = folds[folds.length - 1].end.row;
	            foldLine.end.column = folds[folds.length - 1].end.column;
	        } else
	        if (foldLine.range.isStart(fold.start.row, fold.start.column)) {
	            folds.shift();
	            foldLine.start.row = folds[0].start.row;
	            foldLine.start.column = folds[0].start.column;
	        } else
	        if (fold.sameRow) {
	            folds.splice(folds.indexOf(fold), 1);
	        } else
	        {
	            var newFoldLine = foldLine.split(fold.start.row, fold.start.column);
	            folds = newFoldLine.folds;
	            folds.shift();
	            newFoldLine.start.row = folds[0].start.row;
	            newFoldLine.start.column = folds[0].start.column;
	        }

	        if (!this.$updating) {
	            if (this.$useWrapMode)
	                this.$updateWrapData(startRow, endRow);
	            else
	                this.$updateRowLengthCache(startRow, endRow);
	        }
	        this.$modified = true;
	        this._signal("changeFold", { data: fold, action: "remove" });
	    };

	    this.removeFolds = function(folds) {
	        var cloneFolds = [];
	        for (var i = 0; i < folds.length; i++) {
	            cloneFolds.push(folds[i]);
	        }

	        cloneFolds.forEach(function(fold) {
	            this.removeFold(fold);
	        }, this);
	        this.$modified = true;
	    };

	    this.expandFold = function(fold) {
	        this.removeFold(fold);
	        fold.subFolds.forEach(function(subFold) {
	            fold.restoreRange(subFold);
	            this.addFold(subFold);
	        }, this);
	        if (fold.collapseChildren > 0) {
	            this.foldAll(fold.start.row+1, fold.end.row, fold.collapseChildren-1);
	        }
	        fold.subFolds = [];
	    };

	    this.expandFolds = function(folds) {
	        folds.forEach(function(fold) {
	            this.expandFold(fold);
	        }, this);
	    };

	    this.unfold = function(location, expandInner) {
	        var range, folds;
	        if (location == null) {
	            range = new Range(0, 0, this.getLength(), 0);
	            expandInner = true;
	        } else if (typeof location == "number")
	            range = new Range(location, 0, location, this.getLine(location).length);
	        else if ("row" in location)
	            range = Range.fromPoints(location, location);
	        else
	            range = location;
	        
	        folds = this.getFoldsInRangeList(range);
	        if (expandInner) {
	            this.removeFolds(folds);
	        } else {
	            var subFolds = folds;
	            while (subFolds.length) {
	                this.expandFolds(subFolds);
	                subFolds = this.getFoldsInRangeList(range);
	            }
	        }
	        if (folds.length)
	            return folds;
	    };
	    this.isRowFolded = function(docRow, startFoldRow) {
	        return !!this.getFoldLine(docRow, startFoldRow);
	    };

	    this.getRowFoldEnd = function(docRow, startFoldRow) {
	        var foldLine = this.getFoldLine(docRow, startFoldRow);
	        return foldLine ? foldLine.end.row : docRow;
	    };

	    this.getRowFoldStart = function(docRow, startFoldRow) {
	        var foldLine = this.getFoldLine(docRow, startFoldRow);
	        return foldLine ? foldLine.start.row : docRow;
	    };

	    this.getFoldDisplayLine = function(foldLine, endRow, endColumn, startRow, startColumn) {
	        if (startRow == null)
	            startRow = foldLine.start.row;
	        if (startColumn == null)
	            startColumn = 0;
	        if (endRow == null)
	            endRow = foldLine.end.row;
	        if (endColumn == null)
	            endColumn = this.getLine(endRow).length;
	        var doc = this.doc;
	        var textLine = "";

	        foldLine.walk(function(placeholder, row, column, lastColumn) {
	            if (row < startRow)
	                return;
	            if (row == startRow) {
	                if (column < startColumn)
	                    return;
	                lastColumn = Math.max(startColumn, lastColumn);
	            }

	            if (placeholder != null) {
	                textLine += placeholder;
	            } else {
	                textLine += doc.getLine(row).substring(lastColumn, column);
	            }
	        }, endRow, endColumn);
	        return textLine;
	    };

	    this.getDisplayLine = function(row, endColumn, startRow, startColumn) {
	        var foldLine = this.getFoldLine(row);

	        if (!foldLine) {
	            var line;
	            line = this.doc.getLine(row);
	            return line.substring(startColumn || 0, endColumn || line.length);
	        } else {
	            return this.getFoldDisplayLine(
	                foldLine, row, endColumn, startRow, startColumn);
	        }
	    };

	    this.$cloneFoldData = function() {
	        var fd = [];
	        fd = this.$foldData.map(function(foldLine) {
	            var folds = foldLine.folds.map(function(fold) {
	                return fold.clone();
	            });
	            return new FoldLine(fd, folds);
	        });

	        return fd;
	    };

	    this.toggleFold = function(tryToUnfold) {
	        var selection = this.selection;
	        var range = selection.getRange();
	        var fold;
	        var bracketPos;

	        if (range.isEmpty()) {
	            var cursor = range.start;
	            fold = this.getFoldAt(cursor.row, cursor.column);

	            if (fold) {
	                this.expandFold(fold);
	                return;
	            } else if (bracketPos = this.findMatchingBracket(cursor)) {
	                if (range.comparePoint(bracketPos) == 1) {
	                    range.end = bracketPos;
	                } else {
	                    range.start = bracketPos;
	                    range.start.column++;
	                    range.end.column--;
	                }
	            } else if (bracketPos = this.findMatchingBracket({row: cursor.row, column: cursor.column + 1})) {
	                if (range.comparePoint(bracketPos) == 1)
	                    range.end = bracketPos;
	                else
	                    range.start = bracketPos;

	                range.start.column++;
	            } else {
	                range = this.getCommentFoldRange(cursor.row, cursor.column) || range;
	            }
	        } else {
	            var folds = this.getFoldsInRange(range);
	            if (tryToUnfold && folds.length) {
	                this.expandFolds(folds);
	                return;
	            } else if (folds.length == 1 ) {
	                fold = folds[0];
	            }
	        }

	        if (!fold)
	            fold = this.getFoldAt(range.start.row, range.start.column);

	        if (fold && fold.range.toString() == range.toString()) {
	            this.expandFold(fold);
	            return;
	        }

	        var placeholder = "...";
	        if (!range.isMultiLine()) {
	            placeholder = this.getTextRange(range);
	            if (placeholder.length < 4)
	                return;
	            placeholder = placeholder.trim().substring(0, 2) + "..";
	        }

	        this.addFold(placeholder, range);
	    };

	    this.getCommentFoldRange = function(row, column, dir) {
	        var iterator = new TokenIterator(this, row, column);
	        var token = iterator.getCurrentToken();
	        if (token && /^comment|string/.test(token.type)) {
	            var range = new Range();
	            var re = new RegExp(token.type.replace(/\..*/, "\\."));
	            if (dir != 1) {
	                do {
	                    token = iterator.stepBackward();
	                } while (token && re.test(token.type));
	                iterator.stepForward();
	            }
	            
	            range.start.row = iterator.getCurrentTokenRow();
	            range.start.column = iterator.getCurrentTokenColumn() + 2;

	            iterator = new TokenIterator(this, row, column);
	            
	            if (dir != -1) {
	                do {
	                    token = iterator.stepForward();
	                } while (token && re.test(token.type));
	                token = iterator.stepBackward();
	            } else
	                token = iterator.getCurrentToken();

	            range.end.row = iterator.getCurrentTokenRow();
	            range.end.column = iterator.getCurrentTokenColumn() + token.value.length - 2;
	            return range;
	        }
	    };

	    this.foldAll = function(startRow, endRow, depth) {
	        if (depth == undefined)
	            depth = 100000; // JSON.stringify doesn't hanle Infinity
	        var foldWidgets = this.foldWidgets;
	        if (!foldWidgets)
	            return; // mode doesn't support folding
	        endRow = endRow || this.getLength();
	        startRow = startRow || 0;
	        for (var row = startRow; row < endRow; row++) {
	            if (foldWidgets[row] == null)
	                foldWidgets[row] = this.getFoldWidget(row);
	            if (foldWidgets[row] != "start")
	                continue;

	            var range = this.getFoldWidgetRange(row);
	            if (range && range.isMultiLine()
	                && range.end.row <= endRow
	                && range.start.row >= startRow
	            ) {
	                row = range.end.row;
	                try {
	                    var fold = this.addFold("...", range);
	                    if (fold)
	                        fold.collapseChildren = depth;
	                } catch(e) {}
	            }
	        }
	    };
	    this.$foldStyles = {
	        "manual": 1,
	        "markbegin": 1,
	        "markbeginend": 1
	    };
	    this.$foldStyle = "markbegin";
	    this.setFoldStyle = function(style) {
	        if (!this.$foldStyles[style])
	            throw new Error("invalid fold style: " + style + "[" + Object.keys(this.$foldStyles).join(", ") + "]");
	        
	        if (this.$foldStyle == style)
	            return;

	        this.$foldStyle = style;
	        
	        if (style == "manual")
	            this.unfold();
	        var mode = this.$foldMode;
	        this.$setFolding(null);
	        this.$setFolding(mode);
	    };

	    this.$setFolding = function(foldMode) {
	        if (this.$foldMode == foldMode)
	            return;
	            
	        this.$foldMode = foldMode;
	        
	        this.off('change', this.$updateFoldWidgets);
	        this.off('tokenizerUpdate', this.$tokenizerUpdateFoldWidgets);
	        this._signal("changeAnnotation");
	        
	        if (!foldMode || this.$foldStyle == "manual") {
	            this.foldWidgets = null;
	            return;
	        }
	        
	        this.foldWidgets = [];
	        this.getFoldWidget = foldMode.getFoldWidget.bind(foldMode, this, this.$foldStyle);
	        this.getFoldWidgetRange = foldMode.getFoldWidgetRange.bind(foldMode, this, this.$foldStyle);
	        
	        this.$updateFoldWidgets = this.updateFoldWidgets.bind(this);
	        this.$tokenizerUpdateFoldWidgets = this.tokenizerUpdateFoldWidgets.bind(this);
	        this.on('change', this.$updateFoldWidgets);
	        this.on('tokenizerUpdate', this.$tokenizerUpdateFoldWidgets);
	    };

	    this.getParentFoldRangeData = function (row, ignoreCurrent) {
	        var fw = this.foldWidgets;
	        if (!fw || (ignoreCurrent && fw[row]))
	            return {};

	        var i = row - 1, firstRange;
	        while (i >= 0) {
	            var c = fw[i];
	            if (c == null)
	                c = fw[i] = this.getFoldWidget(i);

	            if (c == "start") {
	                var range = this.getFoldWidgetRange(i);
	                if (!firstRange)
	                    firstRange = range;
	                if (range && range.end.row >= row)
	                    break;
	            }
	            i--;
	        }

	        return {
	            range: i !== -1 && range,
	            firstRange: firstRange
	        };
	    };

	    this.onFoldWidgetClick = function(row, e) {
	        e = e.domEvent;
	        var options = {
	            children: e.shiftKey,
	            all: e.ctrlKey || e.metaKey,
	            siblings: e.altKey
	        };
	        
	        var range = this.$toggleFoldWidget(row, options);
	        if (!range) {
	            var el = (e.target || e.srcElement);
	            if (el && /ace_fold-widget/.test(el.className))
	                el.className += " ace_invalid";
	        }
	    };
	    
	    this.$toggleFoldWidget = function(row, options) {
	        if (!this.getFoldWidget)
	            return;
	        var type = this.getFoldWidget(row);
	        var line = this.getLine(row);

	        var dir = type === "end" ? -1 : 1;
	        var fold = this.getFoldAt(row, dir === -1 ? 0 : line.length, dir);

	        if (fold) {
	            if (options.children || options.all)
	                this.removeFold(fold);
	            else
	                this.expandFold(fold);
	            return fold;
	        }

	        var range = this.getFoldWidgetRange(row, true);
	        if (range && !range.isMultiLine()) {
	            fold = this.getFoldAt(range.start.row, range.start.column, 1);
	            if (fold && range.isEqual(fold.range)) {
	                this.removeFold(fold);
	                return fold;
	            }
	        }
	        
	        if (options.siblings) {
	            var data = this.getParentFoldRangeData(row);
	            if (data.range) {
	                var startRow = data.range.start.row + 1;
	                var endRow = data.range.end.row;
	            }
	            this.foldAll(startRow, endRow, options.all ? 10000 : 0);
	        } else if (options.children) {
	            endRow = range ? range.end.row : this.getLength();
	            this.foldAll(row + 1, endRow, options.all ? 10000 : 0);
	        } else if (range) {
	            if (options.all) 
	                range.collapseChildren = 10000;
	            this.addFold("...", range);
	        }
	        
	        return range;
	    };
	    
	    
	    
	    this.toggleFoldWidget = function(toggleParent) {
	        var row = this.selection.getCursor().row;
	        row = this.getRowFoldStart(row);
	        var range = this.$toggleFoldWidget(row, {});
	        
	        if (range)
	            return;
	        var data = this.getParentFoldRangeData(row, true);
	        range = data.range || data.firstRange;
	        
	        if (range) {
	            row = range.start.row;
	            var fold = this.getFoldAt(row, this.getLine(row).length, 1);

	            if (fold) {
	                this.removeFold(fold);
	            } else {
	                this.addFold("...", range);
	            }
	        }
	    };

	    this.updateFoldWidgets = function(delta) {
	        var firstRow = delta.start.row;
	        var len = delta.end.row - firstRow;

	        if (len === 0) {
	            this.foldWidgets[firstRow] = null;
	        } else if (delta.action == 'remove') {
	            this.foldWidgets.splice(firstRow, len + 1, null);
	        } else {
	            var args = Array(len + 1);
	            args.unshift(firstRow, 1);
	            this.foldWidgets.splice.apply(this.foldWidgets, args);
	        }
	    };
	    this.tokenizerUpdateFoldWidgets = function(e) {
	        var rows = e.data;
	        if (rows.first != rows.last) {
	            if (this.foldWidgets.length > rows.first)
	                this.foldWidgets.splice(rows.first, this.foldWidgets.length);
	        }
	    };
	}

	exports.Folding = Folding;

	});

	ace.define("ace/edit_session/bracket_match",["require","exports","module","ace/token_iterator","ace/range"], function(acequire, exports, module) {
	"use strict";

	var TokenIterator = acequire("../token_iterator").TokenIterator;
	var Range = acequire("../range").Range;


	function BracketMatch() {

	    this.findMatchingBracket = function(position, chr) {
	        if (position.column == 0) return null;

	        var charBeforeCursor = chr || this.getLine(position.row).charAt(position.column-1);
	        if (charBeforeCursor == "") return null;

	        var match = charBeforeCursor.match(/([\(\[\{])|([\)\]\}])/);
	        if (!match)
	            return null;

	        if (match[1])
	            return this.$findClosingBracket(match[1], position);
	        else
	            return this.$findOpeningBracket(match[2], position);
	    };
	    
	    this.getBracketRange = function(pos) {
	        var line = this.getLine(pos.row);
	        var before = true, range;

	        var chr = line.charAt(pos.column-1);
	        var match = chr && chr.match(/([\(\[\{])|([\)\]\}])/);
	        if (!match) {
	            chr = line.charAt(pos.column);
	            pos = {row: pos.row, column: pos.column + 1};
	            match = chr && chr.match(/([\(\[\{])|([\)\]\}])/);
	            before = false;
	        }
	        if (!match)
	            return null;

	        if (match[1]) {
	            var bracketPos = this.$findClosingBracket(match[1], pos);
	            if (!bracketPos)
	                return null;
	            range = Range.fromPoints(pos, bracketPos);
	            if (!before) {
	                range.end.column++;
	                range.start.column--;
	            }
	            range.cursor = range.end;
	        } else {
	            var bracketPos = this.$findOpeningBracket(match[2], pos);
	            if (!bracketPos)
	                return null;
	            range = Range.fromPoints(bracketPos, pos);
	            if (!before) {
	                range.start.column++;
	                range.end.column--;
	            }
	            range.cursor = range.start;
	        }
	        
	        return range;
	    };

	    this.$brackets = {
	        ")": "(",
	        "(": ")",
	        "]": "[",
	        "[": "]",
	        "{": "}",
	        "}": "{"
	    };

	    this.$findOpeningBracket = function(bracket, position, typeRe) {
	        var openBracket = this.$brackets[bracket];
	        var depth = 1;

	        var iterator = new TokenIterator(this, position.row, position.column);
	        var token = iterator.getCurrentToken();
	        if (!token)
	            token = iterator.stepForward();
	        if (!token)
	            return;
	        
	         if (!typeRe){
	            typeRe = new RegExp(
	                "(\\.?" +
	                token.type.replace(".", "\\.").replace("rparen", ".paren")
	                    .replace(/\b(?:end)\b/, "(?:start|begin|end)")
	                + ")+"
	            );
	        }
	        var valueIndex = position.column - iterator.getCurrentTokenColumn() - 2;
	        var value = token.value;
	        
	        while (true) {
	        
	            while (valueIndex >= 0) {
	                var chr = value.charAt(valueIndex);
	                if (chr == openBracket) {
	                    depth -= 1;
	                    if (depth == 0) {
	                        return {row: iterator.getCurrentTokenRow(),
	                            column: valueIndex + iterator.getCurrentTokenColumn()};
	                    }
	                }
	                else if (chr == bracket) {
	                    depth += 1;
	                }
	                valueIndex -= 1;
	            }
	            do {
	                token = iterator.stepBackward();
	            } while (token && !typeRe.test(token.type));

	            if (token == null)
	                break;
	                
	            value = token.value;
	            valueIndex = value.length - 1;
	        }
	        
	        return null;
	    };

	    this.$findClosingBracket = function(bracket, position, typeRe) {
	        var closingBracket = this.$brackets[bracket];
	        var depth = 1;

	        var iterator = new TokenIterator(this, position.row, position.column);
	        var token = iterator.getCurrentToken();
	        if (!token)
	            token = iterator.stepForward();
	        if (!token)
	            return;

	        if (!typeRe){
	            typeRe = new RegExp(
	                "(\\.?" +
	                token.type.replace(".", "\\.").replace("lparen", ".paren")
	                    .replace(/\b(?:start|begin)\b/, "(?:start|begin|end)")
	                + ")+"
	            );
	        }
	        var valueIndex = position.column - iterator.getCurrentTokenColumn();

	        while (true) {

	            var value = token.value;
	            var valueLength = value.length;
	            while (valueIndex < valueLength) {
	                var chr = value.charAt(valueIndex);
	                if (chr == closingBracket) {
	                    depth -= 1;
	                    if (depth == 0) {
	                        return {row: iterator.getCurrentTokenRow(),
	                            column: valueIndex + iterator.getCurrentTokenColumn()};
	                    }
	                }
	                else if (chr == bracket) {
	                    depth += 1;
	                }
	                valueIndex += 1;
	            }
	            do {
	                token = iterator.stepForward();
	            } while (token && !typeRe.test(token.type));

	            if (token == null)
	                break;

	            valueIndex = 0;
	        }
	        
	        return null;
	    };
	}
	exports.BracketMatch = BracketMatch;

	});

	ace.define("ace/edit_session",["require","exports","module","ace/lib/oop","ace/lib/lang","ace/config","ace/lib/event_emitter","ace/selection","ace/mode/text","ace/range","ace/document","ace/background_tokenizer","ace/search_highlight","ace/edit_session/folding","ace/edit_session/bracket_match"], function(acequire, exports, module) {
	"use strict";

	var oop = acequire("./lib/oop");
	var lang = acequire("./lib/lang");
	var config = acequire("./config");
	var EventEmitter = acequire("./lib/event_emitter").EventEmitter;
	var Selection = acequire("./selection").Selection;
	var TextMode = acequire("./mode/text").Mode;
	var Range = acequire("./range").Range;
	var Document = acequire("./document").Document;
	var BackgroundTokenizer = acequire("./background_tokenizer").BackgroundTokenizer;
	var SearchHighlight = acequire("./search_highlight").SearchHighlight;

	var EditSession = function(text, mode) {
	    this.$breakpoints = [];
	    this.$decorations = [];
	    this.$frontMarkers = {};
	    this.$backMarkers = {};
	    this.$markerId = 1;
	    this.$undoSelect = true;

	    this.$foldData = [];
	    this.id = "session" + (++EditSession.$uid);
	    this.$foldData.toString = function() {
	        return this.join("\n");
	    };
	    this.on("changeFold", this.onChangeFold.bind(this));
	    this.$onChange = this.onChange.bind(this);

	    if (typeof text != "object" || !text.getLine)
	        text = new Document(text);

	    this.setDocument(text);
	    this.selection = new Selection(this);

	    config.resetOptions(this);
	    this.setMode(mode);
	    config._signal("session", this);
	};


	(function() {

	    oop.implement(this, EventEmitter);
	    this.setDocument = function(doc) {
	        if (this.doc)
	            this.doc.removeListener("change", this.$onChange);

	        this.doc = doc;
	        doc.on("change", this.$onChange);

	        if (this.bgTokenizer)
	            this.bgTokenizer.setDocument(this.getDocument());

	        this.resetCaches();
	    };
	    this.getDocument = function() {
	        return this.doc;
	    };
	    this.$resetRowCache = function(docRow) {
	        if (!docRow) {
	            this.$docRowCache = [];
	            this.$screenRowCache = [];
	            return;
	        }
	        var l = this.$docRowCache.length;
	        var i = this.$getRowCacheIndex(this.$docRowCache, docRow) + 1;
	        if (l > i) {
	            this.$docRowCache.splice(i, l);
	            this.$screenRowCache.splice(i, l);
	        }
	    };

	    this.$getRowCacheIndex = function(cacheArray, val) {
	        var low = 0;
	        var hi = cacheArray.length - 1;

	        while (low <= hi) {
	            var mid = (low + hi) >> 1;
	            var c = cacheArray[mid];

	            if (val > c)
	                low = mid + 1;
	            else if (val < c)
	                hi = mid - 1;
	            else
	                return mid;
	        }

	        return low -1;
	    };

	    this.resetCaches = function() {
	        this.$modified = true;
	        this.$wrapData = [];
	        this.$rowLengthCache = [];
	        this.$resetRowCache(0);
	        if (this.bgTokenizer)
	            this.bgTokenizer.start(0);
	    };

	    this.onChangeFold = function(e) {
	        var fold = e.data;
	        this.$resetRowCache(fold.start.row);
	    };

	    this.onChange = function(delta) {
	        this.$modified = true;

	        this.$resetRowCache(delta.start.row);

	        var removedFolds = this.$updateInternalDataOnChange(delta);
	        if (!this.$fromUndo && this.$undoManager && !delta.ignore) {
	            this.$deltasDoc.push(delta);
	            if (removedFolds && removedFolds.length != 0) {
	                this.$deltasFold.push({
	                    action: "removeFolds",
	                    folds:  removedFolds
	                });
	            }

	            this.$informUndoManager.schedule();
	        }

	        this.bgTokenizer && this.bgTokenizer.$updateOnChange(delta);
	        this._signal("change", delta);
	    };
	    this.setValue = function(text) {
	        this.doc.setValue(text);
	        this.selection.moveTo(0, 0);

	        this.$resetRowCache(0);
	        this.$deltas = [];
	        this.$deltasDoc = [];
	        this.$deltasFold = [];
	        this.setUndoManager(this.$undoManager);
	        this.getUndoManager().reset();
	    };
	    this.getValue =
	    this.toString = function() {
	        return this.doc.getValue();
	    };
	    this.getSelection = function() {
	        return this.selection;
	    };
	    this.getState = function(row) {
	        return this.bgTokenizer.getState(row);
	    };
	    this.getTokens = function(row) {
	        return this.bgTokenizer.getTokens(row);
	    };
	    this.getTokenAt = function(row, column) {
	        var tokens = this.bgTokenizer.getTokens(row);
	        var token, c = 0;
	        if (column == null) {
	            i = tokens.length - 1;
	            c = this.getLine(row).length;
	        } else {
	            for (var i = 0; i < tokens.length; i++) {
	                c += tokens[i].value.length;
	                if (c >= column)
	                    break;
	            }
	        }
	        token = tokens[i];
	        if (!token)
	            return null;
	        token.index = i;
	        token.start = c - token.value.length;
	        return token;
	    };
	    this.setUndoManager = function(undoManager) {
	        this.$undoManager = undoManager;
	        this.$deltas = [];
	        this.$deltasDoc = [];
	        this.$deltasFold = [];

	        if (this.$informUndoManager)
	            this.$informUndoManager.cancel();

	        if (undoManager) {
	            var self = this;

	            this.$syncInformUndoManager = function() {
	                self.$informUndoManager.cancel();

	                if (self.$deltasFold.length) {
	                    self.$deltas.push({
	                        group: "fold",
	                        deltas: self.$deltasFold
	                    });
	                    self.$deltasFold = [];
	                }

	                if (self.$deltasDoc.length) {
	                    self.$deltas.push({
	                        group: "doc",
	                        deltas: self.$deltasDoc
	                    });
	                    self.$deltasDoc = [];
	                }

	                if (self.$deltas.length > 0) {
	                    undoManager.execute({
	                        action: "aceupdate",
	                        args: [self.$deltas, self],
	                        merge: self.mergeUndoDeltas
	                    });
	                }
	                self.mergeUndoDeltas = false;
	                self.$deltas = [];
	            };
	            this.$informUndoManager = lang.delayedCall(this.$syncInformUndoManager);
	        }
	    };
	    this.markUndoGroup = function() {
	        if (this.$syncInformUndoManager)
	            this.$syncInformUndoManager();
	    };
	    
	    this.$defaultUndoManager = {
	        undo: function() {},
	        redo: function() {},
	        reset: function() {}
	    };
	    this.getUndoManager = function() {
	        return this.$undoManager || this.$defaultUndoManager;
	    };
	    this.getTabString = function() {
	        if (this.getUseSoftTabs()) {
	            return lang.stringRepeat(" ", this.getTabSize());
	        } else {
	            return "\t";
	        }
	    };
	    this.setUseSoftTabs = function(val) {
	        this.setOption("useSoftTabs", val);
	    };
	    this.getUseSoftTabs = function() {
	        return this.$useSoftTabs && !this.$mode.$indentWithTabs;
	    };
	    this.setTabSize = function(tabSize) {
	        this.setOption("tabSize", tabSize);
	    };
	    this.getTabSize = function() {
	        return this.$tabSize;
	    };
	    this.isTabStop = function(position) {
	        return this.$useSoftTabs && (position.column % this.$tabSize === 0);
	    };

	    this.$overwrite = false;
	    this.setOverwrite = function(overwrite) {
	        this.setOption("overwrite", overwrite);
	    };
	    this.getOverwrite = function() {
	        return this.$overwrite;
	    };
	    this.toggleOverwrite = function() {
	        this.setOverwrite(!this.$overwrite);
	    };
	    this.addGutterDecoration = function(row, className) {
	        if (!this.$decorations[row])
	            this.$decorations[row] = "";
	        this.$decorations[row] += " " + className;
	        this._signal("changeBreakpoint", {});
	    };
	    this.removeGutterDecoration = function(row, className) {
	        this.$decorations[row] = (this.$decorations[row] || "").replace(" " + className, "");
	        this._signal("changeBreakpoint", {});
	    };
	    this.getBreakpoints = function() {
	        return this.$breakpoints;
	    };
	    this.setBreakpoints = function(rows) {
	        this.$breakpoints = [];
	        for (var i=0; i<rows.length; i++) {
	            this.$breakpoints[rows[i]] = "ace_breakpoint";
	        }
	        this._signal("changeBreakpoint", {});
	    };
	    this.clearBreakpoints = function() {
	        this.$breakpoints = [];
	        this._signal("changeBreakpoint", {});
	    };
	    this.setBreakpoint = function(row, className) {
	        if (className === undefined)
	            className = "ace_breakpoint";
	        if (className)
	            this.$breakpoints[row] = className;
	        else
	            delete this.$breakpoints[row];
	        this._signal("changeBreakpoint", {});
	    };
	    this.clearBreakpoint = function(row) {
	        delete this.$breakpoints[row];
	        this._signal("changeBreakpoint", {});
	    };
	    this.addMarker = function(range, clazz, type, inFront) {
	        var id = this.$markerId++;

	        var marker = {
	            range : range,
	            type : type || "line",
	            renderer: typeof type == "function" ? type : null,
	            clazz : clazz,
	            inFront: !!inFront,
	            id: id
	        };

	        if (inFront) {
	            this.$frontMarkers[id] = marker;
	            this._signal("changeFrontMarker");
	        } else {
	            this.$backMarkers[id] = marker;
	            this._signal("changeBackMarker");
	        }

	        return id;
	    };
	    this.addDynamicMarker = function(marker, inFront) {
	        if (!marker.update)
	            return;
	        var id = this.$markerId++;
	        marker.id = id;
	        marker.inFront = !!inFront;

	        if (inFront) {
	            this.$frontMarkers[id] = marker;
	            this._signal("changeFrontMarker");
	        } else {
	            this.$backMarkers[id] = marker;
	            this._signal("changeBackMarker");
	        }

	        return marker;
	    };
	    this.removeMarker = function(markerId) {
	        var marker = this.$frontMarkers[markerId] || this.$backMarkers[markerId];
	        if (!marker)
	            return;

	        var markers = marker.inFront ? this.$frontMarkers : this.$backMarkers;
	        if (marker) {
	            delete (markers[markerId]);
	            this._signal(marker.inFront ? "changeFrontMarker" : "changeBackMarker");
	        }
	    };
	    this.getMarkers = function(inFront) {
	        return inFront ? this.$frontMarkers : this.$backMarkers;
	    };

	    this.highlight = function(re) {
	        if (!this.$searchHighlight) {
	            var highlight = new SearchHighlight(null, "ace_selected-word", "text");
	            this.$searchHighlight = this.addDynamicMarker(highlight);
	        }
	        this.$searchHighlight.setRegexp(re);
	    };
	    this.highlightLines = function(startRow, endRow, clazz, inFront) {
	        if (typeof endRow != "number") {
	            clazz = endRow;
	            endRow = startRow;
	        }
	        if (!clazz)
	            clazz = "ace_step";

	        var range = new Range(startRow, 0, endRow, Infinity);
	        range.id = this.addMarker(range, clazz, "fullLine", inFront);
	        return range;
	    };
	    this.setAnnotations = function(annotations) {
	        this.$annotations = annotations;
	        this._signal("changeAnnotation", {});
	    };
	    this.getAnnotations = function() {
	        return this.$annotations || [];
	    };
	    this.clearAnnotations = function() {
	        this.setAnnotations([]);
	    };
	    this.$detectNewLine = function(text) {
	        var match = text.match(/^.*?(\r?\n)/m);
	        if (match) {
	            this.$autoNewLine = match[1];
	        } else {
	            this.$autoNewLine = "\n";
	        }
	    };
	    this.getWordRange = function(row, column) {
	        var line = this.getLine(row);

	        var inToken = false;
	        if (column > 0)
	            inToken = !!line.charAt(column - 1).match(this.tokenRe);

	        if (!inToken)
	            inToken = !!line.charAt(column).match(this.tokenRe);

	        if (inToken)
	            var re = this.tokenRe;
	        else if (/^\s+$/.test(line.slice(column-1, column+1)))
	            var re = /\s/;
	        else
	            var re = this.nonTokenRe;

	        var start = column;
	        if (start > 0) {
	            do {
	                start--;
	            }
	            while (start >= 0 && line.charAt(start).match(re));
	            start++;
	        }

	        var end = column;
	        while (end < line.length && line.charAt(end).match(re)) {
	            end++;
	        }

	        return new Range(row, start, row, end);
	    };
	    this.getAWordRange = function(row, column) {
	        var wordRange = this.getWordRange(row, column);
	        var line = this.getLine(wordRange.end.row);

	        while (line.charAt(wordRange.end.column).match(/[ \t]/)) {
	            wordRange.end.column += 1;
	        }
	        return wordRange;
	    };
	    this.setNewLineMode = function(newLineMode) {
	        this.doc.setNewLineMode(newLineMode);
	    };
	    this.getNewLineMode = function() {
	        return this.doc.getNewLineMode();
	    };
	    this.setUseWorker = function(useWorker) { this.setOption("useWorker", useWorker); };
	    this.getUseWorker = function() { return this.$useWorker; };
	    this.onReloadTokenizer = function(e) {
	        var rows = e.data;
	        this.bgTokenizer.start(rows.first);
	        this._signal("tokenizerUpdate", e);
	    };

	    this.$modes = {};
	    this.$mode = null;
	    this.$modeId = null;
	    this.setMode = function(mode, cb) {
	        if (mode && typeof mode === "object") {
	            if (mode.getTokenizer)
	                return this.$onChangeMode(mode);
	            var options = mode;
	            var path = options.path;
	        } else {
	            path = mode || "ace/mode/text";
	        }
	        if (!this.$modes["ace/mode/text"])
	            this.$modes["ace/mode/text"] = new TextMode();

	        if (this.$modes[path] && !options) {
	            this.$onChangeMode(this.$modes[path]);
	            cb && cb();
	            return;
	        }
	        this.$modeId = path;
	        config.loadModule(["mode", path], function(m) {
	            if (this.$modeId !== path)
	                return cb && cb();
	            if (this.$modes[path] && !options) {
	                this.$onChangeMode(this.$modes[path]);
	            } else if (m && m.Mode) {
	                m = new m.Mode(options);
	                if (!options) {
	                    this.$modes[path] = m;
	                    m.$id = path;
	                }
	                this.$onChangeMode(m);
	            }
	            cb && cb();
	        }.bind(this));
	        if (!this.$mode)
	            this.$onChangeMode(this.$modes["ace/mode/text"], true);
	    };

	    this.$onChangeMode = function(mode, $isPlaceholder) {
	        if (!$isPlaceholder)
	            this.$modeId = mode.$id;
	        if (this.$mode === mode) 
	            return;

	        this.$mode = mode;

	        this.$stopWorker();

	        if (this.$useWorker)
	            this.$startWorker();

	        var tokenizer = mode.getTokenizer();

	        if(tokenizer.addEventListener !== undefined) {
	            var onReloadTokenizer = this.onReloadTokenizer.bind(this);
	            tokenizer.addEventListener("update", onReloadTokenizer);
	        }

	        if (!this.bgTokenizer) {
	            this.bgTokenizer = new BackgroundTokenizer(tokenizer);
	            var _self = this;
	            this.bgTokenizer.addEventListener("update", function(e) {
	                _self._signal("tokenizerUpdate", e);
	            });
	        } else {
	            this.bgTokenizer.setTokenizer(tokenizer);
	        }

	        this.bgTokenizer.setDocument(this.getDocument());

	        this.tokenRe = mode.tokenRe;
	        this.nonTokenRe = mode.nonTokenRe;

	        
	        if (!$isPlaceholder) {
	            if (mode.attachToSession)
	                mode.attachToSession(this);
	            this.$options.wrapMethod.set.call(this, this.$wrapMethod);
	            this.$setFolding(mode.foldingRules);
	            this.bgTokenizer.start(0);
	            this._emit("changeMode");
	        }
	    };

	    this.$stopWorker = function() {
	        if (this.$worker) {
	            this.$worker.terminate();
	            this.$worker = null;
	        }
	    };

	    this.$startWorker = function() {
	        try {
	            this.$worker = this.$mode.createWorker(this);
	        } catch (e) {
	            config.warn("Could not load worker", e);
	            this.$worker = null;
	        }
	    };
	    this.getMode = function() {
	        return this.$mode;
	    };

	    this.$scrollTop = 0;
	    this.setScrollTop = function(scrollTop) {
	        if (this.$scrollTop === scrollTop || isNaN(scrollTop))
	            return;

	        this.$scrollTop = scrollTop;
	        this._signal("changeScrollTop", scrollTop);
	    };
	    this.getScrollTop = function() {
	        return this.$scrollTop;
	    };

	    this.$scrollLeft = 0;
	    this.setScrollLeft = function(scrollLeft) {
	        if (this.$scrollLeft === scrollLeft || isNaN(scrollLeft))
	            return;

	        this.$scrollLeft = scrollLeft;
	        this._signal("changeScrollLeft", scrollLeft);
	    };
	    this.getScrollLeft = function() {
	        return this.$scrollLeft;
	    };
	    this.getScreenWidth = function() {
	        this.$computeWidth();
	        if (this.lineWidgets) 
	            return Math.max(this.getLineWidgetMaxWidth(), this.screenWidth);
	        return this.screenWidth;
	    };
	    
	    this.getLineWidgetMaxWidth = function() {
	        if (this.lineWidgetsWidth != null) return this.lineWidgetsWidth;
	        var width = 0;
	        this.lineWidgets.forEach(function(w) {
	            if (w && w.screenWidth > width)
	                width = w.screenWidth;
	        });
	        return this.lineWidgetWidth = width;
	    };

	    this.$computeWidth = function(force) {
	        if (this.$modified || force) {
	            this.$modified = false;

	            if (this.$useWrapMode)
	                return this.screenWidth = this.$wrapLimit;

	            var lines = this.doc.getAllLines();
	            var cache = this.$rowLengthCache;
	            var longestScreenLine = 0;
	            var foldIndex = 0;
	            var foldLine = this.$foldData[foldIndex];
	            var foldStart = foldLine ? foldLine.start.row : Infinity;
	            var len = lines.length;

	            for (var i = 0; i < len; i++) {
	                if (i > foldStart) {
	                    i = foldLine.end.row + 1;
	                    if (i >= len)
	                        break;
	                    foldLine = this.$foldData[foldIndex++];
	                    foldStart = foldLine ? foldLine.start.row : Infinity;
	                }

	                if (cache[i] == null)
	                    cache[i] = this.$getStringScreenWidth(lines[i])[0];

	                if (cache[i] > longestScreenLine)
	                    longestScreenLine = cache[i];
	            }
	            this.screenWidth = longestScreenLine;
	        }
	    };
	    this.getLine = function(row) {
	        return this.doc.getLine(row);
	    };
	    this.getLines = function(firstRow, lastRow) {
	        return this.doc.getLines(firstRow, lastRow);
	    };
	    this.getLength = function() {
	        return this.doc.getLength();
	    };
	    this.getTextRange = function(range) {
	        return this.doc.getTextRange(range || this.selection.getRange());
	    };
	    this.insert = function(position, text) {
	        return this.doc.insert(position, text);
	    };
	    this.remove = function(range) {
	        return this.doc.remove(range);
	    };
	    this.removeFullLines = function(firstRow, lastRow){
	        return this.doc.removeFullLines(firstRow, lastRow);
	    };
	    this.undoChanges = function(deltas, dontSelect) {
	        if (!deltas.length)
	            return;

	        this.$fromUndo = true;
	        var lastUndoRange = null;
	        for (var i = deltas.length - 1; i != -1; i--) {
	            var delta = deltas[i];
	            if (delta.group == "doc") {
	                this.doc.revertDeltas(delta.deltas);
	                lastUndoRange =
	                    this.$getUndoSelection(delta.deltas, true, lastUndoRange);
	            } else {
	                delta.deltas.forEach(function(foldDelta) {
	                    this.addFolds(foldDelta.folds);
	                }, this);
	            }
	        }
	        this.$fromUndo = false;
	        lastUndoRange &&
	            this.$undoSelect &&
	            !dontSelect &&
	            this.selection.setSelectionRange(lastUndoRange);
	        return lastUndoRange;
	    };
	    this.redoChanges = function(deltas, dontSelect) {
	        if (!deltas.length)
	            return;

	        this.$fromUndo = true;
	        var lastUndoRange = null;
	        for (var i = 0; i < deltas.length; i++) {
	            var delta = deltas[i];
	            if (delta.group == "doc") {
	                this.doc.applyDeltas(delta.deltas);
	                lastUndoRange =
	                    this.$getUndoSelection(delta.deltas, false, lastUndoRange);
	            }
	        }
	        this.$fromUndo = false;
	        lastUndoRange &&
	            this.$undoSelect &&
	            !dontSelect &&
	            this.selection.setSelectionRange(lastUndoRange);
	        return lastUndoRange;
	    };
	    this.setUndoSelect = function(enable) {
	        this.$undoSelect = enable;
	    };

	    this.$getUndoSelection = function(deltas, isUndo, lastUndoRange) {
	        function isInsert(delta) {
	            return isUndo ? delta.action !== "insert" : delta.action === "insert";
	        }

	        var delta = deltas[0];
	        var range, point;
	        var lastDeltaIsInsert = false;
	        if (isInsert(delta)) {
	            range = Range.fromPoints(delta.start, delta.end);
	            lastDeltaIsInsert = true;
	        } else {
	            range = Range.fromPoints(delta.start, delta.start);
	            lastDeltaIsInsert = false;
	        }

	        for (var i = 1; i < deltas.length; i++) {
	            delta = deltas[i];
	            if (isInsert(delta)) {
	                point = delta.start;
	                if (range.compare(point.row, point.column) == -1) {
	                    range.setStart(point);
	                }
	                point = delta.end;
	                if (range.compare(point.row, point.column) == 1) {
	                    range.setEnd(point);
	                }
	                lastDeltaIsInsert = true;
	            } else {
	                point = delta.start;
	                if (range.compare(point.row, point.column) == -1) {
	                    range = Range.fromPoints(delta.start, delta.start);
	                }
	                lastDeltaIsInsert = false;
	            }
	        }
	        if (lastUndoRange != null) {
	            if (Range.comparePoints(lastUndoRange.start, range.start) === 0) {
	                lastUndoRange.start.column += range.end.column - range.start.column;
	                lastUndoRange.end.column += range.end.column - range.start.column;
	            }

	            var cmp = lastUndoRange.compareRange(range);
	            if (cmp == 1) {
	                range.setStart(lastUndoRange.start);
	            } else if (cmp == -1) {
	                range.setEnd(lastUndoRange.end);
	            }
	        }

	        return range;
	    };
	    this.replace = function(range, text) {
	        return this.doc.replace(range, text);
	    };
	    this.moveText = function(fromRange, toPosition, copy) {
	        var text = this.getTextRange(fromRange);
	        var folds = this.getFoldsInRange(fromRange);

	        var toRange = Range.fromPoints(toPosition, toPosition);
	        if (!copy) {
	            this.remove(fromRange);
	            var rowDiff = fromRange.start.row - fromRange.end.row;
	            var collDiff = rowDiff ? -fromRange.end.column : fromRange.start.column - fromRange.end.column;
	            if (collDiff) {
	                if (toRange.start.row == fromRange.end.row && toRange.start.column > fromRange.end.column)
	                    toRange.start.column += collDiff;
	                if (toRange.end.row == fromRange.end.row && toRange.end.column > fromRange.end.column)
	                    toRange.end.column += collDiff;
	            }
	            if (rowDiff && toRange.start.row >= fromRange.end.row) {
	                toRange.start.row += rowDiff;
	                toRange.end.row += rowDiff;
	            }
	        }

	        toRange.end = this.insert(toRange.start, text);
	        if (folds.length) {
	            var oldStart = fromRange.start;
	            var newStart = toRange.start;
	            var rowDiff = newStart.row - oldStart.row;
	            var collDiff = newStart.column - oldStart.column;
	            this.addFolds(folds.map(function(x) {
	                x = x.clone();
	                if (x.start.row == oldStart.row)
	                    x.start.column += collDiff;
	                if (x.end.row == oldStart.row)
	                    x.end.column += collDiff;
	                x.start.row += rowDiff;
	                x.end.row += rowDiff;
	                return x;
	            }));
	        }

	        return toRange;
	    };
	    this.indentRows = function(startRow, endRow, indentString) {
	        indentString = indentString.replace(/\t/g, this.getTabString());
	        for (var row=startRow; row<=endRow; row++)
	            this.doc.insertInLine({row: row, column: 0}, indentString);
	    };
	    this.outdentRows = function (range) {
	        var rowRange = range.collapseRows();
	        var deleteRange = new Range(0, 0, 0, 0);
	        var size = this.getTabSize();

	        for (var i = rowRange.start.row; i <= rowRange.end.row; ++i) {
	            var line = this.getLine(i);

	            deleteRange.start.row = i;
	            deleteRange.end.row = i;
	            for (var j = 0; j < size; ++j)
	                if (line.charAt(j) != ' ')
	                    break;
	            if (j < size && line.charAt(j) == '\t') {
	                deleteRange.start.column = j;
	                deleteRange.end.column = j + 1;
	            } else {
	                deleteRange.start.column = 0;
	                deleteRange.end.column = j;
	            }
	            this.remove(deleteRange);
	        }
	    };

	    this.$moveLines = function(firstRow, lastRow, dir) {
	        firstRow = this.getRowFoldStart(firstRow);
	        lastRow = this.getRowFoldEnd(lastRow);
	        if (dir < 0) {
	            var row = this.getRowFoldStart(firstRow + dir);
	            if (row < 0) return 0;
	            var diff = row-firstRow;
	        } else if (dir > 0) {
	            var row = this.getRowFoldEnd(lastRow + dir);
	            if (row > this.doc.getLength()-1) return 0;
	            var diff = row-lastRow;
	        } else {
	            firstRow = this.$clipRowToDocument(firstRow);
	            lastRow = this.$clipRowToDocument(lastRow);
	            var diff = lastRow - firstRow + 1;
	        }

	        var range = new Range(firstRow, 0, lastRow, Number.MAX_VALUE);
	        var folds = this.getFoldsInRange(range).map(function(x){
	            x = x.clone();
	            x.start.row += diff;
	            x.end.row += diff;
	            return x;
	        });
	        
	        var lines = dir == 0
	            ? this.doc.getLines(firstRow, lastRow)
	            : this.doc.removeFullLines(firstRow, lastRow);
	        this.doc.insertFullLines(firstRow+diff, lines);
	        folds.length && this.addFolds(folds);
	        return diff;
	    };
	    this.moveLinesUp = function(firstRow, lastRow) {
	        return this.$moveLines(firstRow, lastRow, -1);
	    };
	    this.moveLinesDown = function(firstRow, lastRow) {
	        return this.$moveLines(firstRow, lastRow, 1);
	    };
	    this.duplicateLines = function(firstRow, lastRow) {
	        return this.$moveLines(firstRow, lastRow, 0);
	    };


	    this.$clipRowToDocument = function(row) {
	        return Math.max(0, Math.min(row, this.doc.getLength()-1));
	    };

	    this.$clipColumnToRow = function(row, column) {
	        if (column < 0)
	            return 0;
	        return Math.min(this.doc.getLine(row).length, column);
	    };


	    this.$clipPositionToDocument = function(row, column) {
	        column = Math.max(0, column);

	        if (row < 0) {
	            row = 0;
	            column = 0;
	        } else {
	            var len = this.doc.getLength();
	            if (row >= len) {
	                row = len - 1;
	                column = this.doc.getLine(len-1).length;
	            } else {
	                column = Math.min(this.doc.getLine(row).length, column);
	            }
	        }

	        return {
	            row: row,
	            column: column
	        };
	    };

	    this.$clipRangeToDocument = function(range) {
	        if (range.start.row < 0) {
	            range.start.row = 0;
	            range.start.column = 0;
	        } else {
	            range.start.column = this.$clipColumnToRow(
	                range.start.row,
	                range.start.column
	            );
	        }

	        var len = this.doc.getLength() - 1;
	        if (range.end.row > len) {
	            range.end.row = len;
	            range.end.column = this.doc.getLine(len).length;
	        } else {
	            range.end.column = this.$clipColumnToRow(
	                range.end.row,
	                range.end.column
	            );
	        }
	        return range;
	    };
	    this.$wrapLimit = 80;
	    this.$useWrapMode = false;
	    this.$wrapLimitRange = {
	        min : null,
	        max : null
	    };
	    this.setUseWrapMode = function(useWrapMode) {
	        if (useWrapMode != this.$useWrapMode) {
	            this.$useWrapMode = useWrapMode;
	            this.$modified = true;
	            this.$resetRowCache(0);
	            if (useWrapMode) {
	                var len = this.getLength();
	                this.$wrapData = Array(len);
	                this.$updateWrapData(0, len - 1);
	            }

	            this._signal("changeWrapMode");
	        }
	    };
	    this.getUseWrapMode = function() {
	        return this.$useWrapMode;
	    };
	    this.setWrapLimitRange = function(min, max) {
	        if (this.$wrapLimitRange.min !== min || this.$wrapLimitRange.max !== max) {
	            this.$wrapLimitRange = { min: min, max: max };
	            this.$modified = true;
	            if (this.$useWrapMode)
	                this._signal("changeWrapMode");
	        }
	    };
	    this.adjustWrapLimit = function(desiredLimit, $printMargin) {
	        var limits = this.$wrapLimitRange;
	        if (limits.max < 0)
	            limits = {min: $printMargin, max: $printMargin};
	        var wrapLimit = this.$constrainWrapLimit(desiredLimit, limits.min, limits.max);
	        if (wrapLimit != this.$wrapLimit && wrapLimit > 1) {
	            this.$wrapLimit = wrapLimit;
	            this.$modified = true;
	            if (this.$useWrapMode) {
	                this.$updateWrapData(0, this.getLength() - 1);
	                this.$resetRowCache(0);
	                this._signal("changeWrapLimit");
	            }
	            return true;
	        }
	        return false;
	    };

	    this.$constrainWrapLimit = function(wrapLimit, min, max) {
	        if (min)
	            wrapLimit = Math.max(min, wrapLimit);

	        if (max)
	            wrapLimit = Math.min(max, wrapLimit);

	        return wrapLimit;
	    };
	    this.getWrapLimit = function() {
	        return this.$wrapLimit;
	    };
	    this.setWrapLimit = function (limit) {
	        this.setWrapLimitRange(limit, limit);
	    };
	    this.getWrapLimitRange = function() {
	        return {
	            min : this.$wrapLimitRange.min,
	            max : this.$wrapLimitRange.max
	        };
	    };

	    this.$updateInternalDataOnChange = function(delta) {
	        var useWrapMode = this.$useWrapMode;
	        var action = delta.action;
	        var start = delta.start;
	        var end = delta.end;
	        var firstRow = start.row;
	        var lastRow = end.row;
	        var len = lastRow - firstRow;
	        var removedFolds = null;
	        
	        this.$updating = true;
	        if (len != 0) {
	            if (action === "remove") {
	                this[useWrapMode ? "$wrapData" : "$rowLengthCache"].splice(firstRow, len);

	                var foldLines = this.$foldData;
	                removedFolds = this.getFoldsInRange(delta);
	                this.removeFolds(removedFolds);

	                var foldLine = this.getFoldLine(end.row);
	                var idx = 0;
	                if (foldLine) {
	                    foldLine.addRemoveChars(end.row, end.column, start.column - end.column);
	                    foldLine.shiftRow(-len);

	                    var foldLineBefore = this.getFoldLine(firstRow);
	                    if (foldLineBefore && foldLineBefore !== foldLine) {
	                        foldLineBefore.merge(foldLine);
	                        foldLine = foldLineBefore;
	                    }
	                    idx = foldLines.indexOf(foldLine) + 1;
	                }

	                for (idx; idx < foldLines.length; idx++) {
	                    var foldLine = foldLines[idx];
	                    if (foldLine.start.row >= end.row) {
	                        foldLine.shiftRow(-len);
	                    }
	                }

	                lastRow = firstRow;
	            } else {
	                var args = Array(len);
	                args.unshift(firstRow, 0);
	                var arr = useWrapMode ? this.$wrapData : this.$rowLengthCache
	                arr.splice.apply(arr, args);
	                var foldLines = this.$foldData;
	                var foldLine = this.getFoldLine(firstRow);
	                var idx = 0;
	                if (foldLine) {
	                    var cmp = foldLine.range.compareInside(start.row, start.column);
	                    if (cmp == 0) {
	                        foldLine = foldLine.split(start.row, start.column);
	                        if (foldLine) {
	                            foldLine.shiftRow(len);
	                            foldLine.addRemoveChars(lastRow, 0, end.column - start.column);
	                        }
	                    } else
	                    if (cmp == -1) {
	                        foldLine.addRemoveChars(firstRow, 0, end.column - start.column);
	                        foldLine.shiftRow(len);
	                    }
	                    idx = foldLines.indexOf(foldLine) + 1;
	                }

	                for (idx; idx < foldLines.length; idx++) {
	                    var foldLine = foldLines[idx];
	                    if (foldLine.start.row >= firstRow) {
	                        foldLine.shiftRow(len);
	                    }
	                }
	            }
	        } else {
	            len = Math.abs(delta.start.column - delta.end.column);
	            if (action === "remove") {
	                removedFolds = this.getFoldsInRange(delta);
	                this.removeFolds(removedFolds);

	                len = -len;
	            }
	            var foldLine = this.getFoldLine(firstRow);
	            if (foldLine) {
	                foldLine.addRemoveChars(firstRow, start.column, len);
	            }
	        }

	        if (useWrapMode && this.$wrapData.length != this.doc.getLength()) {
	            console.error("doc.getLength() and $wrapData.length have to be the same!");
	        }
	        this.$updating = false;

	        if (useWrapMode)
	            this.$updateWrapData(firstRow, lastRow);
	        else
	            this.$updateRowLengthCache(firstRow, lastRow);

	        return removedFolds;
	    };

	    this.$updateRowLengthCache = function(firstRow, lastRow, b) {
	        this.$rowLengthCache[firstRow] = null;
	        this.$rowLengthCache[lastRow] = null;
	    };

	    this.$updateWrapData = function(firstRow, lastRow) {
	        var lines = this.doc.getAllLines();
	        var tabSize = this.getTabSize();
	        var wrapData = this.$wrapData;
	        var wrapLimit = this.$wrapLimit;
	        var tokens;
	        var foldLine;

	        var row = firstRow;
	        lastRow = Math.min(lastRow, lines.length - 1);
	        while (row <= lastRow) {
	            foldLine = this.getFoldLine(row, foldLine);
	            if (!foldLine) {
	                tokens = this.$getDisplayTokens(lines[row]);
	                wrapData[row] = this.$computeWrapSplits(tokens, wrapLimit, tabSize);
	                row ++;
	            } else {
	                tokens = [];
	                foldLine.walk(function(placeholder, row, column, lastColumn) {
	                        var walkTokens;
	                        if (placeholder != null) {
	                            walkTokens = this.$getDisplayTokens(
	                                            placeholder, tokens.length);
	                            walkTokens[0] = PLACEHOLDER_START;
	                            for (var i = 1; i < walkTokens.length; i++) {
	                                walkTokens[i] = PLACEHOLDER_BODY;
	                            }
	                        } else {
	                            walkTokens = this.$getDisplayTokens(
	                                lines[row].substring(lastColumn, column),
	                                tokens.length);
	                        }
	                        tokens = tokens.concat(walkTokens);
	                    }.bind(this),
	                    foldLine.end.row,
	                    lines[foldLine.end.row].length + 1
	                );

	                wrapData[foldLine.start.row] = this.$computeWrapSplits(tokens, wrapLimit, tabSize);
	                row = foldLine.end.row + 1;
	            }
	        }
	    };
	    var CHAR = 1,
	        CHAR_EXT = 2,
	        PLACEHOLDER_START = 3,
	        PLACEHOLDER_BODY =  4,
	        PUNCTUATION = 9,
	        SPACE = 10,
	        TAB = 11,
	        TAB_SPACE = 12;


	    this.$computeWrapSplits = function(tokens, wrapLimit, tabSize) {
	        if (tokens.length == 0) {
	            return [];
	        }

	        var splits = [];
	        var displayLength = tokens.length;
	        var lastSplit = 0, lastDocSplit = 0;

	        var isCode = this.$wrapAsCode;

	        var indentedSoftWrap = this.$indentedSoftWrap;
	        var maxIndent = wrapLimit <= Math.max(2 * tabSize, 8)
	            || indentedSoftWrap === false ? 0 : Math.floor(wrapLimit / 2);

	        function getWrapIndent() {
	            var indentation = 0;
	            if (maxIndent === 0)
	                return indentation;
	            if (indentedSoftWrap) {
	                for (var i = 0; i < tokens.length; i++) {
	                    var token = tokens[i];
	                    if (token == SPACE)
	                        indentation += 1;
	                    else if (token == TAB)
	                        indentation += tabSize;
	                    else if (token == TAB_SPACE)
	                        continue;
	                    else
	                        break;
	                }
	            }
	            if (isCode && indentedSoftWrap !== false)
	                indentation += tabSize;
	            return Math.min(indentation, maxIndent);
	        }
	        function addSplit(screenPos) {
	            var displayed = tokens.slice(lastSplit, screenPos);
	            var len = displayed.length;
	            displayed.join("")
	                .replace(/12/g, function() {
	                    len -= 1;
	                })
	                .replace(/2/g, function() {
	                    len -= 1;
	                });

	            if (!splits.length) {
	                indent = getWrapIndent();
	                splits.indent = indent;
	            }
	            lastDocSplit += len;
	            splits.push(lastDocSplit);
	            lastSplit = screenPos;
	        }
	        var indent = 0;
	        while (displayLength - lastSplit > wrapLimit - indent) {
	            var split = lastSplit + wrapLimit - indent;
	            if (tokens[split - 1] >= SPACE && tokens[split] >= SPACE) {
	                addSplit(split);
	                continue;
	            }
	            if (tokens[split] == PLACEHOLDER_START || tokens[split] == PLACEHOLDER_BODY) {
	                for (split; split != lastSplit - 1; split--) {
	                    if (tokens[split] == PLACEHOLDER_START) {
	                        break;
	                    }
	                }
	                if (split > lastSplit) {
	                    addSplit(split);
	                    continue;
	                }
	                split = lastSplit + wrapLimit;
	                for (split; split < tokens.length; split++) {
	                    if (tokens[split] != PLACEHOLDER_BODY) {
	                        break;
	                    }
	                }
	                if (split == tokens.length) {
	                    break;  // Breaks the while-loop.
	                }
	                addSplit(split);
	                continue;
	            }
	            var minSplit = Math.max(split - (wrapLimit -(wrapLimit>>2)), lastSplit - 1);
	            while (split > minSplit && tokens[split] < PLACEHOLDER_START) {
	                split --;
	            }
	            if (isCode) {
	                while (split > minSplit && tokens[split] < PLACEHOLDER_START) {
	                    split --;
	                }
	                while (split > minSplit && tokens[split] == PUNCTUATION) {
	                    split --;
	                }
	            } else {
	                while (split > minSplit && tokens[split] < SPACE) {
	                    split --;
	                }
	            }
	            if (split > minSplit) {
	                addSplit(++split);
	                continue;
	            }
	            split = lastSplit + wrapLimit;
	            if (tokens[split] == CHAR_EXT)
	                split--;
	            addSplit(split - indent);
	        }
	        return splits;
	    };
	    this.$getDisplayTokens = function(str, offset) {
	        var arr = [];
	        var tabSize;
	        offset = offset || 0;

	        for (var i = 0; i < str.length; i++) {
	            var c = str.charCodeAt(i);
	            if (c == 9) {
	                tabSize = this.getScreenTabSize(arr.length + offset);
	                arr.push(TAB);
	                for (var n = 1; n < tabSize; n++) {
	                    arr.push(TAB_SPACE);
	                }
	            }
	            else if (c == 32) {
	                arr.push(SPACE);
	            } else if((c > 39 && c < 48) || (c > 57 && c < 64)) {
	                arr.push(PUNCTUATION);
	            }
	            else if (c >= 0x1100 && isFullWidth(c)) {
	                arr.push(CHAR, CHAR_EXT);
	            } else {
	                arr.push(CHAR);
	            }
	        }
	        return arr;
	    };
	    this.$getStringScreenWidth = function(str, maxScreenColumn, screenColumn) {
	        if (maxScreenColumn == 0)
	            return [0, 0];
	        if (maxScreenColumn == null)
	            maxScreenColumn = Infinity;
	        screenColumn = screenColumn || 0;

	        var c, column;
	        for (column = 0; column < str.length; column++) {
	            c = str.charCodeAt(column);
	            if (c == 9) {
	                screenColumn += this.getScreenTabSize(screenColumn);
	            }
	            else if (c >= 0x1100 && isFullWidth(c)) {
	                screenColumn += 2;
	            } else {
	                screenColumn += 1;
	            }
	            if (screenColumn > maxScreenColumn) {
	                break;
	            }
	        }

	        return [screenColumn, column];
	    };

	    this.lineWidgets = null;
	    this.getRowLength = function(row) {
	        if (this.lineWidgets)
	            var h = this.lineWidgets[row] && this.lineWidgets[row].rowCount || 0;
	        else 
	            h = 0
	        if (!this.$useWrapMode || !this.$wrapData[row]) {
	            return 1 + h;
	        } else {
	            return this.$wrapData[row].length + 1 + h;
	        }
	    };
	    this.getRowLineCount = function(row) {
	        if (!this.$useWrapMode || !this.$wrapData[row]) {
	            return 1;
	        } else {
	            return this.$wrapData[row].length + 1;
	        }
	    };

	    this.getRowWrapIndent = function(screenRow) {
	        if (this.$useWrapMode) {
	            var pos = this.screenToDocumentPosition(screenRow, Number.MAX_VALUE);
	            var splits = this.$wrapData[pos.row];
	            return splits.length && splits[0] < pos.column ? splits.indent : 0;
	        } else {
	            return 0;
	        }
	    }
	    this.getScreenLastRowColumn = function(screenRow) {
	        var pos = this.screenToDocumentPosition(screenRow, Number.MAX_VALUE);
	        return this.documentToScreenColumn(pos.row, pos.column);
	    };
	    this.getDocumentLastRowColumn = function(docRow, docColumn) {
	        var screenRow = this.documentToScreenRow(docRow, docColumn);
	        return this.getScreenLastRowColumn(screenRow);
	    };
	    this.getDocumentLastRowColumnPosition = function(docRow, docColumn) {
	        var screenRow = this.documentToScreenRow(docRow, docColumn);
	        return this.screenToDocumentPosition(screenRow, Number.MAX_VALUE / 10);
	    };
	    this.getRowSplitData = function(row) {
	        if (!this.$useWrapMode) {
	            return undefined;
	        } else {
	            return this.$wrapData[row];
	        }
	    };
	    this.getScreenTabSize = function(screenColumn) {
	        return this.$tabSize - screenColumn % this.$tabSize;
	    };


	    this.screenToDocumentRow = function(screenRow, screenColumn) {
	        return this.screenToDocumentPosition(screenRow, screenColumn).row;
	    };


	    this.screenToDocumentColumn = function(screenRow, screenColumn) {
	        return this.screenToDocumentPosition(screenRow, screenColumn).column;
	    };
	    this.screenToDocumentPosition = function(screenRow, screenColumn) {
	        if (screenRow < 0)
	            return {row: 0, column: 0};

	        var line;
	        var docRow = 0;
	        var docColumn = 0;
	        var column;
	        var row = 0;
	        var rowLength = 0;

	        var rowCache = this.$screenRowCache;
	        var i = this.$getRowCacheIndex(rowCache, screenRow);
	        var l = rowCache.length;
	        if (l && i >= 0) {
	            var row = rowCache[i];
	            var docRow = this.$docRowCache[i];
	            var doCache = screenRow > rowCache[l - 1];
	        } else {
	            var doCache = !l;
	        }

	        var maxRow = this.getLength() - 1;
	        var foldLine = this.getNextFoldLine(docRow);
	        var foldStart = foldLine ? foldLine.start.row : Infinity;

	        while (row <= screenRow) {
	            rowLength = this.getRowLength(docRow);
	            if (row + rowLength > screenRow || docRow >= maxRow) {
	                break;
	            } else {
	                row += rowLength;
	                docRow++;
	                if (docRow > foldStart) {
	                    docRow = foldLine.end.row+1;
	                    foldLine = this.getNextFoldLine(docRow, foldLine);
	                    foldStart = foldLine ? foldLine.start.row : Infinity;
	                }
	            }

	            if (doCache) {
	                this.$docRowCache.push(docRow);
	                this.$screenRowCache.push(row);
	            }
	        }

	        if (foldLine && foldLine.start.row <= docRow) {
	            line = this.getFoldDisplayLine(foldLine);
	            docRow = foldLine.start.row;
	        } else if (row + rowLength <= screenRow || docRow > maxRow) {
	            return {
	                row: maxRow,
	                column: this.getLine(maxRow).length
	            };
	        } else {
	            line = this.getLine(docRow);
	            foldLine = null;
	        }
	        var wrapIndent = 0;
	        if (this.$useWrapMode) {
	            var splits = this.$wrapData[docRow];
	            if (splits) {
	                var splitIndex = Math.floor(screenRow - row);
	                column = splits[splitIndex];
	                if(splitIndex > 0 && splits.length) {
	                    wrapIndent = splits.indent;
	                    docColumn = splits[splitIndex - 1] || splits[splits.length - 1];
	                    line = line.substring(docColumn);
	                }
	            }
	        }

	        docColumn += this.$getStringScreenWidth(line, screenColumn - wrapIndent)[1];
	        if (this.$useWrapMode && docColumn >= column)
	            docColumn = column - 1;

	        if (foldLine)
	            return foldLine.idxToPosition(docColumn);

	        return {row: docRow, column: docColumn};
	    };
	    this.documentToScreenPosition = function(docRow, docColumn) {
	        if (typeof docColumn === "undefined")
	            var pos = this.$clipPositionToDocument(docRow.row, docRow.column);
	        else
	            pos = this.$clipPositionToDocument(docRow, docColumn);

	        docRow = pos.row;
	        docColumn = pos.column;

	        var screenRow = 0;
	        var foldStartRow = null;
	        var fold = null;
	        fold = this.getFoldAt(docRow, docColumn, 1);
	        if (fold) {
	            docRow = fold.start.row;
	            docColumn = fold.start.column;
	        }

	        var rowEnd, row = 0;


	        var rowCache = this.$docRowCache;
	        var i = this.$getRowCacheIndex(rowCache, docRow);
	        var l = rowCache.length;
	        if (l && i >= 0) {
	            var row = rowCache[i];
	            var screenRow = this.$screenRowCache[i];
	            var doCache = docRow > rowCache[l - 1];
	        } else {
	            var doCache = !l;
	        }

	        var foldLine = this.getNextFoldLine(row);
	        var foldStart = foldLine ?foldLine.start.row :Infinity;

	        while (row < docRow) {
	            if (row >= foldStart) {
	                rowEnd = foldLine.end.row + 1;
	                if (rowEnd > docRow)
	                    break;
	                foldLine = this.getNextFoldLine(rowEnd, foldLine);
	                foldStart = foldLine ?foldLine.start.row :Infinity;
	            }
	            else {
	                rowEnd = row + 1;
	            }

	            screenRow += this.getRowLength(row);
	            row = rowEnd;

	            if (doCache) {
	                this.$docRowCache.push(row);
	                this.$screenRowCache.push(screenRow);
	            }
	        }
	        var textLine = "";
	        if (foldLine && row >= foldStart) {
	            textLine = this.getFoldDisplayLine(foldLine, docRow, docColumn);
	            foldStartRow = foldLine.start.row;
	        } else {
	            textLine = this.getLine(docRow).substring(0, docColumn);
	            foldStartRow = docRow;
	        }
	        var wrapIndent = 0;
	        if (this.$useWrapMode) {
	            var wrapRow = this.$wrapData[foldStartRow];
	            if (wrapRow) {
	                var screenRowOffset = 0;
	                while (textLine.length >= wrapRow[screenRowOffset]) {
	                    screenRow ++;
	                    screenRowOffset++;
	                }
	                textLine = textLine.substring(
	                    wrapRow[screenRowOffset - 1] || 0, textLine.length
	                );
	                wrapIndent = screenRowOffset > 0 ? wrapRow.indent : 0;
	            }
	        }

	        return {
	            row: screenRow,
	            column: wrapIndent + this.$getStringScreenWidth(textLine)[0]
	        };
	    };
	    this.documentToScreenColumn = function(row, docColumn) {
	        return this.documentToScreenPosition(row, docColumn).column;
	    };
	    this.documentToScreenRow = function(docRow, docColumn) {
	        return this.documentToScreenPosition(docRow, docColumn).row;
	    };
	    this.getScreenLength = function() {
	        var screenRows = 0;
	        var fold = null;
	        if (!this.$useWrapMode) {
	            screenRows = this.getLength();
	            var foldData = this.$foldData;
	            for (var i = 0; i < foldData.length; i++) {
	                fold = foldData[i];
	                screenRows -= fold.end.row - fold.start.row;
	            }
	        } else {
	            var lastRow = this.$wrapData.length;
	            var row = 0, i = 0;
	            var fold = this.$foldData[i++];
	            var foldStart = fold ? fold.start.row :Infinity;

	            while (row < lastRow) {
	                var splits = this.$wrapData[row];
	                screenRows += splits ? splits.length + 1 : 1;
	                row ++;
	                if (row > foldStart) {
	                    row = fold.end.row+1;
	                    fold = this.$foldData[i++];
	                    foldStart = fold ?fold.start.row :Infinity;
	                }
	            }
	        }
	        if (this.lineWidgets)
	            screenRows += this.$getWidgetScreenLength();

	        return screenRows;
	    };
	    this.$setFontMetrics = function(fm) {
	        if (!this.$enableVarChar) return;
	        this.$getStringScreenWidth = function(str, maxScreenColumn, screenColumn) {
	            if (maxScreenColumn === 0)
	                return [0, 0];
	            if (!maxScreenColumn)
	                maxScreenColumn = Infinity;
	            screenColumn = screenColumn || 0;
	            
	            var c, column;
	            for (column = 0; column < str.length; column++) {
	                c = str.charAt(column);
	                if (c === "\t") {
	                    screenColumn += this.getScreenTabSize(screenColumn);
	                } else {
	                    screenColumn += fm.getCharacterWidth(c);
	                }
	                if (screenColumn > maxScreenColumn) {
	                    break;
	                }
	            }
	            
	            return [screenColumn, column];
	        };
	    };
	    
	    this.destroy = function() {
	        if (this.bgTokenizer) {
	            this.bgTokenizer.setDocument(null);
	            this.bgTokenizer = null;
	        }
	        this.$stopWorker();
	    };
	    function isFullWidth(c) {
	        if (c < 0x1100)
	            return false;
	        return c >= 0x1100 && c <= 0x115F ||
	               c >= 0x11A3 && c <= 0x11A7 ||
	               c >= 0x11FA && c <= 0x11FF ||
	               c >= 0x2329 && c <= 0x232A ||
	               c >= 0x2E80 && c <= 0x2E99 ||
	               c >= 0x2E9B && c <= 0x2EF3 ||
	               c >= 0x2F00 && c <= 0x2FD5 ||
	               c >= 0x2FF0 && c <= 0x2FFB ||
	               c >= 0x3000 && c <= 0x303E ||
	               c >= 0x3041 && c <= 0x3096 ||
	               c >= 0x3099 && c <= 0x30FF ||
	               c >= 0x3105 && c <= 0x312D ||
	               c >= 0x3131 && c <= 0x318E ||
	               c >= 0x3190 && c <= 0x31BA ||
	               c >= 0x31C0 && c <= 0x31E3 ||
	               c >= 0x31F0 && c <= 0x321E ||
	               c >= 0x3220 && c <= 0x3247 ||
	               c >= 0x3250 && c <= 0x32FE ||
	               c >= 0x3300 && c <= 0x4DBF ||
	               c >= 0x4E00 && c <= 0xA48C ||
	               c >= 0xA490 && c <= 0xA4C6 ||
	               c >= 0xA960 && c <= 0xA97C ||
	               c >= 0xAC00 && c <= 0xD7A3 ||
	               c >= 0xD7B0 && c <= 0xD7C6 ||
	               c >= 0xD7CB && c <= 0xD7FB ||
	               c >= 0xF900 && c <= 0xFAFF ||
	               c >= 0xFE10 && c <= 0xFE19 ||
	               c >= 0xFE30 && c <= 0xFE52 ||
	               c >= 0xFE54 && c <= 0xFE66 ||
	               c >= 0xFE68 && c <= 0xFE6B ||
	               c >= 0xFF01 && c <= 0xFF60 ||
	               c >= 0xFFE0 && c <= 0xFFE6;
	    }

	}).call(EditSession.prototype);

	acequire("./edit_session/folding").Folding.call(EditSession.prototype);
	acequire("./edit_session/bracket_match").BracketMatch.call(EditSession.prototype);


	config.defineOptions(EditSession.prototype, "session", {
	    wrap: {
	        set: function(value) {
	            if (!value || value == "off")
	                value = false;
	            else if (value == "free")
	                value = true;
	            else if (value == "printMargin")
	                value = -1;
	            else if (typeof value == "string")
	                value = parseInt(value, 10) || false;

	            if (this.$wrap == value)
	                return;
	            this.$wrap = value;
	            if (!value) {
	                this.setUseWrapMode(false);
	            } else {
	                var col = typeof value == "number" ? value : null;
	                this.setWrapLimitRange(col, col);
	                this.setUseWrapMode(true);
	            }
	        },
	        get: function() {
	            if (this.getUseWrapMode()) {
	                if (this.$wrap == -1)
	                    return "printMargin";
	                if (!this.getWrapLimitRange().min)
	                    return "free";
	                return this.$wrap;
	            }
	            return "off";
	        },
	        handlesSet: true
	    },    
	    wrapMethod: {
	        set: function(val) {
	            val = val == "auto"
	                ? this.$mode.type != "text"
	                : val != "text";
	            if (val != this.$wrapAsCode) {
	                this.$wrapAsCode = val;
	                if (this.$useWrapMode) {
	                    this.$modified = true;
	                    this.$resetRowCache(0);
	                    this.$updateWrapData(0, this.getLength() - 1);
	                }
	            }
	        },
	        initialValue: "auto"
	    },
	    indentedSoftWrap: { initialValue: true },
	    firstLineNumber: {
	        set: function() {this._signal("changeBreakpoint");},
	        initialValue: 1
	    },
	    useWorker: {
	        set: function(useWorker) {
	            this.$useWorker = useWorker;

	            this.$stopWorker();
	            if (useWorker)
	                this.$startWorker();
	        },
	        initialValue: true
	    },
	    useSoftTabs: {initialValue: true},
	    tabSize: {
	        set: function(tabSize) {
	            if (isNaN(tabSize) || this.$tabSize === tabSize) return;

	            this.$modified = true;
	            this.$rowLengthCache = [];
	            this.$tabSize = tabSize;
	            this._signal("changeTabSize");
	        },
	        initialValue: 4,
	        handlesSet: true
	    },
	    overwrite: {
	        set: function(val) {this._signal("changeOverwrite");},
	        initialValue: false
	    },
	    newLineMode: {
	        set: function(val) {this.doc.setNewLineMode(val)},
	        get: function() {return this.doc.getNewLineMode()},
	        handlesSet: true
	    },
	    mode: {
	        set: function(val) { this.setMode(val) },
	        get: function() { return this.$modeId }
	    }
	});

	exports.EditSession = EditSession;
	});

	ace.define("ace/search",["require","exports","module","ace/lib/lang","ace/lib/oop","ace/range"], function(acequire, exports, module) {
	"use strict";

	var lang = acequire("./lib/lang");
	var oop = acequire("./lib/oop");
	var Range = acequire("./range").Range;

	var Search = function() {
	    this.$options = {};
	};

	(function() {
	    this.set = function(options) {
	        oop.mixin(this.$options, options);
	        return this;
	    };
	    this.getOptions = function() {
	        return lang.copyObject(this.$options);
	    };
	    this.setOptions = function(options) {
	        this.$options = options;
	    };
	    this.find = function(session) {
	        var options = this.$options;
	        var iterator = this.$matchIterator(session, options);
	        if (!iterator)
	            return false;

	        var firstRange = null;
	        iterator.forEach(function(range, row, offset) {
	            if (!range.start) {
	                var column = range.offset + (offset || 0);
	                firstRange = new Range(row, column, row, column + range.length);
	                if (!range.length && options.start && options.start.start
	                    && options.skipCurrent != false && firstRange.isEqual(options.start)
	                ) {
	                    firstRange = null;
	                    return false;
	                }
	            } else
	                firstRange = range;
	            return true;
	        });

	        return firstRange;
	    };
	    this.findAll = function(session) {
	        var options = this.$options;
	        if (!options.needle)
	            return [];
	        this.$assembleRegExp(options);

	        var range = options.range;
	        var lines = range
	            ? session.getLines(range.start.row, range.end.row)
	            : session.doc.getAllLines();

	        var ranges = [];
	        var re = options.re;
	        if (options.$isMultiLine) {
	            var len = re.length;
	            var maxRow = lines.length - len;
	            var prevRange;
	            outer: for (var row = re.offset || 0; row <= maxRow; row++) {
	                for (var j = 0; j < len; j++)
	                    if (lines[row + j].search(re[j]) == -1)
	                        continue outer;
	                
	                var startLine = lines[row];
	                var line = lines[row + len - 1];
	                var startIndex = startLine.length - startLine.match(re[0])[0].length;
	                var endIndex = line.match(re[len - 1])[0].length;
	                
	                if (prevRange && prevRange.end.row === row &&
	                    prevRange.end.column > startIndex
	                ) {
	                    continue;
	                }
	                ranges.push(prevRange = new Range(
	                    row, startIndex, row + len - 1, endIndex
	                ));
	                if (len > 2)
	                    row = row + len - 2;
	            }
	        } else {
	            for (var i = 0; i < lines.length; i++) {
	                var matches = lang.getMatchOffsets(lines[i], re);
	                for (var j = 0; j < matches.length; j++) {
	                    var match = matches[j];
	                    ranges.push(new Range(i, match.offset, i, match.offset + match.length));
	                }
	            }
	        }

	        if (range) {
	            var startColumn = range.start.column;
	            var endColumn = range.start.column;
	            var i = 0, j = ranges.length - 1;
	            while (i < j && ranges[i].start.column < startColumn && ranges[i].start.row == range.start.row)
	                i++;

	            while (i < j && ranges[j].end.column > endColumn && ranges[j].end.row == range.end.row)
	                j--;
	            
	            ranges = ranges.slice(i, j + 1);
	            for (i = 0, j = ranges.length; i < j; i++) {
	                ranges[i].start.row += range.start.row;
	                ranges[i].end.row += range.start.row;
	            }
	        }

	        return ranges;
	    };
	    this.replace = function(input, replacement) {
	        var options = this.$options;

	        var re = this.$assembleRegExp(options);
	        if (options.$isMultiLine)
	            return replacement;

	        if (!re)
	            return;

	        var match = re.exec(input);
	        if (!match || match[0].length != input.length)
	            return null;
	        
	        replacement = input.replace(re, replacement);
	        if (options.preserveCase) {
	            replacement = replacement.split("");
	            for (var i = Math.min(input.length, input.length); i--; ) {
	                var ch = input[i];
	                if (ch && ch.toLowerCase() != ch)
	                    replacement[i] = replacement[i].toUpperCase();
	                else
	                    replacement[i] = replacement[i].toLowerCase();
	            }
	            replacement = replacement.join("");
	        }
	        
	        return replacement;
	    };

	    this.$matchIterator = function(session, options) {
	        var re = this.$assembleRegExp(options);
	        if (!re)
	            return false;

	        var callback;
	        if (options.$isMultiLine) {
	            var len = re.length;
	            var matchIterator = function(line, row, offset) {
	                var startIndex = line.search(re[0]);
	                if (startIndex == -1)
	                    return;
	                for (var i = 1; i < len; i++) {
	                    line = session.getLine(row + i);
	                    if (line.search(re[i]) == -1)
	                        return;
	                }

	                var endIndex = line.match(re[len - 1])[0].length;

	                var range = new Range(row, startIndex, row + len - 1, endIndex);
	                if (re.offset == 1) {
	                    range.start.row--;
	                    range.start.column = Number.MAX_VALUE;
	                } else if (offset)
	                    range.start.column += offset;

	                if (callback(range))
	                    return true;
	            };
	        } else if (options.backwards) {
	            var matchIterator = function(line, row, startIndex) {
	                var matches = lang.getMatchOffsets(line, re);
	                for (var i = matches.length-1; i >= 0; i--)
	                    if (callback(matches[i], row, startIndex))
	                        return true;
	            };
	        } else {
	            var matchIterator = function(line, row, startIndex) {
	                var matches = lang.getMatchOffsets(line, re);
	                for (var i = 0; i < matches.length; i++)
	                    if (callback(matches[i], row, startIndex))
	                        return true;
	            };
	        }
	        
	        var lineIterator = this.$lineIterator(session, options);

	        return {
	            forEach: function(_callback) {
	                callback = _callback;
	                lineIterator.forEach(matchIterator);
	            }
	        };
	    };

	    this.$assembleRegExp = function(options, $disableFakeMultiline) {
	        if (options.needle instanceof RegExp)
	            return options.re = options.needle;

	        var needle = options.needle;

	        if (!options.needle)
	            return options.re = false;

	        if (!options.regExp)
	            needle = lang.escapeRegExp(needle);

	        if (options.wholeWord)
	            needle = addWordBoundary(needle, options);

	        var modifier = options.caseSensitive ? "gm" : "gmi";

	        options.$isMultiLine = !$disableFakeMultiline && /[\n\r]/.test(needle);
	        if (options.$isMultiLine)
	            return options.re = this.$assembleMultilineRegExp(needle, modifier);

	        try {
	            var re = new RegExp(needle, modifier);
	        } catch(e) {
	            re = false;
	        }
	        return options.re = re;
	    };

	    this.$assembleMultilineRegExp = function(needle, modifier) {
	        var parts = needle.replace(/\r\n|\r|\n/g, "$\n^").split("\n");
	        var re = [];
	        for (var i = 0; i < parts.length; i++) try {
	            re.push(new RegExp(parts[i], modifier));
	        } catch(e) {
	            return false;
	        }
	        if (parts[0] == "") {
	            re.shift();
	            re.offset = 1;
	        } else {
	            re.offset = 0;
	        }
	        return re;
	    };

	    this.$lineIterator = function(session, options) {
	        var backwards = options.backwards == true;
	        var skipCurrent = options.skipCurrent != false;

	        var range = options.range;
	        var start = options.start;
	        if (!start)
	            start = range ? range[backwards ? "end" : "start"] : session.selection.getRange();
	         
	        if (start.start)
	            start = start[skipCurrent != backwards ? "end" : "start"];

	        var firstRow = range ? range.start.row : 0;
	        var lastRow = range ? range.end.row : session.getLength() - 1;

	        var forEach = backwards ? function(callback) {
	                var row = start.row;

	                var line = session.getLine(row).substring(0, start.column);
	                if (callback(line, row))
	                    return;

	                for (row--; row >= firstRow; row--)
	                    if (callback(session.getLine(row), row))
	                        return;

	                if (options.wrap == false)
	                    return;

	                for (row = lastRow, firstRow = start.row; row >= firstRow; row--)
	                    if (callback(session.getLine(row), row))
	                        return;
	            } : function(callback) {
	                var row = start.row;

	                var line = session.getLine(row).substr(start.column);
	                if (callback(line, row, start.column))
	                    return;

	                for (row = row+1; row <= lastRow; row++)
	                    if (callback(session.getLine(row), row))
	                        return;

	                if (options.wrap == false)
	                    return;

	                for (row = firstRow, lastRow = start.row; row <= lastRow; row++)
	                    if (callback(session.getLine(row), row))
	                        return;
	            };
	        
	        return {forEach: forEach};
	    };

	}).call(Search.prototype);

	function addWordBoundary(needle, options) {
	    function wordBoundary(c) {
	        if (/\w/.test(c) || options.regExp) return "\\b";
	        return "";
	    }
	    return wordBoundary(needle[0]) + needle
	        + wordBoundary(needle[needle.length - 1]);
	}

	exports.Search = Search;
	});

	ace.define("ace/keyboard/hash_handler",["require","exports","module","ace/lib/keys","ace/lib/useragent"], function(acequire, exports, module) {
	"use strict";

	var keyUtil = acequire("../lib/keys");
	var useragent = acequire("../lib/useragent");
	var KEY_MODS = keyUtil.KEY_MODS;

	function HashHandler(config, platform) {
	    this.platform = platform || (useragent.isMac ? "mac" : "win");
	    this.commands = {};
	    this.commandKeyBinding = {};
	    this.addCommands(config);
	    this.$singleCommand = true;
	}

	function MultiHashHandler(config, platform) {
	    HashHandler.call(this, config, platform);
	    this.$singleCommand = false;
	}

	MultiHashHandler.prototype = HashHandler.prototype;

	(function() {
	    

	    this.addCommand = function(command) {
	        if (this.commands[command.name])
	            this.removeCommand(command);

	        this.commands[command.name] = command;

	        if (command.bindKey)
	            this._buildKeyHash(command);
	    };

	    this.removeCommand = function(command, keepCommand) {
	        var name = command && (typeof command === 'string' ? command : command.name);
	        command = this.commands[name];
	        if (!keepCommand)
	            delete this.commands[name];
	        var ckb = this.commandKeyBinding;
	        for (var keyId in ckb) {
	            var cmdGroup = ckb[keyId];
	            if (cmdGroup == command) {
	                delete ckb[keyId];
	            } else if (Array.isArray(cmdGroup)) {
	                var i = cmdGroup.indexOf(command);
	                if (i != -1) {
	                    cmdGroup.splice(i, 1);
	                    if (cmdGroup.length == 1)
	                        ckb[keyId] = cmdGroup[0];
	                }
	            }
	        }
	    };

	    this.bindKey = function(key, command, position) {
	        if (typeof key == "object" && key) {
	            if (position == undefined)
	                position = key.position;
	            key = key[this.platform];
	        }
	        if (!key)
	            return;
	        if (typeof command == "function")
	            return this.addCommand({exec: command, bindKey: key, name: command.name || key});
	        
	        key.split("|").forEach(function(keyPart) {
	            var chain = "";
	            if (keyPart.indexOf(" ") != -1) {
	                var parts = keyPart.split(/\s+/);
	                keyPart = parts.pop();
	                parts.forEach(function(keyPart) {
	                    var binding = this.parseKeys(keyPart);
	                    var id = KEY_MODS[binding.hashId] + binding.key;
	                    chain += (chain ? " " : "") + id;
	                    this._addCommandToBinding(chain, "chainKeys");
	                }, this);
	                chain += " ";
	            }
	            var binding = this.parseKeys(keyPart);
	            var id = KEY_MODS[binding.hashId] + binding.key;
	            this._addCommandToBinding(chain + id, command, position);
	        }, this);
	    };
	    
	    function getPosition(command) {
	        return typeof command == "object" && command.bindKey
	            && command.bindKey.position || 0;
	    }
	    this._addCommandToBinding = function(keyId, command, position) {
	        var ckb = this.commandKeyBinding, i;
	        if (!command) {
	            delete ckb[keyId];
	        } else if (!ckb[keyId] || this.$singleCommand) {
	            ckb[keyId] = command;
	        } else {
	            if (!Array.isArray(ckb[keyId])) {
	                ckb[keyId] = [ckb[keyId]];
	            } else if ((i = ckb[keyId].indexOf(command)) != -1) {
	                ckb[keyId].splice(i, 1);
	            }

	            if (typeof position != "number") {
	                if (position || command.isDefault)
	                    position = -100;
	                else
	                   position = getPosition(command);
	            }
	            var commands = ckb[keyId];
	            for (i = 0; i < commands.length; i++) {
	                var other = commands[i];
	                var otherPos = getPosition(other);
	                if (otherPos > position)
	                    break;
	            }
	            commands.splice(i, 0, command);
	        }
	    };

	    this.addCommands = function(commands) {
	        commands && Object.keys(commands).forEach(function(name) {
	            var command = commands[name];
	            if (!command)
	                return;
	            
	            if (typeof command === "string")
	                return this.bindKey(command, name);

	            if (typeof command === "function")
	                command = { exec: command };

	            if (typeof command !== "object")
	                return;

	            if (!command.name)
	                command.name = name;

	            this.addCommand(command);
	        }, this);
	    };

	    this.removeCommands = function(commands) {
	        Object.keys(commands).forEach(function(name) {
	            this.removeCommand(commands[name]);
	        }, this);
	    };

	    this.bindKeys = function(keyList) {
	        Object.keys(keyList).forEach(function(key) {
	            this.bindKey(key, keyList[key]);
	        }, this);
	    };

	    this._buildKeyHash = function(command) {
	        this.bindKey(command.bindKey, command);
	    };
	    this.parseKeys = function(keys) {
	        var parts = keys.toLowerCase().split(/[\-\+]([\-\+])?/).filter(function(x){return x});
	        var key = parts.pop();

	        var keyCode = keyUtil[key];
	        if (keyUtil.FUNCTION_KEYS[keyCode])
	            key = keyUtil.FUNCTION_KEYS[keyCode].toLowerCase();
	        else if (!parts.length)
	            return {key: key, hashId: -1};
	        else if (parts.length == 1 && parts[0] == "shift")
	            return {key: key.toUpperCase(), hashId: -1};

	        var hashId = 0;
	        for (var i = parts.length; i--;) {
	            var modifier = keyUtil.KEY_MODS[parts[i]];
	            if (modifier == null) {
	                if (typeof console != "undefined")
	                    console.error("invalid modifier " + parts[i] + " in " + keys);
	                return false;
	            }
	            hashId |= modifier;
	        }
	        return {key: key, hashId: hashId};
	    };

	    this.findKeyCommand = function findKeyCommand(hashId, keyString) {
	        var key = KEY_MODS[hashId] + keyString;
	        return this.commandKeyBinding[key];
	    };

	    this.handleKeyboard = function(data, hashId, keyString, keyCode) {
	        if (keyCode < 0) return;
	        var key = KEY_MODS[hashId] + keyString;
	        var command = this.commandKeyBinding[key];
	        if (data.$keyChain) {
	            data.$keyChain += " " + key;
	            command = this.commandKeyBinding[data.$keyChain] || command;
	        }
	        
	        if (command) {
	            if (command == "chainKeys" || command[command.length - 1] == "chainKeys") {
	                data.$keyChain = data.$keyChain || key;
	                return {command: "null"};
	            }
	        }
	        
	        if (data.$keyChain) {
	            if ((!hashId || hashId == 4) && keyString.length == 1)
	                data.$keyChain = data.$keyChain.slice(0, -key.length - 1); // wait for input
	            else if (hashId == -1 || keyCode > 0)
	                data.$keyChain = ""; // reset keyChain
	        }
	        return {command: command};
	    };
	    
	    this.getStatusText = function(editor, data) {
	        return data.$keyChain || "";
	    };

	}).call(HashHandler.prototype);

	exports.HashHandler = HashHandler;
	exports.MultiHashHandler = MultiHashHandler;
	});

	ace.define("ace/commands/command_manager",["require","exports","module","ace/lib/oop","ace/keyboard/hash_handler","ace/lib/event_emitter"], function(acequire, exports, module) {
	"use strict";

	var oop = acequire("../lib/oop");
	var MultiHashHandler = acequire("../keyboard/hash_handler").MultiHashHandler;
	var EventEmitter = acequire("../lib/event_emitter").EventEmitter;

	var CommandManager = function(platform, commands) {
	    MultiHashHandler.call(this, commands, platform);
	    this.byName = this.commands;
	    this.setDefaultHandler("exec", function(e) {
	        return e.command.exec(e.editor, e.args || {});
	    });
	};

	oop.inherits(CommandManager, MultiHashHandler);

	(function() {

	    oop.implement(this, EventEmitter);

	    this.exec = function(command, editor, args) {
	        if (Array.isArray(command)) {
	            for (var i = command.length; i--; ) {
	                if (this.exec(command[i], editor, args)) return true;
	            }
	            return false;
	        }
	        
	        if (typeof command === "string")
	            command = this.commands[command];

	        if (!command)
	            return false;

	        if (editor && editor.$readOnly && !command.readOnly)
	            return false;

	        var e = {editor: editor, command: command, args: args};
	        e.returnValue = this._emit("exec", e);
	        this._signal("afterExec", e);

	        return e.returnValue === false ? false : true;
	    };

	    this.toggleRecording = function(editor) {
	        if (this.$inReplay)
	            return;

	        editor && editor._emit("changeStatus");
	        if (this.recording) {
	            this.macro.pop();
	            this.removeEventListener("exec", this.$addCommandToMacro);

	            if (!this.macro.length)
	                this.macro = this.oldMacro;

	            return this.recording = false;
	        }
	        if (!this.$addCommandToMacro) {
	            this.$addCommandToMacro = function(e) {
	                this.macro.push([e.command, e.args]);
	            }.bind(this);
	        }

	        this.oldMacro = this.macro;
	        this.macro = [];
	        this.on("exec", this.$addCommandToMacro);
	        return this.recording = true;
	    };

	    this.replay = function(editor) {
	        if (this.$inReplay || !this.macro)
	            return;

	        if (this.recording)
	            return this.toggleRecording(editor);

	        try {
	            this.$inReplay = true;
	            this.macro.forEach(function(x) {
	                if (typeof x == "string")
	                    this.exec(x, editor);
	                else
	                    this.exec(x[0], editor, x[1]);
	            }, this);
	        } finally {
	            this.$inReplay = false;
	        }
	    };

	    this.trimMacro = function(m) {
	        return m.map(function(x){
	            if (typeof x[0] != "string")
	                x[0] = x[0].name;
	            if (!x[1])
	                x = x[0];
	            return x;
	        });
	    };

	}).call(CommandManager.prototype);

	exports.CommandManager = CommandManager;

	});

	ace.define("ace/commands/default_commands",["require","exports","module","ace/lib/lang","ace/config","ace/range"], function(acequire, exports, module) {
	"use strict";

	var lang = acequire("../lib/lang");
	var config = acequire("../config");
	var Range = acequire("../range").Range;

	function bindKey(win, mac) {
	    return {win: win, mac: mac};
	}
	exports.commands = [{
	    name: "showSettingsMenu",
	    bindKey: bindKey("Ctrl-,", "Command-,"),
	    exec: function(editor) {
	        config.loadModule("ace/ext/settings_menu", function(module) {
	            module.init(editor);
	            editor.showSettingsMenu();
	        });
	    },
	    readOnly: true
	}, {
	    name: "goToNextError",
	    bindKey: bindKey("Alt-E", "F4"),
	    exec: function(editor) {
	        config.loadModule("ace/ext/error_marker", function(module) {
	            module.showErrorMarker(editor, 1);
	        });
	    },
	    scrollIntoView: "animate",
	    readOnly: true
	}, {
	    name: "goToPreviousError",
	    bindKey: bindKey("Alt-Shift-E", "Shift-F4"),
	    exec: function(editor) {
	        config.loadModule("ace/ext/error_marker", function(module) {
	            module.showErrorMarker(editor, -1);
	        });
	    },
	    scrollIntoView: "animate",
	    readOnly: true
	}, {
	    name: "selectall",
	    bindKey: bindKey("Ctrl-A", "Command-A"),
	    exec: function(editor) { editor.selectAll(); },
	    readOnly: true
	}, {
	    name: "centerselection",
	    bindKey: bindKey(null, "Ctrl-L"),
	    exec: function(editor) { editor.centerSelection(); },
	    readOnly: true
	}, {
	    name: "gotoline",
	    bindKey: bindKey("Ctrl-L", "Command-L"),
	    exec: function(editor) {
	        var line = parseInt(prompt("Enter line number:"), 10);
	        if (!isNaN(line)) {
	            editor.gotoLine(line);
	        }
	    },
	    readOnly: true
	}, {
	    name: "fold",
	    bindKey: bindKey("Alt-L|Ctrl-F1", "Command-Alt-L|Command-F1"),
	    exec: function(editor) { editor.session.toggleFold(false); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "center",
	    readOnly: true
	}, {
	    name: "unfold",
	    bindKey: bindKey("Alt-Shift-L|Ctrl-Shift-F1", "Command-Alt-Shift-L|Command-Shift-F1"),
	    exec: function(editor) { editor.session.toggleFold(true); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "center",
	    readOnly: true
	}, {
	    name: "toggleFoldWidget",
	    bindKey: bindKey("F2", "F2"),
	    exec: function(editor) { editor.session.toggleFoldWidget(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "center",
	    readOnly: true
	}, {
	    name: "toggleParentFoldWidget",
	    bindKey: bindKey("Alt-F2", "Alt-F2"),
	    exec: function(editor) { editor.session.toggleFoldWidget(true); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "center",
	    readOnly: true
	}, {
	    name: "foldall",
	    bindKey: bindKey(null, "Ctrl-Command-Option-0"),
	    exec: function(editor) { editor.session.foldAll(); },
	    scrollIntoView: "center",
	    readOnly: true
	}, {
	    name: "foldOther",
	    bindKey: bindKey("Alt-0", "Command-Option-0"),
	    exec: function(editor) { 
	        editor.session.foldAll();
	        editor.session.unfold(editor.selection.getAllRanges());
	    },
	    scrollIntoView: "center",
	    readOnly: true
	}, {
	    name: "unfoldall",
	    bindKey: bindKey("Alt-Shift-0", "Command-Option-Shift-0"),
	    exec: function(editor) { editor.session.unfold(); },
	    scrollIntoView: "center",
	    readOnly: true
	}, {
	    name: "findnext",
	    bindKey: bindKey("Ctrl-K", "Command-G"),
	    exec: function(editor) { editor.findNext(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "center",
	    readOnly: true
	}, {
	    name: "findprevious",
	    bindKey: bindKey("Ctrl-Shift-K", "Command-Shift-G"),
	    exec: function(editor) { editor.findPrevious(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "center",
	    readOnly: true
	}, {
	    name: "selectOrFindNext",
	    bindKey: bindKey("Alt-K", "Ctrl-G"),
	    exec: function(editor) {
	        if (editor.selection.isEmpty())
	            editor.selection.selectWord();
	        else
	            editor.findNext(); 
	    },
	    readOnly: true
	}, {
	    name: "selectOrFindPrevious",
	    bindKey: bindKey("Alt-Shift-K", "Ctrl-Shift-G"),
	    exec: function(editor) { 
	        if (editor.selection.isEmpty())
	            editor.selection.selectWord();
	        else
	            editor.findPrevious();
	    },
	    readOnly: true
	}, {
	    name: "find",
	    bindKey: bindKey("Ctrl-F", "Command-F"),
	    exec: function(editor) {
	        config.loadModule("ace/ext/searchbox", function(e) {e.Search(editor)});
	    },
	    readOnly: true
	}, {
	    name: "overwrite",
	    bindKey: "Insert",
	    exec: function(editor) { editor.toggleOverwrite(); },
	    readOnly: true
	}, {
	    name: "selecttostart",
	    bindKey: bindKey("Ctrl-Shift-Home", "Command-Shift-Home|Command-Shift-Up"),
	    exec: function(editor) { editor.getSelection().selectFileStart(); },
	    multiSelectAction: "forEach",
	    readOnly: true,
	    scrollIntoView: "animate",
	    aceCommandGroup: "fileJump"
	}, {
	    name: "gotostart",
	    bindKey: bindKey("Ctrl-Home", "Command-Home|Command-Up"),
	    exec: function(editor) { editor.navigateFileStart(); },
	    multiSelectAction: "forEach",
	    readOnly: true,
	    scrollIntoView: "animate",
	    aceCommandGroup: "fileJump"
	}, {
	    name: "selectup",
	    bindKey: bindKey("Shift-Up", "Shift-Up|Ctrl-Shift-P"),
	    exec: function(editor) { editor.getSelection().selectUp(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "golineup",
	    bindKey: bindKey("Up", "Up|Ctrl-P"),
	    exec: function(editor, args) { editor.navigateUp(args.times); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "selecttoend",
	    bindKey: bindKey("Ctrl-Shift-End", "Command-Shift-End|Command-Shift-Down"),
	    exec: function(editor) { editor.getSelection().selectFileEnd(); },
	    multiSelectAction: "forEach",
	    readOnly: true,
	    scrollIntoView: "animate",
	    aceCommandGroup: "fileJump"
	}, {
	    name: "gotoend",
	    bindKey: bindKey("Ctrl-End", "Command-End|Command-Down"),
	    exec: function(editor) { editor.navigateFileEnd(); },
	    multiSelectAction: "forEach",
	    readOnly: true,
	    scrollIntoView: "animate",
	    aceCommandGroup: "fileJump"
	}, {
	    name: "selectdown",
	    bindKey: bindKey("Shift-Down", "Shift-Down|Ctrl-Shift-N"),
	    exec: function(editor) { editor.getSelection().selectDown(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "golinedown",
	    bindKey: bindKey("Down", "Down|Ctrl-N"),
	    exec: function(editor, args) { editor.navigateDown(args.times); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "selectwordleft",
	    bindKey: bindKey("Ctrl-Shift-Left", "Option-Shift-Left"),
	    exec: function(editor) { editor.getSelection().selectWordLeft(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "gotowordleft",
	    bindKey: bindKey("Ctrl-Left", "Option-Left"),
	    exec: function(editor) { editor.navigateWordLeft(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "selecttolinestart",
	    bindKey: bindKey("Alt-Shift-Left", "Command-Shift-Left|Ctrl-Shift-A"),
	    exec: function(editor) { editor.getSelection().selectLineStart(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "gotolinestart",
	    bindKey: bindKey("Alt-Left|Home", "Command-Left|Home|Ctrl-A"),
	    exec: function(editor) { editor.navigateLineStart(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "selectleft",
	    bindKey: bindKey("Shift-Left", "Shift-Left|Ctrl-Shift-B"),
	    exec: function(editor) { editor.getSelection().selectLeft(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "gotoleft",
	    bindKey: bindKey("Left", "Left|Ctrl-B"),
	    exec: function(editor, args) { editor.navigateLeft(args.times); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "selectwordright",
	    bindKey: bindKey("Ctrl-Shift-Right", "Option-Shift-Right"),
	    exec: function(editor) { editor.getSelection().selectWordRight(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "gotowordright",
	    bindKey: bindKey("Ctrl-Right", "Option-Right"),
	    exec: function(editor) { editor.navigateWordRight(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "selecttolineend",
	    bindKey: bindKey("Alt-Shift-Right", "Command-Shift-Right|Shift-End|Ctrl-Shift-E"),
	    exec: function(editor) { editor.getSelection().selectLineEnd(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "gotolineend",
	    bindKey: bindKey("Alt-Right|End", "Command-Right|End|Ctrl-E"),
	    exec: function(editor) { editor.navigateLineEnd(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "selectright",
	    bindKey: bindKey("Shift-Right", "Shift-Right"),
	    exec: function(editor) { editor.getSelection().selectRight(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "gotoright",
	    bindKey: bindKey("Right", "Right|Ctrl-F"),
	    exec: function(editor, args) { editor.navigateRight(args.times); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "selectpagedown",
	    bindKey: "Shift-PageDown",
	    exec: function(editor) { editor.selectPageDown(); },
	    readOnly: true
	}, {
	    name: "pagedown",
	    bindKey: bindKey(null, "Option-PageDown"),
	    exec: function(editor) { editor.scrollPageDown(); },
	    readOnly: true
	}, {
	    name: "gotopagedown",
	    bindKey: bindKey("PageDown", "PageDown|Ctrl-V"),
	    exec: function(editor) { editor.gotoPageDown(); },
	    readOnly: true
	}, {
	    name: "selectpageup",
	    bindKey: "Shift-PageUp",
	    exec: function(editor) { editor.selectPageUp(); },
	    readOnly: true
	}, {
	    name: "pageup",
	    bindKey: bindKey(null, "Option-PageUp"),
	    exec: function(editor) { editor.scrollPageUp(); },
	    readOnly: true
	}, {
	    name: "gotopageup",
	    bindKey: "PageUp",
	    exec: function(editor) { editor.gotoPageUp(); },
	    readOnly: true
	}, {
	    name: "scrollup",
	    bindKey: bindKey("Ctrl-Up", null),
	    exec: function(e) { e.renderer.scrollBy(0, -2 * e.renderer.layerConfig.lineHeight); },
	    readOnly: true
	}, {
	    name: "scrolldown",
	    bindKey: bindKey("Ctrl-Down", null),
	    exec: function(e) { e.renderer.scrollBy(0, 2 * e.renderer.layerConfig.lineHeight); },
	    readOnly: true
	}, {
	    name: "selectlinestart",
	    bindKey: "Shift-Home",
	    exec: function(editor) { editor.getSelection().selectLineStart(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "selectlineend",
	    bindKey: "Shift-End",
	    exec: function(editor) { editor.getSelection().selectLineEnd(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "togglerecording",
	    bindKey: bindKey("Ctrl-Alt-E", "Command-Option-E"),
	    exec: function(editor) { editor.commands.toggleRecording(editor); },
	    readOnly: true
	}, {
	    name: "replaymacro",
	    bindKey: bindKey("Ctrl-Shift-E", "Command-Shift-E"),
	    exec: function(editor) { editor.commands.replay(editor); },
	    readOnly: true
	}, {
	    name: "jumptomatching",
	    bindKey: bindKey("Ctrl-P", "Ctrl-P"),
	    exec: function(editor) { editor.jumpToMatching(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "animate",
	    readOnly: true
	}, {
	    name: "selecttomatching",
	    bindKey: bindKey("Ctrl-Shift-P", "Ctrl-Shift-P"),
	    exec: function(editor) { editor.jumpToMatching(true); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "animate",
	    readOnly: true
	}, {
	    name: "expandToMatching",
	    bindKey: bindKey("Ctrl-Shift-M", "Ctrl-Shift-M"),
	    exec: function(editor) { editor.jumpToMatching(true, true); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "animate",
	    readOnly: true
	}, {
	    name: "passKeysToBrowser",
	    bindKey: bindKey(null, null),
	    exec: function() {},
	    passEvent: true,
	    readOnly: true
	}, {
	    name: "copy",
	    exec: function(editor) {
	    },
	    readOnly: true
	},
	{
	    name: "cut",
	    exec: function(editor) {
	        var range = editor.getSelectionRange();
	        editor._emit("cut", range);

	        if (!editor.selection.isEmpty()) {
	            editor.session.remove(range);
	            editor.clearSelection();
	        }
	    },
	    scrollIntoView: "cursor",
	    multiSelectAction: "forEach"
	}, {
	    name: "paste",
	    exec: function(editor, args) {
	        editor.$handlePaste(args);
	    },
	    scrollIntoView: "cursor"
	}, {
	    name: "removeline",
	    bindKey: bindKey("Ctrl-D", "Command-D"),
	    exec: function(editor) { editor.removeLines(); },
	    scrollIntoView: "cursor",
	    multiSelectAction: "forEachLine"
	}, {
	    name: "duplicateSelection",
	    bindKey: bindKey("Ctrl-Shift-D", "Command-Shift-D"),
	    exec: function(editor) { editor.duplicateSelection(); },
	    scrollIntoView: "cursor",
	    multiSelectAction: "forEach"
	}, {
	    name: "sortlines",
	    bindKey: bindKey("Ctrl-Alt-S", "Command-Alt-S"),
	    exec: function(editor) { editor.sortLines(); },
	    scrollIntoView: "selection",
	    multiSelectAction: "forEachLine"
	}, {
	    name: "togglecomment",
	    bindKey: bindKey("Ctrl-/", "Command-/"),
	    exec: function(editor) { editor.toggleCommentLines(); },
	    multiSelectAction: "forEachLine",
	    scrollIntoView: "selectionPart"
	}, {
	    name: "toggleBlockComment",
	    bindKey: bindKey("Ctrl-Shift-/", "Command-Shift-/"),
	    exec: function(editor) { editor.toggleBlockComment(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "selectionPart"
	}, {
	    name: "modifyNumberUp",
	    bindKey: bindKey("Ctrl-Shift-Up", "Alt-Shift-Up"),
	    exec: function(editor) { editor.modifyNumber(1); },
	    scrollIntoView: "cursor",
	    multiSelectAction: "forEach"
	}, {
	    name: "modifyNumberDown",
	    bindKey: bindKey("Ctrl-Shift-Down", "Alt-Shift-Down"),
	    exec: function(editor) { editor.modifyNumber(-1); },
	    scrollIntoView: "cursor",
	    multiSelectAction: "forEach"
	}, {
	    name: "replace",
	    bindKey: bindKey("Ctrl-H", "Command-Option-F"),
	    exec: function(editor) {
	        config.loadModule("ace/ext/searchbox", function(e) {e.Search(editor, true)});
	    }
	}, {
	    name: "undo",
	    bindKey: bindKey("Ctrl-Z", "Command-Z"),
	    exec: function(editor) { editor.undo(); }
	}, {
	    name: "redo",
	    bindKey: bindKey("Ctrl-Shift-Z|Ctrl-Y", "Command-Shift-Z|Command-Y"),
	    exec: function(editor) { editor.redo(); }
	}, {
	    name: "copylinesup",
	    bindKey: bindKey("Alt-Shift-Up", "Command-Option-Up"),
	    exec: function(editor) { editor.copyLinesUp(); },
	    scrollIntoView: "cursor"
	}, {
	    name: "movelinesup",
	    bindKey: bindKey("Alt-Up", "Option-Up"),
	    exec: function(editor) { editor.moveLinesUp(); },
	    scrollIntoView: "cursor"
	}, {
	    name: "copylinesdown",
	    bindKey: bindKey("Alt-Shift-Down", "Command-Option-Down"),
	    exec: function(editor) { editor.copyLinesDown(); },
	    scrollIntoView: "cursor"
	}, {
	    name: "movelinesdown",
	    bindKey: bindKey("Alt-Down", "Option-Down"),
	    exec: function(editor) { editor.moveLinesDown(); },
	    scrollIntoView: "cursor"
	}, {
	    name: "del",
	    bindKey: bindKey("Delete", "Delete|Ctrl-D|Shift-Delete"),
	    exec: function(editor) { editor.remove("right"); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor"
	}, {
	    name: "backspace",
	    bindKey: bindKey(
	        "Shift-Backspace|Backspace",
	        "Ctrl-Backspace|Shift-Backspace|Backspace|Ctrl-H"
	    ),
	    exec: function(editor) { editor.remove("left"); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor"
	}, {
	    name: "cut_or_delete",
	    bindKey: bindKey("Shift-Delete", null),
	    exec: function(editor) { 
	        if (editor.selection.isEmpty()) {
	            editor.remove("left");
	        } else {
	            return false;
	        }
	    },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor"
	}, {
	    name: "removetolinestart",
	    bindKey: bindKey("Alt-Backspace", "Command-Backspace"),
	    exec: function(editor) { editor.removeToLineStart(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor"
	}, {
	    name: "removetolineend",
	    bindKey: bindKey("Alt-Delete", "Ctrl-K"),
	    exec: function(editor) { editor.removeToLineEnd(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor"
	}, {
	    name: "removewordleft",
	    bindKey: bindKey("Ctrl-Backspace", "Alt-Backspace|Ctrl-Alt-Backspace"),
	    exec: function(editor) { editor.removeWordLeft(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor"
	}, {
	    name: "removewordright",
	    bindKey: bindKey("Ctrl-Delete", "Alt-Delete"),
	    exec: function(editor) { editor.removeWordRight(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor"
	}, {
	    name: "outdent",
	    bindKey: bindKey("Shift-Tab", "Shift-Tab"),
	    exec: function(editor) { editor.blockOutdent(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "selectionPart"
	}, {
	    name: "indent",
	    bindKey: bindKey("Tab", "Tab"),
	    exec: function(editor) { editor.indent(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "selectionPart"
	}, {
	    name: "blockoutdent",
	    bindKey: bindKey("Ctrl-[", "Ctrl-["),
	    exec: function(editor) { editor.blockOutdent(); },
	    multiSelectAction: "forEachLine",
	    scrollIntoView: "selectionPart"
	}, {
	    name: "blockindent",
	    bindKey: bindKey("Ctrl-]", "Ctrl-]"),
	    exec: function(editor) { editor.blockIndent(); },
	    multiSelectAction: "forEachLine",
	    scrollIntoView: "selectionPart"
	}, {
	    name: "insertstring",
	    exec: function(editor, str) { editor.insert(str); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor"
	}, {
	    name: "inserttext",
	    exec: function(editor, args) {
	        editor.insert(lang.stringRepeat(args.text  || "", args.times || 1));
	    },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor"
	}, {
	    name: "splitline",
	    bindKey: bindKey(null, "Ctrl-O"),
	    exec: function(editor) { editor.splitLine(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor"
	}, {
	    name: "transposeletters",
	    bindKey: bindKey("Ctrl-T", "Ctrl-T"),
	    exec: function(editor) { editor.transposeLetters(); },
	    multiSelectAction: function(editor) {editor.transposeSelections(1); },
	    scrollIntoView: "cursor"
	}, {
	    name: "touppercase",
	    bindKey: bindKey("Ctrl-U", "Ctrl-U"),
	    exec: function(editor) { editor.toUpperCase(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor"
	}, {
	    name: "tolowercase",
	    bindKey: bindKey("Ctrl-Shift-U", "Ctrl-Shift-U"),
	    exec: function(editor) { editor.toLowerCase(); },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor"
	}, {
	    name: "expandtoline",
	    bindKey: bindKey("Ctrl-Shift-L", "Command-Shift-L"),
	    exec: function(editor) {
	        var range = editor.selection.getRange();

	        range.start.column = range.end.column = 0;
	        range.end.row++;
	        editor.selection.setRange(range, false);
	    },
	    multiSelectAction: "forEach",
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "joinlines",
	    bindKey: bindKey(null, null),
	    exec: function(editor) {
	        var isBackwards = editor.selection.isBackwards();
	        var selectionStart = isBackwards ? editor.selection.getSelectionLead() : editor.selection.getSelectionAnchor();
	        var selectionEnd = isBackwards ? editor.selection.getSelectionAnchor() : editor.selection.getSelectionLead();
	        var firstLineEndCol = editor.session.doc.getLine(selectionStart.row).length;
	        var selectedText = editor.session.doc.getTextRange(editor.selection.getRange());
	        var selectedCount = selectedText.replace(/\n\s*/, " ").length;
	        var insertLine = editor.session.doc.getLine(selectionStart.row);

	        for (var i = selectionStart.row + 1; i <= selectionEnd.row + 1; i++) {
	            var curLine = lang.stringTrimLeft(lang.stringTrimRight(editor.session.doc.getLine(i)));
	            if (curLine.length !== 0) {
	                curLine = " " + curLine;
	            }
	            insertLine += curLine;
	        }

	        if (selectionEnd.row + 1 < (editor.session.doc.getLength() - 1)) {
	            insertLine += editor.session.doc.getNewLineCharacter();
	        }

	        editor.clearSelection();
	        editor.session.doc.replace(new Range(selectionStart.row, 0, selectionEnd.row + 2, 0), insertLine);

	        if (selectedCount > 0) {
	            editor.selection.moveCursorTo(selectionStart.row, selectionStart.column);
	            editor.selection.selectTo(selectionStart.row, selectionStart.column + selectedCount);
	        } else {
	            firstLineEndCol = editor.session.doc.getLine(selectionStart.row).length > firstLineEndCol ? (firstLineEndCol + 1) : firstLineEndCol;
	            editor.selection.moveCursorTo(selectionStart.row, firstLineEndCol);
	        }
	    },
	    multiSelectAction: "forEach",
	    readOnly: true
	}, {
	    name: "invertSelection",
	    bindKey: bindKey(null, null),
	    exec: function(editor) {
	        var endRow = editor.session.doc.getLength() - 1;
	        var endCol = editor.session.doc.getLine(endRow).length;
	        var ranges = editor.selection.rangeList.ranges;
	        var newRanges = [];
	        if (ranges.length < 1) {
	            ranges = [editor.selection.getRange()];
	        }

	        for (var i = 0; i < ranges.length; i++) {
	            if (i == (ranges.length - 1)) {
	                if (!(ranges[i].end.row === endRow && ranges[i].end.column === endCol)) {
	                    newRanges.push(new Range(ranges[i].end.row, ranges[i].end.column, endRow, endCol));
	                }
	            }

	            if (i === 0) {
	                if (!(ranges[i].start.row === 0 && ranges[i].start.column === 0)) {
	                    newRanges.push(new Range(0, 0, ranges[i].start.row, ranges[i].start.column));
	                }
	            } else {
	                newRanges.push(new Range(ranges[i-1].end.row, ranges[i-1].end.column, ranges[i].start.row, ranges[i].start.column));
	            }
	        }

	        editor.exitMultiSelectMode();
	        editor.clearSelection();

	        for(var i = 0; i < newRanges.length; i++) {
	            editor.selection.addRange(newRanges[i], false);
	        }
	    },
	    readOnly: true,
	    scrollIntoView: "none"
	}];

	});

	ace.define("ace/editor",["require","exports","module","ace/lib/fixoldbrowsers","ace/lib/oop","ace/lib/dom","ace/lib/lang","ace/lib/useragent","ace/keyboard/textinput","ace/mouse/mouse_handler","ace/mouse/fold_handler","ace/keyboard/keybinding","ace/edit_session","ace/search","ace/range","ace/lib/event_emitter","ace/commands/command_manager","ace/commands/default_commands","ace/config","ace/token_iterator"], function(acequire, exports, module) {
	"use strict";

	acequire("./lib/fixoldbrowsers");

	var oop = acequire("./lib/oop");
	var dom = acequire("./lib/dom");
	var lang = acequire("./lib/lang");
	var useragent = acequire("./lib/useragent");
	var TextInput = acequire("./keyboard/textinput").TextInput;
	var MouseHandler = acequire("./mouse/mouse_handler").MouseHandler;
	var FoldHandler = acequire("./mouse/fold_handler").FoldHandler;
	var KeyBinding = acequire("./keyboard/keybinding").KeyBinding;
	var EditSession = acequire("./edit_session").EditSession;
	var Search = acequire("./search").Search;
	var Range = acequire("./range").Range;
	var EventEmitter = acequire("./lib/event_emitter").EventEmitter;
	var CommandManager = acequire("./commands/command_manager").CommandManager;
	var defaultCommands = acequire("./commands/default_commands").commands;
	var config = acequire("./config");
	var TokenIterator = acequire("./token_iterator").TokenIterator;
	var Editor = function(renderer, session) {
	    var container = renderer.getContainerElement();
	    this.container = container;
	    this.renderer = renderer;

	    this.commands = new CommandManager(useragent.isMac ? "mac" : "win", defaultCommands);
	    this.textInput  = new TextInput(renderer.getTextAreaContainer(), this);
	    this.renderer.textarea = this.textInput.getElement();
	    this.keyBinding = new KeyBinding(this);
	    this.$mouseHandler = new MouseHandler(this);
	    new FoldHandler(this);

	    this.$blockScrolling = 0;
	    this.$search = new Search().set({
	        wrap: true
	    });

	    this.$historyTracker = this.$historyTracker.bind(this);
	    this.commands.on("exec", this.$historyTracker);

	    this.$initOperationListeners();
	    
	    this._$emitInputEvent = lang.delayedCall(function() {
	        this._signal("input", {});
	        if (this.session && this.session.bgTokenizer)
	            this.session.bgTokenizer.scheduleStart();
	    }.bind(this));
	    
	    this.on("change", function(_, _self) {
	        _self._$emitInputEvent.schedule(31);
	    });

	    this.setSession(session || new EditSession(""));
	    config.resetOptions(this);
	    config._signal("editor", this);
	};

	(function(){

	    oop.implement(this, EventEmitter);

	    this.$initOperationListeners = function() {
	        function last(a) {return a[a.length - 1]}

	        this.selections = [];
	        this.commands.on("exec", this.startOperation.bind(this), true);
	        this.commands.on("afterExec", this.endOperation.bind(this), true);

	        this.$opResetTimer = lang.delayedCall(this.endOperation.bind(this));

	        this.on("change", function() {
	            this.curOp || this.startOperation();
	            this.curOp.docChanged = true;
	        }.bind(this), true);

	        this.on("changeSelection", function() {
	            this.curOp || this.startOperation();
	            this.curOp.selectionChanged = true;
	        }.bind(this), true);
	    };

	    this.curOp = null;
	    this.prevOp = {};
	    this.startOperation = function(commadEvent) {
	        if (this.curOp) {
	            if (!commadEvent || this.curOp.command)
	                return;
	            this.prevOp = this.curOp;
	        }
	        if (!commadEvent) {
	            this.previousCommand = null;
	            commadEvent = {};
	        }

	        this.$opResetTimer.schedule();
	        this.curOp = {
	            command: commadEvent.command || {},
	            args: commadEvent.args,
	            scrollTop: this.renderer.scrollTop
	        };
	        if (this.curOp.command.name && this.curOp.command.scrollIntoView !== undefined)
	            this.$blockScrolling++;
	    };

	    this.endOperation = function(e) {
	        if (this.curOp) {
	            if (e && e.returnValue === false)
	                return this.curOp = null;
	            this._signal("beforeEndOperation");
	            var command = this.curOp.command;
	            if (command.name && this.$blockScrolling > 0)
	                this.$blockScrolling--;
	            var scrollIntoView = command && command.scrollIntoView;
	            if (scrollIntoView) {
	                switch (scrollIntoView) {
	                    case "center-animate":
	                        scrollIntoView = "animate";
	                    case "center":
	                        this.renderer.scrollCursorIntoView(null, 0.5);
	                        break;
	                    case "animate":
	                    case "cursor":
	                        this.renderer.scrollCursorIntoView();
	                        break;
	                    case "selectionPart":
	                        var range = this.selection.getRange();
	                        var config = this.renderer.layerConfig;
	                        if (range.start.row >= config.lastRow || range.end.row <= config.firstRow) {
	                            this.renderer.scrollSelectionIntoView(this.selection.anchor, this.selection.lead);
	                        }
	                        break;
	                    default:
	                        break;
	                }
	                if (scrollIntoView == "animate")
	                    this.renderer.animateScrolling(this.curOp.scrollTop);
	            }
	            
	            this.prevOp = this.curOp;
	            this.curOp = null;
	        }
	    };
	    this.$mergeableCommands = ["backspace", "del", "insertstring"];
	    this.$historyTracker = function(e) {
	        if (!this.$mergeUndoDeltas)
	            return;

	        var prev = this.prevOp;
	        var mergeableCommands = this.$mergeableCommands;
	        var shouldMerge = prev.command && (e.command.name == prev.command.name);
	        if (e.command.name == "insertstring") {
	            var text = e.args;
	            if (this.mergeNextCommand === undefined)
	                this.mergeNextCommand = true;

	            shouldMerge = shouldMerge
	                && this.mergeNextCommand // previous command allows to coalesce with
	                && (!/\s/.test(text) || /\s/.test(prev.args)); // previous insertion was of same type

	            this.mergeNextCommand = true;
	        } else {
	            shouldMerge = shouldMerge
	                && mergeableCommands.indexOf(e.command.name) !== -1; // the command is mergeable
	        }

	        if (
	            this.$mergeUndoDeltas != "always"
	            && Date.now() - this.sequenceStartTime > 2000
	        ) {
	            shouldMerge = false; // the sequence is too long
	        }

	        if (shouldMerge)
	            this.session.mergeUndoDeltas = true;
	        else if (mergeableCommands.indexOf(e.command.name) !== -1)
	            this.sequenceStartTime = Date.now();
	    };
	    this.setKeyboardHandler = function(keyboardHandler, cb) {
	        if (keyboardHandler && typeof keyboardHandler === "string") {
	            this.$keybindingId = keyboardHandler;
	            var _self = this;
	            config.loadModule(["keybinding", keyboardHandler], function(module) {
	                if (_self.$keybindingId == keyboardHandler)
	                    _self.keyBinding.setKeyboardHandler(module && module.handler);
	                cb && cb();
	            });
	        } else {
	            this.$keybindingId = null;
	            this.keyBinding.setKeyboardHandler(keyboardHandler);
	            cb && cb();
	        }
	    };
	    this.getKeyboardHandler = function() {
	        return this.keyBinding.getKeyboardHandler();
	    };
	    this.setSession = function(session) {
	        if (this.session == session)
	            return;
	        if (this.curOp) this.endOperation();
	        this.curOp = {};

	        var oldSession = this.session;
	        if (oldSession) {
	            this.session.off("change", this.$onDocumentChange);
	            this.session.off("changeMode", this.$onChangeMode);
	            this.session.off("tokenizerUpdate", this.$onTokenizerUpdate);
	            this.session.off("changeTabSize", this.$onChangeTabSize);
	            this.session.off("changeWrapLimit", this.$onChangeWrapLimit);
	            this.session.off("changeWrapMode", this.$onChangeWrapMode);
	            this.session.off("changeFold", this.$onChangeFold);
	            this.session.off("changeFrontMarker", this.$onChangeFrontMarker);
	            this.session.off("changeBackMarker", this.$onChangeBackMarker);
	            this.session.off("changeBreakpoint", this.$onChangeBreakpoint);
	            this.session.off("changeAnnotation", this.$onChangeAnnotation);
	            this.session.off("changeOverwrite", this.$onCursorChange);
	            this.session.off("changeScrollTop", this.$onScrollTopChange);
	            this.session.off("changeScrollLeft", this.$onScrollLeftChange);

	            var selection = this.session.getSelection();
	            selection.off("changeCursor", this.$onCursorChange);
	            selection.off("changeSelection", this.$onSelectionChange);
	        }

	        this.session = session;
	        if (session) {
	            this.$onDocumentChange = this.onDocumentChange.bind(this);
	            session.on("change", this.$onDocumentChange);
	            this.renderer.setSession(session);
	    
	            this.$onChangeMode = this.onChangeMode.bind(this);
	            session.on("changeMode", this.$onChangeMode);
	    
	            this.$onTokenizerUpdate = this.onTokenizerUpdate.bind(this);
	            session.on("tokenizerUpdate", this.$onTokenizerUpdate);
	    
	            this.$onChangeTabSize = this.renderer.onChangeTabSize.bind(this.renderer);
	            session.on("changeTabSize", this.$onChangeTabSize);
	    
	            this.$onChangeWrapLimit = this.onChangeWrapLimit.bind(this);
	            session.on("changeWrapLimit", this.$onChangeWrapLimit);
	    
	            this.$onChangeWrapMode = this.onChangeWrapMode.bind(this);
	            session.on("changeWrapMode", this.$onChangeWrapMode);
	    
	            this.$onChangeFold = this.onChangeFold.bind(this);
	            session.on("changeFold", this.$onChangeFold);
	    
	            this.$onChangeFrontMarker = this.onChangeFrontMarker.bind(this);
	            this.session.on("changeFrontMarker", this.$onChangeFrontMarker);
	    
	            this.$onChangeBackMarker = this.onChangeBackMarker.bind(this);
	            this.session.on("changeBackMarker", this.$onChangeBackMarker);
	    
	            this.$onChangeBreakpoint = this.onChangeBreakpoint.bind(this);
	            this.session.on("changeBreakpoint", this.$onChangeBreakpoint);
	    
	            this.$onChangeAnnotation = this.onChangeAnnotation.bind(this);
	            this.session.on("changeAnnotation", this.$onChangeAnnotation);
	    
	            this.$onCursorChange = this.onCursorChange.bind(this);
	            this.session.on("changeOverwrite", this.$onCursorChange);
	    
	            this.$onScrollTopChange = this.onScrollTopChange.bind(this);
	            this.session.on("changeScrollTop", this.$onScrollTopChange);
	    
	            this.$onScrollLeftChange = this.onScrollLeftChange.bind(this);
	            this.session.on("changeScrollLeft", this.$onScrollLeftChange);
	    
	            this.selection = session.getSelection();
	            this.selection.on("changeCursor", this.$onCursorChange);
	    
	            this.$onSelectionChange = this.onSelectionChange.bind(this);
	            this.selection.on("changeSelection", this.$onSelectionChange);
	    
	            this.onChangeMode();
	    
	            this.$blockScrolling += 1;
	            this.onCursorChange();
	            this.$blockScrolling -= 1;
	    
	            this.onScrollTopChange();
	            this.onScrollLeftChange();
	            this.onSelectionChange();
	            this.onChangeFrontMarker();
	            this.onChangeBackMarker();
	            this.onChangeBreakpoint();
	            this.onChangeAnnotation();
	            this.session.getUseWrapMode() && this.renderer.adjustWrapLimit();
	            this.renderer.updateFull();
	        } else {
	            this.selection = null;
	            this.renderer.setSession(session);
	        }

	        this._signal("changeSession", {
	            session: session,
	            oldSession: oldSession
	        });
	        
	        this.curOp = null;
	        
	        oldSession && oldSession._signal("changeEditor", {oldEditor: this});
	        session && session._signal("changeEditor", {editor: this});
	    };
	    this.getSession = function() {
	        return this.session;
	    };
	    this.setValue = function(val, cursorPos) {
	        this.session.doc.setValue(val);

	        if (!cursorPos)
	            this.selectAll();
	        else if (cursorPos == 1)
	            this.navigateFileEnd();
	        else if (cursorPos == -1)
	            this.navigateFileStart();

	        return val;
	    };
	    this.getValue = function() {
	        return this.session.getValue();
	    };
	    this.getSelection = function() {
	        return this.selection;
	    };
	    this.resize = function(force) {
	        this.renderer.onResize(force);
	    };
	    this.setTheme = function(theme, cb) {
	        this.renderer.setTheme(theme, cb);
	    };
	    this.getTheme = function() {
	        return this.renderer.getTheme();
	    };
	    this.setStyle = function(style) {
	        this.renderer.setStyle(style);
	    };
	    this.unsetStyle = function(style) {
	        this.renderer.unsetStyle(style);
	    };
	    this.getFontSize = function () {
	        return this.getOption("fontSize") ||
	           dom.computedStyle(this.container, "fontSize");
	    };
	    this.setFontSize = function(size) {
	        this.setOption("fontSize", size);
	    };

	    this.$highlightBrackets = function() {
	        if (this.session.$bracketHighlight) {
	            this.session.removeMarker(this.session.$bracketHighlight);
	            this.session.$bracketHighlight = null;
	        }

	        if (this.$highlightPending) {
	            return;
	        }
	        var self = this;
	        this.$highlightPending = true;
	        setTimeout(function() {
	            self.$highlightPending = false;
	            var session = self.session;
	            if (!session || !session.bgTokenizer) return;
	            var pos = session.findMatchingBracket(self.getCursorPosition());
	            if (pos) {
	                var range = new Range(pos.row, pos.column, pos.row, pos.column + 1);
	            } else if (session.$mode.getMatching) {
	                var range = session.$mode.getMatching(self.session);
	            }
	            if (range)
	                session.$bracketHighlight = session.addMarker(range, "ace_bracket", "text");
	        }, 50);
	    };
	    this.$highlightTags = function() {
	        if (this.$highlightTagPending)
	            return;
	        var self = this;
	        this.$highlightTagPending = true;
	        setTimeout(function() {
	            self.$highlightTagPending = false;
	            
	            var session = self.session;
	            if (!session || !session.bgTokenizer) return;
	            
	            var pos = self.getCursorPosition();
	            var iterator = new TokenIterator(self.session, pos.row, pos.column);
	            var token = iterator.getCurrentToken();
	            
	            if (!token || !/\b(?:tag-open|tag-name)/.test(token.type)) {
	                session.removeMarker(session.$tagHighlight);
	                session.$tagHighlight = null;
	                return;
	            }
	            
	            if (token.type.indexOf("tag-open") != -1) {
	                token = iterator.stepForward();
	                if (!token)
	                    return;
	            }
	            
	            var tag = token.value;
	            var depth = 0;
	            var prevToken = iterator.stepBackward();
	            
	            if (prevToken.value == '<'){
	                do {
	                    prevToken = token;
	                    token = iterator.stepForward();
	                    
	                    if (token && token.value === tag && token.type.indexOf('tag-name') !== -1) {
	                        if (prevToken.value === '<'){
	                            depth++;
	                        } else if (prevToken.value === '</'){
	                            depth--;
	                        }
	                    }
	                    
	                } while (token && depth >= 0);
	            } else {
	                do {
	                    token = prevToken;
	                    prevToken = iterator.stepBackward();
	                    
	                    if (token && token.value === tag && token.type.indexOf('tag-name') !== -1) {
	                        if (prevToken.value === '<') {
	                            depth++;
	                        } else if (prevToken.value === '</') {
	                            depth--;
	                        }
	                    }
	                } while (prevToken && depth <= 0);
	                iterator.stepForward();
	            }
	            
	            if (!token) {
	                session.removeMarker(session.$tagHighlight);
	                session.$tagHighlight = null;
	                return;
	            }
	            
	            var row = iterator.getCurrentTokenRow();
	            var column = iterator.getCurrentTokenColumn();
	            var range = new Range(row, column, row, column+token.value.length);
	            var sbm = session.$backMarkers[session.$tagHighlight];
	            if (session.$tagHighlight && sbm != undefined && range.compareRange(sbm.range) !== 0) {
	                session.removeMarker(session.$tagHighlight);
	                session.$tagHighlight = null;
	            }
	            
	            if (range && !session.$tagHighlight)
	                session.$tagHighlight = session.addMarker(range, "ace_bracket", "text");
	        }, 50);
	    };
	    this.focus = function() {
	        var _self = this;
	        setTimeout(function() {
	            _self.textInput.focus();
	        });
	        this.textInput.focus();
	    };
	    this.isFocused = function() {
	        return this.textInput.isFocused();
	    };
	    this.blur = function() {
	        this.textInput.blur();
	    };
	    this.onFocus = function(e) {
	        if (this.$isFocused)
	            return;
	        this.$isFocused = true;
	        this.renderer.showCursor();
	        this.renderer.visualizeFocus();
	        this._emit("focus", e);
	    };
	    this.onBlur = function(e) {
	        if (!this.$isFocused)
	            return;
	        this.$isFocused = false;
	        this.renderer.hideCursor();
	        this.renderer.visualizeBlur();
	        this._emit("blur", e);
	    };

	    this.$cursorChange = function() {
	        this.renderer.updateCursor();
	    };
	    this.onDocumentChange = function(delta) {
	        var wrap = this.session.$useWrapMode;
	        var lastRow = (delta.start.row == delta.end.row ? delta.end.row : Infinity);
	        this.renderer.updateLines(delta.start.row, lastRow, wrap);

	        this._signal("change", delta);
	        this.$cursorChange();
	        this.$updateHighlightActiveLine();
	    };

	    this.onTokenizerUpdate = function(e) {
	        var rows = e.data;
	        this.renderer.updateLines(rows.first, rows.last);
	    };


	    this.onScrollTopChange = function() {
	        this.renderer.scrollToY(this.session.getScrollTop());
	    };

	    this.onScrollLeftChange = function() {
	        this.renderer.scrollToX(this.session.getScrollLeft());
	    };
	    this.onCursorChange = function() {
	        this.$cursorChange();

	        if (!this.$blockScrolling) {
	            config.warn("Automatically scrolling cursor into view after selection change",
	                "this will be disabled in the next version",
	                "set editor.$blockScrolling = Infinity to disable this message"
	            );
	            this.renderer.scrollCursorIntoView();
	        }

	        this.$highlightBrackets();
	        this.$highlightTags();
	        this.$updateHighlightActiveLine();
	        this._signal("changeSelection");
	    };

	    this.$updateHighlightActiveLine = function() {
	        var session = this.getSession();

	        var highlight;
	        if (this.$highlightActiveLine) {
	            if ((this.$selectionStyle != "line" || !this.selection.isMultiLine()))
	                highlight = this.getCursorPosition();
	            if (this.renderer.$maxLines && this.session.getLength() === 1 && !(this.renderer.$minLines > 1))
	                highlight = false;
	        }

	        if (session.$highlightLineMarker && !highlight) {
	            session.removeMarker(session.$highlightLineMarker.id);
	            session.$highlightLineMarker = null;
	        } else if (!session.$highlightLineMarker && highlight) {
	            var range = new Range(highlight.row, highlight.column, highlight.row, Infinity);
	            range.id = session.addMarker(range, "ace_active-line", "screenLine");
	            session.$highlightLineMarker = range;
	        } else if (highlight) {
	            session.$highlightLineMarker.start.row = highlight.row;
	            session.$highlightLineMarker.end.row = highlight.row;
	            session.$highlightLineMarker.start.column = highlight.column;
	            session._signal("changeBackMarker");
	        }
	    };

	    this.onSelectionChange = function(e) {
	        var session = this.session;

	        if (session.$selectionMarker) {
	            session.removeMarker(session.$selectionMarker);
	        }
	        session.$selectionMarker = null;

	        if (!this.selection.isEmpty()) {
	            var range = this.selection.getRange();
	            var style = this.getSelectionStyle();
	            session.$selectionMarker = session.addMarker(range, "ace_selection", style);
	        } else {
	            this.$updateHighlightActiveLine();
	        }

	        var re = this.$highlightSelectedWord && this.$getSelectionHighLightRegexp();
	        this.session.highlight(re);

	        this._signal("changeSelection");
	    };

	    this.$getSelectionHighLightRegexp = function() {
	        var session = this.session;

	        var selection = this.getSelectionRange();
	        if (selection.isEmpty() || selection.isMultiLine())
	            return;

	        var startOuter = selection.start.column - 1;
	        var endOuter = selection.end.column + 1;
	        var line = session.getLine(selection.start.row);
	        var lineCols = line.length;
	        var needle = line.substring(Math.max(startOuter, 0),
	                                    Math.min(endOuter, lineCols));
	        if ((startOuter >= 0 && /^[\w\d]/.test(needle)) ||
	            (endOuter <= lineCols && /[\w\d]$/.test(needle)))
	            return;

	        needle = line.substring(selection.start.column, selection.end.column);
	        if (!/^[\w\d]+$/.test(needle))
	            return;

	        var re = this.$search.$assembleRegExp({
	            wholeWord: true,
	            caseSensitive: true,
	            needle: needle
	        });

	        return re;
	    };


	    this.onChangeFrontMarker = function() {
	        this.renderer.updateFrontMarkers();
	    };

	    this.onChangeBackMarker = function() {
	        this.renderer.updateBackMarkers();
	    };


	    this.onChangeBreakpoint = function() {
	        this.renderer.updateBreakpoints();
	    };

	    this.onChangeAnnotation = function() {
	        this.renderer.setAnnotations(this.session.getAnnotations());
	    };


	    this.onChangeMode = function(e) {
	        this.renderer.updateText();
	        this._emit("changeMode", e);
	    };


	    this.onChangeWrapLimit = function() {
	        this.renderer.updateFull();
	    };

	    this.onChangeWrapMode = function() {
	        this.renderer.onResize(true);
	    };


	    this.onChangeFold = function() {
	        this.$updateHighlightActiveLine();
	        this.renderer.updateFull();
	    };
	    this.getSelectedText = function() {
	        return this.session.getTextRange(this.getSelectionRange());
	    };
	    this.getCopyText = function() {
	        var text = this.getSelectedText();
	        this._signal("copy", text);
	        return text;
	    };
	    this.onCopy = function() {
	        this.commands.exec("copy", this);
	    };
	    this.onCut = function() {
	        this.commands.exec("cut", this);
	    };
	    this.onPaste = function(text, event) {
	        var e = {text: text, event: event};
	        this.commands.exec("paste", this, e);
	    };
	    
	    this.$handlePaste = function(e) {
	        if (typeof e == "string") 
	            e = {text: e};
	        this._signal("paste", e);
	        var text = e.text;
	        if (!this.inMultiSelectMode || this.inVirtualSelectionMode) {
	            this.insert(text);
	        } else {
	            var lines = text.split(/\r\n|\r|\n/);
	            var ranges = this.selection.rangeList.ranges;
	    
	            if (lines.length > ranges.length || lines.length < 2 || !lines[1])
	                return this.commands.exec("insertstring", this, text);
	    
	            for (var i = ranges.length; i--;) {
	                var range = ranges[i];
	                if (!range.isEmpty())
	                    this.session.remove(range);
	    
	                this.session.insert(range.start, lines[i]);
	            }
	        }
	    };

	    this.execCommand = function(command, args) {
	        return this.commands.exec(command, this, args);
	    };
	    this.insert = function(text, pasted) {
	        var session = this.session;
	        var mode = session.getMode();
	        var cursor = this.getCursorPosition();

	        if (this.getBehavioursEnabled() && !pasted) {
	            var transform = mode.transformAction(session.getState(cursor.row), 'insertion', this, session, text);
	            if (transform) {
	                if (text !== transform.text) {
	                    this.session.mergeUndoDeltas = false;
	                    this.$mergeNextCommand = false;
	                }
	                text = transform.text;

	            }
	        }
	        
	        if (text == "\t")
	            text = this.session.getTabString();
	        if (!this.selection.isEmpty()) {
	            var range = this.getSelectionRange();
	            cursor = this.session.remove(range);
	            this.clearSelection();
	        }
	        else if (this.session.getOverwrite()) {
	            var range = new Range.fromPoints(cursor, cursor);
	            range.end.column += text.length;
	            this.session.remove(range);
	        }

	        if (text == "\n" || text == "\r\n") {
	            var line = session.getLine(cursor.row);
	            if (cursor.column > line.search(/\S|$/)) {
	                var d = line.substr(cursor.column).search(/\S|$/);
	                session.doc.removeInLine(cursor.row, cursor.column, cursor.column + d);
	            }
	        }
	        this.clearSelection();

	        var start = cursor.column;
	        var lineState = session.getState(cursor.row);
	        var line = session.getLine(cursor.row);
	        var shouldOutdent = mode.checkOutdent(lineState, line, text);
	        var end = session.insert(cursor, text);

	        if (transform && transform.selection) {
	            if (transform.selection.length == 2) { // Transform relative to the current column
	                this.selection.setSelectionRange(
	                    new Range(cursor.row, start + transform.selection[0],
	                              cursor.row, start + transform.selection[1]));
	            } else { // Transform relative to the current row.
	                this.selection.setSelectionRange(
	                    new Range(cursor.row + transform.selection[0],
	                              transform.selection[1],
	                              cursor.row + transform.selection[2],
	                              transform.selection[3]));
	            }
	        }

	        if (session.getDocument().isNewLine(text)) {
	            var lineIndent = mode.getNextLineIndent(lineState, line.slice(0, cursor.column), session.getTabString());

	            session.insert({row: cursor.row+1, column: 0}, lineIndent);
	        }
	        if (shouldOutdent)
	            mode.autoOutdent(lineState, session, cursor.row);
	    };

	    this.onTextInput = function(text) {
	        this.keyBinding.onTextInput(text);
	    };

	    this.onCommandKey = function(e, hashId, keyCode) {
	        this.keyBinding.onCommandKey(e, hashId, keyCode);
	    };
	    this.setOverwrite = function(overwrite) {
	        this.session.setOverwrite(overwrite);
	    };
	    this.getOverwrite = function() {
	        return this.session.getOverwrite();
	    };
	    this.toggleOverwrite = function() {
	        this.session.toggleOverwrite();
	    };
	    this.setScrollSpeed = function(speed) {
	        this.setOption("scrollSpeed", speed);
	    };
	    this.getScrollSpeed = function() {
	        return this.getOption("scrollSpeed");
	    };
	    this.setDragDelay = function(dragDelay) {
	        this.setOption("dragDelay", dragDelay);
	    };
	    this.getDragDelay = function() {
	        return this.getOption("dragDelay");
	    };
	    this.setSelectionStyle = function(val) {
	        this.setOption("selectionStyle", val);
	    };
	    this.getSelectionStyle = function() {
	        return this.getOption("selectionStyle");
	    };
	    this.setHighlightActiveLine = function(shouldHighlight) {
	        this.setOption("highlightActiveLine", shouldHighlight);
	    };
	    this.getHighlightActiveLine = function() {
	        return this.getOption("highlightActiveLine");
	    };
	    this.setHighlightGutterLine = function(shouldHighlight) {
	        this.setOption("highlightGutterLine", shouldHighlight);
	    };

	    this.getHighlightGutterLine = function() {
	        return this.getOption("highlightGutterLine");
	    };
	    this.setHighlightSelectedWord = function(shouldHighlight) {
	        this.setOption("highlightSelectedWord", shouldHighlight);
	    };
	    this.getHighlightSelectedWord = function() {
	        return this.$highlightSelectedWord;
	    };

	    this.setAnimatedScroll = function(shouldAnimate){
	        this.renderer.setAnimatedScroll(shouldAnimate);
	    };

	    this.getAnimatedScroll = function(){
	        return this.renderer.getAnimatedScroll();
	    };
	    this.setShowInvisibles = function(showInvisibles) {
	        this.renderer.setShowInvisibles(showInvisibles);
	    };
	    this.getShowInvisibles = function() {
	        return this.renderer.getShowInvisibles();
	    };

	    this.setDisplayIndentGuides = function(display) {
	        this.renderer.setDisplayIndentGuides(display);
	    };

	    this.getDisplayIndentGuides = function() {
	        return this.renderer.getDisplayIndentGuides();
	    };
	    this.setShowPrintMargin = function(showPrintMargin) {
	        this.renderer.setShowPrintMargin(showPrintMargin);
	    };
	    this.getShowPrintMargin = function() {
	        return this.renderer.getShowPrintMargin();
	    };
	    this.setPrintMarginColumn = function(showPrintMargin) {
	        this.renderer.setPrintMarginColumn(showPrintMargin);
	    };
	    this.getPrintMarginColumn = function() {
	        return this.renderer.getPrintMarginColumn();
	    };
	    this.setReadOnly = function(readOnly) {
	        this.setOption("readOnly", readOnly);
	    };
	    this.getReadOnly = function() {
	        return this.getOption("readOnly");
	    };
	    this.setBehavioursEnabled = function (enabled) {
	        this.setOption("behavioursEnabled", enabled);
	    };
	    this.getBehavioursEnabled = function () {
	        return this.getOption("behavioursEnabled");
	    };
	    this.setWrapBehavioursEnabled = function (enabled) {
	        this.setOption("wrapBehavioursEnabled", enabled);
	    };
	    this.getWrapBehavioursEnabled = function () {
	        return this.getOption("wrapBehavioursEnabled");
	    };
	    this.setShowFoldWidgets = function(show) {
	        this.setOption("showFoldWidgets", show);

	    };
	    this.getShowFoldWidgets = function() {
	        return this.getOption("showFoldWidgets");
	    };

	    this.setFadeFoldWidgets = function(fade) {
	        this.setOption("fadeFoldWidgets", fade);
	    };

	    this.getFadeFoldWidgets = function() {
	        return this.getOption("fadeFoldWidgets");
	    };
	    this.remove = function(dir) {
	        if (this.selection.isEmpty()){
	            if (dir == "left")
	                this.selection.selectLeft();
	            else
	                this.selection.selectRight();
	        }

	        var range = this.getSelectionRange();
	        if (this.getBehavioursEnabled()) {
	            var session = this.session;
	            var state = session.getState(range.start.row);
	            var new_range = session.getMode().transformAction(state, 'deletion', this, session, range);

	            if (range.end.column === 0) {
	                var text = session.getTextRange(range);
	                if (text[text.length - 1] == "\n") {
	                    var line = session.getLine(range.end.row);
	                    if (/^\s+$/.test(line)) {
	                        range.end.column = line.length;
	                    }
	                }
	            }
	            if (new_range)
	                range = new_range;
	        }

	        this.session.remove(range);
	        this.clearSelection();
	    };
	    this.removeWordRight = function() {
	        if (this.selection.isEmpty())
	            this.selection.selectWordRight();

	        this.session.remove(this.getSelectionRange());
	        this.clearSelection();
	    };
	    this.removeWordLeft = function() {
	        if (this.selection.isEmpty())
	            this.selection.selectWordLeft();

	        this.session.remove(this.getSelectionRange());
	        this.clearSelection();
	    };
	    this.removeToLineStart = function() {
	        if (this.selection.isEmpty())
	            this.selection.selectLineStart();

	        this.session.remove(this.getSelectionRange());
	        this.clearSelection();
	    };
	    this.removeToLineEnd = function() {
	        if (this.selection.isEmpty())
	            this.selection.selectLineEnd();

	        var range = this.getSelectionRange();
	        if (range.start.column == range.end.column && range.start.row == range.end.row) {
	            range.end.column = 0;
	            range.end.row++;
	        }

	        this.session.remove(range);
	        this.clearSelection();
	    };
	    this.splitLine = function() {
	        if (!this.selection.isEmpty()) {
	            this.session.remove(this.getSelectionRange());
	            this.clearSelection();
	        }

	        var cursor = this.getCursorPosition();
	        this.insert("\n");
	        this.moveCursorToPosition(cursor);
	    };
	    this.transposeLetters = function() {
	        if (!this.selection.isEmpty()) {
	            return;
	        }

	        var cursor = this.getCursorPosition();
	        var column = cursor.column;
	        if (column === 0)
	            return;

	        var line = this.session.getLine(cursor.row);
	        var swap, range;
	        if (column < line.length) {
	            swap = line.charAt(column) + line.charAt(column-1);
	            range = new Range(cursor.row, column-1, cursor.row, column+1);
	        }
	        else {
	            swap = line.charAt(column-1) + line.charAt(column-2);
	            range = new Range(cursor.row, column-2, cursor.row, column);
	        }
	        this.session.replace(range, swap);
	    };
	    this.toLowerCase = function() {
	        var originalRange = this.getSelectionRange();
	        if (this.selection.isEmpty()) {
	            this.selection.selectWord();
	        }

	        var range = this.getSelectionRange();
	        var text = this.session.getTextRange(range);
	        this.session.replace(range, text.toLowerCase());
	        this.selection.setSelectionRange(originalRange);
	    };
	    this.toUpperCase = function() {
	        var originalRange = this.getSelectionRange();
	        if (this.selection.isEmpty()) {
	            this.selection.selectWord();
	        }

	        var range = this.getSelectionRange();
	        var text = this.session.getTextRange(range);
	        this.session.replace(range, text.toUpperCase());
	        this.selection.setSelectionRange(originalRange);
	    };
	    this.indent = function() {
	        var session = this.session;
	        var range = this.getSelectionRange();

	        if (range.start.row < range.end.row) {
	            var rows = this.$getSelectedRows();
	            session.indentRows(rows.first, rows.last, "\t");
	            return;
	        } else if (range.start.column < range.end.column) {
	            var text = session.getTextRange(range);
	            if (!/^\s+$/.test(text)) {
	                var rows = this.$getSelectedRows();
	                session.indentRows(rows.first, rows.last, "\t");
	                return;
	            }
	        }
	        
	        var line = session.getLine(range.start.row);
	        var position = range.start;
	        var size = session.getTabSize();
	        var column = session.documentToScreenColumn(position.row, position.column);

	        if (this.session.getUseSoftTabs()) {
	            var count = (size - column % size);
	            var indentString = lang.stringRepeat(" ", count);
	        } else {
	            var count = column % size;
	            while (line[range.start.column - 1] == " " && count) {
	                range.start.column--;
	                count--;
	            }
	            this.selection.setSelectionRange(range);
	            indentString = "\t";
	        }
	        return this.insert(indentString);
	    };
	    this.blockIndent = function() {
	        var rows = this.$getSelectedRows();
	        this.session.indentRows(rows.first, rows.last, "\t");
	    };
	    this.blockOutdent = function() {
	        var selection = this.session.getSelection();
	        this.session.outdentRows(selection.getRange());
	    };
	    this.sortLines = function() {
	        var rows = this.$getSelectedRows();
	        var session = this.session;

	        var lines = [];
	        for (i = rows.first; i <= rows.last; i++)
	            lines.push(session.getLine(i));

	        lines.sort(function(a, b) {
	            if (a.toLowerCase() < b.toLowerCase()) return -1;
	            if (a.toLowerCase() > b.toLowerCase()) return 1;
	            return 0;
	        });

	        var deleteRange = new Range(0, 0, 0, 0);
	        for (var i = rows.first; i <= rows.last; i++) {
	            var line = session.getLine(i);
	            deleteRange.start.row = i;
	            deleteRange.end.row = i;
	            deleteRange.end.column = line.length;
	            session.replace(deleteRange, lines[i-rows.first]);
	        }
	    };
	    this.toggleCommentLines = function() {
	        var state = this.session.getState(this.getCursorPosition().row);
	        var rows = this.$getSelectedRows();
	        this.session.getMode().toggleCommentLines(state, this.session, rows.first, rows.last);
	    };

	    this.toggleBlockComment = function() {
	        var cursor = this.getCursorPosition();
	        var state = this.session.getState(cursor.row);
	        var range = this.getSelectionRange();
	        this.session.getMode().toggleBlockComment(state, this.session, range, cursor);
	    };
	    this.getNumberAt = function(row, column) {
	        var _numberRx = /[\-]?[0-9]+(?:\.[0-9]+)?/g;
	        _numberRx.lastIndex = 0;

	        var s = this.session.getLine(row);
	        while (_numberRx.lastIndex < column) {
	            var m = _numberRx.exec(s);
	            if(m.index <= column && m.index+m[0].length >= column){
	                var number = {
	                    value: m[0],
	                    start: m.index,
	                    end: m.index+m[0].length
	                };
	                return number;
	            }
	        }
	        return null;
	    };
	    this.modifyNumber = function(amount) {
	        var row = this.selection.getCursor().row;
	        var column = this.selection.getCursor().column;
	        var charRange = new Range(row, column-1, row, column);

	        var c = this.session.getTextRange(charRange);
	        if (!isNaN(parseFloat(c)) && isFinite(c)) {
	            var nr = this.getNumberAt(row, column);
	            if (nr) {
	                var fp = nr.value.indexOf(".") >= 0 ? nr.start + nr.value.indexOf(".") + 1 : nr.end;
	                var decimals = nr.start + nr.value.length - fp;

	                var t = parseFloat(nr.value);
	                t *= Math.pow(10, decimals);


	                if(fp !== nr.end && column < fp){
	                    amount *= Math.pow(10, nr.end - column - 1);
	                } else {
	                    amount *= Math.pow(10, nr.end - column);
	                }

	                t += amount;
	                t /= Math.pow(10, decimals);
	                var nnr = t.toFixed(decimals);
	                var replaceRange = new Range(row, nr.start, row, nr.end);
	                this.session.replace(replaceRange, nnr);
	                this.moveCursorTo(row, Math.max(nr.start +1, column + nnr.length - nr.value.length));

	            }
	        }
	    };
	    this.removeLines = function() {
	        var rows = this.$getSelectedRows();
	        this.session.removeFullLines(rows.first, rows.last);
	        this.clearSelection();
	    };

	    this.duplicateSelection = function() {
	        var sel = this.selection;
	        var doc = this.session;
	        var range = sel.getRange();
	        var reverse = sel.isBackwards();
	        if (range.isEmpty()) {
	            var row = range.start.row;
	            doc.duplicateLines(row, row);
	        } else {
	            var point = reverse ? range.start : range.end;
	            var endPoint = doc.insert(point, doc.getTextRange(range), false);
	            range.start = point;
	            range.end = endPoint;

	            sel.setSelectionRange(range, reverse);
	        }
	    };
	    this.moveLinesDown = function() {
	        this.$moveLines(1, false);
	    };
	    this.moveLinesUp = function() {
	        this.$moveLines(-1, false);
	    };
	    this.moveText = function(range, toPosition, copy) {
	        return this.session.moveText(range, toPosition, copy);
	    };
	    this.copyLinesUp = function() {
	        this.$moveLines(-1, true);
	    };
	    this.copyLinesDown = function() {
	        this.$moveLines(1, true);
	    };
	    this.$moveLines = function(dir, copy) {
	        var rows, moved;
	        var selection = this.selection;
	        if (!selection.inMultiSelectMode || this.inVirtualSelectionMode) {
	            var range = selection.toOrientedRange();
	            rows = this.$getSelectedRows(range);
	            moved = this.session.$moveLines(rows.first, rows.last, copy ? 0 : dir);
	            if (copy && dir == -1) moved = 0;
	            range.moveBy(moved, 0);
	            selection.fromOrientedRange(range);
	        } else {
	            var ranges = selection.rangeList.ranges;
	            selection.rangeList.detach(this.session);
	            this.inVirtualSelectionMode = true;
	            
	            var diff = 0;
	            var totalDiff = 0;
	            var l = ranges.length;
	            for (var i = 0; i < l; i++) {
	                var rangeIndex = i;
	                ranges[i].moveBy(diff, 0);
	                rows = this.$getSelectedRows(ranges[i]);
	                var first = rows.first;
	                var last = rows.last;
	                while (++i < l) {
	                    if (totalDiff) ranges[i].moveBy(totalDiff, 0);
	                    var subRows = this.$getSelectedRows(ranges[i]);
	                    if (copy && subRows.first != last)
	                        break;
	                    else if (!copy && subRows.first > last + 1)
	                        break;
	                    last = subRows.last;
	                }
	                i--;
	                diff = this.session.$moveLines(first, last, copy ? 0 : dir);
	                if (copy && dir == -1) rangeIndex = i + 1;
	                while (rangeIndex <= i) {
	                    ranges[rangeIndex].moveBy(diff, 0);
	                    rangeIndex++;
	                }
	                if (!copy) diff = 0;
	                totalDiff += diff;
	            }
	            
	            selection.fromOrientedRange(selection.ranges[0]);
	            selection.rangeList.attach(this.session);
	            this.inVirtualSelectionMode = false;
	        }
	    };
	    this.$getSelectedRows = function(range) {
	        range = (range || this.getSelectionRange()).collapseRows();

	        return {
	            first: this.session.getRowFoldStart(range.start.row),
	            last: this.session.getRowFoldEnd(range.end.row)
	        };
	    };

	    this.onCompositionStart = function(text) {
	        this.renderer.showComposition(this.getCursorPosition());
	    };

	    this.onCompositionUpdate = function(text) {
	        this.renderer.setCompositionText(text);
	    };

	    this.onCompositionEnd = function() {
	        this.renderer.hideComposition();
	    };
	    this.getFirstVisibleRow = function() {
	        return this.renderer.getFirstVisibleRow();
	    };
	    this.getLastVisibleRow = function() {
	        return this.renderer.getLastVisibleRow();
	    };
	    this.isRowVisible = function(row) {
	        return (row >= this.getFirstVisibleRow() && row <= this.getLastVisibleRow());
	    };
	    this.isRowFullyVisible = function(row) {
	        return (row >= this.renderer.getFirstFullyVisibleRow() && row <= this.renderer.getLastFullyVisibleRow());
	    };
	    this.$getVisibleRowCount = function() {
	        return this.renderer.getScrollBottomRow() - this.renderer.getScrollTopRow() + 1;
	    };

	    this.$moveByPage = function(dir, select) {
	        var renderer = this.renderer;
	        var config = this.renderer.layerConfig;
	        var rows = dir * Math.floor(config.height / config.lineHeight);

	        this.$blockScrolling++;
	        if (select === true) {
	            this.selection.$moveSelection(function(){
	                this.moveCursorBy(rows, 0);
	            });
	        } else if (select === false) {
	            this.selection.moveCursorBy(rows, 0);
	            this.selection.clearSelection();
	        }
	        this.$blockScrolling--;

	        var scrollTop = renderer.scrollTop;

	        renderer.scrollBy(0, rows * config.lineHeight);
	        if (select != null)
	            renderer.scrollCursorIntoView(null, 0.5);

	        renderer.animateScrolling(scrollTop);
	    };
	    this.selectPageDown = function() {
	        this.$moveByPage(1, true);
	    };
	    this.selectPageUp = function() {
	        this.$moveByPage(-1, true);
	    };
	    this.gotoPageDown = function() {
	       this.$moveByPage(1, false);
	    };
	    this.gotoPageUp = function() {
	        this.$moveByPage(-1, false);
	    };
	    this.scrollPageDown = function() {
	        this.$moveByPage(1);
	    };
	    this.scrollPageUp = function() {
	        this.$moveByPage(-1);
	    };
	    this.scrollToRow = function(row) {
	        this.renderer.scrollToRow(row);
	    };
	    this.scrollToLine = function(line, center, animate, callback) {
	        this.renderer.scrollToLine(line, center, animate, callback);
	    };
	    this.centerSelection = function() {
	        var range = this.getSelectionRange();
	        var pos = {
	            row: Math.floor(range.start.row + (range.end.row - range.start.row) / 2),
	            column: Math.floor(range.start.column + (range.end.column - range.start.column) / 2)
	        };
	        this.renderer.alignCursor(pos, 0.5);
	    };
	    this.getCursorPosition = function() {
	        return this.selection.getCursor();
	    };
	    this.getCursorPositionScreen = function() {
	        return this.session.documentToScreenPosition(this.getCursorPosition());
	    };
	    this.getSelectionRange = function() {
	        return this.selection.getRange();
	    };
	    this.selectAll = function() {
	        this.$blockScrolling += 1;
	        this.selection.selectAll();
	        this.$blockScrolling -= 1;
	    };
	    this.clearSelection = function() {
	        this.selection.clearSelection();
	    };
	    this.moveCursorTo = function(row, column) {
	        this.selection.moveCursorTo(row, column);
	    };
	    this.moveCursorToPosition = function(pos) {
	        this.selection.moveCursorToPosition(pos);
	    };
	    this.jumpToMatching = function(select, expand) {
	        var cursor = this.getCursorPosition();
	        var iterator = new TokenIterator(this.session, cursor.row, cursor.column);
	        var prevToken = iterator.getCurrentToken();
	        var token = prevToken || iterator.stepForward();

	        if (!token) return;
	        var matchType;
	        var found = false;
	        var depth = {};
	        var i = cursor.column - token.start;
	        var bracketType;
	        var brackets = {
	            ")": "(",
	            "(": "(",
	            "]": "[",
	            "[": "[",
	            "{": "{",
	            "}": "{"
	        };
	        
	        do {
	            if (token.value.match(/[{}()\[\]]/g)) {
	                for (; i < token.value.length && !found; i++) {
	                    if (!brackets[token.value[i]]) {
	                        continue;
	                    }

	                    bracketType = brackets[token.value[i]] + '.' + token.type.replace("rparen", "lparen");

	                    if (isNaN(depth[bracketType])) {
	                        depth[bracketType] = 0;
	                    }

	                    switch (token.value[i]) {
	                        case '(':
	                        case '[':
	                        case '{':
	                            depth[bracketType]++;
	                            break;
	                        case ')':
	                        case ']':
	                        case '}':
	                            depth[bracketType]--;

	                            if (depth[bracketType] === -1) {
	                                matchType = 'bracket';
	                                found = true;
	                            }
	                        break;
	                    }
	                }
	            }
	            else if (token && token.type.indexOf('tag-name') !== -1) {
	                if (isNaN(depth[token.value])) {
	                    depth[token.value] = 0;
	                }
	                
	                if (prevToken.value === '<') {
	                    depth[token.value]++;
	                }
	                else if (prevToken.value === '</') {
	                    depth[token.value]--;
	                }
	                
	                if (depth[token.value] === -1) {
	                    matchType = 'tag';
	                    found = true;
	                }
	            }

	            if (!found) {
	                prevToken = token;
	                token = iterator.stepForward();
	                i = 0;
	            }
	        } while (token && !found);
	        if (!matchType)
	            return;

	        var range, pos;
	        if (matchType === 'bracket') {
	            range = this.session.getBracketRange(cursor);
	            if (!range) {
	                range = new Range(
	                    iterator.getCurrentTokenRow(),
	                    iterator.getCurrentTokenColumn() + i - 1,
	                    iterator.getCurrentTokenRow(),
	                    iterator.getCurrentTokenColumn() + i - 1
	                );
	                pos = range.start;
	                if (expand || pos.row === cursor.row && Math.abs(pos.column - cursor.column) < 2)
	                    range = this.session.getBracketRange(pos);
	            }
	        }
	        else if (matchType === 'tag') {
	            if (token && token.type.indexOf('tag-name') !== -1) 
	                var tag = token.value;
	            else
	                return;

	            range = new Range(
	                iterator.getCurrentTokenRow(),
	                iterator.getCurrentTokenColumn() - 2,
	                iterator.getCurrentTokenRow(),
	                iterator.getCurrentTokenColumn() - 2
	            );
	            if (range.compare(cursor.row, cursor.column) === 0) {
	                found = false;
	                do {
	                    token = prevToken;
	                    prevToken = iterator.stepBackward();
	                    
	                    if (prevToken) {
	                        if (prevToken.type.indexOf('tag-close') !== -1) {
	                            range.setEnd(iterator.getCurrentTokenRow(), iterator.getCurrentTokenColumn() + 1);
	                        }

	                        if (token.value === tag && token.type.indexOf('tag-name') !== -1) {
	                            if (prevToken.value === '<') {
	                                depth[tag]++;
	                            }
	                            else if (prevToken.value === '</') {
	                                depth[tag]--;
	                            }
	                            
	                            if (depth[tag] === 0)
	                                found = true;
	                        }
	                    }
	                } while (prevToken && !found);
	            }
	            if (token && token.type.indexOf('tag-name')) {
	                pos = range.start;
	                if (pos.row == cursor.row && Math.abs(pos.column - cursor.column) < 2)
	                    pos = range.end;
	            }
	        }

	        pos = range && range.cursor || pos;
	        if (pos) {
	            if (select) {
	                if (range && expand) {
	                    this.selection.setRange(range);
	                } else if (range && range.isEqual(this.getSelectionRange())) {
	                    this.clearSelection();
	                } else {
	                    this.selection.selectTo(pos.row, pos.column);
	                }
	            } else {
	                this.selection.moveTo(pos.row, pos.column);
	            }
	        }
	    };
	    this.gotoLine = function(lineNumber, column, animate) {
	        this.selection.clearSelection();
	        this.session.unfold({row: lineNumber - 1, column: column || 0});

	        this.$blockScrolling += 1;
	        this.exitMultiSelectMode && this.exitMultiSelectMode();
	        this.moveCursorTo(lineNumber - 1, column || 0);
	        this.$blockScrolling -= 1;

	        if (!this.isRowFullyVisible(lineNumber - 1))
	            this.scrollToLine(lineNumber - 1, true, animate);
	    };
	    this.navigateTo = function(row, column) {
	        this.selection.moveTo(row, column);
	    };
	    this.navigateUp = function(times) {
	        if (this.selection.isMultiLine() && !this.selection.isBackwards()) {
	            var selectionStart = this.selection.anchor.getPosition();
	            return this.moveCursorToPosition(selectionStart);
	        }
	        this.selection.clearSelection();
	        this.selection.moveCursorBy(-times || -1, 0);
	    };
	    this.navigateDown = function(times) {
	        if (this.selection.isMultiLine() && this.selection.isBackwards()) {
	            var selectionEnd = this.selection.anchor.getPosition();
	            return this.moveCursorToPosition(selectionEnd);
	        }
	        this.selection.clearSelection();
	        this.selection.moveCursorBy(times || 1, 0);
	    };
	    this.navigateLeft = function(times) {
	        if (!this.selection.isEmpty()) {
	            var selectionStart = this.getSelectionRange().start;
	            this.moveCursorToPosition(selectionStart);
	        }
	        else {
	            times = times || 1;
	            while (times--) {
	                this.selection.moveCursorLeft();
	            }
	        }
	        this.clearSelection();
	    };
	    this.navigateRight = function(times) {
	        if (!this.selection.isEmpty()) {
	            var selectionEnd = this.getSelectionRange().end;
	            this.moveCursorToPosition(selectionEnd);
	        }
	        else {
	            times = times || 1;
	            while (times--) {
	                this.selection.moveCursorRight();
	            }
	        }
	        this.clearSelection();
	    };
	    this.navigateLineStart = function() {
	        this.selection.moveCursorLineStart();
	        this.clearSelection();
	    };
	    this.navigateLineEnd = function() {
	        this.selection.moveCursorLineEnd();
	        this.clearSelection();
	    };
	    this.navigateFileEnd = function() {
	        this.selection.moveCursorFileEnd();
	        this.clearSelection();
	    };
	    this.navigateFileStart = function() {
	        this.selection.moveCursorFileStart();
	        this.clearSelection();
	    };
	    this.navigateWordRight = function() {
	        this.selection.moveCursorWordRight();
	        this.clearSelection();
	    };
	    this.navigateWordLeft = function() {
	        this.selection.moveCursorWordLeft();
	        this.clearSelection();
	    };
	    this.replace = function(replacement, options) {
	        if (options)
	            this.$search.set(options);

	        var range = this.$search.find(this.session);
	        var replaced = 0;
	        if (!range)
	            return replaced;

	        if (this.$tryReplace(range, replacement)) {
	            replaced = 1;
	        }
	        if (range !== null) {
	            this.selection.setSelectionRange(range);
	            this.renderer.scrollSelectionIntoView(range.start, range.end);
	        }

	        return replaced;
	    };
	    this.replaceAll = function(replacement, options) {
	        if (options) {
	            this.$search.set(options);
	        }

	        var ranges = this.$search.findAll(this.session);
	        var replaced = 0;
	        if (!ranges.length)
	            return replaced;

	        this.$blockScrolling += 1;

	        var selection = this.getSelectionRange();
	        this.selection.moveTo(0, 0);

	        for (var i = ranges.length - 1; i >= 0; --i) {
	            if(this.$tryReplace(ranges[i], replacement)) {
	                replaced++;
	            }
	        }

	        this.selection.setSelectionRange(selection);
	        this.$blockScrolling -= 1;

	        return replaced;
	    };

	    this.$tryReplace = function(range, replacement) {
	        var input = this.session.getTextRange(range);
	        replacement = this.$search.replace(input, replacement);
	        if (replacement !== null) {
	            range.end = this.session.replace(range, replacement);
	            return range;
	        } else {
	            return null;
	        }
	    };
	    this.getLastSearchOptions = function() {
	        return this.$search.getOptions();
	    };
	    this.find = function(needle, options, animate) {
	        if (!options)
	            options = {};

	        if (typeof needle == "string" || needle instanceof RegExp)
	            options.needle = needle;
	        else if (typeof needle == "object")
	            oop.mixin(options, needle);

	        var range = this.selection.getRange();
	        if (options.needle == null) {
	            needle = this.session.getTextRange(range)
	                || this.$search.$options.needle;
	            if (!needle) {
	                range = this.session.getWordRange(range.start.row, range.start.column);
	                needle = this.session.getTextRange(range);
	            }
	            this.$search.set({needle: needle});
	        }

	        this.$search.set(options);
	        if (!options.start)
	            this.$search.set({start: range});

	        var newRange = this.$search.find(this.session);
	        if (options.preventScroll)
	            return newRange;
	        if (newRange) {
	            this.revealRange(newRange, animate);
	            return newRange;
	        }
	        if (options.backwards)
	            range.start = range.end;
	        else
	            range.end = range.start;
	        this.selection.setRange(range);
	    };
	    this.findNext = function(options, animate) {
	        this.find({skipCurrent: true, backwards: false}, options, animate);
	    };
	    this.findPrevious = function(options, animate) {
	        this.find(options, {skipCurrent: true, backwards: true}, animate);
	    };

	    this.revealRange = function(range, animate) {
	        this.$blockScrolling += 1;
	        this.session.unfold(range);
	        this.selection.setSelectionRange(range);
	        this.$blockScrolling -= 1;

	        var scrollTop = this.renderer.scrollTop;
	        this.renderer.scrollSelectionIntoView(range.start, range.end, 0.5);
	        if (animate !== false)
	            this.renderer.animateScrolling(scrollTop);
	    };
	    this.undo = function() {
	        this.$blockScrolling++;
	        this.session.getUndoManager().undo();
	        this.$blockScrolling--;
	        this.renderer.scrollCursorIntoView(null, 0.5);
	    };
	    this.redo = function() {
	        this.$blockScrolling++;
	        this.session.getUndoManager().redo();
	        this.$blockScrolling--;
	        this.renderer.scrollCursorIntoView(null, 0.5);
	    };
	    this.destroy = function() {
	        this.renderer.destroy();
	        this._signal("destroy", this);
	        if (this.session) {
	            this.session.destroy();
	        }
	    };
	    this.setAutoScrollEditorIntoView = function(enable) {
	        if (!enable)
	            return;
	        var rect;
	        var self = this;
	        var shouldScroll = false;
	        if (!this.$scrollAnchor)
	            this.$scrollAnchor = document.createElement("div");
	        var scrollAnchor = this.$scrollAnchor;
	        scrollAnchor.style.cssText = "position:absolute";
	        this.container.insertBefore(scrollAnchor, this.container.firstChild);
	        var onChangeSelection = this.on("changeSelection", function() {
	            shouldScroll = true;
	        });
	        var onBeforeRender = this.renderer.on("beforeRender", function() {
	            if (shouldScroll)
	                rect = self.renderer.container.getBoundingClientRect();
	        });
	        var onAfterRender = this.renderer.on("afterRender", function() {
	            if (shouldScroll && rect && (self.isFocused()
	                || self.searchBox && self.searchBox.isFocused())
	            ) {
	                var renderer = self.renderer;
	                var pos = renderer.$cursorLayer.$pixelPos;
	                var config = renderer.layerConfig;
	                var top = pos.top - config.offset;
	                if (pos.top >= 0 && top + rect.top < 0) {
	                    shouldScroll = true;
	                } else if (pos.top < config.height &&
	                    pos.top + rect.top + config.lineHeight > window.innerHeight) {
	                    shouldScroll = false;
	                } else {
	                    shouldScroll = null;
	                }
	                if (shouldScroll != null) {
	                    scrollAnchor.style.top = top + "px";
	                    scrollAnchor.style.left = pos.left + "px";
	                    scrollAnchor.style.height = config.lineHeight + "px";
	                    scrollAnchor.scrollIntoView(shouldScroll);
	                }
	                shouldScroll = rect = null;
	            }
	        });
	        this.setAutoScrollEditorIntoView = function(enable) {
	            if (enable)
	                return;
	            delete this.setAutoScrollEditorIntoView;
	            this.off("changeSelection", onChangeSelection);
	            this.renderer.off("afterRender", onAfterRender);
	            this.renderer.off("beforeRender", onBeforeRender);
	        };
	    };


	    this.$resetCursorStyle = function() {
	        var style = this.$cursorStyle || "ace";
	        var cursorLayer = this.renderer.$cursorLayer;
	        if (!cursorLayer)
	            return;
	        cursorLayer.setSmoothBlinking(/smooth/.test(style));
	        cursorLayer.isBlinking = !this.$readOnly && style != "wide";
	        dom.setCssClass(cursorLayer.element, "ace_slim-cursors", /slim/.test(style));
	    };

	}).call(Editor.prototype);



	config.defineOptions(Editor.prototype, "editor", {
	    selectionStyle: {
	        set: function(style) {
	            this.onSelectionChange();
	            this._signal("changeSelectionStyle", {data: style});
	        },
	        initialValue: "line"
	    },
	    highlightActiveLine: {
	        set: function() {this.$updateHighlightActiveLine();},
	        initialValue: true
	    },
	    highlightSelectedWord: {
	        set: function(shouldHighlight) {this.$onSelectionChange();},
	        initialValue: true
	    },
	    readOnly: {
	        set: function(readOnly) {
	            this.$resetCursorStyle(); 
	        },
	        initialValue: false
	    },
	    cursorStyle: {
	        set: function(val) { this.$resetCursorStyle(); },
	        values: ["ace", "slim", "smooth", "wide"],
	        initialValue: "ace"
	    },
	    mergeUndoDeltas: {
	        values: [false, true, "always"],
	        initialValue: true
	    },
	    behavioursEnabled: {initialValue: true},
	    wrapBehavioursEnabled: {initialValue: true},
	    autoScrollEditorIntoView: {
	        set: function(val) {this.setAutoScrollEditorIntoView(val)}
	    },
	    keyboardHandler: {
	        set: function(val) { this.setKeyboardHandler(val); },
	        get: function() { return this.keybindingId; },
	        handlesSet: true
	    },

	    hScrollBarAlwaysVisible: "renderer",
	    vScrollBarAlwaysVisible: "renderer",
	    highlightGutterLine: "renderer",
	    animatedScroll: "renderer",
	    showInvisibles: "renderer",
	    showPrintMargin: "renderer",
	    printMarginColumn: "renderer",
	    printMargin: "renderer",
	    fadeFoldWidgets: "renderer",
	    showFoldWidgets: "renderer",
	    showLineNumbers: "renderer",
	    showGutter: "renderer",
	    displayIndentGuides: "renderer",
	    fontSize: "renderer",
	    fontFamily: "renderer",
	    maxLines: "renderer",
	    minLines: "renderer",
	    scrollPastEnd: "renderer",
	    fixedWidthGutter: "renderer",
	    theme: "renderer",

	    scrollSpeed: "$mouseHandler",
	    dragDelay: "$mouseHandler",
	    dragEnabled: "$mouseHandler",
	    focusTimout: "$mouseHandler",
	    tooltipFollowsMouse: "$mouseHandler",

	    firstLineNumber: "session",
	    overwrite: "session",
	    newLineMode: "session",
	    useWorker: "session",
	    useSoftTabs: "session",
	    tabSize: "session",
	    wrap: "session",
	    indentedSoftWrap: "session",
	    foldStyle: "session",
	    mode: "session"
	});

	exports.Editor = Editor;
	});

	ace.define("ace/undomanager",["require","exports","module"], function(acequire, exports, module) {
	"use strict";
	var UndoManager = function() {
	    this.reset();
	};

	(function() {
	    this.execute = function(options) {
	        var deltaSets = options.args[0];
	        this.$doc  = options.args[1];
	        if (options.merge && this.hasUndo()){
	            this.dirtyCounter--;
	            deltaSets = this.$undoStack.pop().concat(deltaSets);
	        }
	        this.$undoStack.push(deltaSets);
	        this.$redoStack = [];
	        if (this.dirtyCounter < 0) {
	            this.dirtyCounter = NaN;
	        }
	        this.dirtyCounter++;
	    };
	    this.undo = function(dontSelect) {
	        var deltaSets = this.$undoStack.pop();
	        var undoSelectionRange = null;
	        if (deltaSets) {
	            undoSelectionRange = this.$doc.undoChanges(deltaSets, dontSelect);
	            this.$redoStack.push(deltaSets);
	            this.dirtyCounter--;
	        }

	        return undoSelectionRange;
	    };
	    this.redo = function(dontSelect) {
	        var deltaSets = this.$redoStack.pop();
	        var redoSelectionRange = null;
	        if (deltaSets) {
	            redoSelectionRange =
	                this.$doc.redoChanges(this.$deserializeDeltas(deltaSets), dontSelect);
	            this.$undoStack.push(deltaSets);
	            this.dirtyCounter++;
	        }
	        return redoSelectionRange;
	    };
	    this.reset = function() {
	        this.$undoStack = [];
	        this.$redoStack = [];
	        this.dirtyCounter = 0;
	    };
	    this.hasUndo = function() {
	        return this.$undoStack.length > 0;
	    };
	    this.hasRedo = function() {
	        return this.$redoStack.length > 0;
	    };
	    this.markClean = function() {
	        this.dirtyCounter = 0;
	    };
	    this.isClean = function() {
	        return this.dirtyCounter === 0;
	    };
	    this.$serializeDeltas = function(deltaSets) {
	        return cloneDeltaSetsObj(deltaSets, $serializeDelta);
	    };
	    this.$deserializeDeltas = function(deltaSets) {
	        return cloneDeltaSetsObj(deltaSets, $deserializeDelta);
	    };
	    
	    function $serializeDelta(delta){
	        return {
	            action: delta.action,
	            start: delta.start,
	            end: delta.end,
	            lines: delta.lines.length == 1 ? null : delta.lines,
	            text: delta.lines.length == 1 ? delta.lines[0] : null
	        };
	    }
	        
	    function $deserializeDelta(delta) {
	        return {
	            action: delta.action,
	            start: delta.start,
	            end: delta.end,
	            lines: delta.lines || [delta.text]
	        };
	    }
	    
	    function cloneDeltaSetsObj(deltaSets_old, fnGetModifiedDelta) {
	        var deltaSets_new = new Array(deltaSets_old.length);
	        for (var i = 0; i < deltaSets_old.length; i++) {
	            var deltaSet_old = deltaSets_old[i];
	            var deltaSet_new = { group: deltaSet_old.group, deltas: new Array(deltaSet_old.length)};
	            
	            for (var j = 0; j < deltaSet_old.deltas.length; j++) {
	                var delta_old = deltaSet_old.deltas[j];
	                deltaSet_new.deltas[j] = fnGetModifiedDelta(delta_old);
	            }
	            
	            deltaSets_new[i] = deltaSet_new;
	        }
	        return deltaSets_new;
	    }
	    
	}).call(UndoManager.prototype);

	exports.UndoManager = UndoManager;
	});

	ace.define("ace/layer/gutter",["require","exports","module","ace/lib/dom","ace/lib/oop","ace/lib/lang","ace/lib/event_emitter"], function(acequire, exports, module) {
	"use strict";

	var dom = acequire("../lib/dom");
	var oop = acequire("../lib/oop");
	var lang = acequire("../lib/lang");
	var EventEmitter = acequire("../lib/event_emitter").EventEmitter;

	var Gutter = function(parentEl) {
	    this.element = dom.createElement("div");
	    this.element.className = "ace_layer ace_gutter-layer";
	    parentEl.appendChild(this.element);
	    this.setShowFoldWidgets(this.$showFoldWidgets);
	    
	    this.gutterWidth = 0;

	    this.$annotations = [];
	    this.$updateAnnotations = this.$updateAnnotations.bind(this);

	    this.$cells = [];
	};

	(function() {

	    oop.implement(this, EventEmitter);

	    this.setSession = function(session) {
	        if (this.session)
	            this.session.removeEventListener("change", this.$updateAnnotations);
	        this.session = session;
	        if (session)
	            session.on("change", this.$updateAnnotations);
	    };

	    this.addGutterDecoration = function(row, className){
	        if (window.console)
	            console.warn && console.warn("deprecated use session.addGutterDecoration");
	        this.session.addGutterDecoration(row, className);
	    };

	    this.removeGutterDecoration = function(row, className){
	        if (window.console)
	            console.warn && console.warn("deprecated use session.removeGutterDecoration");
	        this.session.removeGutterDecoration(row, className);
	    };

	    this.setAnnotations = function(annotations) {
	        this.$annotations = [];
	        for (var i = 0; i < annotations.length; i++) {
	            var annotation = annotations[i];
	            var row = annotation.row;
	            var rowInfo = this.$annotations[row];
	            if (!rowInfo)
	                rowInfo = this.$annotations[row] = {text: []};
	           
	            var annoText = annotation.text;
	            annoText = annoText ? lang.escapeHTML(annoText) : annotation.html || "";

	            if (rowInfo.text.indexOf(annoText) === -1)
	                rowInfo.text.push(annoText);

	            var type = annotation.type;
	            if (type == "error")
	                rowInfo.className = " ace_error";
	            else if (type == "warning" && rowInfo.className != " ace_error")
	                rowInfo.className = " ace_warning";
	            else if (type == "info" && (!rowInfo.className))
	                rowInfo.className = " ace_info";
	        }
	    };

	    this.$updateAnnotations = function (delta) {
	        if (!this.$annotations.length)
	            return;
	        var firstRow = delta.start.row;
	        var len = delta.end.row - firstRow;
	        if (len === 0) {
	        } else if (delta.action == 'remove') {
	            this.$annotations.splice(firstRow, len + 1, null);
	        } else {
	            var args = new Array(len + 1);
	            args.unshift(firstRow, 1);
	            this.$annotations.splice.apply(this.$annotations, args);
	        }
	    };

	    this.update = function(config) {
	        var session = this.session;
	        var firstRow = config.firstRow;
	        var lastRow = Math.min(config.lastRow + config.gutterOffset,  // needed to compensate for hor scollbar
	            session.getLength() - 1);
	        var fold = session.getNextFoldLine(firstRow);
	        var foldStart = fold ? fold.start.row : Infinity;
	        var foldWidgets = this.$showFoldWidgets && session.foldWidgets;
	        var breakpoints = session.$breakpoints;
	        var decorations = session.$decorations;
	        var firstLineNumber = session.$firstLineNumber;
	        var lastLineNumber = 0;
	        
	        var gutterRenderer = session.gutterRenderer || this.$renderer;

	        var cell = null;
	        var index = -1;
	        var row = firstRow;
	        while (true) {
	            if (row > foldStart) {
	                row = fold.end.row + 1;
	                fold = session.getNextFoldLine(row, fold);
	                foldStart = fold ? fold.start.row : Infinity;
	            }
	            if (row > lastRow) {
	                while (this.$cells.length > index + 1) {
	                    cell = this.$cells.pop();
	                    this.element.removeChild(cell.element);
	                }
	                break;
	            }

	            cell = this.$cells[++index];
	            if (!cell) {
	                cell = {element: null, textNode: null, foldWidget: null};
	                cell.element = dom.createElement("div");
	                cell.textNode = document.createTextNode('');
	                cell.element.appendChild(cell.textNode);
	                this.element.appendChild(cell.element);
	                this.$cells[index] = cell;
	            }

	            var className = "ace_gutter-cell ";
	            if (breakpoints[row])
	                className += breakpoints[row];
	            if (decorations[row])
	                className += decorations[row];
	            if (this.$annotations[row])
	                className += this.$annotations[row].className;
	            if (cell.element.className != className)
	                cell.element.className = className;

	            var height = session.getRowLength(row) * config.lineHeight + "px";
	            if (height != cell.element.style.height)
	                cell.element.style.height = height;

	            if (foldWidgets) {
	                var c = foldWidgets[row];
	                if (c == null)
	                    c = foldWidgets[row] = session.getFoldWidget(row);
	            }

	            if (c) {
	                if (!cell.foldWidget) {
	                    cell.foldWidget = dom.createElement("span");
	                    cell.element.appendChild(cell.foldWidget);
	                }
	                var className = "ace_fold-widget ace_" + c;
	                if (c == "start" && row == foldStart && row < fold.end.row)
	                    className += " ace_closed";
	                else
	                    className += " ace_open";
	                if (cell.foldWidget.className != className)
	                    cell.foldWidget.className = className;

	                var height = config.lineHeight + "px";
	                if (cell.foldWidget.style.height != height)
	                    cell.foldWidget.style.height = height;
	            } else {
	                if (cell.foldWidget) {
	                    cell.element.removeChild(cell.foldWidget);
	                    cell.foldWidget = null;
	                }
	            }
	            
	            var text = lastLineNumber = gutterRenderer
	                ? gutterRenderer.getText(session, row)
	                : row + firstLineNumber;
	            if (text != cell.textNode.data)
	                cell.textNode.data = text;

	            row++;
	        }

	        this.element.style.height = config.minHeight + "px";

	        if (this.$fixedWidth || session.$useWrapMode)
	            lastLineNumber = session.getLength() + firstLineNumber;

	        var gutterWidth = gutterRenderer 
	            ? gutterRenderer.getWidth(session, lastLineNumber, config)
	            : lastLineNumber.toString().length * config.characterWidth;
	        
	        var padding = this.$padding || this.$computePadding();
	        gutterWidth += padding.left + padding.right;
	        if (gutterWidth !== this.gutterWidth && !isNaN(gutterWidth)) {
	            this.gutterWidth = gutterWidth;
	            this.element.style.width = Math.ceil(this.gutterWidth) + "px";
	            this._emit("changeGutterWidth", gutterWidth);
	        }
	    };

	    this.$fixedWidth = false;
	    
	    this.$showLineNumbers = true;
	    this.$renderer = "";
	    this.setShowLineNumbers = function(show) {
	        this.$renderer = !show && {
	            getWidth: function() {return ""},
	            getText: function() {return ""}
	        };
	    };
	    
	    this.getShowLineNumbers = function() {
	        return this.$showLineNumbers;
	    };
	    
	    this.$showFoldWidgets = true;
	    this.setShowFoldWidgets = function(show) {
	        if (show)
	            dom.addCssClass(this.element, "ace_folding-enabled");
	        else
	            dom.removeCssClass(this.element, "ace_folding-enabled");

	        this.$showFoldWidgets = show;
	        this.$padding = null;
	    };
	    
	    this.getShowFoldWidgets = function() {
	        return this.$showFoldWidgets;
	    };

	    this.$computePadding = function() {
	        if (!this.element.firstChild)
	            return {left: 0, right: 0};
	        var style = dom.computedStyle(this.element.firstChild);
	        this.$padding = {};
	        this.$padding.left = parseInt(style.paddingLeft) + 1 || 0;
	        this.$padding.right = parseInt(style.paddingRight) || 0;
	        return this.$padding;
	    };

	    this.getRegion = function(point) {
	        var padding = this.$padding || this.$computePadding();
	        var rect = this.element.getBoundingClientRect();
	        if (point.x < padding.left + rect.left)
	            return "markers";
	        if (this.$showFoldWidgets && point.x > rect.right - padding.right)
	            return "foldWidgets";
	    };

	}).call(Gutter.prototype);

	exports.Gutter = Gutter;

	});

	ace.define("ace/layer/marker",["require","exports","module","ace/range","ace/lib/dom"], function(acequire, exports, module) {
	"use strict";

	var Range = acequire("../range").Range;
	var dom = acequire("../lib/dom");

	var Marker = function(parentEl) {
	    this.element = dom.createElement("div");
	    this.element.className = "ace_layer ace_marker-layer";
	    parentEl.appendChild(this.element);
	};

	(function() {

	    this.$padding = 0;

	    this.setPadding = function(padding) {
	        this.$padding = padding;
	    };
	    this.setSession = function(session) {
	        this.session = session;
	    };
	    
	    this.setMarkers = function(markers) {
	        this.markers = markers;
	    };

	    this.update = function(config) {
	        var config = config || this.config;
	        if (!config)
	            return;

	        this.config = config;


	        var html = [];
	        for (var key in this.markers) {
	            var marker = this.markers[key];

	            if (!marker.range) {
	                marker.update(html, this, this.session, config);
	                continue;
	            }

	            var range = marker.range.clipRows(config.firstRow, config.lastRow);
	            if (range.isEmpty()) continue;

	            range = range.toScreenRange(this.session);
	            if (marker.renderer) {
	                var top = this.$getTop(range.start.row, config);
	                var left = this.$padding + range.start.column * config.characterWidth;
	                marker.renderer(html, range, left, top, config);
	            } else if (marker.type == "fullLine") {
	                this.drawFullLineMarker(html, range, marker.clazz, config);
	            } else if (marker.type == "screenLine") {
	                this.drawScreenLineMarker(html, range, marker.clazz, config);
	            } else if (range.isMultiLine()) {
	                if (marker.type == "text")
	                    this.drawTextMarker(html, range, marker.clazz, config);
	                else
	                    this.drawMultiLineMarker(html, range, marker.clazz, config);
	            } else {
	                this.drawSingleLineMarker(html, range, marker.clazz + " ace_start" + " ace_br15", config);
	            }
	        }
	        this.element.innerHTML = html.join("");
	    };

	    this.$getTop = function(row, layerConfig) {
	        return (row - layerConfig.firstRowScreen) * layerConfig.lineHeight;
	    };

	    function getBorderClass(tl, tr, br, bl) {
	        return (tl ? 1 : 0) | (tr ? 2 : 0) | (br ? 4 : 0) | (bl ? 8 : 0);
	    }
	    this.drawTextMarker = function(stringBuilder, range, clazz, layerConfig, extraStyle) {
	        var session = this.session;
	        var start = range.start.row;
	        var end = range.end.row;
	        var row = start;
	        var prev = 0; 
	        var curr = 0;
	        var next = session.getScreenLastRowColumn(row);
	        var lineRange = new Range(row, range.start.column, row, curr);
	        for (; row <= end; row++) {
	            lineRange.start.row = lineRange.end.row = row;
	            lineRange.start.column = row == start ? range.start.column : session.getRowWrapIndent(row);
	            lineRange.end.column = next;
	            prev = curr;
	            curr = next;
	            next = row + 1 < end ? session.getScreenLastRowColumn(row + 1) : row == end ? 0 : range.end.column;
	            this.drawSingleLineMarker(stringBuilder, lineRange, 
	                clazz + (row == start  ? " ace_start" : "") + " ace_br"
	                    + getBorderClass(row == start || row == start + 1 && range.start.column, prev < curr, curr > next, row == end),
	                layerConfig, row == end ? 0 : 1, extraStyle);
	        }
	    };
	    this.drawMultiLineMarker = function(stringBuilder, range, clazz, config, extraStyle) {
	        var padding = this.$padding;
	        var height = config.lineHeight;
	        var top = this.$getTop(range.start.row, config);
	        var left = padding + range.start.column * config.characterWidth;
	        extraStyle = extraStyle || "";

	        stringBuilder.push(
	            "<div class='", clazz, " ace_br1 ace_start' style='",
	            "height:", height, "px;",
	            "right:0;",
	            "top:", top, "px;",
	            "left:", left, "px;", extraStyle, "'></div>"
	        );
	        top = this.$getTop(range.end.row, config);
	        var width = range.end.column * config.characterWidth;

	        stringBuilder.push(
	            "<div class='", clazz, " ace_br12' style='",
	            "height:", height, "px;",
	            "width:", width, "px;",
	            "top:", top, "px;",
	            "left:", padding, "px;", extraStyle, "'></div>"
	        );
	        height = (range.end.row - range.start.row - 1) * config.lineHeight;
	        if (height <= 0)
	            return;
	        top = this.$getTop(range.start.row + 1, config);
	        
	        var radiusClass = (range.start.column ? 1 : 0) | (range.end.column ? 0 : 8);

	        stringBuilder.push(
	            "<div class='", clazz, (radiusClass ? " ace_br" + radiusClass : ""), "' style='",
	            "height:", height, "px;",
	            "right:0;",
	            "top:", top, "px;",
	            "left:", padding, "px;", extraStyle, "'></div>"
	        );
	    };
	    this.drawSingleLineMarker = function(stringBuilder, range, clazz, config, extraLength, extraStyle) {
	        var height = config.lineHeight;
	        var width = (range.end.column + (extraLength || 0) - range.start.column) * config.characterWidth;

	        var top = this.$getTop(range.start.row, config);
	        var left = this.$padding + range.start.column * config.characterWidth;

	        stringBuilder.push(
	            "<div class='", clazz, "' style='",
	            "height:", height, "px;",
	            "width:", width, "px;",
	            "top:", top, "px;",
	            "left:", left, "px;", extraStyle || "", "'></div>"
	        );
	    };

	    this.drawFullLineMarker = function(stringBuilder, range, clazz, config, extraStyle) {
	        var top = this.$getTop(range.start.row, config);
	        var height = config.lineHeight;
	        if (range.start.row != range.end.row)
	            height += this.$getTop(range.end.row, config) - top;

	        stringBuilder.push(
	            "<div class='", clazz, "' style='",
	            "height:", height, "px;",
	            "top:", top, "px;",
	            "left:0;right:0;", extraStyle || "", "'></div>"
	        );
	    };
	    
	    this.drawScreenLineMarker = function(stringBuilder, range, clazz, config, extraStyle) {
	        var top = this.$getTop(range.start.row, config);
	        var height = config.lineHeight;

	        stringBuilder.push(
	            "<div class='", clazz, "' style='",
	            "height:", height, "px;",
	            "top:", top, "px;",
	            "left:0;right:0;", extraStyle || "", "'></div>"
	        );
	    };

	}).call(Marker.prototype);

	exports.Marker = Marker;

	});

	ace.define("ace/layer/text",["require","exports","module","ace/lib/oop","ace/lib/dom","ace/lib/lang","ace/lib/useragent","ace/lib/event_emitter"], function(acequire, exports, module) {
	"use strict";

	var oop = acequire("../lib/oop");
	var dom = acequire("../lib/dom");
	var lang = acequire("../lib/lang");
	var useragent = acequire("../lib/useragent");
	var EventEmitter = acequire("../lib/event_emitter").EventEmitter;

	var Text = function(parentEl) {
	    this.element = dom.createElement("div");
	    this.element.className = "ace_layer ace_text-layer";
	    parentEl.appendChild(this.element);
	    this.$updateEolChar = this.$updateEolChar.bind(this);
	};

	(function() {

	    oop.implement(this, EventEmitter);

	    this.EOF_CHAR = "\xB6";
	    this.EOL_CHAR_LF = "\xAC";
	    this.EOL_CHAR_CRLF = "\xa4";
	    this.EOL_CHAR = this.EOL_CHAR_LF;
	    this.TAB_CHAR = "\u2014"; //"\u21E5";
	    this.SPACE_CHAR = "\xB7";
	    this.$padding = 0;

	    this.$updateEolChar = function() {
	        var EOL_CHAR = this.session.doc.getNewLineCharacter() == "\n"
	           ? this.EOL_CHAR_LF
	           : this.EOL_CHAR_CRLF;
	        if (this.EOL_CHAR != EOL_CHAR) {
	            this.EOL_CHAR = EOL_CHAR;
	            return true;
	        }
	    }

	    this.setPadding = function(padding) {
	        this.$padding = padding;
	        this.element.style.padding = "0 " + padding + "px";
	    };

	    this.getLineHeight = function() {
	        return this.$fontMetrics.$characterSize.height || 0;
	    };

	    this.getCharacterWidth = function() {
	        return this.$fontMetrics.$characterSize.width || 0;
	    };
	    
	    this.$setFontMetrics = function(measure) {
	        this.$fontMetrics = measure;
	        this.$fontMetrics.on("changeCharacterSize", function(e) {
	            this._signal("changeCharacterSize", e);
	        }.bind(this));
	        this.$pollSizeChanges();
	    }

	    this.checkForSizeChanges = function() {
	        this.$fontMetrics.checkForSizeChanges();
	    };
	    this.$pollSizeChanges = function() {
	        return this.$pollSizeChangesTimer = this.$fontMetrics.$pollSizeChanges();
	    };
	    this.setSession = function(session) {
	        this.session = session;
	        if (session)
	            this.$computeTabString();
	    };

	    this.showInvisibles = false;
	    this.setShowInvisibles = function(showInvisibles) {
	        if (this.showInvisibles == showInvisibles)
	            return false;

	        this.showInvisibles = showInvisibles;
	        this.$computeTabString();
	        return true;
	    };

	    this.displayIndentGuides = true;
	    this.setDisplayIndentGuides = function(display) {
	        if (this.displayIndentGuides == display)
	            return false;

	        this.displayIndentGuides = display;
	        this.$computeTabString();
	        return true;
	    };

	    this.$tabStrings = [];
	    this.onChangeTabSize =
	    this.$computeTabString = function() {
	        var tabSize = this.session.getTabSize();
	        this.tabSize = tabSize;
	        var tabStr = this.$tabStrings = [0];
	        for (var i = 1; i < tabSize + 1; i++) {
	            if (this.showInvisibles) {
	                tabStr.push("<span class='ace_invisible ace_invisible_tab'>"
	                    + lang.stringRepeat(this.TAB_CHAR, i)
	                    + "</span>");
	            } else {
	                tabStr.push(lang.stringRepeat(" ", i));
	            }
	        }
	        if (this.displayIndentGuides) {
	            this.$indentGuideRe =  /\s\S| \t|\t |\s$/;
	            var className = "ace_indent-guide";
	            var spaceClass = "";
	            var tabClass = "";
	            if (this.showInvisibles) {
	                className += " ace_invisible";
	                spaceClass = " ace_invisible_space";
	                tabClass = " ace_invisible_tab";
	                var spaceContent = lang.stringRepeat(this.SPACE_CHAR, this.tabSize);
	                var tabContent = lang.stringRepeat(this.TAB_CHAR, this.tabSize);
	            } else{
	                var spaceContent = lang.stringRepeat(" ", this.tabSize);
	                var tabContent = spaceContent;
	            }

	            this.$tabStrings[" "] = "<span class='" + className + spaceClass + "'>" + spaceContent + "</span>";
	            this.$tabStrings["\t"] = "<span class='" + className + tabClass + "'>" + tabContent + "</span>";
	        }
	    };

	    this.updateLines = function(config, firstRow, lastRow) {
	        if (this.config.lastRow != config.lastRow ||
	            this.config.firstRow != config.firstRow) {
	            this.scrollLines(config);
	        }
	        this.config = config;

	        var first = Math.max(firstRow, config.firstRow);
	        var last = Math.min(lastRow, config.lastRow);

	        var lineElements = this.element.childNodes;
	        var lineElementsIdx = 0;

	        for (var row = config.firstRow; row < first; row++) {
	            var foldLine = this.session.getFoldLine(row);
	            if (foldLine) {
	                if (foldLine.containsRow(first)) {
	                    first = foldLine.start.row;
	                    break;
	                } else {
	                    row = foldLine.end.row;
	                }
	            }
	            lineElementsIdx ++;
	        }

	        var row = first;
	        var foldLine = this.session.getNextFoldLine(row);
	        var foldStart = foldLine ? foldLine.start.row : Infinity;

	        while (true) {
	            if (row > foldStart) {
	                row = foldLine.end.row+1;
	                foldLine = this.session.getNextFoldLine(row, foldLine);
	                foldStart = foldLine ? foldLine.start.row :Infinity;
	            }
	            if (row > last)
	                break;

	            var lineElement = lineElements[lineElementsIdx++];
	            if (lineElement) {
	                var html = [];
	                this.$renderLine(
	                    html, row, !this.$useLineGroups(), row == foldStart ? foldLine : false
	                );
	                lineElement.style.height = config.lineHeight * this.session.getRowLength(row) + "px";
	                lineElement.innerHTML = html.join("");
	            }
	            row++;
	        }
	    };

	    this.scrollLines = function(config) {
	        var oldConfig = this.config;
	        this.config = config;

	        if (!oldConfig || oldConfig.lastRow < config.firstRow)
	            return this.update(config);

	        if (config.lastRow < oldConfig.firstRow)
	            return this.update(config);

	        var el = this.element;
	        if (oldConfig.firstRow < config.firstRow)
	            for (var row=this.session.getFoldedRowCount(oldConfig.firstRow, config.firstRow - 1); row>0; row--)
	                el.removeChild(el.firstChild);

	        if (oldConfig.lastRow > config.lastRow)
	            for (var row=this.session.getFoldedRowCount(config.lastRow + 1, oldConfig.lastRow); row>0; row--)
	                el.removeChild(el.lastChild);

	        if (config.firstRow < oldConfig.firstRow) {
	            var fragment = this.$renderLinesFragment(config, config.firstRow, oldConfig.firstRow - 1);
	            if (el.firstChild)
	                el.insertBefore(fragment, el.firstChild);
	            else
	                el.appendChild(fragment);
	        }

	        if (config.lastRow > oldConfig.lastRow) {
	            var fragment = this.$renderLinesFragment(config, oldConfig.lastRow + 1, config.lastRow);
	            el.appendChild(fragment);
	        }
	    };

	    this.$renderLinesFragment = function(config, firstRow, lastRow) {
	        var fragment = this.element.ownerDocument.createDocumentFragment();
	        var row = firstRow;
	        var foldLine = this.session.getNextFoldLine(row);
	        var foldStart = foldLine ? foldLine.start.row : Infinity;

	        while (true) {
	            if (row > foldStart) {
	                row = foldLine.end.row+1;
	                foldLine = this.session.getNextFoldLine(row, foldLine);
	                foldStart = foldLine ? foldLine.start.row : Infinity;
	            }
	            if (row > lastRow)
	                break;

	            var container = dom.createElement("div");

	            var html = [];
	            this.$renderLine(html, row, false, row == foldStart ? foldLine : false);
	            container.innerHTML = html.join("");
	            if (this.$useLineGroups()) {
	                container.className = 'ace_line_group';
	                fragment.appendChild(container);
	                container.style.height = config.lineHeight * this.session.getRowLength(row) + "px";

	            } else {
	                while(container.firstChild)
	                    fragment.appendChild(container.firstChild);
	            }

	            row++;
	        }
	        return fragment;
	    };

	    this.update = function(config) {
	        this.config = config;

	        var html = [];
	        var firstRow = config.firstRow, lastRow = config.lastRow;

	        var row = firstRow;
	        var foldLine = this.session.getNextFoldLine(row);
	        var foldStart = foldLine ? foldLine.start.row : Infinity;

	        while (true) {
	            if (row > foldStart) {
	                row = foldLine.end.row+1;
	                foldLine = this.session.getNextFoldLine(row, foldLine);
	                foldStart = foldLine ? foldLine.start.row :Infinity;
	            }
	            if (row > lastRow)
	                break;

	            if (this.$useLineGroups())
	                html.push("<div class='ace_line_group' style='height:", config.lineHeight*this.session.getRowLength(row), "px'>")

	            this.$renderLine(html, row, false, row == foldStart ? foldLine : false);

	            if (this.$useLineGroups())
	                html.push("</div>"); // end the line group

	            row++;
	        }
	        this.element.innerHTML = html.join("");
	    };

	    this.$textToken = {
	        "text": true,
	        "rparen": true,
	        "lparen": true
	    };

	    this.$renderToken = function(stringBuilder, screenColumn, token, value) {
	        var self = this;
	        var replaceReg = /\t|&|<|>|( +)|([\x00-\x1f\x80-\xa0\xad\u1680\u180E\u2000-\u200f\u2028\u2029\u202F\u205F\u3000\uFEFF\uFFF9-\uFFFC])|[\u1100-\u115F\u11A3-\u11A7\u11FA-\u11FF\u2329-\u232A\u2E80-\u2E99\u2E9B-\u2EF3\u2F00-\u2FD5\u2FF0-\u2FFB\u3000-\u303E\u3041-\u3096\u3099-\u30FF\u3105-\u312D\u3131-\u318E\u3190-\u31BA\u31C0-\u31E3\u31F0-\u321E\u3220-\u3247\u3250-\u32FE\u3300-\u4DBF\u4E00-\uA48C\uA490-\uA4C6\uA960-\uA97C\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFAFF\uFE10-\uFE19\uFE30-\uFE52\uFE54-\uFE66\uFE68-\uFE6B\uFF01-\uFF60\uFFE0-\uFFE6]/g;
	        var replaceFunc = function(c, a, b, tabIdx, idx4) {
	            if (a) {
	                return self.showInvisibles
	                    ? "<span class='ace_invisible ace_invisible_space'>" + lang.stringRepeat(self.SPACE_CHAR, c.length) + "</span>"
	                    : c;
	            } else if (c == "&") {
	                return "&#38;";
	            } else if (c == "<") {
	                return "&#60;";
	            } else if (c == ">") {
	                return "&#62;";
	            } else if (c == "\t") {
	                var tabSize = self.session.getScreenTabSize(screenColumn + tabIdx);
	                screenColumn += tabSize - 1;
	                return self.$tabStrings[tabSize];
	            } else if (c == "\u3000") {
	                var classToUse = self.showInvisibles ? "ace_cjk ace_invisible ace_invisible_space" : "ace_cjk";
	                var space = self.showInvisibles ? self.SPACE_CHAR : "";
	                screenColumn += 1;
	                return "<span class='" + classToUse + "' style='width:" +
	                    (self.config.characterWidth * 2) +
	                    "px'>" + space + "</span>";
	            } else if (b) {
	                return "<span class='ace_invisible ace_invisible_space ace_invalid'>" + self.SPACE_CHAR + "</span>";
	            } else {
	                screenColumn += 1;
	                return "<span class='ace_cjk' style='width:" +
	                    (self.config.characterWidth * 2) +
	                    "px'>" + c + "</span>";
	            }
	        };

	        var output = value.replace(replaceReg, replaceFunc);

	        if (!this.$textToken[token.type]) {
	            var classes = "ace_" + token.type.replace(/\./g, " ace_");
	            var style = "";
	            if (token.type == "fold")
	                style = " style='width:" + (token.value.length * this.config.characterWidth) + "px;' ";
	            stringBuilder.push("<span class='", classes, "'", style, ">", output, "</span>");
	        }
	        else {
	            stringBuilder.push(output);
	        }
	        return screenColumn + value.length;
	    };

	    this.renderIndentGuide = function(stringBuilder, value, max) {
	        var cols = value.search(this.$indentGuideRe);
	        if (cols <= 0 || cols >= max)
	            return value;
	        if (value[0] == " ") {
	            cols -= cols % this.tabSize;
	            stringBuilder.push(lang.stringRepeat(this.$tabStrings[" "], cols/this.tabSize));
	            return value.substr(cols);
	        } else if (value[0] == "\t") {
	            stringBuilder.push(lang.stringRepeat(this.$tabStrings["\t"], cols));
	            return value.substr(cols);
	        }
	        return value;
	    };

	    this.$renderWrappedLine = function(stringBuilder, tokens, splits, onlyContents) {
	        var chars = 0;
	        var split = 0;
	        var splitChars = splits[0];
	        var screenColumn = 0;

	        for (var i = 0; i < tokens.length; i++) {
	            var token = tokens[i];
	            var value = token.value;
	            if (i == 0 && this.displayIndentGuides) {
	                chars = value.length;
	                value = this.renderIndentGuide(stringBuilder, value, splitChars);
	                if (!value)
	                    continue;
	                chars -= value.length;
	            }

	            if (chars + value.length < splitChars) {
	                screenColumn = this.$renderToken(stringBuilder, screenColumn, token, value);
	                chars += value.length;
	            } else {
	                while (chars + value.length >= splitChars) {
	                    screenColumn = this.$renderToken(
	                        stringBuilder, screenColumn,
	                        token, value.substring(0, splitChars - chars)
	                    );
	                    value = value.substring(splitChars - chars);
	                    chars = splitChars;

	                    if (!onlyContents) {
	                        stringBuilder.push("</div>",
	                            "<div class='ace_line' style='height:",
	                            this.config.lineHeight, "px'>"
	                        );
	                    }

	                    stringBuilder.push(lang.stringRepeat("\xa0", splits.indent));

	                    split ++;
	                    screenColumn = 0;
	                    splitChars = splits[split] || Number.MAX_VALUE;
	                }
	                if (value.length != 0) {
	                    chars += value.length;
	                    screenColumn = this.$renderToken(
	                        stringBuilder, screenColumn, token, value
	                    );
	                }
	            }
	        }
	    };

	    this.$renderSimpleLine = function(stringBuilder, tokens) {
	        var screenColumn = 0;
	        var token = tokens[0];
	        var value = token.value;
	        if (this.displayIndentGuides)
	            value = this.renderIndentGuide(stringBuilder, value);
	        if (value)
	            screenColumn = this.$renderToken(stringBuilder, screenColumn, token, value);
	        for (var i = 1; i < tokens.length; i++) {
	            token = tokens[i];
	            value = token.value;
	            screenColumn = this.$renderToken(stringBuilder, screenColumn, token, value);
	        }
	    };
	    this.$renderLine = function(stringBuilder, row, onlyContents, foldLine) {
	        if (!foldLine && foldLine != false)
	            foldLine = this.session.getFoldLine(row);

	        if (foldLine)
	            var tokens = this.$getFoldLineTokens(row, foldLine);
	        else
	            var tokens = this.session.getTokens(row);


	        if (!onlyContents) {
	            stringBuilder.push(
	                "<div class='ace_line' style='height:", 
	                    this.config.lineHeight * (
	                        this.$useLineGroups() ? 1 :this.session.getRowLength(row)
	                    ), "px'>"
	            );
	        }

	        if (tokens.length) {
	            var splits = this.session.getRowSplitData(row);
	            if (splits && splits.length)
	                this.$renderWrappedLine(stringBuilder, tokens, splits, onlyContents);
	            else
	                this.$renderSimpleLine(stringBuilder, tokens);
	        }

	        if (this.showInvisibles) {
	            if (foldLine)
	                row = foldLine.end.row

	            stringBuilder.push(
	                "<span class='ace_invisible ace_invisible_eol'>",
	                row == this.session.getLength() - 1 ? this.EOF_CHAR : this.EOL_CHAR,
	                "</span>"
	            );
	        }
	        if (!onlyContents)
	            stringBuilder.push("</div>");
	    };

	    this.$getFoldLineTokens = function(row, foldLine) {
	        var session = this.session;
	        var renderTokens = [];

	        function addTokens(tokens, from, to) {
	            var idx = 0, col = 0;
	            while ((col + tokens[idx].value.length) < from) {
	                col += tokens[idx].value.length;
	                idx++;

	                if (idx == tokens.length)
	                    return;
	            }
	            if (col != from) {
	                var value = tokens[idx].value.substring(from - col);
	                if (value.length > (to - from))
	                    value = value.substring(0, to - from);

	                renderTokens.push({
	                    type: tokens[idx].type,
	                    value: value
	                });

	                col = from + value.length;
	                idx += 1;
	            }

	            while (col < to && idx < tokens.length) {
	                var value = tokens[idx].value;
	                if (value.length + col > to) {
	                    renderTokens.push({
	                        type: tokens[idx].type,
	                        value: value.substring(0, to - col)
	                    });
	                } else
	                    renderTokens.push(tokens[idx]);
	                col += value.length;
	                idx += 1;
	            }
	        }

	        var tokens = session.getTokens(row);
	        foldLine.walk(function(placeholder, row, column, lastColumn, isNewRow) {
	            if (placeholder != null) {
	                renderTokens.push({
	                    type: "fold",
	                    value: placeholder
	                });
	            } else {
	                if (isNewRow)
	                    tokens = session.getTokens(row);

	                if (tokens.length)
	                    addTokens(tokens, lastColumn, column);
	            }
	        }, foldLine.end.row, this.session.getLine(foldLine.end.row).length);

	        return renderTokens;
	    };

	    this.$useLineGroups = function() {
	        return this.session.getUseWrapMode();
	    };

	    this.destroy = function() {
	        clearInterval(this.$pollSizeChangesTimer);
	        if (this.$measureNode)
	            this.$measureNode.parentNode.removeChild(this.$measureNode);
	        delete this.$measureNode;
	    };

	}).call(Text.prototype);

	exports.Text = Text;

	});

	ace.define("ace/layer/cursor",["require","exports","module","ace/lib/dom"], function(acequire, exports, module) {
	"use strict";

	var dom = acequire("../lib/dom");
	var isIE8;

	var Cursor = function(parentEl) {
	    this.element = dom.createElement("div");
	    this.element.className = "ace_layer ace_cursor-layer";
	    parentEl.appendChild(this.element);
	    
	    if (isIE8 === undefined)
	        isIE8 = !("opacity" in this.element.style);

	    this.isVisible = false;
	    this.isBlinking = true;
	    this.blinkInterval = 1000;
	    this.smoothBlinking = false;

	    this.cursors = [];
	    this.cursor = this.addCursor();
	    dom.addCssClass(this.element, "ace_hidden-cursors");
	    this.$updateCursors = (isIE8
	        ? this.$updateVisibility
	        : this.$updateOpacity).bind(this);
	};

	(function() {
	    
	    this.$updateVisibility = function(val) {
	        var cursors = this.cursors;
	        for (var i = cursors.length; i--; )
	            cursors[i].style.visibility = val ? "" : "hidden";
	    };
	    this.$updateOpacity = function(val) {
	        var cursors = this.cursors;
	        for (var i = cursors.length; i--; )
	            cursors[i].style.opacity = val ? "" : "0";
	    };
	    

	    this.$padding = 0;
	    this.setPadding = function(padding) {
	        this.$padding = padding;
	    };

	    this.setSession = function(session) {
	        this.session = session;
	    };

	    this.setBlinking = function(blinking) {
	        if (blinking != this.isBlinking){
	            this.isBlinking = blinking;
	            this.restartTimer();
	        }
	    };

	    this.setBlinkInterval = function(blinkInterval) {
	        if (blinkInterval != this.blinkInterval){
	            this.blinkInterval = blinkInterval;
	            this.restartTimer();
	        }
	    };

	    this.setSmoothBlinking = function(smoothBlinking) {
	        if (smoothBlinking != this.smoothBlinking && !isIE8) {
	            this.smoothBlinking = smoothBlinking;
	            dom.setCssClass(this.element, "ace_smooth-blinking", smoothBlinking);
	            this.$updateCursors(true);
	            this.$updateCursors = (this.$updateOpacity).bind(this);
	            this.restartTimer();
	        }
	    };

	    this.addCursor = function() {
	        var el = dom.createElement("div");
	        el.className = "ace_cursor";
	        this.element.appendChild(el);
	        this.cursors.push(el);
	        return el;
	    };

	    this.removeCursor = function() {
	        if (this.cursors.length > 1) {
	            var el = this.cursors.pop();
	            el.parentNode.removeChild(el);
	            return el;
	        }
	    };

	    this.hideCursor = function() {
	        this.isVisible = false;
	        dom.addCssClass(this.element, "ace_hidden-cursors");
	        this.restartTimer();
	    };

	    this.showCursor = function() {
	        this.isVisible = true;
	        dom.removeCssClass(this.element, "ace_hidden-cursors");
	        this.restartTimer();
	    };

	    this.restartTimer = function() {
	        var update = this.$updateCursors;
	        clearInterval(this.intervalId);
	        clearTimeout(this.timeoutId);
	        if (this.smoothBlinking) {
	            dom.removeCssClass(this.element, "ace_smooth-blinking");
	        }
	        
	        update(true);

	        if (!this.isBlinking || !this.blinkInterval || !this.isVisible)
	            return;

	        if (this.smoothBlinking) {
	            setTimeout(function(){
	                dom.addCssClass(this.element, "ace_smooth-blinking");
	            }.bind(this));
	        }
	        
	        var blink = function(){
	            this.timeoutId = setTimeout(function() {
	                update(false);
	            }, 0.6 * this.blinkInterval);
	        }.bind(this);

	        this.intervalId = setInterval(function() {
	            update(true);
	            blink();
	        }, this.blinkInterval);

	        blink();
	    };

	    this.getPixelPosition = function(position, onScreen) {
	        if (!this.config || !this.session)
	            return {left : 0, top : 0};

	        if (!position)
	            position = this.session.selection.getCursor();
	        var pos = this.session.documentToScreenPosition(position);
	        var cursorLeft = this.$padding + pos.column * this.config.characterWidth;
	        var cursorTop = (pos.row - (onScreen ? this.config.firstRowScreen : 0)) *
	            this.config.lineHeight;

	        return {left : cursorLeft, top : cursorTop};
	    };

	    this.update = function(config) {
	        this.config = config;

	        var selections = this.session.$selectionMarkers;
	        var i = 0, cursorIndex = 0;

	        if (selections === undefined || selections.length === 0){
	            selections = [{cursor: null}];
	        }

	        for (var i = 0, n = selections.length; i < n; i++) {
	            var pixelPos = this.getPixelPosition(selections[i].cursor, true);
	            if ((pixelPos.top > config.height + config.offset ||
	                 pixelPos.top < 0) && i > 1) {
	                continue;
	            }

	            var style = (this.cursors[cursorIndex++] || this.addCursor()).style;
	            
	            if (!this.drawCursor) {
	                style.left = pixelPos.left + "px";
	                style.top = pixelPos.top + "px";
	                style.width = config.characterWidth + "px";
	                style.height = config.lineHeight + "px";
	            } else {
	                this.drawCursor(style, pixelPos, config, selections[i], this.session);
	            }
	        }
	        while (this.cursors.length > cursorIndex)
	            this.removeCursor();

	        var overwrite = this.session.getOverwrite();
	        this.$setOverwrite(overwrite);
	        this.$pixelPos = pixelPos;
	        this.restartTimer();
	    };
	    
	    this.drawCursor = null;

	    this.$setOverwrite = function(overwrite) {
	        if (overwrite != this.overwrite) {
	            this.overwrite = overwrite;
	            if (overwrite)
	                dom.addCssClass(this.element, "ace_overwrite-cursors");
	            else
	                dom.removeCssClass(this.element, "ace_overwrite-cursors");
	        }
	    };

	    this.destroy = function() {
	        clearInterval(this.intervalId);
	        clearTimeout(this.timeoutId);
	    };

	}).call(Cursor.prototype);

	exports.Cursor = Cursor;

	});

	ace.define("ace/scrollbar",["require","exports","module","ace/lib/oop","ace/lib/dom","ace/lib/event","ace/lib/event_emitter"], function(acequire, exports, module) {
	"use strict";

	var oop = acequire("./lib/oop");
	var dom = acequire("./lib/dom");
	var event = acequire("./lib/event");
	var EventEmitter = acequire("./lib/event_emitter").EventEmitter;
	var MAX_SCROLL_H = 0x8000;
	var ScrollBar = function(parent) {
	    this.element = dom.createElement("div");
	    this.element.className = "ace_scrollbar ace_scrollbar" + this.classSuffix;

	    this.inner = dom.createElement("div");
	    this.inner.className = "ace_scrollbar-inner";
	    this.element.appendChild(this.inner);

	    parent.appendChild(this.element);

	    this.setVisible(false);
	    this.skipEvent = false;

	    event.addListener(this.element, "scroll", this.onScroll.bind(this));
	    event.addListener(this.element, "mousedown", event.preventDefault);
	};

	(function() {
	    oop.implement(this, EventEmitter);

	    this.setVisible = function(isVisible) {
	        this.element.style.display = isVisible ? "" : "none";
	        this.isVisible = isVisible;
	        this.coeff = 1;
	    };
	}).call(ScrollBar.prototype);
	var VScrollBar = function(parent, renderer) {
	    ScrollBar.call(this, parent);
	    this.scrollTop = 0;
	    this.scrollHeight = 0;
	    renderer.$scrollbarWidth = 
	    this.width = dom.scrollbarWidth(parent.ownerDocument);
	    this.inner.style.width =
	    this.element.style.width = (this.width || 15) + 5 + "px";
	};

	oop.inherits(VScrollBar, ScrollBar);

	(function() {

	    this.classSuffix = '-v';
	    this.onScroll = function() {
	        if (!this.skipEvent) {
	            this.scrollTop = this.element.scrollTop;
	            if (this.coeff != 1) {
	                var h = this.element.clientHeight / this.scrollHeight;
	                this.scrollTop = this.scrollTop * (1 - h) / (this.coeff - h);
	            }
	            this._emit("scroll", {data: this.scrollTop});
	        }
	        this.skipEvent = false;
	    };
	    this.getWidth = function() {
	        return this.isVisible ? this.width : 0;
	    };
	    this.setHeight = function(height) {
	        this.element.style.height = height + "px";
	    };
	    this.setInnerHeight =
	    this.setScrollHeight = function(height) {
	        this.scrollHeight = height;
	        if (height > MAX_SCROLL_H) {
	            this.coeff = MAX_SCROLL_H / height;
	            height = MAX_SCROLL_H;
	        } else if (this.coeff != 1) {
	            this.coeff = 1
	        }
	        this.inner.style.height = height + "px";
	    };
	    this.setScrollTop = function(scrollTop) {
	        if (this.scrollTop != scrollTop) {
	            this.skipEvent = true;
	            this.scrollTop = scrollTop;
	            this.element.scrollTop = scrollTop * this.coeff;
	        }
	    };

	}).call(VScrollBar.prototype);
	var HScrollBar = function(parent, renderer) {
	    ScrollBar.call(this, parent);
	    this.scrollLeft = 0;
	    this.height = renderer.$scrollbarWidth;
	    this.inner.style.height =
	    this.element.style.height = (this.height || 15) + 5 + "px";
	};

	oop.inherits(HScrollBar, ScrollBar);

	(function() {

	    this.classSuffix = '-h';
	    this.onScroll = function() {
	        if (!this.skipEvent) {
	            this.scrollLeft = this.element.scrollLeft;
	            this._emit("scroll", {data: this.scrollLeft});
	        }
	        this.skipEvent = false;
	    };
	    this.getHeight = function() {
	        return this.isVisible ? this.height : 0;
	    };
	    this.setWidth = function(width) {
	        this.element.style.width = width + "px";
	    };
	    this.setInnerWidth = function(width) {
	        this.inner.style.width = width + "px";
	    };
	    this.setScrollWidth = function(width) {
	        this.inner.style.width = width + "px";
	    };
	    this.setScrollLeft = function(scrollLeft) {
	        if (this.scrollLeft != scrollLeft) {
	            this.skipEvent = true;
	            this.scrollLeft = this.element.scrollLeft = scrollLeft;
	        }
	    };

	}).call(HScrollBar.prototype);


	exports.ScrollBar = VScrollBar; // backward compatibility
	exports.ScrollBarV = VScrollBar; // backward compatibility
	exports.ScrollBarH = HScrollBar; // backward compatibility

	exports.VScrollBar = VScrollBar;
	exports.HScrollBar = HScrollBar;
	});

	ace.define("ace/renderloop",["require","exports","module","ace/lib/event"], function(acequire, exports, module) {
	"use strict";

	var event = acequire("./lib/event");


	var RenderLoop = function(onRender, win) {
	    this.onRender = onRender;
	    this.pending = false;
	    this.changes = 0;
	    this.window = win || window;
	};

	(function() {


	    this.schedule = function(change) {
	        this.changes = this.changes | change;
	        if (!this.pending && this.changes) {
	            this.pending = true;
	            var _self = this;
	            event.nextFrame(function() {
	                _self.pending = false;
	                var changes;
	                while (changes = _self.changes) {
	                    _self.changes = 0;
	                    _self.onRender(changes);
	                }
	            }, this.window);
	        }
	    };

	}).call(RenderLoop.prototype);

	exports.RenderLoop = RenderLoop;
	});

	ace.define("ace/layer/font_metrics",["require","exports","module","ace/lib/oop","ace/lib/dom","ace/lib/lang","ace/lib/useragent","ace/lib/event_emitter"], function(acequire, exports, module) {

	var oop = acequire("../lib/oop");
	var dom = acequire("../lib/dom");
	var lang = acequire("../lib/lang");
	var useragent = acequire("../lib/useragent");
	var EventEmitter = acequire("../lib/event_emitter").EventEmitter;

	var CHAR_COUNT = 0;

	var FontMetrics = exports.FontMetrics = function(parentEl) {
	    this.el = dom.createElement("div");
	    this.$setMeasureNodeStyles(this.el.style, true);
	    
	    this.$main = dom.createElement("div");
	    this.$setMeasureNodeStyles(this.$main.style);
	    
	    this.$measureNode = dom.createElement("div");
	    this.$setMeasureNodeStyles(this.$measureNode.style);
	    
	    
	    this.el.appendChild(this.$main);
	    this.el.appendChild(this.$measureNode);
	    parentEl.appendChild(this.el);
	    
	    if (!CHAR_COUNT)
	        this.$testFractionalRect();
	    this.$measureNode.innerHTML = lang.stringRepeat("X", CHAR_COUNT);
	    
	    this.$characterSize = {width: 0, height: 0};
	    this.checkForSizeChanges();
	};

	(function() {

	    oop.implement(this, EventEmitter);
	        
	    this.$characterSize = {width: 0, height: 0};
	    
	    this.$testFractionalRect = function() {
	        var el = dom.createElement("div");
	        this.$setMeasureNodeStyles(el.style);
	        el.style.width = "0.2px";
	        document.documentElement.appendChild(el);
	        var w = el.getBoundingClientRect().width;
	        if (w > 0 && w < 1)
	            CHAR_COUNT = 50;
	        else
	            CHAR_COUNT = 100;
	        el.parentNode.removeChild(el);
	    };
	    
	    this.$setMeasureNodeStyles = function(style, isRoot) {
	        style.width = style.height = "auto";
	        style.left = style.top = "0px";
	        style.visibility = "hidden";
	        style.position = "absolute";
	        style.whiteSpace = "pre";

	        if (useragent.isIE < 8) {
	            style["font-family"] = "inherit";
	        } else {
	            style.font = "inherit";
	        }
	        style.overflow = isRoot ? "hidden" : "visible";
	    };

	    this.checkForSizeChanges = function() {
	        var size = this.$measureSizes();
	        if (size && (this.$characterSize.width !== size.width || this.$characterSize.height !== size.height)) {
	            this.$measureNode.style.fontWeight = "bold";
	            var boldSize = this.$measureSizes();
	            this.$measureNode.style.fontWeight = "";
	            this.$characterSize = size;
	            this.charSizes = Object.create(null);
	            this.allowBoldFonts = boldSize && boldSize.width === size.width && boldSize.height === size.height;
	            this._emit("changeCharacterSize", {data: size});
	        }
	    };

	    this.$pollSizeChanges = function() {
	        if (this.$pollSizeChangesTimer)
	            return this.$pollSizeChangesTimer;
	        var self = this;
	        return this.$pollSizeChangesTimer = setInterval(function() {
	            self.checkForSizeChanges();
	        }, 500);
	    };
	    
	    this.setPolling = function(val) {
	        if (val) {
	            this.$pollSizeChanges();
	        } else if (this.$pollSizeChangesTimer) {
	            clearInterval(this.$pollSizeChangesTimer);
	            this.$pollSizeChangesTimer = 0;
	        }
	    };

	    this.$measureSizes = function() {
	        if (CHAR_COUNT === 50) {
	            var rect = null;
	            try { 
	               rect = this.$measureNode.getBoundingClientRect();
	            } catch(e) {
	               rect = {width: 0, height:0 };
	            }
	            var size = {
	                height: rect.height,
	                width: rect.width / CHAR_COUNT
	            };
	        } else {
	            var size = {
	                height: this.$measureNode.clientHeight,
	                width: this.$measureNode.clientWidth / CHAR_COUNT
	            };
	        }
	        if (size.width === 0 || size.height === 0)
	            return null;
	        return size;
	    };

	    this.$measureCharWidth = function(ch) {
	        this.$main.innerHTML = lang.stringRepeat(ch, CHAR_COUNT);
	        var rect = this.$main.getBoundingClientRect();
	        return rect.width / CHAR_COUNT;
	    };
	    
	    this.getCharacterWidth = function(ch) {
	        var w = this.charSizes[ch];
	        if (w === undefined) {
	            w = this.charSizes[ch] = this.$measureCharWidth(ch) / this.$characterSize.width;
	        }
	        return w;
	    };

	    this.destroy = function() {
	        clearInterval(this.$pollSizeChangesTimer);
	        if (this.el && this.el.parentNode)
	            this.el.parentNode.removeChild(this.el);
	    };

	}).call(FontMetrics.prototype);

	});

	ace.define("ace/virtual_renderer",["require","exports","module","ace/lib/oop","ace/lib/dom","ace/config","ace/lib/useragent","ace/layer/gutter","ace/layer/marker","ace/layer/text","ace/layer/cursor","ace/scrollbar","ace/scrollbar","ace/renderloop","ace/layer/font_metrics","ace/lib/event_emitter"], function(acequire, exports, module) {
	"use strict";

	var oop = acequire("./lib/oop");
	var dom = acequire("./lib/dom");
	var config = acequire("./config");
	var useragent = acequire("./lib/useragent");
	var GutterLayer = acequire("./layer/gutter").Gutter;
	var MarkerLayer = acequire("./layer/marker").Marker;
	var TextLayer = acequire("./layer/text").Text;
	var CursorLayer = acequire("./layer/cursor").Cursor;
	var HScrollBar = acequire("./scrollbar").HScrollBar;
	var VScrollBar = acequire("./scrollbar").VScrollBar;
	var RenderLoop = acequire("./renderloop").RenderLoop;
	var FontMetrics = acequire("./layer/font_metrics").FontMetrics;
	var EventEmitter = acequire("./lib/event_emitter").EventEmitter;
	var editorCss = ".ace_editor {\
	position: relative;\
	overflow: hidden;\
	font: 12px/normal 'Monaco', 'Menlo', 'Ubuntu Mono', 'Consolas', 'source-code-pro', monospace;\
	direction: ltr;\
	text-align: left;\
	}\
	.ace_scroller {\
	position: absolute;\
	overflow: hidden;\
	top: 0;\
	bottom: 0;\
	background-color: inherit;\
	-ms-user-select: none;\
	-moz-user-select: none;\
	-webkit-user-select: none;\
	user-select: none;\
	cursor: text;\
	}\
	.ace_content {\
	position: absolute;\
	-moz-box-sizing: border-box;\
	-webkit-box-sizing: border-box;\
	box-sizing: border-box;\
	min-width: 100%;\
	}\
	.ace_dragging .ace_scroller:before{\
	position: absolute;\
	top: 0;\
	left: 0;\
	right: 0;\
	bottom: 0;\
	content: '';\
	background: rgba(250, 250, 250, 0.01);\
	z-index: 1000;\
	}\
	.ace_dragging.ace_dark .ace_scroller:before{\
	background: rgba(0, 0, 0, 0.01);\
	}\
	.ace_selecting, .ace_selecting * {\
	cursor: text !important;\
	}\
	.ace_gutter {\
	position: absolute;\
	overflow : hidden;\
	width: auto;\
	top: 0;\
	bottom: 0;\
	left: 0;\
	cursor: default;\
	z-index: 4;\
	-ms-user-select: none;\
	-moz-user-select: none;\
	-webkit-user-select: none;\
	user-select: none;\
	}\
	.ace_gutter-active-line {\
	position: absolute;\
	left: 0;\
	right: 0;\
	}\
	.ace_scroller.ace_scroll-left {\
	box-shadow: 17px 0 16px -16px rgba(0, 0, 0, 0.4) inset;\
	}\
	.ace_gutter-cell {\
	padding-left: 19px;\
	padding-right: 6px;\
	background-repeat: no-repeat;\
	}\
	.ace_gutter-cell.ace_error {\
	background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAABOFBMVEX/////////QRswFAb/Ui4wFAYwFAYwFAaWGAfDRymzOSH/PxswFAb/SiUwFAYwFAbUPRvjQiDllog5HhHdRybsTi3/Tyv9Tir+Syj/UC3////XurebMBIwFAb/RSHbPx/gUzfdwL3kzMivKBAwFAbbvbnhPx66NhowFAYwFAaZJg8wFAaxKBDZurf/RB6mMxb/SCMwFAYwFAbxQB3+RB4wFAb/Qhy4Oh+4QifbNRcwFAYwFAYwFAb/QRzdNhgwFAYwFAbav7v/Uy7oaE68MBK5LxLewr/r2NXewLswFAaxJw4wFAbkPRy2PyYwFAaxKhLm1tMwFAazPiQwFAaUGAb/QBrfOx3bvrv/VC/maE4wFAbRPBq6MRO8Qynew8Dp2tjfwb0wFAbx6eju5+by6uns4uH9/f36+vr/GkHjAAAAYnRSTlMAGt+64rnWu/bo8eAA4InH3+DwoN7j4eLi4xP99Nfg4+b+/u9B/eDs1MD1mO7+4PHg2MXa347g7vDizMLN4eG+Pv7i5evs/v79yu7S3/DV7/498Yv24eH+4ufQ3Ozu/v7+y13sRqwAAADLSURBVHjaZc/XDsFgGIBhtDrshlitmk2IrbHFqL2pvXf/+78DPokj7+Fz9qpU/9UXJIlhmPaTaQ6QPaz0mm+5gwkgovcV6GZzd5JtCQwgsxoHOvJO15kleRLAnMgHFIESUEPmawB9ngmelTtipwwfASilxOLyiV5UVUyVAfbG0cCPHig+GBkzAENHS0AstVF6bacZIOzgLmxsHbt2OecNgJC83JERmePUYq8ARGkJx6XtFsdddBQgZE2nPR6CICZhawjA4Fb/chv+399kfR+MMMDGOQAAAABJRU5ErkJggg==\");\
	background-repeat: no-repeat;\
	background-position: 2px center;\
	}\
	.ace_gutter-cell.ace_warning {\
	background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAmVBMVEX///8AAAD///8AAAAAAABPSzb/5sAAAAB/blH/73z/ulkAAAAAAAD85pkAAAAAAAACAgP/vGz/rkDerGbGrV7/pkQICAf////e0IsAAAD/oED/qTvhrnUAAAD/yHD/njcAAADuv2r/nz//oTj/p064oGf/zHAAAAA9Nir/tFIAAAD/tlTiuWf/tkIAAACynXEAAAAAAAAtIRW7zBpBAAAAM3RSTlMAABR1m7RXO8Ln31Z36zT+neXe5OzooRDfn+TZ4p3h2hTf4t3k3ucyrN1K5+Xaks52Sfs9CXgrAAAAjklEQVR42o3PbQ+CIBQFYEwboPhSYgoYunIqqLn6/z8uYdH8Vmdnu9vz4WwXgN/xTPRD2+sgOcZjsge/whXZgUaYYvT8QnuJaUrjrHUQreGczuEafQCO/SJTufTbroWsPgsllVhq3wJEk2jUSzX3CUEDJC84707djRc5MTAQxoLgupWRwW6UB5fS++NV8AbOZgnsC7BpEAAAAABJRU5ErkJggg==\");\
	background-position: 2px center;\
	}\
	.ace_gutter-cell.ace_info {\
	background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAAAAAA6mKC9AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAAJ0Uk5TAAB2k804AAAAPklEQVQY02NgIB68QuO3tiLznjAwpKTgNyDbMegwisCHZUETUZV0ZqOquBpXj2rtnpSJT1AEnnRmL2OgGgAAIKkRQap2htgAAAAASUVORK5CYII=\");\
	background-position: 2px center;\
	}\
	.ace_dark .ace_gutter-cell.ace_info {\
	background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQBAMAAADt3eJSAAAAJFBMVEUAAAChoaGAgIAqKiq+vr6tra1ZWVmUlJSbm5s8PDxubm56enrdgzg3AAAAAXRSTlMAQObYZgAAAClJREFUeNpjYMAPdsMYHegyJZFQBlsUlMFVCWUYKkAZMxZAGdxlDMQBAG+TBP4B6RyJAAAAAElFTkSuQmCC\");\
	}\
	.ace_scrollbar {\
	position: absolute;\
	right: 0;\
	bottom: 0;\
	z-index: 6;\
	}\
	.ace_scrollbar-inner {\
	position: absolute;\
	cursor: text;\
	left: 0;\
	top: 0;\
	}\
	.ace_scrollbar-v{\
	overflow-x: hidden;\
	overflow-y: scroll;\
	top: 0;\
	}\
	.ace_scrollbar-h {\
	overflow-x: scroll;\
	overflow-y: hidden;\
	left: 0;\
	}\
	.ace_print-margin {\
	position: absolute;\
	height: 100%;\
	}\
	.ace_text-input {\
	position: absolute;\
	z-index: 0;\
	width: 0.5em;\
	height: 1em;\
	opacity: 0;\
	background: transparent;\
	-moz-appearance: none;\
	appearance: none;\
	border: none;\
	resize: none;\
	outline: none;\
	overflow: hidden;\
	font: inherit;\
	padding: 0 1px;\
	margin: 0 -1px;\
	text-indent: -1em;\
	-ms-user-select: text;\
	-moz-user-select: text;\
	-webkit-user-select: text;\
	user-select: text;\
	white-space: pre!important;\
	}\
	.ace_text-input.ace_composition {\
	background: inherit;\
	color: inherit;\
	z-index: 1000;\
	opacity: 1;\
	text-indent: 0;\
	}\
	.ace_layer {\
	z-index: 1;\
	position: absolute;\
	overflow: hidden;\
	word-wrap: normal;\
	white-space: pre;\
	height: 100%;\
	width: 100%;\
	-moz-box-sizing: border-box;\
	-webkit-box-sizing: border-box;\
	box-sizing: border-box;\
	pointer-events: none;\
	}\
	.ace_gutter-layer {\
	position: relative;\
	width: auto;\
	text-align: right;\
	pointer-events: auto;\
	}\
	.ace_text-layer {\
	font: inherit !important;\
	}\
	.ace_cjk {\
	display: inline-block;\
	text-align: center;\
	}\
	.ace_cursor-layer {\
	z-index: 4;\
	}\
	.ace_cursor {\
	z-index: 4;\
	position: absolute;\
	-moz-box-sizing: border-box;\
	-webkit-box-sizing: border-box;\
	box-sizing: border-box;\
	border-left: 2px solid;\
	transform: translatez(0);\
	}\
	.ace_slim-cursors .ace_cursor {\
	border-left-width: 1px;\
	}\
	.ace_overwrite-cursors .ace_cursor {\
	border-left-width: 0;\
	border-bottom: 1px solid;\
	}\
	.ace_hidden-cursors .ace_cursor {\
	opacity: 0.2;\
	}\
	.ace_smooth-blinking .ace_cursor {\
	-webkit-transition: opacity 0.18s;\
	transition: opacity 0.18s;\
	}\
	.ace_editor.ace_multiselect .ace_cursor {\
	border-left-width: 1px;\
	}\
	.ace_marker-layer .ace_step, .ace_marker-layer .ace_stack {\
	position: absolute;\
	z-index: 3;\
	}\
	.ace_marker-layer .ace_selection {\
	position: absolute;\
	z-index: 5;\
	}\
	.ace_marker-layer .ace_bracket {\
	position: absolute;\
	z-index: 6;\
	}\
	.ace_marker-layer .ace_active-line {\
	position: absolute;\
	z-index: 2;\
	}\
	.ace_marker-layer .ace_selected-word {\
	position: absolute;\
	z-index: 4;\
	-moz-box-sizing: border-box;\
	-webkit-box-sizing: border-box;\
	box-sizing: border-box;\
	}\
	.ace_line .ace_fold {\
	-moz-box-sizing: border-box;\
	-webkit-box-sizing: border-box;\
	box-sizing: border-box;\
	display: inline-block;\
	height: 11px;\
	margin-top: -2px;\
	vertical-align: middle;\
	background-image:\
	url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABEAAAAJCAYAAADU6McMAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAJpJREFUeNpi/P//PwOlgAXGYGRklAVSokD8GmjwY1wasKljQpYACtpCFeADcHVQfQyMQAwzwAZI3wJKvCLkfKBaMSClBlR7BOQikCFGQEErIH0VqkabiGCAqwUadAzZJRxQr/0gwiXIal8zQQPnNVTgJ1TdawL0T5gBIP1MUJNhBv2HKoQHHjqNrA4WO4zY0glyNKLT2KIfIMAAQsdgGiXvgnYAAAAASUVORK5CYII=\"),\
	url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAA3CAYAAADNNiA5AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAACJJREFUeNpi+P//fxgTAwPDBxDxD078RSX+YeEyDFMCIMAAI3INmXiwf2YAAAAASUVORK5CYII=\");\
	background-repeat: no-repeat, repeat-x;\
	background-position: center center, top left;\
	color: transparent;\
	border: 1px solid black;\
	border-radius: 2px;\
	cursor: pointer;\
	pointer-events: auto;\
	}\
	.ace_dark .ace_fold {\
	}\
	.ace_fold:hover{\
	background-image:\
	url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABEAAAAJCAYAAADU6McMAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAJpJREFUeNpi/P//PwOlgAXGYGRklAVSokD8GmjwY1wasKljQpYACtpCFeADcHVQfQyMQAwzwAZI3wJKvCLkfKBaMSClBlR7BOQikCFGQEErIH0VqkabiGCAqwUadAzZJRxQr/0gwiXIal8zQQPnNVTgJ1TdawL0T5gBIP1MUJNhBv2HKoQHHjqNrA4WO4zY0glyNKLT2KIfIMAAQsdgGiXvgnYAAAAASUVORK5CYII=\"),\
	url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAA3CAYAAADNNiA5AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAACBJREFUeNpi+P//fz4TAwPDZxDxD5X4i5fLMEwJgAADAEPVDbjNw87ZAAAAAElFTkSuQmCC\");\
	}\
	.ace_tooltip {\
	background-color: #FFF;\
	background-image: -webkit-linear-gradient(top, transparent, rgba(0, 0, 0, 0.1));\
	background-image: linear-gradient(to bottom, transparent, rgba(0, 0, 0, 0.1));\
	border: 1px solid gray;\
	border-radius: 1px;\
	box-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);\
	color: black;\
	max-width: 100%;\
	padding: 3px 4px;\
	position: fixed;\
	z-index: 999999;\
	-moz-box-sizing: border-box;\
	-webkit-box-sizing: border-box;\
	box-sizing: border-box;\
	cursor: default;\
	white-space: pre;\
	word-wrap: break-word;\
	line-height: normal;\
	font-style: normal;\
	font-weight: normal;\
	letter-spacing: normal;\
	pointer-events: none;\
	}\
	.ace_folding-enabled > .ace_gutter-cell {\
	padding-right: 13px;\
	}\
	.ace_fold-widget {\
	-moz-box-sizing: border-box;\
	-webkit-box-sizing: border-box;\
	box-sizing: border-box;\
	margin: 0 -12px 0 1px;\
	display: none;\
	width: 11px;\
	vertical-align: top;\
	background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAANElEQVR42mWKsQ0AMAzC8ixLlrzQjzmBiEjp0A6WwBCSPgKAXoLkqSot7nN3yMwR7pZ32NzpKkVoDBUxKAAAAABJRU5ErkJggg==\");\
	background-repeat: no-repeat;\
	background-position: center;\
	border-radius: 3px;\
	border: 1px solid transparent;\
	cursor: pointer;\
	}\
	.ace_folding-enabled .ace_fold-widget {\
	display: inline-block;   \
	}\
	.ace_fold-widget.ace_end {\
	background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAANElEQVR42m3HwQkAMAhD0YzsRchFKI7sAikeWkrxwScEB0nh5e7KTPWimZki4tYfVbX+MNl4pyZXejUO1QAAAABJRU5ErkJggg==\");\
	}\
	.ace_fold-widget.ace_closed {\
	background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAAGCAYAAAAG5SQMAAAAOUlEQVR42jXKwQkAMAgDwKwqKD4EwQ26sSOkVWjgIIHAzPiCgaqiqnJHZnKICBERHN194O5b9vbLuAVRL+l0YWnZAAAAAElFTkSuQmCCXA==\");\
	}\
	.ace_fold-widget:hover {\
	border: 1px solid rgba(0, 0, 0, 0.3);\
	background-color: rgba(255, 255, 255, 0.2);\
	box-shadow: 0 1px 1px rgba(255, 255, 255, 0.7);\
	}\
	.ace_fold-widget:active {\
	border: 1px solid rgba(0, 0, 0, 0.4);\
	background-color: rgba(0, 0, 0, 0.05);\
	box-shadow: 0 1px 1px rgba(255, 255, 255, 0.8);\
	}\
	.ace_dark .ace_fold-widget {\
	background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHklEQVQIW2P4//8/AzoGEQ7oGCaLLAhWiSwB146BAQCSTPYocqT0AAAAAElFTkSuQmCC\");\
	}\
	.ace_dark .ace_fold-widget.ace_end {\
	background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAH0lEQVQIW2P4//8/AxQ7wNjIAjDMgC4AxjCVKBirIAAF0kz2rlhxpAAAAABJRU5ErkJggg==\");\
	}\
	.ace_dark .ace_fold-widget.ace_closed {\
	background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAAFCAYAAACAcVaiAAAAHElEQVQIW2P4//+/AxAzgDADlOOAznHAKgPWAwARji8UIDTfQQAAAABJRU5ErkJggg==\");\
	}\
	.ace_dark .ace_fold-widget:hover {\
	box-shadow: 0 1px 1px rgba(255, 255, 255, 0.2);\
	background-color: rgba(255, 255, 255, 0.1);\
	}\
	.ace_dark .ace_fold-widget:active {\
	box-shadow: 0 1px 1px rgba(255, 255, 255, 0.2);\
	}\
	.ace_fold-widget.ace_invalid {\
	background-color: #FFB4B4;\
	border-color: #DE5555;\
	}\
	.ace_fade-fold-widgets .ace_fold-widget {\
	-webkit-transition: opacity 0.4s ease 0.05s;\
	transition: opacity 0.4s ease 0.05s;\
	opacity: 0;\
	}\
	.ace_fade-fold-widgets:hover .ace_fold-widget {\
	-webkit-transition: opacity 0.05s ease 0.05s;\
	transition: opacity 0.05s ease 0.05s;\
	opacity:1;\
	}\
	.ace_underline {\
	text-decoration: underline;\
	}\
	.ace_bold {\
	font-weight: bold;\
	}\
	.ace_nobold .ace_bold {\
	font-weight: normal;\
	}\
	.ace_italic {\
	font-style: italic;\
	}\
	.ace_error-marker {\
	background-color: rgba(255, 0, 0,0.2);\
	position: absolute;\
	z-index: 9;\
	}\
	.ace_highlight-marker {\
	background-color: rgba(255, 255, 0,0.2);\
	position: absolute;\
	z-index: 8;\
	}\
	.ace_br1 {border-top-left-radius    : 3px;}\
	.ace_br2 {border-top-right-radius   : 3px;}\
	.ace_br3 {border-top-left-radius    : 3px; border-top-right-radius:    3px;}\
	.ace_br4 {border-bottom-right-radius: 3px;}\
	.ace_br5 {border-top-left-radius    : 3px; border-bottom-right-radius: 3px;}\
	.ace_br6 {border-top-right-radius   : 3px; border-bottom-right-radius: 3px;}\
	.ace_br7 {border-top-left-radius    : 3px; border-top-right-radius:    3px; border-bottom-right-radius: 3px;}\
	.ace_br8 {border-bottom-left-radius : 3px;}\
	.ace_br9 {border-top-left-radius    : 3px; border-bottom-left-radius:  3px;}\
	.ace_br10{border-top-right-radius   : 3px; border-bottom-left-radius:  3px;}\
	.ace_br11{border-top-left-radius    : 3px; border-top-right-radius:    3px; border-bottom-left-radius:  3px;}\
	.ace_br12{border-bottom-right-radius: 3px; border-bottom-left-radius:  3px;}\
	.ace_br13{border-top-left-radius    : 3px; border-bottom-right-radius: 3px; border-bottom-left-radius:  3px;}\
	.ace_br14{border-top-right-radius   : 3px; border-bottom-right-radius: 3px; border-bottom-left-radius:  3px;}\
	.ace_br15{border-top-left-radius    : 3px; border-top-right-radius:    3px; border-bottom-right-radius: 3px; border-bottom-left-radius: 3px;}\
	";

	dom.importCssString(editorCss, "ace_editor.css");

	var VirtualRenderer = function(container, theme) {
	    var _self = this;

	    this.container = container || dom.createElement("div");
	    this.$keepTextAreaAtCursor = !useragent.isOldIE;

	    dom.addCssClass(this.container, "ace_editor");

	    this.setTheme(theme);

	    this.$gutter = dom.createElement("div");
	    this.$gutter.className = "ace_gutter";
	    this.container.appendChild(this.$gutter);

	    this.scroller = dom.createElement("div");
	    this.scroller.className = "ace_scroller";
	    this.container.appendChild(this.scroller);

	    this.content = dom.createElement("div");
	    this.content.className = "ace_content";
	    this.scroller.appendChild(this.content);

	    this.$gutterLayer = new GutterLayer(this.$gutter);
	    this.$gutterLayer.on("changeGutterWidth", this.onGutterResize.bind(this));

	    this.$markerBack = new MarkerLayer(this.content);

	    var textLayer = this.$textLayer = new TextLayer(this.content);
	    this.canvas = textLayer.element;

	    this.$markerFront = new MarkerLayer(this.content);

	    this.$cursorLayer = new CursorLayer(this.content);
	    this.$horizScroll = false;
	    this.$vScroll = false;

	    this.scrollBar = 
	    this.scrollBarV = new VScrollBar(this.container, this);
	    this.scrollBarH = new HScrollBar(this.container, this);
	    this.scrollBarV.addEventListener("scroll", function(e) {
	        if (!_self.$scrollAnimation)
	            _self.session.setScrollTop(e.data - _self.scrollMargin.top);
	    });
	    this.scrollBarH.addEventListener("scroll", function(e) {
	        if (!_self.$scrollAnimation)
	            _self.session.setScrollLeft(e.data - _self.scrollMargin.left);
	    });

	    this.scrollTop = 0;
	    this.scrollLeft = 0;

	    this.cursorPos = {
	        row : 0,
	        column : 0
	    };

	    this.$fontMetrics = new FontMetrics(this.container);
	    this.$textLayer.$setFontMetrics(this.$fontMetrics);
	    this.$textLayer.addEventListener("changeCharacterSize", function(e) {
	        _self.updateCharacterSize();
	        _self.onResize(true, _self.gutterWidth, _self.$size.width, _self.$size.height);
	        _self._signal("changeCharacterSize", e);
	    });

	    this.$size = {
	        width: 0,
	        height: 0,
	        scrollerHeight: 0,
	        scrollerWidth: 0,
	        $dirty: true
	    };

	    this.layerConfig = {
	        width : 1,
	        padding : 0,
	        firstRow : 0,
	        firstRowScreen: 0,
	        lastRow : 0,
	        lineHeight : 0,
	        characterWidth : 0,
	        minHeight : 1,
	        maxHeight : 1,
	        offset : 0,
	        height : 1,
	        gutterOffset: 1
	    };
	    
	    this.scrollMargin = {
	        left: 0,
	        right: 0,
	        top: 0,
	        bottom: 0,
	        v: 0,
	        h: 0
	    };

	    this.$loop = new RenderLoop(
	        this.$renderChanges.bind(this),
	        this.container.ownerDocument.defaultView
	    );
	    this.$loop.schedule(this.CHANGE_FULL);

	    this.updateCharacterSize();
	    this.setPadding(4);
	    config.resetOptions(this);
	    config._emit("renderer", this);
	};

	(function() {

	    this.CHANGE_CURSOR = 1;
	    this.CHANGE_MARKER = 2;
	    this.CHANGE_GUTTER = 4;
	    this.CHANGE_SCROLL = 8;
	    this.CHANGE_LINES = 16;
	    this.CHANGE_TEXT = 32;
	    this.CHANGE_SIZE = 64;
	    this.CHANGE_MARKER_BACK = 128;
	    this.CHANGE_MARKER_FRONT = 256;
	    this.CHANGE_FULL = 512;
	    this.CHANGE_H_SCROLL = 1024;

	    oop.implement(this, EventEmitter);

	    this.updateCharacterSize = function() {
	        if (this.$textLayer.allowBoldFonts != this.$allowBoldFonts) {
	            this.$allowBoldFonts = this.$textLayer.allowBoldFonts;
	            this.setStyle("ace_nobold", !this.$allowBoldFonts);
	        }

	        this.layerConfig.characterWidth =
	        this.characterWidth = this.$textLayer.getCharacterWidth();
	        this.layerConfig.lineHeight =
	        this.lineHeight = this.$textLayer.getLineHeight();
	        this.$updatePrintMargin();
	    };
	    this.setSession = function(session) {
	        if (this.session)
	            this.session.doc.off("changeNewLineMode", this.onChangeNewLineMode);
	            
	        this.session = session;
	        if (session && this.scrollMargin.top && session.getScrollTop() <= 0)
	            session.setScrollTop(-this.scrollMargin.top);

	        this.$cursorLayer.setSession(session);
	        this.$markerBack.setSession(session);
	        this.$markerFront.setSession(session);
	        this.$gutterLayer.setSession(session);
	        this.$textLayer.setSession(session);
	        if (!session)
	            return;
	        
	        this.$loop.schedule(this.CHANGE_FULL);
	        this.session.$setFontMetrics(this.$fontMetrics);
	        this.scrollBarV.scrollLeft = this.scrollBarV.scrollTop = null;
	        
	        this.onChangeNewLineMode = this.onChangeNewLineMode.bind(this);
	        this.onChangeNewLineMode()
	        this.session.doc.on("changeNewLineMode", this.onChangeNewLineMode);
	    };
	    this.updateLines = function(firstRow, lastRow, force) {
	        if (lastRow === undefined)
	            lastRow = Infinity;

	        if (!this.$changedLines) {
	            this.$changedLines = {
	                firstRow: firstRow,
	                lastRow: lastRow
	            };
	        }
	        else {
	            if (this.$changedLines.firstRow > firstRow)
	                this.$changedLines.firstRow = firstRow;

	            if (this.$changedLines.lastRow < lastRow)
	                this.$changedLines.lastRow = lastRow;
	        }
	        if (this.$changedLines.lastRow < this.layerConfig.firstRow) {
	            if (force)
	                this.$changedLines.lastRow = this.layerConfig.lastRow;
	            else
	                return;
	        }
	        if (this.$changedLines.firstRow > this.layerConfig.lastRow)
	            return;
	        this.$loop.schedule(this.CHANGE_LINES);
	    };

	    this.onChangeNewLineMode = function() {
	        this.$loop.schedule(this.CHANGE_TEXT);
	        this.$textLayer.$updateEolChar();
	    };
	    
	    this.onChangeTabSize = function() {
	        this.$loop.schedule(this.CHANGE_TEXT | this.CHANGE_MARKER);
	        this.$textLayer.onChangeTabSize();
	    };
	    this.updateText = function() {
	        this.$loop.schedule(this.CHANGE_TEXT);
	    };
	    this.updateFull = function(force) {
	        if (force)
	            this.$renderChanges(this.CHANGE_FULL, true);
	        else
	            this.$loop.schedule(this.CHANGE_FULL);
	    };
	    this.updateFontSize = function() {
	        this.$textLayer.checkForSizeChanges();
	    };

	    this.$changes = 0;
	    this.$updateSizeAsync = function() {
	        if (this.$loop.pending)
	            this.$size.$dirty = true;
	        else
	            this.onResize();
	    };
	    this.onResize = function(force, gutterWidth, width, height) {
	        if (this.resizing > 2)
	            return;
	        else if (this.resizing > 0)
	            this.resizing++;
	        else
	            this.resizing = force ? 1 : 0;
	        var el = this.container;
	        if (!height)
	            height = el.clientHeight || el.scrollHeight;
	        if (!width)
	            width = el.clientWidth || el.scrollWidth;
	        var changes = this.$updateCachedSize(force, gutterWidth, width, height);

	        
	        if (!this.$size.scrollerHeight || (!width && !height))
	            return this.resizing = 0;

	        if (force)
	            this.$gutterLayer.$padding = null;

	        if (force)
	            this.$renderChanges(changes | this.$changes, true);
	        else
	            this.$loop.schedule(changes | this.$changes);

	        if (this.resizing)
	            this.resizing = 0;
	        this.scrollBarV.scrollLeft = this.scrollBarV.scrollTop = null;
	    };
	    
	    this.$updateCachedSize = function(force, gutterWidth, width, height) {
	        height -= (this.$extraHeight || 0);
	        var changes = 0;
	        var size = this.$size;
	        var oldSize = {
	            width: size.width,
	            height: size.height,
	            scrollerHeight: size.scrollerHeight,
	            scrollerWidth: size.scrollerWidth
	        };
	        if (height && (force || size.height != height)) {
	            size.height = height;
	            changes |= this.CHANGE_SIZE;

	            size.scrollerHeight = size.height;
	            if (this.$horizScroll)
	                size.scrollerHeight -= this.scrollBarH.getHeight();
	            this.scrollBarV.element.style.bottom = this.scrollBarH.getHeight() + "px";

	            changes = changes | this.CHANGE_SCROLL;
	        }

	        if (width && (force || size.width != width)) {
	            changes |= this.CHANGE_SIZE;
	            size.width = width;
	            
	            if (gutterWidth == null)
	                gutterWidth = this.$showGutter ? this.$gutter.offsetWidth : 0;
	            
	            this.gutterWidth = gutterWidth;
	            
	            this.scrollBarH.element.style.left = 
	            this.scroller.style.left = gutterWidth + "px";
	            size.scrollerWidth = Math.max(0, width - gutterWidth - this.scrollBarV.getWidth());           
	            
	            this.scrollBarH.element.style.right = 
	            this.scroller.style.right = this.scrollBarV.getWidth() + "px";
	            this.scroller.style.bottom = this.scrollBarH.getHeight() + "px";

	            if (this.session && this.session.getUseWrapMode() && this.adjustWrapLimit() || force)
	                changes |= this.CHANGE_FULL;
	        }
	        
	        size.$dirty = !width || !height;

	        if (changes)
	            this._signal("resize", oldSize);

	        return changes;
	    };

	    this.onGutterResize = function() {
	        var gutterWidth = this.$showGutter ? this.$gutter.offsetWidth : 0;
	        if (gutterWidth != this.gutterWidth)
	            this.$changes |= this.$updateCachedSize(true, gutterWidth, this.$size.width, this.$size.height);

	        if (this.session.getUseWrapMode() && this.adjustWrapLimit()) {
	            this.$loop.schedule(this.CHANGE_FULL);
	        } else if (this.$size.$dirty) {
	            this.$loop.schedule(this.CHANGE_FULL);
	        } else {
	            this.$computeLayerConfig();
	            this.$loop.schedule(this.CHANGE_MARKER);
	        }
	    };
	    this.adjustWrapLimit = function() {
	        var availableWidth = this.$size.scrollerWidth - this.$padding * 2;
	        var limit = Math.floor(availableWidth / this.characterWidth);
	        return this.session.adjustWrapLimit(limit, this.$showPrintMargin && this.$printMarginColumn);
	    };
	    this.setAnimatedScroll = function(shouldAnimate){
	        this.setOption("animatedScroll", shouldAnimate);
	    };
	    this.getAnimatedScroll = function() {
	        return this.$animatedScroll;
	    };
	    this.setShowInvisibles = function(showInvisibles) {
	        this.setOption("showInvisibles", showInvisibles);
	    };
	    this.getShowInvisibles = function() {
	        return this.getOption("showInvisibles");
	    };
	    this.getDisplayIndentGuides = function() {
	        return this.getOption("displayIndentGuides");
	    };

	    this.setDisplayIndentGuides = function(display) {
	        this.setOption("displayIndentGuides", display);
	    };
	    this.setShowPrintMargin = function(showPrintMargin) {
	        this.setOption("showPrintMargin", showPrintMargin);
	    };
	    this.getShowPrintMargin = function() {
	        return this.getOption("showPrintMargin");
	    };
	    this.setPrintMarginColumn = function(showPrintMargin) {
	        this.setOption("printMarginColumn", showPrintMargin);
	    };
	    this.getPrintMarginColumn = function() {
	        return this.getOption("printMarginColumn");
	    };
	    this.getShowGutter = function(){
	        return this.getOption("showGutter");
	    };
	    this.setShowGutter = function(show){
	        return this.setOption("showGutter", show);
	    };

	    this.getFadeFoldWidgets = function(){
	        return this.getOption("fadeFoldWidgets")
	    };

	    this.setFadeFoldWidgets = function(show) {
	        this.setOption("fadeFoldWidgets", show);
	    };

	    this.setHighlightGutterLine = function(shouldHighlight) {
	        this.setOption("highlightGutterLine", shouldHighlight);
	    };

	    this.getHighlightGutterLine = function() {
	        return this.getOption("highlightGutterLine");
	    };

	    this.$updateGutterLineHighlight = function() {
	        var pos = this.$cursorLayer.$pixelPos;
	        var height = this.layerConfig.lineHeight;
	        if (this.session.getUseWrapMode()) {
	            var cursor = this.session.selection.getCursor();
	            cursor.column = 0;
	            pos = this.$cursorLayer.getPixelPosition(cursor, true);
	            height *= this.session.getRowLength(cursor.row);
	        }
	        this.$gutterLineHighlight.style.top = pos.top - this.layerConfig.offset + "px";
	        this.$gutterLineHighlight.style.height = height + "px";
	    };

	    this.$updatePrintMargin = function() {
	        if (!this.$showPrintMargin && !this.$printMarginEl)
	            return;

	        if (!this.$printMarginEl) {
	            var containerEl = dom.createElement("div");
	            containerEl.className = "ace_layer ace_print-margin-layer";
	            this.$printMarginEl = dom.createElement("div");
	            this.$printMarginEl.className = "ace_print-margin";
	            containerEl.appendChild(this.$printMarginEl);
	            this.content.insertBefore(containerEl, this.content.firstChild);
	        }

	        var style = this.$printMarginEl.style;
	        style.left = ((this.characterWidth * this.$printMarginColumn) + this.$padding) + "px";
	        style.visibility = this.$showPrintMargin ? "visible" : "hidden";
	        
	        if (this.session && this.session.$wrap == -1)
	            this.adjustWrapLimit();
	    };
	    this.getContainerElement = function() {
	        return this.container;
	    };
	    this.getMouseEventTarget = function() {
	        return this.scroller;
	    };
	    this.getTextAreaContainer = function() {
	        return this.container;
	    };
	    this.$moveTextAreaToCursor = function() {
	        if (!this.$keepTextAreaAtCursor)
	            return;
	        var config = this.layerConfig;
	        var posTop = this.$cursorLayer.$pixelPos.top;
	        var posLeft = this.$cursorLayer.$pixelPos.left;
	        posTop -= config.offset;

	        var style = this.textarea.style;
	        var h = this.lineHeight;
	        if (posTop < 0 || posTop > config.height - h) {
	            style.top = style.left = "0";
	            return;
	        }

	        var w = this.characterWidth;
	        if (this.$composition) {
	            var val = this.textarea.value.replace(/^\x01+/, "");
	            w *= (this.session.$getStringScreenWidth(val)[0]+2);
	            h += 2;
	        }
	        posLeft -= this.scrollLeft;
	        if (posLeft > this.$size.scrollerWidth - w)
	            posLeft = this.$size.scrollerWidth - w;

	        posLeft += this.gutterWidth;
	        style.height = h + "px";
	        style.width = w + "px";
	        style.left = Math.min(posLeft, this.$size.scrollerWidth - w) + "px";
	        style.top = Math.min(posTop, this.$size.height - h) + "px";
	    };
	    this.getFirstVisibleRow = function() {
	        return this.layerConfig.firstRow;
	    };
	    this.getFirstFullyVisibleRow = function() {
	        return this.layerConfig.firstRow + (this.layerConfig.offset === 0 ? 0 : 1);
	    };
	    this.getLastFullyVisibleRow = function() {
	        var config = this.layerConfig;
	        var lastRow = config.lastRow
	        var top = this.session.documentToScreenRow(lastRow, 0) * config.lineHeight;
	        if (top - this.session.getScrollTop() > config.height - config.lineHeight)
	            return lastRow - 1;
	        return lastRow;
	    };
	    this.getLastVisibleRow = function() {
	        return this.layerConfig.lastRow;
	    };

	    this.$padding = null;
	    this.setPadding = function(padding) {
	        this.$padding = padding;
	        this.$textLayer.setPadding(padding);
	        this.$cursorLayer.setPadding(padding);
	        this.$markerFront.setPadding(padding);
	        this.$markerBack.setPadding(padding);
	        this.$loop.schedule(this.CHANGE_FULL);
	        this.$updatePrintMargin();
	    };
	    
	    this.setScrollMargin = function(top, bottom, left, right) {
	        var sm = this.scrollMargin;
	        sm.top = top|0;
	        sm.bottom = bottom|0;
	        sm.right = right|0;
	        sm.left = left|0;
	        sm.v = sm.top + sm.bottom;
	        sm.h = sm.left + sm.right;
	        if (sm.top && this.scrollTop <= 0 && this.session)
	            this.session.setScrollTop(-sm.top);
	        this.updateFull();
	    };
	    this.getHScrollBarAlwaysVisible = function() {
	        return this.$hScrollBarAlwaysVisible;
	    };
	    this.setHScrollBarAlwaysVisible = function(alwaysVisible) {
	        this.setOption("hScrollBarAlwaysVisible", alwaysVisible);
	    };
	    this.getVScrollBarAlwaysVisible = function() {
	        return this.$vScrollBarAlwaysVisible;
	    };
	    this.setVScrollBarAlwaysVisible = function(alwaysVisible) {
	        this.setOption("vScrollBarAlwaysVisible", alwaysVisible);
	    };

	    this.$updateScrollBarV = function() {
	        var scrollHeight = this.layerConfig.maxHeight;
	        var scrollerHeight = this.$size.scrollerHeight;
	        if (!this.$maxLines && this.$scrollPastEnd) {
	            scrollHeight -= (scrollerHeight - this.lineHeight) * this.$scrollPastEnd;
	            if (this.scrollTop > scrollHeight - scrollerHeight) {
	                scrollHeight = this.scrollTop + scrollerHeight;
	                this.scrollBarV.scrollTop = null;
	            }
	        }
	        this.scrollBarV.setScrollHeight(scrollHeight + this.scrollMargin.v);
	        this.scrollBarV.setScrollTop(this.scrollTop + this.scrollMargin.top);
	    };
	    this.$updateScrollBarH = function() {
	        this.scrollBarH.setScrollWidth(this.layerConfig.width + 2 * this.$padding + this.scrollMargin.h);
	        this.scrollBarH.setScrollLeft(this.scrollLeft + this.scrollMargin.left);
	    };
	    
	    this.$frozen = false;
	    this.freeze = function() {
	        this.$frozen = true;
	    };
	    
	    this.unfreeze = function() {
	        this.$frozen = false;
	    };

	    this.$renderChanges = function(changes, force) {
	        if (this.$changes) {
	            changes |= this.$changes;
	            this.$changes = 0;
	        }
	        if ((!this.session || !this.container.offsetWidth || this.$frozen) || (!changes && !force)) {
	            this.$changes |= changes;
	            return; 
	        } 
	        if (this.$size.$dirty) {
	            this.$changes |= changes;
	            return this.onResize(true);
	        }
	        if (!this.lineHeight) {
	            this.$textLayer.checkForSizeChanges();
	        }
	        
	        this._signal("beforeRender");
	        var config = this.layerConfig;
	        if (changes & this.CHANGE_FULL ||
	            changes & this.CHANGE_SIZE ||
	            changes & this.CHANGE_TEXT ||
	            changes & this.CHANGE_LINES ||
	            changes & this.CHANGE_SCROLL ||
	            changes & this.CHANGE_H_SCROLL
	        ) {
	            changes |= this.$computeLayerConfig();
	            if (config.firstRow != this.layerConfig.firstRow && config.firstRowScreen == this.layerConfig.firstRowScreen) {
	                var st = this.scrollTop + (config.firstRow - this.layerConfig.firstRow) * this.lineHeight;
	                if (st > 0) {
	                    this.scrollTop = st;
	                    changes = changes | this.CHANGE_SCROLL;
	                    changes |= this.$computeLayerConfig();
	                }
	            }
	            config = this.layerConfig;
	            this.$updateScrollBarV();
	            if (changes & this.CHANGE_H_SCROLL)
	                this.$updateScrollBarH();
	            this.$gutterLayer.element.style.marginTop = (-config.offset) + "px";
	            this.content.style.marginTop = (-config.offset) + "px";
	            this.content.style.width = config.width + 2 * this.$padding + "px";
	            this.content.style.height = config.minHeight + "px";
	        }
	        if (changes & this.CHANGE_H_SCROLL) {
	            this.content.style.marginLeft = -this.scrollLeft + "px";
	            this.scroller.className = this.scrollLeft <= 0 ? "ace_scroller" : "ace_scroller ace_scroll-left";
	        }
	        if (changes & this.CHANGE_FULL) {
	            this.$textLayer.update(config);
	            if (this.$showGutter)
	                this.$gutterLayer.update(config);
	            this.$markerBack.update(config);
	            this.$markerFront.update(config);
	            this.$cursorLayer.update(config);
	            this.$moveTextAreaToCursor();
	            this.$highlightGutterLine && this.$updateGutterLineHighlight();
	            this._signal("afterRender");
	            return;
	        }
	        if (changes & this.CHANGE_SCROLL) {
	            if (changes & this.CHANGE_TEXT || changes & this.CHANGE_LINES)
	                this.$textLayer.update(config);
	            else
	                this.$textLayer.scrollLines(config);

	            if (this.$showGutter)
	                this.$gutterLayer.update(config);
	            this.$markerBack.update(config);
	            this.$markerFront.update(config);
	            this.$cursorLayer.update(config);
	            this.$highlightGutterLine && this.$updateGutterLineHighlight();
	            this.$moveTextAreaToCursor();
	            this._signal("afterRender");
	            return;
	        }

	        if (changes & this.CHANGE_TEXT) {
	            this.$textLayer.update(config);
	            if (this.$showGutter)
	                this.$gutterLayer.update(config);
	        }
	        else if (changes & this.CHANGE_LINES) {
	            if (this.$updateLines() || (changes & this.CHANGE_GUTTER) && this.$showGutter)
	                this.$gutterLayer.update(config);
	        }
	        else if (changes & this.CHANGE_TEXT || changes & this.CHANGE_GUTTER) {
	            if (this.$showGutter)
	                this.$gutterLayer.update(config);
	        }

	        if (changes & this.CHANGE_CURSOR) {
	            this.$cursorLayer.update(config);
	            this.$moveTextAreaToCursor();
	            this.$highlightGutterLine && this.$updateGutterLineHighlight();
	        }

	        if (changes & (this.CHANGE_MARKER | this.CHANGE_MARKER_FRONT)) {
	            this.$markerFront.update(config);
	        }

	        if (changes & (this.CHANGE_MARKER | this.CHANGE_MARKER_BACK)) {
	            this.$markerBack.update(config);
	        }

	        this._signal("afterRender");
	    };

	    
	    this.$autosize = function() {
	        var height = this.session.getScreenLength() * this.lineHeight;
	        var maxHeight = this.$maxLines * this.lineHeight;
	        var desiredHeight = Math.min(maxHeight,
	            Math.max((this.$minLines || 1) * this.lineHeight, height)
	        ) + this.scrollMargin.v + (this.$extraHeight || 0);
	        if (this.$horizScroll)
	            desiredHeight += this.scrollBarH.getHeight();
	        if (this.$maxPixelHeight && desiredHeight > this.$maxPixelHeight)
	            desiredHeight = this.$maxPixelHeight;
	        var vScroll = height > maxHeight;
	        
	        if (desiredHeight != this.desiredHeight ||
	            this.$size.height != this.desiredHeight || vScroll != this.$vScroll) {
	            if (vScroll != this.$vScroll) {
	                this.$vScroll = vScroll;
	                this.scrollBarV.setVisible(vScroll);
	            }
	            
	            var w = this.container.clientWidth;
	            this.container.style.height = desiredHeight + "px";
	            this.$updateCachedSize(true, this.$gutterWidth, w, desiredHeight);
	            this.desiredHeight = desiredHeight;
	            
	            this._signal("autosize");
	        }
	    };
	    
	    this.$computeLayerConfig = function() {
	        var session = this.session;
	        var size = this.$size;
	        
	        var hideScrollbars = size.height <= 2 * this.lineHeight;
	        var screenLines = this.session.getScreenLength();
	        var maxHeight = screenLines * this.lineHeight;

	        var longestLine = this.$getLongestLine();
	        
	        var horizScroll = !hideScrollbars && (this.$hScrollBarAlwaysVisible ||
	            size.scrollerWidth - longestLine - 2 * this.$padding < 0);

	        var hScrollChanged = this.$horizScroll !== horizScroll;
	        if (hScrollChanged) {
	            this.$horizScroll = horizScroll;
	            this.scrollBarH.setVisible(horizScroll);
	        }
	        var vScrollBefore = this.$vScroll; // autosize can change vscroll value in which case we need to update longestLine
	        if (this.$maxLines && this.lineHeight > 1)
	            this.$autosize();

	        var offset = this.scrollTop % this.lineHeight;
	        var minHeight = size.scrollerHeight + this.lineHeight;
	        
	        var scrollPastEnd = !this.$maxLines && this.$scrollPastEnd
	            ? (size.scrollerHeight - this.lineHeight) * this.$scrollPastEnd
	            : 0;
	        maxHeight += scrollPastEnd;
	        
	        var sm = this.scrollMargin;
	        this.session.setScrollTop(Math.max(-sm.top,
	            Math.min(this.scrollTop, maxHeight - size.scrollerHeight + sm.bottom)));

	        this.session.setScrollLeft(Math.max(-sm.left, Math.min(this.scrollLeft, 
	            longestLine + 2 * this.$padding - size.scrollerWidth + sm.right)));
	        
	        var vScroll = !hideScrollbars && (this.$vScrollBarAlwaysVisible ||
	            size.scrollerHeight - maxHeight + scrollPastEnd < 0 || this.scrollTop > sm.top);
	        var vScrollChanged = vScrollBefore !== vScroll;
	        if (vScrollChanged) {
	            this.$vScroll = vScroll;
	            this.scrollBarV.setVisible(vScroll);
	        }

	        var lineCount = Math.ceil(minHeight / this.lineHeight) - 1;
	        var firstRow = Math.max(0, Math.round((this.scrollTop - offset) / this.lineHeight));
	        var lastRow = firstRow + lineCount;
	        var firstRowScreen, firstRowHeight;
	        var lineHeight = this.lineHeight;
	        firstRow = session.screenToDocumentRow(firstRow, 0);
	        var foldLine = session.getFoldLine(firstRow);
	        if (foldLine) {
	            firstRow = foldLine.start.row;
	        }

	        firstRowScreen = session.documentToScreenRow(firstRow, 0);
	        firstRowHeight = session.getRowLength(firstRow) * lineHeight;

	        lastRow = Math.min(session.screenToDocumentRow(lastRow, 0), session.getLength() - 1);
	        minHeight = size.scrollerHeight + session.getRowLength(lastRow) * lineHeight +
	                                                firstRowHeight;

	        offset = this.scrollTop - firstRowScreen * lineHeight;

	        var changes = 0;
	        if (this.layerConfig.width != longestLine) 
	            changes = this.CHANGE_H_SCROLL;
	        if (hScrollChanged || vScrollChanged) {
	            changes = this.$updateCachedSize(true, this.gutterWidth, size.width, size.height);
	            this._signal("scrollbarVisibilityChanged");
	            if (vScrollChanged)
	                longestLine = this.$getLongestLine();
	        }
	        
	        this.layerConfig = {
	            width : longestLine,
	            padding : this.$padding,
	            firstRow : firstRow,
	            firstRowScreen: firstRowScreen,
	            lastRow : lastRow,
	            lineHeight : lineHeight,
	            characterWidth : this.characterWidth,
	            minHeight : minHeight,
	            maxHeight : maxHeight,
	            offset : offset,
	            gutterOffset : lineHeight ? Math.max(0, Math.ceil((offset + size.height - size.scrollerHeight) / lineHeight)) : 0,
	            height : this.$size.scrollerHeight
	        };

	        return changes;
	    };

	    this.$updateLines = function() {
	        var firstRow = this.$changedLines.firstRow;
	        var lastRow = this.$changedLines.lastRow;
	        this.$changedLines = null;

	        var layerConfig = this.layerConfig;

	        if (firstRow > layerConfig.lastRow + 1) { return; }
	        if (lastRow < layerConfig.firstRow) { return; }
	        if (lastRow === Infinity) {
	            if (this.$showGutter)
	                this.$gutterLayer.update(layerConfig);
	            this.$textLayer.update(layerConfig);
	            return;
	        }
	        this.$textLayer.updateLines(layerConfig, firstRow, lastRow);
	        return true;
	    };

	    this.$getLongestLine = function() {
	        var charCount = this.session.getScreenWidth();
	        if (this.showInvisibles && !this.session.$useWrapMode)
	            charCount += 1;

	        return Math.max(this.$size.scrollerWidth - 2 * this.$padding, Math.round(charCount * this.characterWidth));
	    };
	    this.updateFrontMarkers = function() {
	        this.$markerFront.setMarkers(this.session.getMarkers(true));
	        this.$loop.schedule(this.CHANGE_MARKER_FRONT);
	    };
	    this.updateBackMarkers = function() {
	        this.$markerBack.setMarkers(this.session.getMarkers());
	        this.$loop.schedule(this.CHANGE_MARKER_BACK);
	    };
	    this.addGutterDecoration = function(row, className){
	        this.$gutterLayer.addGutterDecoration(row, className);
	    };
	    this.removeGutterDecoration = function(row, className){
	        this.$gutterLayer.removeGutterDecoration(row, className);
	    };
	    this.updateBreakpoints = function(rows) {
	        this.$loop.schedule(this.CHANGE_GUTTER);
	    };
	    this.setAnnotations = function(annotations) {
	        this.$gutterLayer.setAnnotations(annotations);
	        this.$loop.schedule(this.CHANGE_GUTTER);
	    };
	    this.updateCursor = function() {
	        this.$loop.schedule(this.CHANGE_CURSOR);
	    };
	    this.hideCursor = function() {
	        this.$cursorLayer.hideCursor();
	    };
	    this.showCursor = function() {
	        this.$cursorLayer.showCursor();
	    };

	    this.scrollSelectionIntoView = function(anchor, lead, offset) {
	        this.scrollCursorIntoView(anchor, offset);
	        this.scrollCursorIntoView(lead, offset);
	    };
	    this.scrollCursorIntoView = function(cursor, offset, $viewMargin) {
	        if (this.$size.scrollerHeight === 0)
	            return;

	        var pos = this.$cursorLayer.getPixelPosition(cursor);

	        var left = pos.left;
	        var top = pos.top;
	        
	        var topMargin = $viewMargin && $viewMargin.top || 0;
	        var bottomMargin = $viewMargin && $viewMargin.bottom || 0;
	        
	        var scrollTop = this.$scrollAnimation ? this.session.getScrollTop() : this.scrollTop;
	        
	        if (scrollTop + topMargin > top) {
	            if (offset && scrollTop + topMargin > top + this.lineHeight)
	                top -= offset * this.$size.scrollerHeight;
	            if (top === 0)
	                top = -this.scrollMargin.top;
	            this.session.setScrollTop(top);
	        } else if (scrollTop + this.$size.scrollerHeight - bottomMargin < top + this.lineHeight) {
	            if (offset && scrollTop + this.$size.scrollerHeight - bottomMargin < top -  this.lineHeight)
	                top += offset * this.$size.scrollerHeight;
	            this.session.setScrollTop(top + this.lineHeight - this.$size.scrollerHeight);
	        }

	        var scrollLeft = this.scrollLeft;

	        if (scrollLeft > left) {
	            if (left < this.$padding + 2 * this.layerConfig.characterWidth)
	                left = -this.scrollMargin.left;
	            this.session.setScrollLeft(left);
	        } else if (scrollLeft + this.$size.scrollerWidth < left + this.characterWidth) {
	            this.session.setScrollLeft(Math.round(left + this.characterWidth - this.$size.scrollerWidth));
	        } else if (scrollLeft <= this.$padding && left - scrollLeft < this.characterWidth) {
	            this.session.setScrollLeft(0);
	        }
	    };
	    this.getScrollTop = function() {
	        return this.session.getScrollTop();
	    };
	    this.getScrollLeft = function() {
	        return this.session.getScrollLeft();
	    };
	    this.getScrollTopRow = function() {
	        return this.scrollTop / this.lineHeight;
	    };
	    this.getScrollBottomRow = function() {
	        return Math.max(0, Math.floor((this.scrollTop + this.$size.scrollerHeight) / this.lineHeight) - 1);
	    };
	    this.scrollToRow = function(row) {
	        this.session.setScrollTop(row * this.lineHeight);
	    };

	    this.alignCursor = function(cursor, alignment) {
	        if (typeof cursor == "number")
	            cursor = {row: cursor, column: 0};

	        var pos = this.$cursorLayer.getPixelPosition(cursor);
	        var h = this.$size.scrollerHeight - this.lineHeight;
	        var offset = pos.top - h * (alignment || 0);

	        this.session.setScrollTop(offset);
	        return offset;
	    };

	    this.STEPS = 8;
	    this.$calcSteps = function(fromValue, toValue){
	        var i = 0;
	        var l = this.STEPS;
	        var steps = [];

	        var func  = function(t, x_min, dx) {
	            return dx * (Math.pow(t - 1, 3) + 1) + x_min;
	        };

	        for (i = 0; i < l; ++i)
	            steps.push(func(i / this.STEPS, fromValue, toValue - fromValue));

	        return steps;
	    };
	    this.scrollToLine = function(line, center, animate, callback) {
	        var pos = this.$cursorLayer.getPixelPosition({row: line, column: 0});
	        var offset = pos.top;
	        if (center)
	            offset -= this.$size.scrollerHeight / 2;

	        var initialScroll = this.scrollTop;
	        this.session.setScrollTop(offset);
	        if (animate !== false)
	            this.animateScrolling(initialScroll, callback);
	    };

	    this.animateScrolling = function(fromValue, callback) {
	        var toValue = this.scrollTop;
	        if (!this.$animatedScroll)
	            return;
	        var _self = this;
	        
	        if (fromValue == toValue)
	            return;
	        
	        if (this.$scrollAnimation) {
	            var oldSteps = this.$scrollAnimation.steps;
	            if (oldSteps.length) {
	                fromValue = oldSteps[0];
	                if (fromValue == toValue)
	                    return;
	            }
	        }
	        
	        var steps = _self.$calcSteps(fromValue, toValue);
	        this.$scrollAnimation = {from: fromValue, to: toValue, steps: steps};

	        clearInterval(this.$timer);

	        _self.session.setScrollTop(steps.shift());
	        _self.session.$scrollTop = toValue;
	        this.$timer = setInterval(function() {
	            if (steps.length) {
	                _self.session.setScrollTop(steps.shift());
	                _self.session.$scrollTop = toValue;
	            } else if (toValue != null) {
	                _self.session.$scrollTop = -1;
	                _self.session.setScrollTop(toValue);
	                toValue = null;
	            } else {
	                _self.$timer = clearInterval(_self.$timer);
	                _self.$scrollAnimation = null;
	                callback && callback();
	            }
	        }, 10);
	    };
	    this.scrollToY = function(scrollTop) {
	        if (this.scrollTop !== scrollTop) {
	            this.$loop.schedule(this.CHANGE_SCROLL);
	            this.scrollTop = scrollTop;
	        }
	    };
	    this.scrollToX = function(scrollLeft) {
	        if (this.scrollLeft !== scrollLeft)
	            this.scrollLeft = scrollLeft;
	        this.$loop.schedule(this.CHANGE_H_SCROLL);
	    };
	    this.scrollTo = function(x, y) {
	        this.session.setScrollTop(y);
	        this.session.setScrollLeft(y);
	    };
	    this.scrollBy = function(deltaX, deltaY) {
	        deltaY && this.session.setScrollTop(this.session.getScrollTop() + deltaY);
	        deltaX && this.session.setScrollLeft(this.session.getScrollLeft() + deltaX);
	    };
	    this.isScrollableBy = function(deltaX, deltaY) {
	        if (deltaY < 0 && this.session.getScrollTop() >= 1 - this.scrollMargin.top)
	           return true;
	        if (deltaY > 0 && this.session.getScrollTop() + this.$size.scrollerHeight
	            - this.layerConfig.maxHeight < -1 + this.scrollMargin.bottom)
	           return true;
	        if (deltaX < 0 && this.session.getScrollLeft() >= 1 - this.scrollMargin.left)
	            return true;
	        if (deltaX > 0 && this.session.getScrollLeft() + this.$size.scrollerWidth
	            - this.layerConfig.width < -1 + this.scrollMargin.right)
	           return true;
	    };

	    this.pixelToScreenCoordinates = function(x, y) {
	        var canvasPos = this.scroller.getBoundingClientRect();

	        var offset = (x + this.scrollLeft - canvasPos.left - this.$padding) / this.characterWidth;
	        var row = Math.floor((y + this.scrollTop - canvasPos.top) / this.lineHeight);
	        var col = Math.round(offset);

	        return {row: row, column: col, side: offset - col > 0 ? 1 : -1};
	    };

	    this.screenToTextCoordinates = function(x, y) {
	        var canvasPos = this.scroller.getBoundingClientRect();

	        var col = Math.round(
	            (x + this.scrollLeft - canvasPos.left - this.$padding) / this.characterWidth
	        );

	        var row = (y + this.scrollTop - canvasPos.top) / this.lineHeight;

	        return this.session.screenToDocumentPosition(row, Math.max(col, 0));
	    };
	    this.textToScreenCoordinates = function(row, column) {
	        var canvasPos = this.scroller.getBoundingClientRect();
	        var pos = this.session.documentToScreenPosition(row, column);

	        var x = this.$padding + Math.round(pos.column * this.characterWidth);
	        var y = pos.row * this.lineHeight;

	        return {
	            pageX: canvasPos.left + x - this.scrollLeft,
	            pageY: canvasPos.top + y - this.scrollTop
	        };
	    };
	    this.visualizeFocus = function() {
	        dom.addCssClass(this.container, "ace_focus");
	    };
	    this.visualizeBlur = function() {
	        dom.removeCssClass(this.container, "ace_focus");
	    };
	    this.showComposition = function(position) {
	        if (!this.$composition)
	            this.$composition = {
	                keepTextAreaAtCursor: this.$keepTextAreaAtCursor,
	                cssText: this.textarea.style.cssText
	            };

	        this.$keepTextAreaAtCursor = true;
	        dom.addCssClass(this.textarea, "ace_composition");
	        this.textarea.style.cssText = "";
	        this.$moveTextAreaToCursor();
	    };
	    this.setCompositionText = function(text) {
	        this.$moveTextAreaToCursor();
	    };
	    this.hideComposition = function() {
	        if (!this.$composition)
	            return;

	        dom.removeCssClass(this.textarea, "ace_composition");
	        this.$keepTextAreaAtCursor = this.$composition.keepTextAreaAtCursor;
	        this.textarea.style.cssText = this.$composition.cssText;
	        this.$composition = null;
	    };
	    this.setTheme = function(theme, cb) {
	        var _self = this;
	        this.$themeId = theme;
	        _self._dispatchEvent('themeChange',{theme:theme});

	        if (!theme || typeof theme == "string") {
	            var moduleName = theme || this.$options.theme.initialValue;
	            config.loadModule(["theme", moduleName], afterLoad);
	        } else {
	            afterLoad(theme);
	        }

	        function afterLoad(module) {
	            if (_self.$themeId != theme)
	                return cb && cb();
	            if (!module || !module.cssClass)
	                throw new Error("couldn't load module " + theme + " or it didn't call define");
	            dom.importCssString(
	                module.cssText,
	                module.cssClass,
	                _self.container.ownerDocument
	            );

	            if (_self.theme)
	                dom.removeCssClass(_self.container, _self.theme.cssClass);

	            var padding = "padding" in module ? module.padding 
	                : "padding" in (_self.theme || {}) ? 4 : _self.$padding;
	            if (_self.$padding && padding != _self.$padding)
	                _self.setPadding(padding);
	            _self.$theme = module.cssClass;

	            _self.theme = module;
	            dom.addCssClass(_self.container, module.cssClass);
	            dom.setCssClass(_self.container, "ace_dark", module.isDark);
	            if (_self.$size) {
	                _self.$size.width = 0;
	                _self.$updateSizeAsync();
	            }

	            _self._dispatchEvent('themeLoaded', {theme:module});
	            cb && cb();
	        }
	    };
	    this.getTheme = function() {
	        return this.$themeId;
	    };
	    this.setStyle = function(style, include) {
	        dom.setCssClass(this.container, style, include !== false);
	    };
	    this.unsetStyle = function(style) {
	        dom.removeCssClass(this.container, style);
	    };
	    
	    this.setCursorStyle = function(style) {
	        if (this.scroller.style.cursor != style)
	            this.scroller.style.cursor = style;
	    };
	    this.setMouseCursor = function(cursorStyle) {
	        this.scroller.style.cursor = cursorStyle;
	    };
	    this.destroy = function() {
	        this.$textLayer.destroy();
	        this.$cursorLayer.destroy();
	    };

	}).call(VirtualRenderer.prototype);


	config.defineOptions(VirtualRenderer.prototype, "renderer", {
	    animatedScroll: {initialValue: false},
	    showInvisibles: {
	        set: function(value) {
	            if (this.$textLayer.setShowInvisibles(value))
	                this.$loop.schedule(this.CHANGE_TEXT);
	        },
	        initialValue: false
	    },
	    showPrintMargin: {
	        set: function() { this.$updatePrintMargin(); },
	        initialValue: true
	    },
	    printMarginColumn: {
	        set: function() { this.$updatePrintMargin(); },
	        initialValue: 80
	    },
	    printMargin: {
	        set: function(val) {
	            if (typeof val == "number")
	                this.$printMarginColumn = val;
	            this.$showPrintMargin = !!val;
	            this.$updatePrintMargin();
	        },
	        get: function() {
	            return this.$showPrintMargin && this.$printMarginColumn; 
	        }
	    },
	    showGutter: {
	        set: function(show){
	            this.$gutter.style.display = show ? "block" : "none";
	            this.$loop.schedule(this.CHANGE_FULL);
	            this.onGutterResize();
	        },
	        initialValue: true
	    },
	    fadeFoldWidgets: {
	        set: function(show) {
	            dom.setCssClass(this.$gutter, "ace_fade-fold-widgets", show);
	        },
	        initialValue: false
	    },
	    showFoldWidgets: {
	        set: function(show) {this.$gutterLayer.setShowFoldWidgets(show)},
	        initialValue: true
	    },
	    showLineNumbers: {
	        set: function(show) {
	            this.$gutterLayer.setShowLineNumbers(show);
	            this.$loop.schedule(this.CHANGE_GUTTER);
	        },
	        initialValue: true
	    },
	    displayIndentGuides: {
	        set: function(show) {
	            if (this.$textLayer.setDisplayIndentGuides(show))
	                this.$loop.schedule(this.CHANGE_TEXT);
	        },
	        initialValue: true
	    },
	    highlightGutterLine: {
	        set: function(shouldHighlight) {
	            if (!this.$gutterLineHighlight) {
	                this.$gutterLineHighlight = dom.createElement("div");
	                this.$gutterLineHighlight.className = "ace_gutter-active-line";
	                this.$gutter.appendChild(this.$gutterLineHighlight);
	                return;
	            }

	            this.$gutterLineHighlight.style.display = shouldHighlight ? "" : "none";
	            if (this.$cursorLayer.$pixelPos)
	                this.$updateGutterLineHighlight();
	        },
	        initialValue: false,
	        value: true
	    },
	    hScrollBarAlwaysVisible: {
	        set: function(val) {
	            if (!this.$hScrollBarAlwaysVisible || !this.$horizScroll)
	                this.$loop.schedule(this.CHANGE_SCROLL);
	        },
	        initialValue: false
	    },
	    vScrollBarAlwaysVisible: {
	        set: function(val) {
	            if (!this.$vScrollBarAlwaysVisible || !this.$vScroll)
	                this.$loop.schedule(this.CHANGE_SCROLL);
	        },
	        initialValue: false
	    },
	    fontSize:  {
	        set: function(size) {
	            if (typeof size == "number")
	                size = size + "px";
	            this.container.style.fontSize = size;
	            this.updateFontSize();
	        },
	        initialValue: 12
	    },
	    fontFamily: {
	        set: function(name) {
	            this.container.style.fontFamily = name;
	            this.updateFontSize();
	        }
	    },
	    maxLines: {
	        set: function(val) {
	            this.updateFull();
	        }
	    },
	    minLines: {
	        set: function(val) {
	            this.updateFull();
	        }
	    },
	    maxPixelHeight: {
	        set: function(val) {
	            this.updateFull();
	        },
	        initialValue: 0
	    },
	    scrollPastEnd: {
	        set: function(val) {
	            val = +val || 0;
	            if (this.$scrollPastEnd == val)
	                return;
	            this.$scrollPastEnd = val;
	            this.$loop.schedule(this.CHANGE_SCROLL);
	        },
	        initialValue: 0,
	        handlesSet: true
	    },
	    fixedWidthGutter: {
	        set: function(val) {
	            this.$gutterLayer.$fixedWidth = !!val;
	            this.$loop.schedule(this.CHANGE_GUTTER);
	        }
	    },
	    theme: {
	        set: function(val) { this.setTheme(val) },
	        get: function() { return this.$themeId || this.theme; },
	        initialValue: "./theme/textmate",
	        handlesSet: true
	    }
	});

	exports.VirtualRenderer = VirtualRenderer;
	});

	ace.define("ace/worker/worker_client",["require","exports","module","ace/lib/oop","ace/lib/net","ace/lib/event_emitter","ace/config"], function(acequire, exports, module) {
	"use strict";

	var oop = acequire("../lib/oop");
	var net = acequire("../lib/net");
	var EventEmitter = acequire("../lib/event_emitter").EventEmitter;
	var config = acequire("../config");

	var WorkerClient = function(topLevelNamespaces, mod, classname, workerUrl) {
	    this.$sendDeltaQueue = this.$sendDeltaQueue.bind(this);
	    this.changeListener = this.changeListener.bind(this);
	    this.onMessage = this.onMessage.bind(this);
	    if (acequire.nameToUrl && !acequire.toUrl)
	        acequire.toUrl = acequire.nameToUrl;
	    
	    if (config.get("packaged") || !acequire.toUrl) {
	        workerUrl = workerUrl || config.moduleUrl(mod.id, "worker")
	    } else {
	        var normalizePath = this.$normalizePath;
	        workerUrl = workerUrl || normalizePath(acequire.toUrl("ace/worker/worker.js", null, "_"));

	        var tlns = {};
	        topLevelNamespaces.forEach(function(ns) {
	            tlns[ns] = normalizePath(acequire.toUrl(ns, null, "_").replace(/(\.js)?(\?.*)?$/, ""));
	        });
	    }

	    try {
	            var workerSrc = mod.src;
	    var Blob = __webpack_require__(906);
	    var blob = new Blob([ workerSrc ], { type: 'application/javascript' });
	    var blobUrl = (window.URL || window.webkitURL).createObjectURL(blob);

	    this.$worker = new Worker(blobUrl);

	    } catch(e) {
	        if (e instanceof window.DOMException) {
	            var blob = this.$workerBlob(workerUrl);
	            var URL = window.URL || window.webkitURL;
	            var blobURL = URL.createObjectURL(blob);

	            this.$worker = new Worker(blobURL);
	            URL.revokeObjectURL(blobURL);
	        } else {
	            throw e;
	        }
	    }
	    this.$worker.postMessage({
	        init : true,
	        tlns : tlns,
	        module : mod.id,
	        classname : classname
	    });

	    this.callbackId = 1;
	    this.callbacks = {};

	    this.$worker.onmessage = this.onMessage;
	};

	(function(){

	    oop.implement(this, EventEmitter);

	    this.onMessage = function(e) {
	        var msg = e.data;
	        switch(msg.type) {
	            case "event":
	                this._signal(msg.name, {data: msg.data});
	                break;
	            case "call":
	                var callback = this.callbacks[msg.id];
	                if (callback) {
	                    callback(msg.data);
	                    delete this.callbacks[msg.id];
	                }
	                break;
	            case "error":
	                this.reportError(msg.data);
	                break;
	            case "log":
	                window.console && console.log && console.log.apply(console, msg.data);
	                break;
	        }
	    };
	    
	    this.reportError = function(err) {
	        window.console && console.error && console.error(err);
	    };

	    this.$normalizePath = function(path) {
	        return net.qualifyURL(path);
	    };

	    this.terminate = function() {
	        this._signal("terminate", {});
	        this.deltaQueue = null;
	        this.$worker.terminate();
	        this.$worker = null;
	        if (this.$doc)
	            this.$doc.off("change", this.changeListener);
	        this.$doc = null;
	    };

	    this.send = function(cmd, args) {
	        this.$worker.postMessage({command: cmd, args: args});
	    };

	    this.call = function(cmd, args, callback) {
	        if (callback) {
	            var id = this.callbackId++;
	            this.callbacks[id] = callback;
	            args.push(id);
	        }
	        this.send(cmd, args);
	    };

	    this.emit = function(event, data) {
	        try {
	            this.$worker.postMessage({event: event, data: {data: data.data}});
	        }
	        catch(ex) {
	            console.error(ex.stack);
	        }
	    };

	    this.attachToDocument = function(doc) {
	        if(this.$doc)
	            this.terminate();

	        this.$doc = doc;
	        this.call("setValue", [doc.getValue()]);
	        doc.on("change", this.changeListener);
	    };

	    this.changeListener = function(delta) {
	        if (!this.deltaQueue) {
	            this.deltaQueue = [];
	            setTimeout(this.$sendDeltaQueue, 0);
	        }
	        if (delta.action == "insert")
	            this.deltaQueue.push(delta.start, delta.lines);
	        else
	            this.deltaQueue.push(delta.start, delta.end);
	    };

	    this.$sendDeltaQueue = function() {
	        var q = this.deltaQueue;
	        if (!q) return;
	        this.deltaQueue = null;
	        if (q.length > 50 && q.length > this.$doc.getLength() >> 1) {
	            this.call("setValue", [this.$doc.getValue()]);
	        } else
	            this.emit("change", {data: q});
	    };

	    this.$workerBlob = function(workerUrl) {
	        var script = "importScripts('" + net.qualifyURL(workerUrl) + "');";
	        try {
	            return new Blob([script], {"type": "application/javascript"});
	        } catch (e) { // Backwards-compatibility
	            var BlobBuilder = window.BlobBuilder || window.WebKitBlobBuilder || window.MozBlobBuilder;
	            var blobBuilder = new BlobBuilder();
	            blobBuilder.append(script);
	            return blobBuilder.getBlob("application/javascript");
	        }
	    };

	}).call(WorkerClient.prototype);


	var UIWorkerClient = function(topLevelNamespaces, mod, classname) {
	    this.$sendDeltaQueue = this.$sendDeltaQueue.bind(this);
	    this.changeListener = this.changeListener.bind(this);
	    this.callbackId = 1;
	    this.callbacks = {};
	    this.messageBuffer = [];

	    var main = null;
	    var emitSync = false;
	    var sender = Object.create(EventEmitter);
	    var _self = this;

	    this.$worker = {};
	    this.$worker.terminate = function() {};
	    this.$worker.postMessage = function(e) {
	        _self.messageBuffer.push(e);
	        if (main) {
	            if (emitSync)
	                setTimeout(processNext);
	            else
	                processNext();
	        }
	    };
	    this.setEmitSync = function(val) { emitSync = val };

	    var processNext = function() {
	        var msg = _self.messageBuffer.shift();
	        if (msg.command)
	            main[msg.command].apply(main, msg.args);
	        else if (msg.event)
	            sender._signal(msg.event, msg.data);
	    };

	    sender.postMessage = function(msg) {
	        _self.onMessage({data: msg});
	    };
	    sender.callback = function(data, callbackId) {
	        this.postMessage({type: "call", id: callbackId, data: data});
	    };
	    sender.emit = function(name, data) {
	        this.postMessage({type: "event", name: name, data: data});
	    };

	    config.loadModule(["worker", mod], function(Main) {
	        main = new Main[classname](sender);
	        while (_self.messageBuffer.length)
	            processNext();
	    });
	};

	UIWorkerClient.prototype = WorkerClient.prototype;

	exports.UIWorkerClient = UIWorkerClient;
	exports.WorkerClient = WorkerClient;

	});

	ace.define("ace/placeholder",["require","exports","module","ace/range","ace/lib/event_emitter","ace/lib/oop"], function(acequire, exports, module) {
	"use strict";

	var Range = acequire("./range").Range;
	var EventEmitter = acequire("./lib/event_emitter").EventEmitter;
	var oop = acequire("./lib/oop");

	var PlaceHolder = function(session, length, pos, others, mainClass, othersClass) {
	    var _self = this;
	    this.length = length;
	    this.session = session;
	    this.doc = session.getDocument();
	    this.mainClass = mainClass;
	    this.othersClass = othersClass;
	    this.$onUpdate = this.onUpdate.bind(this);
	    this.doc.on("change", this.$onUpdate);
	    this.$others = others;
	    
	    this.$onCursorChange = function() {
	        setTimeout(function() {
	            _self.onCursorChange();
	        });
	    };
	    
	    this.$pos = pos;
	    var undoStack = session.getUndoManager().$undoStack || session.getUndoManager().$undostack || {length: -1};
	    this.$undoStackDepth = undoStack.length;
	    this.setup();

	    session.selection.on("changeCursor", this.$onCursorChange);
	};

	(function() {

	    oop.implement(this, EventEmitter);
	    this.setup = function() {
	        var _self = this;
	        var doc = this.doc;
	        var session = this.session;
	        
	        this.selectionBefore = session.selection.toJSON();
	        if (session.selection.inMultiSelectMode)
	            session.selection.toSingleRange();

	        this.pos = doc.createAnchor(this.$pos.row, this.$pos.column);
	        var pos = this.pos;
	        pos.$insertRight = true;
	        pos.detach();
	        pos.markerId = session.addMarker(new Range(pos.row, pos.column, pos.row, pos.column + this.length), this.mainClass, null, false);
	        this.others = [];
	        this.$others.forEach(function(other) {
	            var anchor = doc.createAnchor(other.row, other.column);
	            anchor.$insertRight = true;
	            anchor.detach();
	            _self.others.push(anchor);
	        });
	        session.setUndoSelect(false);
	    };
	    this.showOtherMarkers = function() {
	        if (this.othersActive) return;
	        var session = this.session;
	        var _self = this;
	        this.othersActive = true;
	        this.others.forEach(function(anchor) {
	            anchor.markerId = session.addMarker(new Range(anchor.row, anchor.column, anchor.row, anchor.column+_self.length), _self.othersClass, null, false);
	        });
	    };
	    this.hideOtherMarkers = function() {
	        if (!this.othersActive) return;
	        this.othersActive = false;
	        for (var i = 0; i < this.others.length; i++) {
	            this.session.removeMarker(this.others[i].markerId);
	        }
	    };
	    this.onUpdate = function(delta) {
	        if (this.$updating)
	            return this.updateAnchors(delta);
	            
	        var range = delta;
	        if (range.start.row !== range.end.row) return;
	        if (range.start.row !== this.pos.row) return;
	        this.$updating = true;
	        var lengthDiff = delta.action === "insert" ? range.end.column - range.start.column : range.start.column - range.end.column;
	        var inMainRange = range.start.column >= this.pos.column && range.start.column <= this.pos.column + this.length + 1;
	        var distanceFromStart = range.start.column - this.pos.column;
	        
	        this.updateAnchors(delta);
	        
	        if (inMainRange)
	            this.length += lengthDiff;

	        if (inMainRange && !this.session.$fromUndo) {
	            if (delta.action === 'insert') {
	                for (var i = this.others.length - 1; i >= 0; i--) {
	                    var otherPos = this.others[i];
	                    var newPos = {row: otherPos.row, column: otherPos.column + distanceFromStart};
	                    this.doc.insertMergedLines(newPos, delta.lines);
	                }
	            } else if (delta.action === 'remove') {
	                for (var i = this.others.length - 1; i >= 0; i--) {
	                    var otherPos = this.others[i];
	                    var newPos = {row: otherPos.row, column: otherPos.column + distanceFromStart};
	                    this.doc.remove(new Range(newPos.row, newPos.column, newPos.row, newPos.column - lengthDiff));
	                }
	            }
	        }
	        
	        this.$updating = false;
	        this.updateMarkers();
	    };
	    
	    this.updateAnchors = function(delta) {
	        this.pos.onChange(delta);
	        for (var i = this.others.length; i--;)
	            this.others[i].onChange(delta);
	        this.updateMarkers();
	    };
	    
	    this.updateMarkers = function() {
	        if (this.$updating)
	            return;
	        var _self = this;
	        var session = this.session;
	        var updateMarker = function(pos, className) {
	            session.removeMarker(pos.markerId);
	            pos.markerId = session.addMarker(new Range(pos.row, pos.column, pos.row, pos.column+_self.length), className, null, false);
	        };
	        updateMarker(this.pos, this.mainClass);
	        for (var i = this.others.length; i--;)
	            updateMarker(this.others[i], this.othersClass);
	    };

	    this.onCursorChange = function(event) {
	        if (this.$updating || !this.session) return;
	        var pos = this.session.selection.getCursor();
	        if (pos.row === this.pos.row && pos.column >= this.pos.column && pos.column <= this.pos.column + this.length) {
	            this.showOtherMarkers();
	            this._emit("cursorEnter", event);
	        } else {
	            this.hideOtherMarkers();
	            this._emit("cursorLeave", event);
	        }
	    };    
	    this.detach = function() {
	        this.session.removeMarker(this.pos && this.pos.markerId);
	        this.hideOtherMarkers();
	        this.doc.removeEventListener("change", this.$onUpdate);
	        this.session.selection.removeEventListener("changeCursor", this.$onCursorChange);
	        this.session.setUndoSelect(true);
	        this.session = null;
	    };
	    this.cancel = function() {
	        if (this.$undoStackDepth === -1)
	            return;
	        var undoManager = this.session.getUndoManager();
	        var undosRequired = (undoManager.$undoStack || undoManager.$undostack).length - this.$undoStackDepth;
	        for (var i = 0; i < undosRequired; i++) {
	            undoManager.undo(true);
	        }
	        if (this.selectionBefore)
	            this.session.selection.fromJSON(this.selectionBefore);
	    };
	}).call(PlaceHolder.prototype);


	exports.PlaceHolder = PlaceHolder;
	});

	ace.define("ace/mouse/multi_select_handler",["require","exports","module","ace/lib/event","ace/lib/useragent"], function(acequire, exports, module) {

	var event = acequire("../lib/event");
	var useragent = acequire("../lib/useragent");
	function isSamePoint(p1, p2) {
	    return p1.row == p2.row && p1.column == p2.column;
	}

	function onMouseDown(e) {
	    var ev = e.domEvent;
	    var alt = ev.altKey;
	    var shift = ev.shiftKey;
	    var ctrl = ev.ctrlKey;
	    var accel = e.getAccelKey();
	    var button = e.getButton();
	    
	    if (ctrl && useragent.isMac)
	        button = ev.button;

	    if (e.editor.inMultiSelectMode && button == 2) {
	        e.editor.textInput.onContextMenu(e.domEvent);
	        return;
	    }
	    
	    if (!ctrl && !alt && !accel) {
	        if (button === 0 && e.editor.inMultiSelectMode)
	            e.editor.exitMultiSelectMode();
	        return;
	    }
	    
	    if (button !== 0)
	        return;

	    var editor = e.editor;
	    var selection = editor.selection;
	    var isMultiSelect = editor.inMultiSelectMode;
	    var pos = e.getDocumentPosition();
	    var cursor = selection.getCursor();
	    var inSelection = e.inSelection() || (selection.isEmpty() && isSamePoint(pos, cursor));

	    var mouseX = e.x, mouseY = e.y;
	    var onMouseSelection = function(e) {
	        mouseX = e.clientX;
	        mouseY = e.clientY;
	    };
	    
	    var session = editor.session;
	    var screenAnchor = editor.renderer.pixelToScreenCoordinates(mouseX, mouseY);
	    var screenCursor = screenAnchor;
	    
	    var selectionMode;
	    if (editor.$mouseHandler.$enableJumpToDef) {
	        if (ctrl && alt || accel && alt)
	            selectionMode = shift ? "block" : "add";
	        else if (alt && editor.$blockSelectEnabled)
	            selectionMode = "block";
	    } else {
	        if (accel && !alt) {
	            selectionMode = "add";
	            if (!isMultiSelect && shift)
	                return;
	        } else if (alt && editor.$blockSelectEnabled) {
	            selectionMode = "block";
	        }
	    }
	    
	    if (selectionMode && useragent.isMac && ev.ctrlKey) {
	        editor.$mouseHandler.cancelContextMenu();
	    }

	    if (selectionMode == "add") {
	        if (!isMultiSelect && inSelection)
	            return; // dragging

	        if (!isMultiSelect) {
	            var range = selection.toOrientedRange();
	            editor.addSelectionMarker(range);
	        }

	        var oldRange = selection.rangeList.rangeAtPoint(pos);
	        
	        
	        editor.$blockScrolling++;
	        editor.inVirtualSelectionMode = true;
	        
	        if (shift) {
	            oldRange = null;
	            range = selection.ranges[0] || range;
	            editor.removeSelectionMarker(range);
	        }
	        editor.once("mouseup", function() {
	            var tmpSel = selection.toOrientedRange();

	            if (oldRange && tmpSel.isEmpty() && isSamePoint(oldRange.cursor, tmpSel.cursor))
	                selection.substractPoint(tmpSel.cursor);
	            else {
	                if (shift) {
	                    selection.substractPoint(range.cursor);
	                } else if (range) {
	                    editor.removeSelectionMarker(range);
	                    selection.addRange(range);
	                }
	                selection.addRange(tmpSel);
	            }
	            editor.$blockScrolling--;
	            editor.inVirtualSelectionMode = false;
	        });

	    } else if (selectionMode == "block") {
	        e.stop();
	        editor.inVirtualSelectionMode = true;        
	        var initialRange;
	        var rectSel = [];
	        var blockSelect = function() {
	            var newCursor = editor.renderer.pixelToScreenCoordinates(mouseX, mouseY);
	            var cursor = session.screenToDocumentPosition(newCursor.row, newCursor.column);

	            if (isSamePoint(screenCursor, newCursor) && isSamePoint(cursor, selection.lead))
	                return;
	            screenCursor = newCursor;
	            
	            editor.$blockScrolling++;
	            editor.selection.moveToPosition(cursor);
	            editor.renderer.scrollCursorIntoView();

	            editor.removeSelectionMarkers(rectSel);
	            rectSel = selection.rectangularRangeBlock(screenCursor, screenAnchor);
	            if (editor.$mouseHandler.$clickSelection && rectSel.length == 1 && rectSel[0].isEmpty())
	                rectSel[0] = editor.$mouseHandler.$clickSelection.clone();
	            rectSel.forEach(editor.addSelectionMarker, editor);
	            editor.updateSelectionMarkers();
	            editor.$blockScrolling--;
	        };
	        editor.$blockScrolling++;
	        if (isMultiSelect && !accel) {
	            selection.toSingleRange();
	        } else if (!isMultiSelect && accel) {
	            initialRange = selection.toOrientedRange();
	            editor.addSelectionMarker(initialRange);
	        }
	        
	        if (shift)
	            screenAnchor = session.documentToScreenPosition(selection.lead);            
	        else
	            selection.moveToPosition(pos);
	        editor.$blockScrolling--;
	        
	        screenCursor = {row: -1, column: -1};

	        var onMouseSelectionEnd = function(e) {
	            clearInterval(timerId);
	            editor.removeSelectionMarkers(rectSel);
	            if (!rectSel.length)
	                rectSel = [selection.toOrientedRange()];
	            editor.$blockScrolling++;
	            if (initialRange) {
	                editor.removeSelectionMarker(initialRange);
	                selection.toSingleRange(initialRange);
	            }
	            for (var i = 0; i < rectSel.length; i++)
	                selection.addRange(rectSel[i]);
	            editor.inVirtualSelectionMode = false;
	            editor.$mouseHandler.$clickSelection = null;
	            editor.$blockScrolling--;
	        };

	        var onSelectionInterval = blockSelect;

	        event.capture(editor.container, onMouseSelection, onMouseSelectionEnd);
	        var timerId = setInterval(function() {onSelectionInterval();}, 20);

	        return e.preventDefault();
	    }
	}


	exports.onMouseDown = onMouseDown;

	});

	ace.define("ace/commands/multi_select_commands",["require","exports","module","ace/keyboard/hash_handler"], function(acequire, exports, module) {
	exports.defaultCommands = [{
	    name: "addCursorAbove",
	    exec: function(editor) { editor.selectMoreLines(-1); },
	    bindKey: {win: "Ctrl-Alt-Up", mac: "Ctrl-Alt-Up"},
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "addCursorBelow",
	    exec: function(editor) { editor.selectMoreLines(1); },
	    bindKey: {win: "Ctrl-Alt-Down", mac: "Ctrl-Alt-Down"},
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "addCursorAboveSkipCurrent",
	    exec: function(editor) { editor.selectMoreLines(-1, true); },
	    bindKey: {win: "Ctrl-Alt-Shift-Up", mac: "Ctrl-Alt-Shift-Up"},
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "addCursorBelowSkipCurrent",
	    exec: function(editor) { editor.selectMoreLines(1, true); },
	    bindKey: {win: "Ctrl-Alt-Shift-Down", mac: "Ctrl-Alt-Shift-Down"},
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "selectMoreBefore",
	    exec: function(editor) { editor.selectMore(-1); },
	    bindKey: {win: "Ctrl-Alt-Left", mac: "Ctrl-Alt-Left"},
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "selectMoreAfter",
	    exec: function(editor) { editor.selectMore(1); },
	    bindKey: {win: "Ctrl-Alt-Right", mac: "Ctrl-Alt-Right"},
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "selectNextBefore",
	    exec: function(editor) { editor.selectMore(-1, true); },
	    bindKey: {win: "Ctrl-Alt-Shift-Left", mac: "Ctrl-Alt-Shift-Left"},
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "selectNextAfter",
	    exec: function(editor) { editor.selectMore(1, true); },
	    bindKey: {win: "Ctrl-Alt-Shift-Right", mac: "Ctrl-Alt-Shift-Right"},
	    scrollIntoView: "cursor",
	    readOnly: true
	}, {
	    name: "splitIntoLines",
	    exec: function(editor) { editor.multiSelect.splitIntoLines(); },
	    bindKey: {win: "Ctrl-Alt-L", mac: "Ctrl-Alt-L"},
	    readOnly: true
	}, {
	    name: "alignCursors",
	    exec: function(editor) { editor.alignCursors(); },
	    bindKey: {win: "Ctrl-Alt-A", mac: "Ctrl-Alt-A"},
	    scrollIntoView: "cursor"
	}, {
	    name: "findAll",
	    exec: function(editor) { editor.findAll(); },
	    bindKey: {win: "Ctrl-Alt-K", mac: "Ctrl-Alt-G"},
	    scrollIntoView: "cursor",
	    readOnly: true
	}];
	exports.multiSelectCommands = [{
	    name: "singleSelection",
	    bindKey: "esc",
	    exec: function(editor) { editor.exitMultiSelectMode(); },
	    scrollIntoView: "cursor",
	    readOnly: true,
	    isAvailable: function(editor) {return editor && editor.inMultiSelectMode}
	}];

	var HashHandler = acequire("../keyboard/hash_handler").HashHandler;
	exports.keyboardHandler = new HashHandler(exports.multiSelectCommands);

	});

	ace.define("ace/multi_select",["require","exports","module","ace/range_list","ace/range","ace/selection","ace/mouse/multi_select_handler","ace/lib/event","ace/lib/lang","ace/commands/multi_select_commands","ace/search","ace/edit_session","ace/editor","ace/config"], function(acequire, exports, module) {

	var RangeList = acequire("./range_list").RangeList;
	var Range = acequire("./range").Range;
	var Selection = acequire("./selection").Selection;
	var onMouseDown = acequire("./mouse/multi_select_handler").onMouseDown;
	var event = acequire("./lib/event");
	var lang = acequire("./lib/lang");
	var commands = acequire("./commands/multi_select_commands");
	exports.commands = commands.defaultCommands.concat(commands.multiSelectCommands);
	var Search = acequire("./search").Search;
	var search = new Search();

	function find(session, needle, dir) {
	    search.$options.wrap = true;
	    search.$options.needle = needle;
	    search.$options.backwards = dir == -1;
	    return search.find(session);
	}
	var EditSession = acequire("./edit_session").EditSession;
	(function() {
	    this.getSelectionMarkers = function() {
	        return this.$selectionMarkers;
	    };
	}).call(EditSession.prototype);
	(function() {
	    this.ranges = null;
	    this.rangeList = null;
	    this.addRange = function(range, $blockChangeEvents) {
	        if (!range)
	            return;

	        if (!this.inMultiSelectMode && this.rangeCount === 0) {
	            var oldRange = this.toOrientedRange();
	            this.rangeList.add(oldRange);
	            this.rangeList.add(range);
	            if (this.rangeList.ranges.length != 2) {
	                this.rangeList.removeAll();
	                return $blockChangeEvents || this.fromOrientedRange(range);
	            }
	            this.rangeList.removeAll();
	            this.rangeList.add(oldRange);
	            this.$onAddRange(oldRange);
	        }

	        if (!range.cursor)
	            range.cursor = range.end;

	        var removed = this.rangeList.add(range);

	        this.$onAddRange(range);

	        if (removed.length)
	            this.$onRemoveRange(removed);

	        if (this.rangeCount > 1 && !this.inMultiSelectMode) {
	            this._signal("multiSelect");
	            this.inMultiSelectMode = true;
	            this.session.$undoSelect = false;
	            this.rangeList.attach(this.session);
	        }

	        return $blockChangeEvents || this.fromOrientedRange(range);
	    };

	    this.toSingleRange = function(range) {
	        range = range || this.ranges[0];
	        var removed = this.rangeList.removeAll();
	        if (removed.length)
	            this.$onRemoveRange(removed);

	        range && this.fromOrientedRange(range);
	    };
	    this.substractPoint = function(pos) {
	        var removed = this.rangeList.substractPoint(pos);
	        if (removed) {
	            this.$onRemoveRange(removed);
	            return removed[0];
	        }
	    };
	    this.mergeOverlappingRanges = function() {
	        var removed = this.rangeList.merge();
	        if (removed.length)
	            this.$onRemoveRange(removed);
	        else if(this.ranges[0])
	            this.fromOrientedRange(this.ranges[0]);
	    };

	    this.$onAddRange = function(range) {
	        this.rangeCount = this.rangeList.ranges.length;
	        this.ranges.unshift(range);
	        this._signal("addRange", {range: range});
	    };

	    this.$onRemoveRange = function(removed) {
	        this.rangeCount = this.rangeList.ranges.length;
	        if (this.rangeCount == 1 && this.inMultiSelectMode) {
	            var lastRange = this.rangeList.ranges.pop();
	            removed.push(lastRange);
	            this.rangeCount = 0;
	        }

	        for (var i = removed.length; i--; ) {
	            var index = this.ranges.indexOf(removed[i]);
	            this.ranges.splice(index, 1);
	        }

	        this._signal("removeRange", {ranges: removed});

	        if (this.rangeCount === 0 && this.inMultiSelectMode) {
	            this.inMultiSelectMode = false;
	            this._signal("singleSelect");
	            this.session.$undoSelect = true;
	            this.rangeList.detach(this.session);
	        }

	        lastRange = lastRange || this.ranges[0];
	        if (lastRange && !lastRange.isEqual(this.getRange()))
	            this.fromOrientedRange(lastRange);
	    };
	    this.$initRangeList = function() {
	        if (this.rangeList)
	            return;

	        this.rangeList = new RangeList();
	        this.ranges = [];
	        this.rangeCount = 0;
	    };
	    this.getAllRanges = function() {
	        return this.rangeCount ? this.rangeList.ranges.concat() : [this.getRange()];
	    };

	    this.splitIntoLines = function () {
	        if (this.rangeCount > 1) {
	            var ranges = this.rangeList.ranges;
	            var lastRange = ranges[ranges.length - 1];
	            var range = Range.fromPoints(ranges[0].start, lastRange.end);

	            this.toSingleRange();
	            this.setSelectionRange(range, lastRange.cursor == lastRange.start);
	        } else {
	            var range = this.getRange();
	            var isBackwards = this.isBackwards();
	            var startRow = range.start.row;
	            var endRow = range.end.row;
	            if (startRow == endRow) {
	                if (isBackwards)
	                    var start = range.end, end = range.start;
	                else
	                    var start = range.start, end = range.end;
	                
	                this.addRange(Range.fromPoints(end, end));
	                this.addRange(Range.fromPoints(start, start));
	                return;
	            }

	            var rectSel = [];
	            var r = this.getLineRange(startRow, true);
	            r.start.column = range.start.column;
	            rectSel.push(r);

	            for (var i = startRow + 1; i < endRow; i++)
	                rectSel.push(this.getLineRange(i, true));

	            r = this.getLineRange(endRow, true);
	            r.end.column = range.end.column;
	            rectSel.push(r);

	            rectSel.forEach(this.addRange, this);
	        }
	    };
	    this.toggleBlockSelection = function () {
	        if (this.rangeCount > 1) {
	            var ranges = this.rangeList.ranges;
	            var lastRange = ranges[ranges.length - 1];
	            var range = Range.fromPoints(ranges[0].start, lastRange.end);

	            this.toSingleRange();
	            this.setSelectionRange(range, lastRange.cursor == lastRange.start);
	        } else {
	            var cursor = this.session.documentToScreenPosition(this.selectionLead);
	            var anchor = this.session.documentToScreenPosition(this.selectionAnchor);

	            var rectSel = this.rectangularRangeBlock(cursor, anchor);
	            rectSel.forEach(this.addRange, this);
	        }
	    };
	    this.rectangularRangeBlock = function(screenCursor, screenAnchor, includeEmptyLines) {
	        var rectSel = [];

	        var xBackwards = screenCursor.column < screenAnchor.column;
	        if (xBackwards) {
	            var startColumn = screenCursor.column;
	            var endColumn = screenAnchor.column;
	        } else {
	            var startColumn = screenAnchor.column;
	            var endColumn = screenCursor.column;
	        }

	        var yBackwards = screenCursor.row < screenAnchor.row;
	        if (yBackwards) {
	            var startRow = screenCursor.row;
	            var endRow = screenAnchor.row;
	        } else {
	            var startRow = screenAnchor.row;
	            var endRow = screenCursor.row;
	        }

	        if (startColumn < 0)
	            startColumn = 0;
	        if (startRow < 0)
	            startRow = 0;

	        if (startRow == endRow)
	            includeEmptyLines = true;

	        for (var row = startRow; row <= endRow; row++) {
	            var range = Range.fromPoints(
	                this.session.screenToDocumentPosition(row, startColumn),
	                this.session.screenToDocumentPosition(row, endColumn)
	            );
	            if (range.isEmpty()) {
	                if (docEnd && isSamePoint(range.end, docEnd))
	                    break;
	                var docEnd = range.end;
	            }
	            range.cursor = xBackwards ? range.start : range.end;
	            rectSel.push(range);
	        }

	        if (yBackwards)
	            rectSel.reverse();

	        if (!includeEmptyLines) {
	            var end = rectSel.length - 1;
	            while (rectSel[end].isEmpty() && end > 0)
	                end--;
	            if (end > 0) {
	                var start = 0;
	                while (rectSel[start].isEmpty())
	                    start++;
	            }
	            for (var i = end; i >= start; i--) {
	                if (rectSel[i].isEmpty())
	                    rectSel.splice(i, 1);
	            }
	        }

	        return rectSel;
	    };
	}).call(Selection.prototype);
	var Editor = acequire("./editor").Editor;
	(function() {
	    this.updateSelectionMarkers = function() {
	        this.renderer.updateCursor();
	        this.renderer.updateBackMarkers();
	    };
	    this.addSelectionMarker = function(orientedRange) {
	        if (!orientedRange.cursor)
	            orientedRange.cursor = orientedRange.end;

	        var style = this.getSelectionStyle();
	        orientedRange.marker = this.session.addMarker(orientedRange, "ace_selection", style);

	        this.session.$selectionMarkers.push(orientedRange);
	        this.session.selectionMarkerCount = this.session.$selectionMarkers.length;
	        return orientedRange;
	    };
	    this.removeSelectionMarker = function(range) {
	        if (!range.marker)
	            return;
	        this.session.removeMarker(range.marker);
	        var index = this.session.$selectionMarkers.indexOf(range);
	        if (index != -1)
	            this.session.$selectionMarkers.splice(index, 1);
	        this.session.selectionMarkerCount = this.session.$selectionMarkers.length;
	    };

	    this.removeSelectionMarkers = function(ranges) {
	        var markerList = this.session.$selectionMarkers;
	        for (var i = ranges.length; i--; ) {
	            var range = ranges[i];
	            if (!range.marker)
	                continue;
	            this.session.removeMarker(range.marker);
	            var index = markerList.indexOf(range);
	            if (index != -1)
	                markerList.splice(index, 1);
	        }
	        this.session.selectionMarkerCount = markerList.length;
	    };

	    this.$onAddRange = function(e) {
	        this.addSelectionMarker(e.range);
	        this.renderer.updateCursor();
	        this.renderer.updateBackMarkers();
	    };

	    this.$onRemoveRange = function(e) {
	        this.removeSelectionMarkers(e.ranges);
	        this.renderer.updateCursor();
	        this.renderer.updateBackMarkers();
	    };

	    this.$onMultiSelect = function(e) {
	        if (this.inMultiSelectMode)
	            return;
	        this.inMultiSelectMode = true;

	        this.setStyle("ace_multiselect");
	        this.keyBinding.addKeyboardHandler(commands.keyboardHandler);
	        this.commands.setDefaultHandler("exec", this.$onMultiSelectExec);

	        this.renderer.updateCursor();
	        this.renderer.updateBackMarkers();
	    };

	    this.$onSingleSelect = function(e) {
	        if (this.session.multiSelect.inVirtualMode)
	            return;
	        this.inMultiSelectMode = false;

	        this.unsetStyle("ace_multiselect");
	        this.keyBinding.removeKeyboardHandler(commands.keyboardHandler);

	        this.commands.removeDefaultHandler("exec", this.$onMultiSelectExec);
	        this.renderer.updateCursor();
	        this.renderer.updateBackMarkers();
	        this._emit("changeSelection");
	    };

	    this.$onMultiSelectExec = function(e) {
	        var command = e.command;
	        var editor = e.editor;
	        if (!editor.multiSelect)
	            return;
	        if (!command.multiSelectAction) {
	            var result = command.exec(editor, e.args || {});
	            editor.multiSelect.addRange(editor.multiSelect.toOrientedRange());
	            editor.multiSelect.mergeOverlappingRanges();
	        } else if (command.multiSelectAction == "forEach") {
	            result = editor.forEachSelection(command, e.args);
	        } else if (command.multiSelectAction == "forEachLine") {
	            result = editor.forEachSelection(command, e.args, true);
	        } else if (command.multiSelectAction == "single") {
	            editor.exitMultiSelectMode();
	            result = command.exec(editor, e.args || {});
	        } else {
	            result = command.multiSelectAction(editor, e.args || {});
	        }
	        return result;
	    }; 
	    this.forEachSelection = function(cmd, args, options) {
	        if (this.inVirtualSelectionMode)
	            return;
	        var keepOrder = options && options.keepOrder;
	        var $byLines = options == true || options && options.$byLines
	        var session = this.session;
	        var selection = this.selection;
	        var rangeList = selection.rangeList;
	        var ranges = (keepOrder ? selection : rangeList).ranges;
	        var result;
	        
	        if (!ranges.length)
	            return cmd.exec ? cmd.exec(this, args || {}) : cmd(this, args || {});
	        
	        var reg = selection._eventRegistry;
	        selection._eventRegistry = {};

	        var tmpSel = new Selection(session);
	        this.inVirtualSelectionMode = true;
	        for (var i = ranges.length; i--;) {
	            if ($byLines) {
	                while (i > 0 && ranges[i].start.row == ranges[i - 1].end.row)
	                    i--;
	            }
	            tmpSel.fromOrientedRange(ranges[i]);
	            tmpSel.index = i;
	            this.selection = session.selection = tmpSel;
	            var cmdResult = cmd.exec ? cmd.exec(this, args || {}) : cmd(this, args || {});
	            if (!result && cmdResult !== undefined)
	                result = cmdResult;
	            tmpSel.toOrientedRange(ranges[i]);
	        }
	        tmpSel.detach();

	        this.selection = session.selection = selection;
	        this.inVirtualSelectionMode = false;
	        selection._eventRegistry = reg;
	        selection.mergeOverlappingRanges();
	        
	        var anim = this.renderer.$scrollAnimation;
	        this.onCursorChange();
	        this.onSelectionChange();
	        if (anim && anim.from == anim.to)
	            this.renderer.animateScrolling(anim.from);
	        
	        return result;
	    };
	    this.exitMultiSelectMode = function() {
	        if (!this.inMultiSelectMode || this.inVirtualSelectionMode)
	            return;
	        this.multiSelect.toSingleRange();
	    };

	    this.getSelectedText = function() {
	        var text = "";
	        if (this.inMultiSelectMode && !this.inVirtualSelectionMode) {
	            var ranges = this.multiSelect.rangeList.ranges;
	            var buf = [];
	            for (var i = 0; i < ranges.length; i++) {
	                buf.push(this.session.getTextRange(ranges[i]));
	            }
	            var nl = this.session.getDocument().getNewLineCharacter();
	            text = buf.join(nl);
	            if (text.length == (buf.length - 1) * nl.length)
	                text = "";
	        } else if (!this.selection.isEmpty()) {
	            text = this.session.getTextRange(this.getSelectionRange());
	        }
	        return text;
	    };
	    
	    this.$checkMultiselectChange = function(e, anchor) {
	        if (this.inMultiSelectMode && !this.inVirtualSelectionMode) {
	            var range = this.multiSelect.ranges[0];
	            if (this.multiSelect.isEmpty() && anchor == this.multiSelect.anchor)
	                return;
	            var pos = anchor == this.multiSelect.anchor
	                ? range.cursor == range.start ? range.end : range.start
	                : range.cursor;
	            if (pos.row != anchor.row 
	                || this.session.$clipPositionToDocument(pos.row, pos.column).column != anchor.column)
	                this.multiSelect.toSingleRange(this.multiSelect.toOrientedRange());
	        }
	    };
	    this.findAll = function(needle, options, additive) {
	        options = options || {};
	        options.needle = needle || options.needle;
	        if (options.needle == undefined) {
	            var range = this.selection.isEmpty()
	                ? this.selection.getWordRange()
	                : this.selection.getRange();
	            options.needle = this.session.getTextRange(range);
	        }    
	        this.$search.set(options);
	        
	        var ranges = this.$search.findAll(this.session);
	        if (!ranges.length)
	            return 0;

	        this.$blockScrolling += 1;
	        var selection = this.multiSelect;

	        if (!additive)
	            selection.toSingleRange(ranges[0]);

	        for (var i = ranges.length; i--; )
	            selection.addRange(ranges[i], true);
	        if (range && selection.rangeList.rangeAtPoint(range.start))
	            selection.addRange(range, true);
	        
	        this.$blockScrolling -= 1;

	        return ranges.length;
	    };
	    this.selectMoreLines = function(dir, skip) {
	        var range = this.selection.toOrientedRange();
	        var isBackwards = range.cursor == range.end;

	        var screenLead = this.session.documentToScreenPosition(range.cursor);
	        if (this.selection.$desiredColumn)
	            screenLead.column = this.selection.$desiredColumn;

	        var lead = this.session.screenToDocumentPosition(screenLead.row + dir, screenLead.column);

	        if (!range.isEmpty()) {
	            var screenAnchor = this.session.documentToScreenPosition(isBackwards ? range.end : range.start);
	            var anchor = this.session.screenToDocumentPosition(screenAnchor.row + dir, screenAnchor.column);
	        } else {
	            var anchor = lead;
	        }

	        if (isBackwards) {
	            var newRange = Range.fromPoints(lead, anchor);
	            newRange.cursor = newRange.start;
	        } else {
	            var newRange = Range.fromPoints(anchor, lead);
	            newRange.cursor = newRange.end;
	        }

	        newRange.desiredColumn = screenLead.column;
	        if (!this.selection.inMultiSelectMode) {
	            this.selection.addRange(range);
	        } else {
	            if (skip)
	                var toRemove = range.cursor;
	        }

	        this.selection.addRange(newRange);
	        if (toRemove)
	            this.selection.substractPoint(toRemove);
	    };
	    this.transposeSelections = function(dir) {
	        var session = this.session;
	        var sel = session.multiSelect;
	        var all = sel.ranges;

	        for (var i = all.length; i--; ) {
	            var range = all[i];
	            if (range.isEmpty()) {
	                var tmp = session.getWordRange(range.start.row, range.start.column);
	                range.start.row = tmp.start.row;
	                range.start.column = tmp.start.column;
	                range.end.row = tmp.end.row;
	                range.end.column = tmp.end.column;
	            }
	        }
	        sel.mergeOverlappingRanges();

	        var words = [];
	        for (var i = all.length; i--; ) {
	            var range = all[i];
	            words.unshift(session.getTextRange(range));
	        }

	        if (dir < 0)
	            words.unshift(words.pop());
	        else
	            words.push(words.shift());

	        for (var i = all.length; i--; ) {
	            var range = all[i];
	            var tmp = range.clone();
	            session.replace(range, words[i]);
	            range.start.row = tmp.start.row;
	            range.start.column = tmp.start.column;
	        }
	    };
	    this.selectMore = function(dir, skip, stopAtFirst) {
	        var session = this.session;
	        var sel = session.multiSelect;

	        var range = sel.toOrientedRange();
	        if (range.isEmpty()) {
	            range = session.getWordRange(range.start.row, range.start.column);
	            range.cursor = dir == -1 ? range.start : range.end;
	            this.multiSelect.addRange(range);
	            if (stopAtFirst)
	                return;
	        }
	        var needle = session.getTextRange(range);

	        var newRange = find(session, needle, dir);
	        if (newRange) {
	            newRange.cursor = dir == -1 ? newRange.start : newRange.end;
	            this.$blockScrolling += 1;
	            this.session.unfold(newRange);
	            this.multiSelect.addRange(newRange);
	            this.$blockScrolling -= 1;
	            this.renderer.scrollCursorIntoView(null, 0.5);
	        }
	        if (skip)
	            this.multiSelect.substractPoint(range.cursor);
	    };
	    this.alignCursors = function() {
	        var session = this.session;
	        var sel = session.multiSelect;
	        var ranges = sel.ranges;
	        var row = -1;
	        var sameRowRanges = ranges.filter(function(r) {
	            if (r.cursor.row == row)
	                return true;
	            row = r.cursor.row;
	        });
	        
	        if (!ranges.length || sameRowRanges.length == ranges.length - 1) {
	            var range = this.selection.getRange();
	            var fr = range.start.row, lr = range.end.row;
	            var guessRange = fr == lr;
	            if (guessRange) {
	                var max = this.session.getLength();
	                var line;
	                do {
	                    line = this.session.getLine(lr);
	                } while (/[=:]/.test(line) && ++lr < max);
	                do {
	                    line = this.session.getLine(fr);
	                } while (/[=:]/.test(line) && --fr > 0);
	                
	                if (fr < 0) fr = 0;
	                if (lr >= max) lr = max - 1;
	            }
	            var lines = this.session.removeFullLines(fr, lr);
	            lines = this.$reAlignText(lines, guessRange);
	            this.session.insert({row: fr, column: 0}, lines.join("\n") + "\n");
	            if (!guessRange) {
	                range.start.column = 0;
	                range.end.column = lines[lines.length - 1].length;
	            }
	            this.selection.setRange(range);
	        } else {
	            sameRowRanges.forEach(function(r) {
	                sel.substractPoint(r.cursor);
	            });

	            var maxCol = 0;
	            var minSpace = Infinity;
	            var spaceOffsets = ranges.map(function(r) {
	                var p = r.cursor;
	                var line = session.getLine(p.row);
	                var spaceOffset = line.substr(p.column).search(/\S/g);
	                if (spaceOffset == -1)
	                    spaceOffset = 0;

	                if (p.column > maxCol)
	                    maxCol = p.column;
	                if (spaceOffset < minSpace)
	                    minSpace = spaceOffset;
	                return spaceOffset;
	            });
	            ranges.forEach(function(r, i) {
	                var p = r.cursor;
	                var l = maxCol - p.column;
	                var d = spaceOffsets[i] - minSpace;
	                if (l > d)
	                    session.insert(p, lang.stringRepeat(" ", l - d));
	                else
	                    session.remove(new Range(p.row, p.column, p.row, p.column - l + d));

	                r.start.column = r.end.column = maxCol;
	                r.start.row = r.end.row = p.row;
	                r.cursor = r.end;
	            });
	            sel.fromOrientedRange(ranges[0]);
	            this.renderer.updateCursor();
	            this.renderer.updateBackMarkers();
	        }
	    };

	    this.$reAlignText = function(lines, forceLeft) {
	        var isLeftAligned = true, isRightAligned = true;
	        var startW, textW, endW;

	        return lines.map(function(line) {
	            var m = line.match(/(\s*)(.*?)(\s*)([=:].*)/);
	            if (!m)
	                return [line];

	            if (startW == null) {
	                startW = m[1].length;
	                textW = m[2].length;
	                endW = m[3].length;
	                return m;
	            }

	            if (startW + textW + endW != m[1].length + m[2].length + m[3].length)
	                isRightAligned = false;
	            if (startW != m[1].length)
	                isLeftAligned = false;

	            if (startW > m[1].length)
	                startW = m[1].length;
	            if (textW < m[2].length)
	                textW = m[2].length;
	            if (endW > m[3].length)
	                endW = m[3].length;

	            return m;
	        }).map(forceLeft ? alignLeft :
	            isLeftAligned ? isRightAligned ? alignRight : alignLeft : unAlign);

	        function spaces(n) {
	            return lang.stringRepeat(" ", n);
	        }

	        function alignLeft(m) {
	            return !m[2] ? m[0] : spaces(startW) + m[2]
	                + spaces(textW - m[2].length + endW)
	                + m[4].replace(/^([=:])\s+/, "$1 ");
	        }
	        function alignRight(m) {
	            return !m[2] ? m[0] : spaces(startW + textW - m[2].length) + m[2]
	                + spaces(endW, " ")
	                + m[4].replace(/^([=:])\s+/, "$1 ");
	        }
	        function unAlign(m) {
	            return !m[2] ? m[0] : spaces(startW) + m[2]
	                + spaces(endW)
	                + m[4].replace(/^([=:])\s+/, "$1 ");
	        }
	    };
	}).call(Editor.prototype);


	function isSamePoint(p1, p2) {
	    return p1.row == p2.row && p1.column == p2.column;
	}
	exports.onSessionChange = function(e) {
	    var session = e.session;
	    if (session && !session.multiSelect) {
	        session.$selectionMarkers = [];
	        session.selection.$initRangeList();
	        session.multiSelect = session.selection;
	    }
	    this.multiSelect = session && session.multiSelect;

	    var oldSession = e.oldSession;
	    if (oldSession) {
	        oldSession.multiSelect.off("addRange", this.$onAddRange);
	        oldSession.multiSelect.off("removeRange", this.$onRemoveRange);
	        oldSession.multiSelect.off("multiSelect", this.$onMultiSelect);
	        oldSession.multiSelect.off("singleSelect", this.$onSingleSelect);
	        oldSession.multiSelect.lead.off("change", this.$checkMultiselectChange);
	        oldSession.multiSelect.anchor.off("change", this.$checkMultiselectChange);
	    }

	    if (session) {
	        session.multiSelect.on("addRange", this.$onAddRange);
	        session.multiSelect.on("removeRange", this.$onRemoveRange);
	        session.multiSelect.on("multiSelect", this.$onMultiSelect);
	        session.multiSelect.on("singleSelect", this.$onSingleSelect);
	        session.multiSelect.lead.on("change", this.$checkMultiselectChange);
	        session.multiSelect.anchor.on("change", this.$checkMultiselectChange);
	    }

	    if (session && this.inMultiSelectMode != session.selection.inMultiSelectMode) {
	        if (session.selection.inMultiSelectMode)
	            this.$onMultiSelect();
	        else
	            this.$onSingleSelect();
	    }
	};
	function MultiSelect(editor) {
	    if (editor.$multiselectOnSessionChange)
	        return;
	    editor.$onAddRange = editor.$onAddRange.bind(editor);
	    editor.$onRemoveRange = editor.$onRemoveRange.bind(editor);
	    editor.$onMultiSelect = editor.$onMultiSelect.bind(editor);
	    editor.$onSingleSelect = editor.$onSingleSelect.bind(editor);
	    editor.$multiselectOnSessionChange = exports.onSessionChange.bind(editor);
	    editor.$checkMultiselectChange = editor.$checkMultiselectChange.bind(editor);

	    editor.$multiselectOnSessionChange(editor);
	    editor.on("changeSession", editor.$multiselectOnSessionChange);

	    editor.on("mousedown", onMouseDown);
	    editor.commands.addCommands(commands.defaultCommands);

	    addAltCursorListeners(editor);
	}

	function addAltCursorListeners(editor){
	    var el = editor.textInput.getElement();
	    var altCursor = false;
	    event.addListener(el, "keydown", function(e) {
	        var altDown = e.keyCode == 18 && !(e.ctrlKey || e.shiftKey || e.metaKey);
	        if (editor.$blockSelectEnabled && altDown) {
	            if (!altCursor) {
	                editor.renderer.setMouseCursor("crosshair");
	                altCursor = true;
	            }
	        } else if (altCursor) {
	            reset();
	        }
	    });

	    event.addListener(el, "keyup", reset);
	    event.addListener(el, "blur", reset);
	    function reset(e) {
	        if (altCursor) {
	            editor.renderer.setMouseCursor("");
	            altCursor = false;
	        }
	    }
	}

	exports.MultiSelect = MultiSelect;


	acequire("./config").defineOptions(Editor.prototype, "editor", {
	    enableMultiselect: {
	        set: function(val) {
	            MultiSelect(this);
	            if (val) {
	                this.on("changeSession", this.$multiselectOnSessionChange);
	                this.on("mousedown", onMouseDown);
	            } else {
	                this.off("changeSession", this.$multiselectOnSessionChange);
	                this.off("mousedown", onMouseDown);
	            }
	        },
	        value: true
	    },
	    enableBlockSelect: {
	        set: function(val) {
	            this.$blockSelectEnabled = val;
	        },
	        value: true
	    }
	});



	});

	ace.define("ace/mode/folding/fold_mode",["require","exports","module","ace/range"], function(acequire, exports, module) {
	"use strict";

	var Range = acequire("../../range").Range;

	var FoldMode = exports.FoldMode = function() {};

	(function() {

	    this.foldingStartMarker = null;
	    this.foldingStopMarker = null;
	    this.getFoldWidget = function(session, foldStyle, row) {
	        var line = session.getLine(row);
	        if (this.foldingStartMarker.test(line))
	            return "start";
	        if (foldStyle == "markbeginend"
	                && this.foldingStopMarker
	                && this.foldingStopMarker.test(line))
	            return "end";
	        return "";
	    };

	    this.getFoldWidgetRange = function(session, foldStyle, row) {
	        return null;
	    };

	    this.indentationBlock = function(session, row, column) {
	        var re = /\S/;
	        var line = session.getLine(row);
	        var startLevel = line.search(re);
	        if (startLevel == -1)
	            return;

	        var startColumn = column || line.length;
	        var maxRow = session.getLength();
	        var startRow = row;
	        var endRow = row;

	        while (++row < maxRow) {
	            var level = session.getLine(row).search(re);

	            if (level == -1)
	                continue;

	            if (level <= startLevel)
	                break;

	            endRow = row;
	        }

	        if (endRow > startRow) {
	            var endColumn = session.getLine(endRow).length;
	            return new Range(startRow, startColumn, endRow, endColumn);
	        }
	    };

	    this.openingBracketBlock = function(session, bracket, row, column, typeRe) {
	        var start = {row: row, column: column + 1};
	        var end = session.$findClosingBracket(bracket, start, typeRe);
	        if (!end)
	            return;

	        var fw = session.foldWidgets[end.row];
	        if (fw == null)
	            fw = session.getFoldWidget(end.row);

	        if (fw == "start" && end.row > start.row) {
	            end.row --;
	            end.column = session.getLine(end.row).length;
	        }
	        return Range.fromPoints(start, end);
	    };

	    this.closingBracketBlock = function(session, bracket, row, column, typeRe) {
	        var end = {row: row, column: column};
	        var start = session.$findOpeningBracket(bracket, end);

	        if (!start)
	            return;

	        start.column++;
	        end.column--;

	        return  Range.fromPoints(start, end);
	    };
	}).call(FoldMode.prototype);

	});

	ace.define("ace/theme/textmate",["require","exports","module","ace/lib/dom"], function(acequire, exports, module) {
	"use strict";

	exports.isDark = false;
	exports.cssClass = "ace-tm";
	exports.cssText = ".ace-tm .ace_gutter {\
	background: #f0f0f0;\
	color: #333;\
	}\
	.ace-tm .ace_print-margin {\
	width: 1px;\
	background: #e8e8e8;\
	}\
	.ace-tm .ace_fold {\
	background-color: #6B72E6;\
	}\
	.ace-tm {\
	background-color: #FFFFFF;\
	color: black;\
	}\
	.ace-tm .ace_cursor {\
	color: black;\
	}\
	.ace-tm .ace_invisible {\
	color: rgb(191, 191, 191);\
	}\
	.ace-tm .ace_storage,\
	.ace-tm .ace_keyword {\
	color: blue;\
	}\
	.ace-tm .ace_constant {\
	color: rgb(197, 6, 11);\
	}\
	.ace-tm .ace_constant.ace_buildin {\
	color: rgb(88, 72, 246);\
	}\
	.ace-tm .ace_constant.ace_language {\
	color: rgb(88, 92, 246);\
	}\
	.ace-tm .ace_constant.ace_library {\
	color: rgb(6, 150, 14);\
	}\
	.ace-tm .ace_invalid {\
	background-color: rgba(255, 0, 0, 0.1);\
	color: red;\
	}\
	.ace-tm .ace_support.ace_function {\
	color: rgb(60, 76, 114);\
	}\
	.ace-tm .ace_support.ace_constant {\
	color: rgb(6, 150, 14);\
	}\
	.ace-tm .ace_support.ace_type,\
	.ace-tm .ace_support.ace_class {\
	color: rgb(109, 121, 222);\
	}\
	.ace-tm .ace_keyword.ace_operator {\
	color: rgb(104, 118, 135);\
	}\
	.ace-tm .ace_string {\
	color: rgb(3, 106, 7);\
	}\
	.ace-tm .ace_comment {\
	color: rgb(76, 136, 107);\
	}\
	.ace-tm .ace_comment.ace_doc {\
	color: rgb(0, 102, 255);\
	}\
	.ace-tm .ace_comment.ace_doc.ace_tag {\
	color: rgb(128, 159, 191);\
	}\
	.ace-tm .ace_constant.ace_numeric {\
	color: rgb(0, 0, 205);\
	}\
	.ace-tm .ace_variable {\
	color: rgb(49, 132, 149);\
	}\
	.ace-tm .ace_xml-pe {\
	color: rgb(104, 104, 91);\
	}\
	.ace-tm .ace_entity.ace_name.ace_function {\
	color: #0000A2;\
	}\
	.ace-tm .ace_heading {\
	color: rgb(12, 7, 255);\
	}\
	.ace-tm .ace_list {\
	color:rgb(185, 6, 144);\
	}\
	.ace-tm .ace_meta.ace_tag {\
	color:rgb(0, 22, 142);\
	}\
	.ace-tm .ace_string.ace_regex {\
	color: rgb(255, 0, 0)\
	}\
	.ace-tm .ace_marker-layer .ace_selection {\
	background: rgb(181, 213, 255);\
	}\
	.ace-tm.ace_multiselect .ace_selection.ace_start {\
	box-shadow: 0 0 3px 0px white;\
	}\
	.ace-tm .ace_marker-layer .ace_step {\
	background: rgb(252, 255, 0);\
	}\
	.ace-tm .ace_marker-layer .ace_stack {\
	background: rgb(164, 229, 101);\
	}\
	.ace-tm .ace_marker-layer .ace_bracket {\
	margin: -1px 0 0 -1px;\
	border: 1px solid rgb(192, 192, 192);\
	}\
	.ace-tm .ace_marker-layer .ace_active-line {\
	background: rgba(0, 0, 0, 0.07);\
	}\
	.ace-tm .ace_gutter-active-line {\
	background-color : #dcdcdc;\
	}\
	.ace-tm .ace_marker-layer .ace_selected-word {\
	background: rgb(250, 250, 255);\
	border: 1px solid rgb(200, 200, 250);\
	}\
	.ace-tm .ace_indent-guide {\
	background: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAACCAYAAACZgbYnAAAAE0lEQVQImWP4////f4bLly//BwAmVgd1/w11/gAAAABJRU5ErkJggg==\") right repeat-y;\
	}\
	";

	var dom = acequire("../lib/dom");
	dom.importCssString(exports.cssText, exports.cssClass);
	});

	ace.define("ace/line_widgets",["require","exports","module","ace/lib/oop","ace/lib/dom","ace/range"], function(acequire, exports, module) {
	"use strict";

	var oop = acequire("./lib/oop");
	var dom = acequire("./lib/dom");
	var Range = acequire("./range").Range;


	function LineWidgets(session) {
	    this.session = session;
	    this.session.widgetManager = this;
	    this.session.getRowLength = this.getRowLength;
	    this.session.$getWidgetScreenLength = this.$getWidgetScreenLength;
	    this.updateOnChange = this.updateOnChange.bind(this);
	    this.renderWidgets = this.renderWidgets.bind(this);
	    this.measureWidgets = this.measureWidgets.bind(this);
	    this.session._changedWidgets = [];
	    this.$onChangeEditor = this.$onChangeEditor.bind(this);
	    
	    this.session.on("change", this.updateOnChange);
	    this.session.on("changeFold", this.updateOnFold);
	    this.session.on("changeEditor", this.$onChangeEditor);
	}

	(function() {
	    this.getRowLength = function(row) {
	        var h;
	        if (this.lineWidgets)
	            h = this.lineWidgets[row] && this.lineWidgets[row].rowCount || 0;
	        else 
	            h = 0;
	        if (!this.$useWrapMode || !this.$wrapData[row]) {
	            return 1 + h;
	        } else {
	            return this.$wrapData[row].length + 1 + h;
	        }
	    };

	    this.$getWidgetScreenLength = function() {
	        var screenRows = 0;
	        this.lineWidgets.forEach(function(w){
	            if (w && w.rowCount && !w.hidden)
	                screenRows += w.rowCount;
	        });
	        return screenRows;
	    };    
	    
	    this.$onChangeEditor = function(e) {
	        this.attach(e.editor);
	    };
	    
	    this.attach = function(editor) {
	        if (editor  && editor.widgetManager && editor.widgetManager != this)
	            editor.widgetManager.detach();

	        if (this.editor == editor)
	            return;

	        this.detach();
	        this.editor = editor;
	        
	        if (editor) {
	            editor.widgetManager = this;
	            editor.renderer.on("beforeRender", this.measureWidgets);
	            editor.renderer.on("afterRender", this.renderWidgets);
	        }
	    };
	    this.detach = function(e) {
	        var editor = this.editor;
	        if (!editor)
	            return;
	        
	        this.editor = null;
	        editor.widgetManager = null;
	        
	        editor.renderer.off("beforeRender", this.measureWidgets);
	        editor.renderer.off("afterRender", this.renderWidgets);
	        var lineWidgets = this.session.lineWidgets;
	        lineWidgets && lineWidgets.forEach(function(w) {
	            if (w && w.el && w.el.parentNode) {
	                w._inDocument = false;
	                w.el.parentNode.removeChild(w.el);
	            }
	        });
	    };

	    this.updateOnFold = function(e, session) {
	        var lineWidgets = session.lineWidgets;
	        if (!lineWidgets || !e.action)
	            return;
	        var fold = e.data;
	        var start = fold.start.row;
	        var end = fold.end.row;
	        var hide = e.action == "add";
	        for (var i = start + 1; i < end; i++) {
	            if (lineWidgets[i])
	                lineWidgets[i].hidden = hide;
	        }
	        if (lineWidgets[end]) {
	            if (hide) {
	                if (!lineWidgets[start])
	                    lineWidgets[start] = lineWidgets[end];
	                else
	                    lineWidgets[end].hidden = hide;
	            } else {
	                if (lineWidgets[start] == lineWidgets[end])
	                    lineWidgets[start] = undefined;
	                lineWidgets[end].hidden = hide;
	            }
	        }
	    };
	    
	    this.updateOnChange = function(delta) {
	        var lineWidgets = this.session.lineWidgets;
	        if (!lineWidgets) return;
	        
	        var startRow = delta.start.row;
	        var len = delta.end.row - startRow;

	        if (len === 0) {
	        } else if (delta.action == 'remove') {
	            var removed = lineWidgets.splice(startRow + 1, len);
	            removed.forEach(function(w) {
	                w && this.removeLineWidget(w);
	            }, this);
	            this.$updateRows();
	        } else {
	            var args = new Array(len);
	            args.unshift(startRow, 0);
	            lineWidgets.splice.apply(lineWidgets, args);
	            this.$updateRows();
	        }
	    };
	    
	    this.$updateRows = function() {
	        var lineWidgets = this.session.lineWidgets;
	        if (!lineWidgets) return;
	        var noWidgets = true;
	        lineWidgets.forEach(function(w, i) {
	            if (w) {
	                noWidgets = false;
	                w.row = i;
	                while (w.$oldWidget) {
	                    w.$oldWidget.row = i;
	                    w = w.$oldWidget;
	                }
	            }
	        });
	        if (noWidgets)
	            this.session.lineWidgets = null;
	    };

	    this.addLineWidget = function(w) {
	        if (!this.session.lineWidgets)
	            this.session.lineWidgets = new Array(this.session.getLength());
	        
	        var old = this.session.lineWidgets[w.row];
	        if (old) {
	            w.$oldWidget = old;
	            if (old.el && old.el.parentNode) {
	                old.el.parentNode.removeChild(old.el);
	                old._inDocument = false;
	            }
	        }
	            
	        this.session.lineWidgets[w.row] = w;
	        
	        w.session = this.session;
	        
	        var renderer = this.editor.renderer;
	        if (w.html && !w.el) {
	            w.el = dom.createElement("div");
	            w.el.innerHTML = w.html;
	        }
	        if (w.el) {
	            dom.addCssClass(w.el, "ace_lineWidgetContainer");
	            w.el.style.position = "absolute";
	            w.el.style.zIndex = 5;
	            renderer.container.appendChild(w.el);
	            w._inDocument = true;
	        }
	        
	        if (!w.coverGutter) {
	            w.el.style.zIndex = 3;
	        }
	        if (w.pixelHeight == null) {
	            w.pixelHeight = w.el.offsetHeight;
	        }
	        if (w.rowCount == null) {
	            w.rowCount = w.pixelHeight / renderer.layerConfig.lineHeight;
	        }
	        
	        var fold = this.session.getFoldAt(w.row, 0);
	        w.$fold = fold;
	        if (fold) {
	            var lineWidgets = this.session.lineWidgets;
	            if (w.row == fold.end.row && !lineWidgets[fold.start.row])
	                lineWidgets[fold.start.row] = w;
	            else
	                w.hidden = true;
	        }
	            
	        this.session._emit("changeFold", {data:{start:{row: w.row}}});
	        
	        this.$updateRows();
	        this.renderWidgets(null, renderer);
	        this.onWidgetChanged(w);
	        return w;
	    };
	    
	    this.removeLineWidget = function(w) {
	        w._inDocument = false;
	        w.session = null;
	        if (w.el && w.el.parentNode)
	            w.el.parentNode.removeChild(w.el);
	        if (w.editor && w.editor.destroy) try {
	            w.editor.destroy();
	        } catch(e){}
	        if (this.session.lineWidgets) {
	            var w1 = this.session.lineWidgets[w.row]
	            if (w1 == w) {
	                this.session.lineWidgets[w.row] = w.$oldWidget;
	                if (w.$oldWidget)
	                    this.onWidgetChanged(w.$oldWidget);
	            } else {
	                while (w1) {
	                    if (w1.$oldWidget == w) {
	                        w1.$oldWidget = w.$oldWidget;
	                        break;
	                    }
	                    w1 = w1.$oldWidget;
	                }
	            }
	        }
	        this.session._emit("changeFold", {data:{start:{row: w.row}}});
	        this.$updateRows();
	    };
	    
	    this.getWidgetsAtRow = function(row) {
	        var lineWidgets = this.session.lineWidgets;
	        var w = lineWidgets && lineWidgets[row];
	        var list = [];
	        while (w) {
	            list.push(w);
	            w = w.$oldWidget;
	        }
	        return list;
	    };
	    
	    this.onWidgetChanged = function(w) {
	        this.session._changedWidgets.push(w);
	        this.editor && this.editor.renderer.updateFull();
	    };
	    
	    this.measureWidgets = function(e, renderer) {
	        var changedWidgets = this.session._changedWidgets;
	        var config = renderer.layerConfig;
	        
	        if (!changedWidgets || !changedWidgets.length) return;
	        var min = Infinity;
	        for (var i = 0; i < changedWidgets.length; i++) {
	            var w = changedWidgets[i];
	            if (!w || !w.el) continue;
	            if (w.session != this.session) continue;
	            if (!w._inDocument) {
	                if (this.session.lineWidgets[w.row] != w)
	                    continue;
	                w._inDocument = true;
	                renderer.container.appendChild(w.el);
	            }
	            
	            w.h = w.el.offsetHeight;
	            
	            if (!w.fixedWidth) {
	                w.w = w.el.offsetWidth;
	                w.screenWidth = Math.ceil(w.w / config.characterWidth);
	            }
	            
	            var rowCount = w.h / config.lineHeight;
	            if (w.coverLine) {
	                rowCount -= this.session.getRowLineCount(w.row);
	                if (rowCount < 0)
	                    rowCount = 0;
	            }
	            if (w.rowCount != rowCount) {
	                w.rowCount = rowCount;
	                if (w.row < min)
	                    min = w.row;
	            }
	        }
	        if (min != Infinity) {
	            this.session._emit("changeFold", {data:{start:{row: min}}});
	            this.session.lineWidgetWidth = null;
	        }
	        this.session._changedWidgets = [];
	    };
	    
	    this.renderWidgets = function(e, renderer) {
	        var config = renderer.layerConfig;
	        var lineWidgets = this.session.lineWidgets;
	        if (!lineWidgets)
	            return;
	        var first = Math.min(this.firstRow, config.firstRow);
	        var last = Math.max(this.lastRow, config.lastRow, lineWidgets.length);
	        
	        while (first > 0 && !lineWidgets[first])
	            first--;
	        
	        this.firstRow = config.firstRow;
	        this.lastRow = config.lastRow;

	        renderer.$cursorLayer.config = config;
	        for (var i = first; i <= last; i++) {
	            var w = lineWidgets[i];
	            if (!w || !w.el) continue;
	            if (w.hidden) {
	                w.el.style.top = -100 - (w.pixelHeight || 0) + "px";
	                continue;
	            }
	            if (!w._inDocument) {
	                w._inDocument = true;
	                renderer.container.appendChild(w.el);
	            }
	            var top = renderer.$cursorLayer.getPixelPosition({row: i, column:0}, true).top;
	            if (!w.coverLine)
	                top += config.lineHeight * this.session.getRowLineCount(w.row);
	            w.el.style.top = top - config.offset + "px";
	            
	            var left = w.coverGutter ? 0 : renderer.gutterWidth;
	            if (!w.fixedWidth)
	                left -= renderer.scrollLeft;
	            w.el.style.left = left + "px";
	            
	            if (w.fullWidth && w.screenWidth) {
	                w.el.style.minWidth = config.width + 2 * config.padding + "px";
	            }
	            
	            if (w.fixedWidth) {
	                w.el.style.right = renderer.scrollBar.getWidth() + "px";
	            } else {
	                w.el.style.right = "";
	            }
	        }
	    };
	    
	}).call(LineWidgets.prototype);


	exports.LineWidgets = LineWidgets;

	});

	ace.define("ace/ext/error_marker",["require","exports","module","ace/line_widgets","ace/lib/dom","ace/range"], function(acequire, exports, module) {
	"use strict";
	var LineWidgets = acequire("../line_widgets").LineWidgets;
	var dom = acequire("../lib/dom");
	var Range = acequire("../range").Range;

	function binarySearch(array, needle, comparator) {
	    var first = 0;
	    var last = array.length - 1;

	    while (first <= last) {
	        var mid = (first + last) >> 1;
	        var c = comparator(needle, array[mid]);
	        if (c > 0)
	            first = mid + 1;
	        else if (c < 0)
	            last = mid - 1;
	        else
	            return mid;
	    }
	    return -(first + 1);
	}

	function findAnnotations(session, row, dir) {
	    var annotations = session.getAnnotations().sort(Range.comparePoints);
	    if (!annotations.length)
	        return;
	    
	    var i = binarySearch(annotations, {row: row, column: -1}, Range.comparePoints);
	    if (i < 0)
	        i = -i - 1;
	    
	    if (i >= annotations.length)
	        i = dir > 0 ? 0 : annotations.length - 1;
	    else if (i === 0 && dir < 0)
	        i = annotations.length - 1;
	    
	    var annotation = annotations[i];
	    if (!annotation || !dir)
	        return;

	    if (annotation.row === row) {
	        do {
	            annotation = annotations[i += dir];
	        } while (annotation && annotation.row === row);
	        if (!annotation)
	            return annotations.slice();
	    }
	    
	    
	    var matched = [];
	    row = annotation.row;
	    do {
	        matched[dir < 0 ? "unshift" : "push"](annotation);
	        annotation = annotations[i += dir];
	    } while (annotation && annotation.row == row);
	    return matched.length && matched;
	}

	exports.showErrorMarker = function(editor, dir) {
	    var session = editor.session;
	    if (!session.widgetManager) {
	        session.widgetManager = new LineWidgets(session);
	        session.widgetManager.attach(editor);
	    }
	    
	    var pos = editor.getCursorPosition();
	    var row = pos.row;
	    var oldWidget = session.widgetManager.getWidgetsAtRow(row).filter(function(w) {
	        return w.type == "errorMarker";
	    })[0];
	    if (oldWidget) {
	        oldWidget.destroy();
	    } else {
	        row -= dir;
	    }
	    var annotations = findAnnotations(session, row, dir);
	    var gutterAnno;
	    if (annotations) {
	        var annotation = annotations[0];
	        pos.column = (annotation.pos && typeof annotation.column != "number"
	            ? annotation.pos.sc
	            : annotation.column) || 0;
	        pos.row = annotation.row;
	        gutterAnno = editor.renderer.$gutterLayer.$annotations[pos.row];
	    } else if (oldWidget) {
	        return;
	    } else {
	        gutterAnno = {
	            text: ["Looks good!"],
	            className: "ace_ok"
	        };
	    }
	    editor.session.unfold(pos.row);
	    editor.selection.moveToPosition(pos);
	    
	    var w = {
	        row: pos.row, 
	        fixedWidth: true,
	        coverGutter: true,
	        el: dom.createElement("div"),
	        type: "errorMarker"
	    };
	    var el = w.el.appendChild(dom.createElement("div"));
	    var arrow = w.el.appendChild(dom.createElement("div"));
	    arrow.className = "error_widget_arrow " + gutterAnno.className;
	    
	    var left = editor.renderer.$cursorLayer
	        .getPixelPosition(pos).left;
	    arrow.style.left = left + editor.renderer.gutterWidth - 5 + "px";
	    
	    w.el.className = "error_widget_wrapper";
	    el.className = "error_widget " + gutterAnno.className;
	    el.innerHTML = gutterAnno.text.join("<br>");
	    
	    el.appendChild(dom.createElement("div"));
	    
	    var kb = function(_, hashId, keyString) {
	        if (hashId === 0 && (keyString === "esc" || keyString === "return")) {
	            w.destroy();
	            return {command: "null"};
	        }
	    };
	    
	    w.destroy = function() {
	        if (editor.$mouseHandler.isMousePressed)
	            return;
	        editor.keyBinding.removeKeyboardHandler(kb);
	        session.widgetManager.removeLineWidget(w);
	        editor.off("changeSelection", w.destroy);
	        editor.off("changeSession", w.destroy);
	        editor.off("mouseup", w.destroy);
	        editor.off("change", w.destroy);
	    };
	    
	    editor.keyBinding.addKeyboardHandler(kb);
	    editor.on("changeSelection", w.destroy);
	    editor.on("changeSession", w.destroy);
	    editor.on("mouseup", w.destroy);
	    editor.on("change", w.destroy);
	    
	    editor.session.widgetManager.addLineWidget(w);
	    
	    w.el.onmousedown = editor.focus.bind(editor);
	    
	    editor.renderer.scrollCursorIntoView(null, 0.5, {bottom: w.el.offsetHeight});
	};


	dom.importCssString("\
	    .error_widget_wrapper {\
	        background: inherit;\
	        color: inherit;\
	        border:none\
	    }\
	    .error_widget {\
	        border-top: solid 2px;\
	        border-bottom: solid 2px;\
	        margin: 5px 0;\
	        padding: 10px 40px;\
	        white-space: pre-wrap;\
	    }\
	    .error_widget.ace_error, .error_widget_arrow.ace_error{\
	        border-color: #ff5a5a\
	    }\
	    .error_widget.ace_warning, .error_widget_arrow.ace_warning{\
	        border-color: #F1D817\
	    }\
	    .error_widget.ace_info, .error_widget_arrow.ace_info{\
	        border-color: #5a5a5a\
	    }\
	    .error_widget.ace_ok, .error_widget_arrow.ace_ok{\
	        border-color: #5aaa5a\
	    }\
	    .error_widget_arrow {\
	        position: absolute;\
	        border: solid 5px;\
	        border-top-color: transparent!important;\
	        border-right-color: transparent!important;\
	        border-left-color: transparent!important;\
	        top: -5px;\
	    }\
	", "");

	});

	ace.define("ace/ace",["require","exports","module","ace/lib/fixoldbrowsers","ace/lib/dom","ace/lib/event","ace/editor","ace/edit_session","ace/undomanager","ace/virtual_renderer","ace/worker/worker_client","ace/keyboard/hash_handler","ace/placeholder","ace/multi_select","ace/mode/folding/fold_mode","ace/theme/textmate","ace/ext/error_marker","ace/config"], function(acequire, exports, module) {
	"use strict";

	acequire("./lib/fixoldbrowsers");

	var dom = acequire("./lib/dom");
	var event = acequire("./lib/event");

	var Editor = acequire("./editor").Editor;
	var EditSession = acequire("./edit_session").EditSession;
	var UndoManager = acequire("./undomanager").UndoManager;
	var Renderer = acequire("./virtual_renderer").VirtualRenderer;
	acequire("./worker/worker_client");
	acequire("./keyboard/hash_handler");
	acequire("./placeholder");
	acequire("./multi_select");
	acequire("./mode/folding/fold_mode");
	acequire("./theme/textmate");
	acequire("./ext/error_marker");

	exports.config = acequire("./config");
	exports.acequire = acequire;

	if (true)
	    exports.define = __webpack_require__(905);
	exports.edit = function(el) {
	    if (typeof el == "string") {
	        var _id = el;
	        el = document.getElementById(_id);
	        if (!el)
	            throw new Error("ace.edit can't find div #" + _id);
	    }

	    if (el && el.env && el.env.editor instanceof Editor)
	        return el.env.editor;

	    var value = "";
	    if (el && /input|textarea/i.test(el.tagName)) {
	        var oldNode = el;
	        value = oldNode.value;
	        el = dom.createElement("pre");
	        oldNode.parentNode.replaceChild(el, oldNode);
	    } else if (el) {
	        value = dom.getInnerText(el);
	        el.innerHTML = "";
	    }

	    var doc = exports.createEditSession(value);

	    var editor = new Editor(new Renderer(el));
	    editor.setSession(doc);

	    var env = {
	        document: doc,
	        editor: editor,
	        onResize: editor.resize.bind(editor, null)
	    };
	    if (oldNode) env.textarea = oldNode;
	    event.addListener(window, "resize", env.onResize);
	    editor.on("destroy", function() {
	        event.removeListener(window, "resize", env.onResize);
	        env.editor.container.env = null; // prevent memory leak on old ie
	    });
	    editor.container.env = editor.env = env;
	    return editor;
	};
	exports.createEditSession = function(text, mode) {
	    var doc = new EditSession(text, mode);
	    doc.setUndoManager(new UndoManager());
	    return doc;
	}
	exports.EditSession = EditSession;
	exports.UndoManager = UndoManager;
	exports.version = "1.2.6";
	});
	            (function() {
	                ace.acequire(["ace/ace"], function(a) {
	                    if (a) {
	                        a.config.init(true);
	                        a.define = ace.define;
	                    }
	                    if (!window.ace)
	                        window.ace = a;
	                    for (var key in a) if (a.hasOwnProperty(key))
	                        window.ace[key] = a[key];
	                });
	            })();
	        
	module.exports = window.ace.acequire("ace/ace");

/***/ },

/***/ 905:
/***/ function(module, exports) {

	module.exports = function() { throw new Error("define cannot be used indirect"); };


/***/ },

/***/ 906:
/***/ function(module, exports) {

	/* WEBPACK VAR INJECTION */(function(global) {module.exports = get_blob()

	function get_blob() {
	  if(global.Blob) {
	    try {
	      new Blob(['asdf'], {type: 'text/plain'})
	      return Blob
	    } catch(err) {}
	  }

	  var Builder = global.WebKitBlobBuilder ||
	                global.MozBlobBuilder ||
	                global.MSBlobBuilder

	  return function(parts, bag) {
	    var builder = new Builder
	      , endings = bag.endings
	      , type = bag.type

	    if(endings) for(var i = 0, len = parts.length; i < len; ++i) {
	      builder.append(parts[i], endings)
	    } else for(var i = 0, len = parts.length; i < len; ++i) {
	      builder.append(parts[i])
	    }

	    return type ? builder.getBlob(type) : builder.getBlob()
	  }
	}

	/* WEBPACK VAR INJECTION */}.call(exports, (function() { return this; }())))

/***/ },

/***/ 911:
/***/ function(module, exports, __webpack_require__) {

	// json5.js
	// Modern JSON. See README.md for details.
	//
	// This file is based directly off of Douglas Crockford's json_parse.js:
	// https://github.com/douglascrockford/JSON-js/blob/master/json_parse.js

	var JSON5 = ( true ? exports : {});

	JSON5.parse = (function () {
	    "use strict";

	// This is a function that can parse a JSON5 text, producing a JavaScript
	// data structure. It is a simple, recursive descent parser. It does not use
	// eval or regular expressions, so it can be used as a model for implementing
	// a JSON5 parser in other languages.

	// We are defining the function inside of another function to avoid creating
	// global variables.

	    var at,           // The index of the current character
	        lineNumber,   // The current line number
	        columnNumber, // The current column number
	        ch,           // The current character
	        escapee = {
	            "'":  "'",
	            '"':  '"',
	            '\\': '\\',
	            '/':  '/',
	            '\n': '',       // Replace escaped newlines in strings w/ empty string
	            b:    '\b',
	            f:    '\f',
	            n:    '\n',
	            r:    '\r',
	            t:    '\t'
	        },
	        ws = [
	            ' ',
	            '\t',
	            '\r',
	            '\n',
	            '\v',
	            '\f',
	            '\xA0',
	            '\uFEFF'
	        ],
	        text,

	        renderChar = function (chr) {
	            return chr === '' ? 'EOF' : "'" + chr + "'";
	        },

	        error = function (m) {

	// Call error when something is wrong.

	            var error = new SyntaxError();
	            // beginning of message suffix to agree with that provided by Gecko - see https://developer.mozilla.org/en/docs/Web/JavaScript/Reference/Global_Objects/JSON/parse
	            error.message = m + " at line " + lineNumber + " column " + columnNumber + " of the JSON5 data. Still to read: " + JSON.stringify(text.substring(at - 1, at + 19));
	            error.at = at;
	            // These two property names have been chosen to agree with the ones in Gecko, the only popular
	            // environment which seems to supply this info on JSON.parse
	            error.lineNumber = lineNumber;
	            error.columnNumber = columnNumber;
	            throw error;
	        },

	        next = function (c) {

	// If a c parameter is provided, verify that it matches the current character.

	            if (c && c !== ch) {
	                error("Expected " + renderChar(c) + " instead of " + renderChar(ch));
	            }

	// Get the next character. When there are no more characters,
	// return the empty string.

	            ch = text.charAt(at);
	            at++;
	            columnNumber++;
	            if (ch === '\n' || ch === '\r' && peek() !== '\n') {
	                lineNumber++;
	                columnNumber = 0;
	            }
	            return ch;
	        },

	        peek = function () {

	// Get the next character without consuming it or
	// assigning it to the ch varaible.

	            return text.charAt(at);
	        },

	        identifier = function () {

	// Parse an identifier. Normally, reserved words are disallowed here, but we
	// only use this for unquoted object keys, where reserved words are allowed,
	// so we don't check for those here. References:
	// - http://es5.github.com/#x7.6
	// - https://developer.mozilla.org/en/Core_JavaScript_1.5_Guide/Core_Language_Features#Variables
	// - http://docstore.mik.ua/orelly/webprog/jscript/ch02_07.htm
	// TODO Identifiers can have Unicode "letters" in them; add support for those.

	            var key = ch;

	            // Identifiers must start with a letter, _ or $.
	            if ((ch !== '_' && ch !== '$') &&
	                    (ch < 'a' || ch > 'z') &&
	                    (ch < 'A' || ch > 'Z')) {
	                error("Bad identifier as unquoted key");
	            }

	            // Subsequent characters can contain digits.
	            while (next() && (
	                    ch === '_' || ch === '$' ||
	                    (ch >= 'a' && ch <= 'z') ||
	                    (ch >= 'A' && ch <= 'Z') ||
	                    (ch >= '0' && ch <= '9'))) {
	                key += ch;
	            }

	            return key;
	        },

	        number = function () {

	// Parse a number value.

	            var number,
	                sign = '',
	                string = '',
	                base = 10;

	            if (ch === '-' || ch === '+') {
	                sign = ch;
	                next(ch);
	            }

	            // support for Infinity (could tweak to allow other words):
	            if (ch === 'I') {
	                number = word();
	                if (typeof number !== 'number' || isNaN(number)) {
	                    error('Unexpected word for number');
	                }
	                return (sign === '-') ? -number : number;
	            }

	            // support for NaN
	            if (ch === 'N' ) {
	              number = word();
	              if (!isNaN(number)) {
	                error('expected word to be NaN');
	              }
	              // ignore sign as -NaN also is NaN
	              return number;
	            }

	            if (ch === '0') {
	                string += ch;
	                next();
	                if (ch === 'x' || ch === 'X') {
	                    string += ch;
	                    next();
	                    base = 16;
	                } else if (ch >= '0' && ch <= '9') {
	                    error('Octal literal');
	                }
	            }

	            switch (base) {
	            case 10:
	                while (ch >= '0' && ch <= '9' ) {
	                    string += ch;
	                    next();
	                }
	                if (ch === '.') {
	                    string += '.';
	                    while (next() && ch >= '0' && ch <= '9') {
	                        string += ch;
	                    }
	                }
	                if (ch === 'e' || ch === 'E') {
	                    string += ch;
	                    next();
	                    if (ch === '-' || ch === '+') {
	                        string += ch;
	                        next();
	                    }
	                    while (ch >= '0' && ch <= '9') {
	                        string += ch;
	                        next();
	                    }
	                }
	                break;
	            case 16:
	                while (ch >= '0' && ch <= '9' || ch >= 'A' && ch <= 'F' || ch >= 'a' && ch <= 'f') {
	                    string += ch;
	                    next();
	                }
	                break;
	            }

	            if(sign === '-') {
	                number = -string;
	            } else {
	                number = +string;
	            }

	            if (!isFinite(number)) {
	                error("Bad number");
	            } else {
	                return number;
	            }
	        },

	        string = function () {

	// Parse a string value.

	            var hex,
	                i,
	                string = '',
	                delim,      // double quote or single quote
	                uffff;

	// When parsing for string values, we must look for ' or " and \ characters.

	            if (ch === '"' || ch === "'") {
	                delim = ch;
	                while (next()) {
	                    if (ch === delim) {
	                        next();
	                        return string;
	                    } else if (ch === '\\') {
	                        next();
	                        if (ch === 'u') {
	                            uffff = 0;
	                            for (i = 0; i < 4; i += 1) {
	                                hex = parseInt(next(), 16);
	                                if (!isFinite(hex)) {
	                                    break;
	                                }
	                                uffff = uffff * 16 + hex;
	                            }
	                            string += String.fromCharCode(uffff);
	                        } else if (ch === '\r') {
	                            if (peek() === '\n') {
	                                next();
	                            }
	                        } else if (typeof escapee[ch] === 'string') {
	                            string += escapee[ch];
	                        } else {
	                            break;
	                        }
	                    } else if (ch === '\n') {
	                        // unescaped newlines are invalid; see:
	                        // https://github.com/aseemk/json5/issues/24
	                        // TODO this feels special-cased; are there other
	                        // invalid unescaped chars?
	                        break;
	                    } else {
	                        string += ch;
	                    }
	                }
	            }
	            error("Bad string");
	        },

	        inlineComment = function () {

	// Skip an inline comment, assuming this is one. The current character should
	// be the second / character in the // pair that begins this inline comment.
	// To finish the inline comment, we look for a newline or the end of the text.

	            if (ch !== '/') {
	                error("Not an inline comment");
	            }

	            do {
	                next();
	                if (ch === '\n' || ch === '\r') {
	                    next();
	                    return;
	                }
	            } while (ch);
	        },

	        blockComment = function () {

	// Skip a block comment, assuming this is one. The current character should be
	// the * character in the /* pair that begins this block comment.
	// To finish the block comment, we look for an ending */ pair of characters,
	// but we also watch for the end of text before the comment is terminated.

	            if (ch !== '*') {
	                error("Not a block comment");
	            }

	            do {
	                next();
	                while (ch === '*') {
	                    next('*');
	                    if (ch === '/') {
	                        next('/');
	                        return;
	                    }
	                }
	            } while (ch);

	            error("Unterminated block comment");
	        },

	        comment = function () {

	// Skip a comment, whether inline or block-level, assuming this is one.
	// Comments always begin with a / character.

	            if (ch !== '/') {
	                error("Not a comment");
	            }

	            next('/');

	            if (ch === '/') {
	                inlineComment();
	            } else if (ch === '*') {
	                blockComment();
	            } else {
	                error("Unrecognized comment");
	            }
	        },

	        white = function () {

	// Skip whitespace and comments.
	// Note that we're detecting comments by only a single / character.
	// This works since regular expressions are not valid JSON(5), but this will
	// break if there are other valid values that begin with a / character!

	            while (ch) {
	                if (ch === '/') {
	                    comment();
	                } else if (ws.indexOf(ch) >= 0) {
	                    next();
	                } else {
	                    return;
	                }
	            }
	        },

	        word = function () {

	// true, false, or null.

	            switch (ch) {
	            case 't':
	                next('t');
	                next('r');
	                next('u');
	                next('e');
	                return true;
	            case 'f':
	                next('f');
	                next('a');
	                next('l');
	                next('s');
	                next('e');
	                return false;
	            case 'n':
	                next('n');
	                next('u');
	                next('l');
	                next('l');
	                return null;
	            case 'I':
	                next('I');
	                next('n');
	                next('f');
	                next('i');
	                next('n');
	                next('i');
	                next('t');
	                next('y');
	                return Infinity;
	            case 'N':
	              next( 'N' );
	              next( 'a' );
	              next( 'N' );
	              return NaN;
	            }
	            error("Unexpected " + renderChar(ch));
	        },

	        value,  // Place holder for the value function.

	        array = function () {

	// Parse an array value.

	            var array = [];

	            if (ch === '[') {
	                next('[');
	                white();
	                while (ch) {
	                    if (ch === ']') {
	                        next(']');
	                        return array;   // Potentially empty array
	                    }
	                    // ES5 allows omitting elements in arrays, e.g. [,] and
	                    // [,null]. We don't allow this in JSON5.
	                    if (ch === ',') {
	                        error("Missing array element");
	                    } else {
	                        array.push(value());
	                    }
	                    white();
	                    // If there's no comma after this value, this needs to
	                    // be the end of the array.
	                    if (ch !== ',') {
	                        next(']');
	                        return array;
	                    }
	                    next(',');
	                    white();
	                }
	            }
	            error("Bad array");
	        },

	        object = function () {

	// Parse an object value.

	            var key,
	                object = {};

	            if (ch === '{') {
	                next('{');
	                white();
	                while (ch) {
	                    if (ch === '}') {
	                        next('}');
	                        return object;   // Potentially empty object
	                    }

	                    // Keys can be unquoted. If they are, they need to be
	                    // valid JS identifiers.
	                    if (ch === '"' || ch === "'") {
	                        key = string();
	                    } else {
	                        key = identifier();
	                    }

	                    white();
	                    next(':');
	                    object[key] = value();
	                    white();
	                    // If there's no comma after this pair, this needs to be
	                    // the end of the object.
	                    if (ch !== ',') {
	                        next('}');
	                        return object;
	                    }
	                    next(',');
	                    white();
	                }
	            }
	            error("Bad object");
	        };

	    value = function () {

	// Parse a JSON value. It could be an object, an array, a string, a number,
	// or a word.

	        white();
	        switch (ch) {
	        case '{':
	            return object();
	        case '[':
	            return array();
	        case '"':
	        case "'":
	            return string();
	        case '-':
	        case '+':
	        case '.':
	            return number();
	        default:
	            return ch >= '0' && ch <= '9' ? number() : word();
	        }
	    };

	// Return the json_parse function. It will have access to all of the above
	// functions and variables.

	    return function (source, reviver) {
	        var result;

	        text = String(source);
	        at = 0;
	        lineNumber = 1;
	        columnNumber = 1;
	        ch = ' ';
	        result = value();
	        white();
	        if (ch) {
	            error("Syntax error");
	        }

	// If there is a reviver function, we recursively walk the new structure,
	// passing each name/value pair to the reviver function for possible
	// transformation, starting with a temporary root object that holds the result
	// in an empty key. If there is not a reviver function, we simply return the
	// result.

	        return typeof reviver === 'function' ? (function walk(holder, key) {
	            var k, v, value = holder[key];
	            if (value && typeof value === 'object') {
	                for (k in value) {
	                    if (Object.prototype.hasOwnProperty.call(value, k)) {
	                        v = walk(value, k);
	                        if (v !== undefined) {
	                            value[k] = v;
	                        } else {
	                            delete value[k];
	                        }
	                    }
	                }
	            }
	            return reviver.call(holder, key, value);
	        }({'': result}, '')) : result;
	    };
	}());

	// JSON5 stringify will not quote keys where appropriate
	JSON5.stringify = function (obj, replacer, space) {
	    if (replacer && (typeof(replacer) !== "function" && !isArray(replacer))) {
	        throw new Error('Replacer must be a function or an array');
	    }
	    var getReplacedValueOrUndefined = function(holder, key, isTopLevel) {
	        var value = holder[key];

	        // Replace the value with its toJSON value first, if possible
	        if (value && value.toJSON && typeof value.toJSON === "function") {
	            value = value.toJSON();
	        }

	        // If the user-supplied replacer if a function, call it. If it's an array, check objects' string keys for
	        // presence in the array (removing the key/value pair from the resulting JSON if the key is missing).
	        if (typeof(replacer) === "function") {
	            return replacer.call(holder, key, value);
	        } else if(replacer) {
	            if (isTopLevel || isArray(holder) || replacer.indexOf(key) >= 0) {
	                return value;
	            } else {
	                return undefined;
	            }
	        } else {
	            return value;
	        }
	    };

	    function isWordChar(c) {
	        return (c >= 'a' && c <= 'z') ||
	            (c >= 'A' && c <= 'Z') ||
	            (c >= '0' && c <= '9') ||
	            c === '_' || c === '$';
	    }

	    function isWordStart(c) {
	        return (c >= 'a' && c <= 'z') ||
	            (c >= 'A' && c <= 'Z') ||
	            c === '_' || c === '$';
	    }

	    function isWord(key) {
	        if (typeof key !== 'string') {
	            return false;
	        }
	        if (!isWordStart(key[0])) {
	            return false;
	        }
	        var i = 1, length = key.length;
	        while (i < length) {
	            if (!isWordChar(key[i])) {
	                return false;
	            }
	            i++;
	        }
	        return true;
	    }

	    // export for use in tests
	    JSON5.isWord = isWord;

	    // polyfills
	    function isArray(obj) {
	        if (Array.isArray) {
	            return Array.isArray(obj);
	        } else {
	            return Object.prototype.toString.call(obj) === '[object Array]';
	        }
	    }

	    function isDate(obj) {
	        return Object.prototype.toString.call(obj) === '[object Date]';
	    }

	    var objStack = [];
	    function checkForCircular(obj) {
	        for (var i = 0; i < objStack.length; i++) {
	            if (objStack[i] === obj) {
	                throw new TypeError("Converting circular structure to JSON");
	            }
	        }
	    }

	    function makeIndent(str, num, noNewLine) {
	        if (!str) {
	            return "";
	        }
	        // indentation no more than 10 chars
	        if (str.length > 10) {
	            str = str.substring(0, 10);
	        }

	        var indent = noNewLine ? "" : "\n";
	        for (var i = 0; i < num; i++) {
	            indent += str;
	        }

	        return indent;
	    }

	    var indentStr;
	    if (space) {
	        if (typeof space === "string") {
	            indentStr = space;
	        } else if (typeof space === "number" && space >= 0) {
	            indentStr = makeIndent(" ", space, true);
	        } else {
	            // ignore space parameter
	        }
	    }

	    // Copied from Crokford's implementation of JSON
	    // See https://github.com/douglascrockford/JSON-js/blob/e39db4b7e6249f04a195e7dd0840e610cc9e941e/json2.js#L195
	    // Begin
	    var cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
	        escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
	        meta = { // table of character substitutions
	        '\b': '\\b',
	        '\t': '\\t',
	        '\n': '\\n',
	        '\f': '\\f',
	        '\r': '\\r',
	        '"' : '\\"',
	        '\\': '\\\\'
	    };
	    function escapeString(string) {

	// If the string contains no control characters, no quote characters, and no
	// backslash characters, then we can safely slap some quotes around it.
	// Otherwise we must also replace the offending characters with safe escape
	// sequences.
	        escapable.lastIndex = 0;
	        return escapable.test(string) ? '"' + string.replace(escapable, function (a) {
	            var c = meta[a];
	            return typeof c === 'string' ?
	                c :
	                '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
	        }) + '"' : '"' + string + '"';
	    }
	    // End

	    function internalStringify(holder, key, isTopLevel) {
	        var buffer, res;

	        // Replace the value, if necessary
	        var obj_part = getReplacedValueOrUndefined(holder, key, isTopLevel);

	        if (obj_part && !isDate(obj_part)) {
	            // unbox objects
	            // don't unbox dates, since will turn it into number
	            obj_part = obj_part.valueOf();
	        }
	        switch(typeof obj_part) {
	            case "boolean":
	                return obj_part.toString();

	            case "number":
	                if (isNaN(obj_part) || !isFinite(obj_part)) {
	                    return "null";
	                }
	                return obj_part.toString();

	            case "string":
	                return escapeString(obj_part.toString());

	            case "object":
	                if (obj_part === null) {
	                    return "null";
	                } else if (isArray(obj_part)) {
	                    checkForCircular(obj_part);
	                    buffer = "[";
	                    objStack.push(obj_part);

	                    for (var i = 0; i < obj_part.length; i++) {
	                        res = internalStringify(obj_part, i, false);
	                        buffer += makeIndent(indentStr, objStack.length);
	                        if (res === null || typeof res === "undefined") {
	                            buffer += "null";
	                        } else {
	                            buffer += res;
	                        }
	                        if (i < obj_part.length-1) {
	                            buffer += ",";
	                        } else if (indentStr) {
	                            buffer += "\n";
	                        }
	                    }
	                    objStack.pop();
	                    if (obj_part.length) {
	                        buffer += makeIndent(indentStr, objStack.length, true)
	                    }
	                    buffer += "]";
	                } else {
	                    checkForCircular(obj_part);
	                    buffer = "{";
	                    var nonEmpty = false;
	                    objStack.push(obj_part);
	                    for (var prop in obj_part) {
	                        if (obj_part.hasOwnProperty(prop)) {
	                            var value = internalStringify(obj_part, prop, false);
	                            isTopLevel = false;
	                            if (typeof value !== "undefined" && value !== null) {
	                                buffer += makeIndent(indentStr, objStack.length);
	                                nonEmpty = true;
	                                key = isWord(prop) ? prop : escapeString(prop);
	                                buffer += key + ":" + (indentStr ? ' ' : '') + value + ",";
	                            }
	                        }
	                    }
	                    objStack.pop();
	                    if (nonEmpty) {
	                        buffer = buffer.substring(0, buffer.length-1) + makeIndent(indentStr, objStack.length) + "}";
	                    } else {
	                        buffer = '{}';
	                    }
	                }
	                return buffer;
	            default:
	                // functions and undefined should be ignored
	                return undefined;
	        }
	    }

	    // special case...when undefined is used inside of
	    // a compound object/array, return null.
	    // but when top-level, return undefined
	    var topLevelHolder = {"":obj};
	    if (obj === undefined) {
	        return getReplacedValueOrUndefined(topLevelHolder, '', true);
	    }
	    return internalStringify(topLevelHolder, '', true);
	};


/***/ }

});